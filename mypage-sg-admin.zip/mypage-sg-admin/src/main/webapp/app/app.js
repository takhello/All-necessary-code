angular.module('adminManageApp', ['ui.router', 'ngResource', 'ui.bootstrap']);

angular.module('adminManageApp').config(configure);
configure.$injector = ['$urlRouterProvider', '$stateProvider','$locationProvider','$qProvider'];

function configure($urlRouterProvider, $stateProvider,$locationProvider,$qProvider) {
	$urlRouterProvider.otherwise(''); //defult state --> site
	$locationProvider.hashPrefix(''); //solve url contain "!" 
	$qProvider.errorOnUnhandledRejections(false); 

	$stateProvider
		.state("home", {
			url: "",
			views: {
				"main-header@": {
					templateUrl: "app/layout/main-header.html",
					controller:"MainHeaderController",
					controllerAs:"vm"
				},
				"side-bar@": {
					templateUrl: "app/layout/side-bar.html",
					controller:"SidebarController",
					controllerAs:"vm"
				},
				"footer-bar@": {
					templateUrl: "app/layout/footer-bar.html"
				}
			}
		})
		.state("home.permission", { //home state --> 
			url: "/permission",
			views: {
				"content-panel@": {
					templateUrl: "app/permission/permission-list.html",
					controller: "PermissionController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.role", {
			url: "/role",
			views: {
				"content-panel@": {
					templateUrl: "app/role/role-list.html",
					controller: "RoleController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.role.role-permission", {
			url: "/:id/permission",
			views: {
				"content-panel@": {
					templateUrl: "app/role_permission/role-permission-list.html",
					controller:"RolePermissionController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.group", {
			url: "/group",
			views: {
				"content-panel@": {
					templateUrl: "app/group/group-list.html",
					controller: "GroupController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.group.group-role",{
			url:"/:id/role",
			views:{
				"content-panel@":{
					templateUrl:"app/group_role/group-role-list.html",
					controller:"GroupRoleController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.admin",{
			url:"/admin",
			views:{
				"content-panel@":{
					templateUrl:"app/admin/admin-list.html",
					controller:"AdminController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.admin.admin-group",{
			url:"/:id/group",
			views:{
				"content-panel@":{
					templateUrl:"app/admin_group/admin-group-list.html",
					controller:"AdminGroupController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.version",{
			url:"/version",
			views:{
				"content-panel@":{
					templateUrl:"app/version/version-list.html",
					controller:"VersionController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.403",{
			url:"/403",
			views:{
				"content-panel@":{
					templateUrl:"403.html"
				}
			}
		});
}

$(document).ajaxStart(function() { Pace.restart(); });