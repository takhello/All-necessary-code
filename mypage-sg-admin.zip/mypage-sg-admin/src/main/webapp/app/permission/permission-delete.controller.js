(function() {
	"use strict";
	//delete modal inner--> controller
	angular.module("adminManageApp").controller('PermissionDeleteController', PermissionDeleteController);
	PermissionDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'PermissionService', 'permissionId', "permissionData"];

	function PermissionDeleteController($scope, $modal, $modalInstance, PermissionService, permissionId, permissionData) {
		var vm = this;
		vm.deletePermissionCancel = deletePermissionCancel;
		vm.deletePermissionConfirm = deletePermissionConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;

		function deletePermissionCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deletePermissionConfirm() {
			PermissionService.deletePermission(permissionId,vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

	}



})();