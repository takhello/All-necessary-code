(function() {
	"use strict";
	angular.module("adminManageApp").controller("AdminEditController", AdminEditController);
	AdminEditController.$injector = ['$scope', '$modalInstance', 'adminData', 'adminId', 'AdminService'];

	function AdminEditController($scope, $modalInstance, adminData, adminId, AdminService) {
		var vm = this;
		vm.isAlertHide = true;
		vm.editAdminCancel = editAdminCancel;
		vm.editAdminConfirm = editAdminConfirm;
		vm.adminVal = angular.copy(adminData);
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		
		function closeError(){
			vm.isAlertHide = true;
		}

		function editAdminCancel() {
			$modalInstance.dismiss('cancel');
		}

		function editAdminConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.adminVal
			};
			AdminService.editAdmin(adminId, obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result){
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error){
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();