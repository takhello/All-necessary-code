package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.GroupRoleGRDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class GroupRoleGRDAOImpl extends JPABaseRepImpl<GroupRoleGR> implements GroupRoleGRDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<GroupRoleGR> getGroupRoleGRsList(Group group, Role role) {
        String groupId = group.getGroupId();
        String roleId = role.getRoleId();
        StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.GroupRoleGR");
        sql.append(" (groupRole.groupRoleId, groupRole.isDefault, group.groupId, group.groupName,"
                + " group.groupDesc, group.groupStatus,");
        sql.append(" role.roleId, role.roleName, role.roleDesc, role.roleStatus)");
        sql.append(
                " from Role role, Group group, GroupRole groupRole where group.groupId=GroupRole.groupId and GroupRole.roleId=role.roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(roleId) && roleId != null) {
            sql.append(" and role.roleId =:roleId");
            parameters.put("roleId", roleId);
        }
        if (!"".equals(groupId) && groupId != null) {
            sql.append(" and group.groupId =:groupId");
            parameters.put("groupId", groupId);
        }
        String groupStatus = group.getGroupStatus();
        if (!"".equals(groupStatus) && groupStatus != null) {
            sql.append(" and group.groupStatus =:groupStatus");
            parameters.put("groupStatus", groupStatus);
        }
        String isDefault = group.getIsDefault();
        if (!"".equals(isDefault) && isDefault != null) {
            sql.append(" and group.isDefault =:isDefault");
            parameters.put("isDefault", isDefault);
        }
        String groupName = group.getGroupName();
        if (!"".equals(groupName) && groupName != null) {
            sql.append(" and lower(group.groupName) like:groupName");
            parameters.put("groupName", "%" + groupName.toLowerCase() + "%");
        }
        String roleName = role.getRoleName();
        if (!"".equals(roleName) && roleName != null) {
            sql.append(" and lower(role.roleName) like:roleName");
            parameters.put("roleName", "%" + roleName.toLowerCase() + "%");
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<GroupRoleGR> list = super.query(sqlParameters);
        return list;
    }
}
