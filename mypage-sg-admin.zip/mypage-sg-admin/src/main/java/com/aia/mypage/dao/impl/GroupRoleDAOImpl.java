package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.GroupRoleDAO;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class GroupRoleDAOImpl extends JPABaseRepImpl<GroupRole> implements GroupRoleDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<GroupRole> getGroupRoleListByRoleId(String roleId) {
        StringBuffer sql = new StringBuffer("from GroupRole where roleId = :roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("roleId", roleId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    public boolean deleteGroupRoleById(int groupRoleId) {
        super.remove(groupRoleId);
        return true;
    }

    public List<GroupRole> getGroupRoleListByGroupId(String groupId) {
        StringBuffer sql = new StringBuffer("from GroupRole where groupId = :groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    public GroupRole addGroupRole(GroupRole groupRole) {
        groupRole = super.create(groupRole);
        return groupRole;
    }

    public GroupRole hasSameGroupRole(String groupId, String roleId) {
        StringBuffer sql = new StringBuffer("from GroupRole where groupId = :groupId and roleId =:roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        parameters.put("roleId", roleId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    @Override
    public List<GroupRole> getGroupRoleList() {

        return queryByNoParamters("from GroupRole");
    }

    @Override
    public GroupRole getGroupRoleListById(Integer groupRoleId) {

        return super.find(groupRoleId);
    }

}
