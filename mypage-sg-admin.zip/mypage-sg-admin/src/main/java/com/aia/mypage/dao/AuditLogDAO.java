package com.aia.mypage.dao;

import com.aia.mypage.entity.AuditLog;

public interface AuditLogDAO {

    void addAuditLog(AuditLog auditLog);

}
