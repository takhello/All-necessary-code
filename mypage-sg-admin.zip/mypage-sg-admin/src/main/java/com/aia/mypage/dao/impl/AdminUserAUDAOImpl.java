package com.aia.mypage.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserAUDAOImpl extends JPABaseRepImpl<AdminUser> implements AdminUserAUDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AdminUser addAdminUser(AdminUser adminUser) {

        return super.create(adminUser);
    }

    @Override
    public int updateAdmin(AdminUser adminUser) {

        StringBuffer sql = new StringBuffer(
                "update AdminUser set isEnabled= :isEnabled ,updateTime =:updateTime where userId= :userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("isEnabled", adminUser.getIsEnabled());
        parameters.put("userId", adminUser.getUserId());
        parameters.put("updateTime", new Date());
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return newUpdate(sqlParameters);
    }

    @Override
    public boolean deleteAdminByUserId(Integer userId) {
        super.remove(userId);
        return true;
    }

    @Override
    public AdminUser getAdminUserByUserId(Integer userId) {

        return super.find(userId);
    }

}
