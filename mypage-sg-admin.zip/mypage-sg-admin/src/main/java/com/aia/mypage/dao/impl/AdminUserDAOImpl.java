package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserDAO;
import com.aia.mypage.entity.AdminUserInfoVO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserDAOImpl extends JPABaseRepImpl<AdminUserInfoVO> implements AdminUserDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AdminUserInfoVO getAdminUserInfoByAccountName(String accountName) {

        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.AdminUserInfoVO"
                + "(account.password, account.userId, admin.isEnabled)");
        sql.append(
                " from Account account, AdminUser admin where account.userId=admin.userId and lower(account.accountName)=:accountName ");

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("accountName", accountName.toLowerCase());
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);

    }
}
