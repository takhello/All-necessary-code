package com.aia.mypage.entity;

import java.io.Serializable;

import javax.persistence.Column;

public class AdminUserGroupInfo implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 6561637192504467495L;

    /** user_group_id. */
    private Integer userGroupId;

    /** is_default. */
    @Column(name = "is_default")
    private String isDefault;

    /** group_id. */
    private String groupId;

    /** group_name. */
    private String groupName;

    /** group_desc. */
    private String groupDesc;

    /** group_status. */
    private String groupStatus;

    /** user_id. */
    private int userId;

    /** is_enabled. */
    private String isEnabled;

    public AdminUserGroupInfo(Integer userGroupId, String isDefault, String groupId, String groupName, String groupDesc,
            String groupStatus, int userId, String isEnabled) {
        super();
        this.userGroupId = userGroupId;
        this.isDefault = isDefault;
        this.groupId = groupId;
        this.groupName = groupName;
        this.groupDesc = groupDesc;
        this.groupStatus = groupStatus;
        this.userId = userId;
        this.isEnabled = isEnabled;
    }

    public Integer getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(Integer userGroupId) {
        this.userGroupId = userGroupId;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public String getGroupStatus() {
        return groupStatus;
    }

    public void setGroupStatus(String groupStatus) {
        this.groupStatus = groupStatus;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

}
