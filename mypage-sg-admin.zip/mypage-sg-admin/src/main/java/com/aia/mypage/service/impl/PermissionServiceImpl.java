package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.PermissionDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.util.BaseUtil;

public class PermissionServiceImpl implements PermissionService {

    @Autowired
    @Qualifier("permissionDAOImpl")
    private PermissionDAO permissionDAO;

    public List<Permission> getPermissionsList(Permission permission) {
        List<Permission> permissionList = permissionDAO.getPermissionsList(permission);
        return permissionList;
    }

    public Permission updatePermissionById(Permission permission) {
        Permission newPermission = permissionDAO.getPermissionById(permission.getPermissionId());
        if (newPermission == null) {
            return null;
        }
        permission.setUpdateTime(new Date());
        permission.setCreateTime(newPermission.getCreateTime());
        permission.setIsDefault(newPermission.getIsDefault());
        permission = permissionDAO.updatePermissionById(permission);
        return permission;
    }

    public boolean deletePermissionById(String permissionId) {
        boolean result = permissionDAO.deletePermissionById(permissionId);
        return result;
    }

    public Permission addPermission(Permission permission) {
        permission.setCreateTime(new Date());
        permission.setIsDefault(BaseUtil.IS_DEFAULT_N);
        permission = permissionDAO.addPermission(permission);
        return permission;
    }

    public Permission getPermissionById(String permissionId) {

        return permissionDAO.getPermissionById(permissionId);
    }

}
