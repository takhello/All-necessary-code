package com.aia.mypage.service;

import com.aia.mypage.entity.Account;

public interface AccountService {

    Account getAccountByAccountName(String accountName);

}
