package com.aia.mypage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.User;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class UserDAOImpl extends JPABaseRepImpl<User> implements UserDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<User> getList() {
        return super.queryByNoParamters("from User");
    }

    public User getUserById(int userId) {
        return super.find(userId);
    }

}
