package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class RoleController extends BaseController {

    @Autowired
    @Qualifier("roleServiceImpl")
    private RoleService roleService;

    @Autowired
    @Qualifier("rolePermissionServiceImpl")
    private RolePermissionService rolePermissionService;

    @Autowired
    @Qualifier("groupRoleServiceImpl")
    private GroupRoleService groupRoleService;

    /**
     * retrieving role list.
     * 
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unused")
    @ResponseBody
    @RequestMapping(value = "/roles", method = RequestMethod.GET)
    public Map<String, Object> getRolesList(HttpServletRequest request, HttpServletResponse response) {

        String userId = request.getParameter("userId");
        String sessionId = request.getParameter("sessionId");
        String country = request.getParameter("country");
        String language = request.getParameter("language");
        String roleId = request.getParameter("roleId");
        String roleName = request.getParameter("roleName");
        String roleStatus = request.getParameter("roleStatus");

        Role role = new Role();
        role.setRoleId(roleId);
        role.setRoleName(roleName);
        role.setRoleStatus(roleStatus);

        List<Role> rolesList = roleService.getRolesList(role);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("roleList", rolesList);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * creating role.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/role", method = RequestMethod.POST)
    public Map<String, Object> addRole(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyRole(data);
        Object object = verifyMap.get("role");
        if (object == null) {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

        Role role = (Role) verifyMap.get("role");
        role = roleService.addRole(role);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * deleting role.
     * 
     * @param role_id
     * @param request
     * @param response
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/role/{role_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteRole(@PathVariable String role_id, HttpServletRequest request,
            HttpServletResponse response) {

        Role role = roleService.getRoleById(role_id);
        if (role == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ROLE_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(role.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("role"));
        }

        List<RolePermission> rolePermissionList = rolePermissionService.getRolePermissionListByRoleId(role_id);
        if (rolePermissionList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ROLE_PERMISSION_MAPPING);
        }

        List<GroupRole> groupRoleList = groupRoleService.getGroupRoleListByRoleId(role_id);
        if (groupRoleList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_ROLE_MAPPING);
        }

        roleService.deleteRoleById(role_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

    /**
     * updating role.
     * 
     * @param role_id
     * @param jsonMap
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/role/{role_id}", method = RequestMethod.PUT)
    public Map<String, Object> updateRole(@PathVariable String role_id, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyRole(data);
        Object object = verifyMap.get("role");
        if (object == null) {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

        // role is default.
        Role role = roleService.getRoleById(role_id);
        if (role == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ROLE_UNREGISTERED);
        }
        if (BaseUtil.IS_DEFAULT_Y.equals(role.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("role"));
        }

        role = (Role) verifyMap.get("role");
        role.setRoleId(role_id);
        Role result = roleService.updateRole(role);
        if (result == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ROLE_UNREGISTERED);
        }
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    public Map<String, Object> verifyRole(Map<String, Object> data) {
        Map<String, Object> errorjson = new LinkedHashMap<String, Object>();
        String roleName = (String) data.get("roleName");
        if ("".equals(roleName) || roleName == null) {
            errorjson.put("errorKey", "roleName");
            return errorjson;
        }
        String roleDesc = (String) data.get("roleDesc");
        if ("".equals(roleDesc) || roleDesc == null) {
            errorjson.put("errorKey", "roleDesc");
            return errorjson;
        }
        String roleStatus = (String) data.get("roleStatus");
        if ("".equals(roleStatus) || roleStatus == null) {
            errorjson.put("errorKey", "roleStatus");
            return errorjson;
        }
        Role role = new Role();
        role.setRoleName(roleName);
        role.setRoleDesc(roleDesc);
        role.setRoleStatus(roleStatus);
        errorjson.put("role", role);
        return errorjson;
    }
}
