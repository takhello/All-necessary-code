package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AccountUserDAO;
import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.dao.AdminUserInfoDAO;
import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.entity.User;
import com.aia.mypage.service.AdminUserService;
import com.aia.mypage.util.BaseUtil;

public class AdminUserServiceImpl implements AdminUserService {

    @Autowired
    @Qualifier("adminUserInfoDAOImpl")
    private AdminUserInfoDAO adminUserInfoDAO;

    @Autowired
    @Qualifier("accountUserDAOImpl")
    private AccountUserDAO accountUserDAO;

    @Autowired
    @Qualifier("adminUserAUDAOImpl")
    private AdminUserAUDAO adminUserAUDAO;

    @Autowired
    @Qualifier("userDAOImpl")
    private UserDAO userDAO;

    @Override
    public List<AdminUserInfo> getAdminUserListByAccountName(AdminUserInfo adminUserInfo) {

        return adminUserInfoDAO.getAdminUserListByAccountName(adminUserInfo);
    }

    @Override
    public AccountUserInfo getAccountUserByAccountName(String accountName) {

        return accountUserDAO.getAccountUserByAccountName(accountName);
    }

    @Override
    public AdminUser addAdminUser(int userId) {

        User user = userDAO.getUserById(userId);
        if (user == null) {
            return null;
        }
        AdminUser adminUser = new AdminUser();
        adminUser.setUserId(userId);
        adminUser.setIsEnabled(BaseUtil.IS_ENABLED_Y);
        adminUser.setCreateTime(new Date());
        adminUser.setIsDefault(BaseUtil.IS_DEFAULT_N);
        adminUser = adminUserAUDAO.addAdminUser(adminUser);
        return adminUser;
    }

    public boolean updateAdmin(AdminUser adminUser) {

        int result = adminUserAUDAO.updateAdmin(adminUser);
        return result == 1;
    }

    @Override
    public boolean deleteAdminByUserId(Integer userId) {

        return adminUserAUDAO.deleteAdminByUserId(userId);
    }

    @Override
    public AdminUserInfo getAdminProfile(String accountName) {

        return adminUserInfoDAO.getAdminProfile(accountName);
    }

    @Override
    public AdminUser getAdminUserByUserId(Integer userId) {

        return adminUserAUDAO.getAdminUserByUserId(userId);
    }
}
