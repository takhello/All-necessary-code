package com.aia.mypage.entity;

import java.io.Serializable;

public class UserRole implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 5156096352466172755L;

    public UserRole(int userId, String groupId, String roleId, String roleName) {
        super();
        this.userId = userId;
        this.groupId = groupId;
        this.roleId = roleId;
        this.roleName = roleName;
    }

    private int userId;

    private String groupId;

    private String roleId;

    private String roleName;

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Override
    public String toString() {
        return "UserRole [userId=" + userId + ", groupId=" + groupId + ", roleId=" + roleId + ", roleName=" + roleName
                + "]";
    }

}
