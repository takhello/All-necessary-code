package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "T_CONFIG")
public class Config implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -4725858417192385771L;

    @Id
    @SequenceGenerator(name = "SEQ_T_CONFIG_ID", sequenceName = "SEQ_T_CONFIG_ID", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ_T_CONFIG_ID")
    @Column(name = "id")
    private String id;

    @Column(name = "key_code", nullable = false)
    private String keyCode;

    @Column(name = "value", nullable = false)
    private String value;

    @Column(name = "description")
    private String description;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    public Config() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatedTime() {
        return createTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createTime = createdTime;
    }

    public Date getUpdatedTime() {
        return updateTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updateTime = updatedTime;
    }

}