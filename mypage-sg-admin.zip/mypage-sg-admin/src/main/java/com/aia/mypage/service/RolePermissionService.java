package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.RolePermissionRP;

public interface RolePermissionService {

    List<RolePermissionRP> getRolePermissionsRPList(Role role, Permission permission);

    RolePermission addRolePermission(RolePermission rolePermission);

    boolean deleteRolePermissionById(Integer rolePermissionId);

    boolean deleteRolePermissionByPermissionId(String permissionId);

    boolean deleteRolePermissionByRoleId(String roleId);

    boolean hasSameRolePermission(String permissionId);

    List<RolePermission> getRolePermissionList();

    List<RolePermission> getRolePermissionByPermissionId(String permission_id);

    List<RolePermission> getRolePermissionListByRoleId(String roleId);

    RolePermission getRolePermissionById(Integer role_permission_id);

}
