package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class PermissionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private PermissionService mockPermissionService;

    @Mock
    private RolePermissionService mockRolePermissionService;

    @InjectMocks
    private PermissionController mockPermissionController;

    private Map<String, Object> errorjsonMap;

    private Map<String, Object> successjsonMap;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockPermissionController).build();
    }

    @Test
    public void testGetPermissionsListSuccess() throws Exception {
        List<Permission> mockPermissionsList = new ArrayList<Permission>();
        Permission mockPermission = new Permission();
        mockPermission.setCreateTime(new Date());
        mockPermissionsList.add(mockPermission);
        Mockito.when(mockPermissionService.getPermissionsList(Mockito.any(Permission.class)))
                .thenReturn(mockPermissionsList);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/permissions")
                .param("permissionId", "")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionName() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionName"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionName01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionName"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionDesc() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionDesc01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionType() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionType"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionType01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionType"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionPattern() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionPattern"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionPattern01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionPattern"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionMethod() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionMethod"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionMethod01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionMethod"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionStatus() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "method");
        data.put("permissionStatus", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionStatus"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullPermissionStatus01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "method");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionStatus"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullIsOTP() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "method");
        data.put("permissionStatus", "status");
        data.put("isOTP", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("isOTP"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionNullIsOTP01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("permissionName", "132");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "method");
        data.put("permissionStatus", "status");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("isOTP"))));
        // @formatter:on
    }

    @Test
    public void testAddPermissionSuccess() throws Exception {
        successJson();
        Mockito.when(mockPermissionService.addPermission(Mockito.any(Permission.class))).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testDeletePermissionRolePermissionMapping() throws Exception {
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("N");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        RolePermission rolePermission = new RolePermission();
        rolePermissionList.add(rolePermission);
        Mockito.when(mockRolePermissionService.getRolePermissionByPermissionId(Mockito.anyString()))
                .thenReturn(rolePermissionList);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/permission/{permission_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.ROLE_PERMISSION_MAPPING)));
        // @formatter:on
    }

    @Test
    public void testDeletePermissionIsDefault() throws Exception {
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("Y");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionService.getRolePermissionByPermissionId(Mockito.anyString()))
                .thenReturn(rolePermissionList);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/permission/{permission_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("permission"))));
        // @formatter:on
    }

    @Test
    public void testDeletePermissionSuccess() throws Exception {
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("N");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionService.getRolePermissionByPermissionId(Mockito.anyString()))
                .thenReturn(rolePermissionList);
        Mockito.when(mockPermissionService.deletePermissionById(Mockito.anyString())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/permission/{permission_id}",1)
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testDeletePermissionsFalse() throws Exception {
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("N");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionService.getRolePermissionByPermissionId(Mockito.anyString()))
                .thenReturn(rolePermissionList);
        Mockito.when(mockPermissionService.deletePermissionById(Mockito.anyString())).thenReturn(false);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/permission/{permission_id}",1)
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testUpdatePermissionIsDefault() throws Exception {
        successJson();
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("Y");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/permission/{permission_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("permission"))));
        // @formatter:on
    }

    @Test
    public void testUpdatePermissionSuccess() throws Exception {
        successJson();
        Permission mockPermission = new Permission();
        mockPermission.setIsDefault("N");
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        mockPermission.setCreateTime(new Date());
        Mockito.when(mockPermissionService.updatePermissionById(Mockito.any(Permission.class)))
                .thenReturn(mockPermission);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/permission/{permission_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testUpdatePermissionError() throws Exception {
        errorJson();
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/permission/{permission_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(errorjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionName"))));
        // @formatter:on
    }

    public void errorJson() {
        errorjsonMap = new LinkedHashMap<String, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("permissionId", "");
        data.put("permissionName", "");
        data.put("permissionDesc", "");
        data.put("permissionType", "");
        data.put("permissionPattern", "");
        data.put("permissionMethod", "");
        data.put("permissionStatus", "");
        data.put("isOTP", "");
        errorjsonMap.put("data", data);
    }

    public void successJson() {
        successjsonMap = new LinkedHashMap<String, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("permissionId", "111");
        data.put("permissionName", "name");
        data.put("permissionDesc", "desc");
        data.put("permissionType", "type");
        data.put("permissionPattern", "pattern");
        data.put("permissionMethod", "method");
        data.put("permissionStatus", "Y");
        data.put("isOTP", "N");
        successjsonMap.put("data", data);
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
