package com.aia.mypage.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.GroupRoleDAO;
import com.aia.mypage.dao.GroupRoleGRDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.impl.GroupRoleServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class GroupRoleServiceTest {

    @Mock
    private GroupRoleDAO mockGroupRoleDAO;

    @Mock
    private GroupRoleGRDAO mockGroupRoleGRDAO;

    @InjectMocks
    private GroupRoleServiceImpl mockGroupRoleServiceImpl = new GroupRoleServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDeleteGroupRoleByRoleIdNull() {
        List<GroupRole> mockGroupRoleList = new ArrayList<GroupRole>();
        Mockito.when(mockGroupRoleDAO.getGroupRoleListByRoleId(Mockito.anyString())).thenReturn(mockGroupRoleList);
        String mockRoleId = "1111111";
        boolean result = mockGroupRoleServiceImpl.deleteGroupRoleByRoleId(mockRoleId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteGroupRoleByRoleId() {
        List<GroupRole> mockGroupRoleList = new ArrayList<GroupRole>();
        GroupRole mockGroupRole = new GroupRole();
        mockGroupRoleList.add(mockGroupRole);
        Mockito.when(mockGroupRoleDAO.getGroupRoleListByRoleId(Mockito.anyString())).thenReturn(mockGroupRoleList);
        Mockito.when(mockGroupRoleDAO.deleteGroupRoleById(Mockito.anyInt())).thenReturn(true);
        String mockRoleId = "1111111";
        boolean result = mockGroupRoleServiceImpl.deleteGroupRoleByRoleId(mockRoleId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testDeleteGroupRoleByGroupIdNull() {
        List<GroupRole> mockGroupRoleList = new ArrayList<GroupRole>();
        Mockito.when(mockGroupRoleDAO.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(mockGroupRoleList);
        String mockGroupId = "1111111";
        boolean result = mockGroupRoleServiceImpl.deleteGroupRoleByGroupId(mockGroupId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteGroupRoleByGroupId() {
        List<GroupRole> mockGroupRoleList = new ArrayList<GroupRole>();
        GroupRole mockGroupRole = new GroupRole();
        mockGroupRoleList.add(mockGroupRole);
        Mockito.when(mockGroupRoleDAO.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(mockGroupRoleList);
        Mockito.when(mockGroupRoleDAO.deleteGroupRoleById(Mockito.anyInt())).thenReturn(true);
        String mockGroupId = "1111111";
        boolean result = mockGroupRoleServiceImpl.deleteGroupRoleByGroupId(mockGroupId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testGetGroupRoleGRsList() {
        Mockito.when(mockGroupRoleGRDAO.getGroupRoleGRsList(Mockito.any(Group.class), Mockito.any(Role.class)))
                .thenReturn(null);
        Group mockGroup = new Group();
        Role mockRole = new Role();
        List<GroupRoleGR> groupRoleGRsList = mockGroupRoleServiceImpl.getGroupRoleGRsList(mockGroup, mockRole);
        Assert.assertEquals(groupRoleGRsList, null);
    }

    @Test
    public void testAddGroupRole() {
        GroupRole mockGroupRole = new GroupRole();
        String mockRoleId = "123";
        String mockGroupId = "1234";
        mockGroupRole.setGroupId(mockGroupId);
        mockGroupRole.setRoleId(mockRoleId);
        Mockito.when(mockGroupRoleDAO.addGroupRole(Mockito.any(GroupRole.class))).thenReturn(mockGroupRole);
        GroupRole groupRole = mockGroupRoleServiceImpl.addGroupRole(mockGroupId, mockRoleId);
        Assert.assertEquals(groupRole.getGroupId(), mockGroupId);
    }

    @Test
    public void testDeleteGroupRoleById() {
        int mockGroupRoleId = 1;
        Mockito.when(mockGroupRoleDAO.deleteGroupRoleById(mockGroupRoleId)).thenReturn(true);
        boolean result = mockGroupRoleServiceImpl.deleteGroupRoleById(mockGroupRoleId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testHasSameGroupRoleFalse() {
        String mockGroupId = "1234";
        String mockRoleId = "1234";
        Mockito.when(mockGroupRoleDAO.hasSameGroupRole(mockGroupId, mockRoleId)).thenReturn(null);
        boolean result = mockGroupRoleServiceImpl.hasSameGroupRole(mockGroupId, mockRoleId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testHasSameGroupRoleTrue() {
        GroupRole mockGroupRole = new GroupRole();
        String mockRoleId = "123";
        String mockGroupId = "1234";
        mockGroupRole.setGroupId(mockGroupId);
        mockGroupRole.setRoleId(mockRoleId);
        Mockito.when(mockGroupRoleDAO.hasSameGroupRole(mockGroupId, mockRoleId)).thenReturn(mockGroupRole);
        boolean result = mockGroupRoleServiceImpl.hasSameGroupRole(mockGroupId, mockRoleId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testGetGroupRoleList() {

        Mockito.when(mockGroupRoleDAO.getGroupRoleList()).thenReturn(null);
        List<GroupRole> groupRoleList = mockGroupRoleServiceImpl.getGroupRoleList();
        Assert.assertEquals(groupRoleList, null);
    }

    @Test
    public void testGetGroupRoleListByRoleId() {
        Mockito.when(mockGroupRoleDAO.getGroupRoleListByRoleId(Mockito.anyString())).thenReturn(null);
        List<GroupRole> groupRoleList = mockGroupRoleServiceImpl.getGroupRoleListByRoleId("qq");
        Assert.assertEquals(groupRoleList, null);
    }

    @Test
    public void testGetGroupRoleListByGroupId() {

        Mockito.when(mockGroupRoleDAO.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(null);
        List<GroupRole> groupRoleList = mockGroupRoleServiceImpl.getGroupRoleListByGroupId("1");
        Assert.assertEquals(groupRoleList, null);
    }

    @Test
    public void testgGetGroupRoleListById() {
        Mockito.when(mockGroupRoleDAO.getGroupRoleListById(Mockito.anyInt())).thenReturn(null);
        GroupRole groupRole = mockGroupRoleServiceImpl.getGroupRoleListById(1);
        Assert.assertEquals(groupRole, null);
    }
}
