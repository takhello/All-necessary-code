package com.aia.mypage.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.RoleDAO;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.impl.RoleServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class RoleServiceTest {

    @Mock
    private RoleDAO mockRoleDAO;

    @InjectMocks
    private RoleServiceImpl mockRoleServiceImpl = new RoleServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetRolesList() {
        Role mockRole = new Role();
        mockRole.setRoleId("123");
        Mockito.when(mockRoleDAO.getRolesList(Mockito.any(Role.class))).thenReturn(null);
        List<Role> rolesList = mockRoleServiceImpl.getRolesList(mockRole);
        Assert.assertEquals(rolesList, null);
    }

    @Test
    public void testAddRole() {
        Role mockRole = new Role();
        mockRole.setRoleId("123");
        Mockito.when(mockRoleDAO.addRole(Mockito.any(Role.class))).thenReturn(mockRole);
        Role newRole = mockRoleServiceImpl.addRole(mockRole);
        Assert.assertEquals(newRole.getRoleId(), "123");
    }

    @Test
    public void testDeleteRoleById() {
        String mockRoleId = "11";
        Mockito.when(mockRoleDAO.deleteRoleById(Mockito.anyString())).thenReturn(false);
        boolean result = mockRoleServiceImpl.deleteRoleById(mockRoleId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testUpdateRoleFalse() {
        Mockito.when(mockRoleDAO.getRoleById(Mockito.anyString())).thenReturn(null);
        Role mockRole = new Role();
        Role result = mockRoleServiceImpl.updateRole(mockRole);
        Assert.assertEquals(result, null);
    }

    @Test
    public void testUpdateRoleSuccess() {
        Role mockRole = new Role();
        Mockito.when(mockRoleDAO.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Role newRole = new Role();
        newRole.setRoleName("132");
        Mockito.when(mockRoleDAO.updateRoleById(mockRole)).thenReturn(newRole);
        Role result = mockRoleServiceImpl.updateRole(mockRole);
        Assert.assertEquals(result.getRoleName(), "132");
    }

    @Test
    public void testGetRoleById() {
        Mockito.when(mockRoleDAO.getRoleById(Mockito.anyString())).thenReturn(null);
        String mockRoleId = "11";
        Role role = mockRoleServiceImpl.getRoleById(mockRoleId);
        Assert.assertEquals(role, null);
    }
}
