package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.service.AdminUserService;
import com.aia.mypage.util.BaseUtil;

import mockit.NonStrictExpectations;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AdminProfileControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AdminUserService mockAdminUserService;

    @InjectMocks
    private AdminProfileController mockAdminProfileController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockAdminProfileController).build();
    }

    public void setupMockBaseController() throws IOException {
        final BaseController baseController = new BaseController();

        new NonStrictExpectations(BaseController.class) {
            {
                baseController.getUserName();
                result = "name";
            }
        };
    }

    @Test
    public void testGetAdminUserFalse() throws Exception {
        setupMockBaseController();
        Mockito.when(mockAdminUserService.getAdminProfile(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/profile")
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(BaseUtil.EXCEPTION_MESSAGE)));
        // @formatter:on
    }

    @Test
    public void testGetAdminUserSuccess() throws Exception {
        setupMockBaseController();
        AdminUserInfo mockAdminUserInfo = new AdminUserInfo();
        mockAdminUserInfo.setFirstName("name");
        Mockito.when(mockAdminUserService.getAdminProfile(Mockito.anyString())).thenReturn(mockAdminUserInfo);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/profile")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
        // @formatter:on
    }
}
