package com.aia.mypage.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.PermissionDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.service.impl.PermissionServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class PermissionServiceTest {

    @Mock
    private PermissionDAO mockPermissionDAO;

    @InjectMocks
    private PermissionServiceImpl mockPermissionServiceImpl = new PermissionServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetPermissionList() {
        Mockito.when(mockPermissionDAO.getPermissionsList(Mockito.any(Permission.class))).thenReturn(null);
        Permission mockPermission = new Permission();
        List<Permission> permissionList = mockPermissionServiceImpl.getPermissionsList(mockPermission);
        Assert.assertEquals(permissionList, null);
    }

    @Test
    public void testUpdatePermissionByIdSuccess() {
        Permission mockpermission = new Permission();
        mockpermission.setIsOTP("Y");
        Mockito.when(mockPermissionDAO.getPermissionById(Mockito.anyString())).thenReturn(mockpermission);
        Mockito.when(mockPermissionDAO.updatePermissionById(Mockito.any(Permission.class))).thenReturn(mockpermission);
        Permission permission = mockPermissionServiceImpl.updatePermissionById(mockpermission);
        Assert.assertEquals(permission.getIsOTP(), "Y");
    }

    @Test
    public void testUpdatePermissionByIdFalse() {
        Permission mockpermission = new Permission();
        mockpermission.setIsOTP("Y");
        Mockito.when(mockPermissionDAO.getPermissionById(Mockito.anyString())).thenReturn(null);
        Permission permission = mockPermissionServiceImpl.updatePermissionById(mockpermission);
        Assert.assertEquals(permission, null);
    }

    @Test
    public void testDeletePermissionById() {
        Mockito.when(mockPermissionDAO.deletePermissionById(Mockito.anyString())).thenReturn(true);
        String mockPermissionId = "123";
        boolean result = mockPermissionServiceImpl.deletePermissionById(mockPermissionId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testAddPermission() {
        Permission mockPermission = new Permission();
        mockPermission.setIsOTP("Y");
        Mockito.when(mockPermissionDAO.addPermission(Mockito.any(Permission.class))).thenReturn(mockPermission);
        Permission permission = mockPermissionServiceImpl.addPermission(mockPermission);
        Assert.assertEquals(permission.getIsOTP(), "Y");
    }

    @Test
    public void testGetPermissionById() {
        Mockito.when(mockPermissionDAO.getPermissionById(Mockito.anyString())).thenReturn(null);
        String mockPermissionId = "11";
        Permission permission = mockPermissionServiceImpl.getPermissionById(mockPermissionId);
        Assert.assertEquals(permission, null);
    }
}
