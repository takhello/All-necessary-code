module.exports = function(config){
  	config.set({

	    basePath : '../../..',

	    reporters: ['progress','coverage'],
	    preprocessors : {'src/main/webapp/app/**/*.js': 'coverage'},
	    
	    files : [
	        'src/main/webapp/lib/jquery/dist/jquery.min.js',
	      	'src/main/webapp/lib/jquery.slimscroll.min.js',
	      	'src/main/webapp/lib/fastclick.js',
	      	'src/main/webapp/lib/app.min.js',

	      	'src/main/webapp/lib/angular/angular.js',
	      	'src/main/webapp/lib/angular-mocks/angular-mocks.js',
	      	'src/main/webapp/lib/angular-resource/angular-resource.min.js',
	      	'src/main/webapp/lib/angular-ui-router/angular-ui-router.js',

	      	'src/main/webapp/lib/ui-bootstrap/ui-bootstrap-tpls-0.13.1.js',
	      	'src/main/webapp/lib/bootstrap/dist/js/bootstrap.min.js',
	      	'src/main/webapp/app/app.js',
	      	'src/main/webapp/app/config.js',
	      	'src/main/webapp/app/**/*.js',
	      	'src/test/javascript/unit/**/*.js'
	    ],
	    exclude: [
	        'src/test/javascript/karma.conf*.js'
	    ],
	    autoWatch : false,
	    frameworks: ['jasmine-jquery','jasmine'],
	    browsers:['PhantomJS'],
	    port: 9876,
        logLevel: config.LOG_INFO,
        singleRun: true,
	    plugins : [
	        'karma-phantomjs-launcher',  
	    	'karma-jasmine-jquery',
	     	'karma-jasmine',
	      	'karma-coverage'
	 	],

	    coverageReporter: {
	        dir : 'target/site',
	        reporters: [
	            { type: 'html', subdir: 'report-html' },
	            { type: 'cobertura', subdir: 'cobertura', file: 'coverage-javascript.xml' }
	        ]
	    }

  	});
};