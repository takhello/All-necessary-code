'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('RoleController', function() {
		var scope, modalInstance, controller, roleService, modal,state;
		beforeEach(inject(function($rootScope, $controller, RoleService, $modal,$state) {
			scope = $rootScope.$new();
			roleService = RoleService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('RoleController', {
				$scope: scope,
				$modalInstance: modalInstance,
				RoleService: roleService,
				$state:$state
			});
			spyOn(state,'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			
		});
		describe('Test:Callback function', function() {
			it('should test successCallback', function() {
				controller.successCallback({
					"data": {
						"roleList": [{
							"roleId": "1",
							"roleName": "Role1",
							"roleDesc": "Role1 Desc",
							"roleStatus": "Y",
							"createTime": "",
							"updateTime": ""
						}]

					}
				});
				expect(controller.roles).toBeDefined();
			});
		});

		 describe('RoleService:call', function() {
		 	beforeEach(inject(function() {
		 		spyOn(roleService, 'getRoleList');
		 	}));
		 	it('roleService:getPermissionList', function() {
		 		controller.roleName = 'sss';
		 		controller.roleStatus = 'Y';
		 		controller.getRoleList();
		 		expect(roleService.getRoleList).toHaveBeenCalled();
		 	});
		 });
		 describe('Test:callback function', function() {
		 	it('should return data when run successCallback', function() {
		 		controller.successCallback({
		 			data: {
		 				roleList: {}
		 			}
		 		});
		 		expect(controller.roles).toBeDefined();
		 	});
		 	it('should jump to home.403 state',function(){
		 		controller.failCallback({
		 			data:{
		 				code:403,
		 				message:{}
		 			}
		 		});
		 		expect(state.go).toHaveBeenCalledWith("home.403");
		 	});
		 	it('should not to jump to home.403 state',function(){
		 		controller.failCallback({
		 			data:{
		 				code:550,
		 				message:{}
		 			}
		 		});
		 		// expect(state.go).toHaveBeenCalledWith("home.403");
		 	});
		 	it('should link to related permission',function(){
		 		controller.getRoleToPermission();
		 		expect(state.go).toHaveBeenCalled();
		 	});
		 });
		 describe('Test:operation function', function() {
		 	it('should test deleteRole', function() {
		 		controller.deleteRole();
		 		expect(modal.open).toBeDefined();
		 	});
		 	it('should test editRole', function() {
		 		controller.editRole({
		 			"roleName": "Policy",
		 			"roleStatus": "Y"
		 		});
		 		expect(modal.open).toBeDefined();
		 	});
		 	it('should test addRole', function() {
		 		controller.addRole();
		 		expect(modal.open).toBeDefined();
		 	});
		 });
		 
	});
});