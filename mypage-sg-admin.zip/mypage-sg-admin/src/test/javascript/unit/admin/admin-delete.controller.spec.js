'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminDeleteController', function() {
		var scope, modalInstance, controller, adminService, adminId, adminData;
		beforeEach(inject(function($rootScope, $controller, AdminService) {
			adminService = AdminService;
			adminId = "12345";
			adminData = {
				"userId": "",
				"partyId": "",
				"sessionId": "123456",
				"country": "en",
				"language": "en-SG",
				"data": {}
			};

			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('AdminDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminService: adminService,
				adminId: adminId,
				adminData: adminData
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback();
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about delete admin', function() {
			beforeEach(inject(function() {
				spyOn(adminService, 'deleteAdmin');
			}));
			it('should confirm save delete admin data', function() {
				controller.deleteAdminConfirm();
				expect(adminService.deleteAdmin).toHaveBeenCalled();
			});
			it('should cancel delete admin data', function() {
				controller.deleteAdminCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});
	});
});