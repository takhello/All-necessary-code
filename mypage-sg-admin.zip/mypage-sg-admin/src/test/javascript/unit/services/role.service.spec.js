'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:RoleService service', function() {
		var $resource, RoleService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_RoleService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			RoleService = _RoleService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test RoleService newRole',function(){
			spyOn(RoleService,'newRole').and.callThrough();
			RoleService.newRole({},function(){},function(){});
			expect(RoleService.newRole).toHaveBeenCalled();
		});
		it('test RoleService deleteRole',function(){
			spyOn(RoleService,'deleteRole').and.callThrough();
			RoleService.deleteRole('123',function(){},function(){});
			expect(RoleService.deleteRole).toHaveBeenCalled();
		});
		it('tset RoleService editRole',function(){
			spyOn(RoleService,'editRole').and.callThrough();
			RoleService.editRole('123',{},function(){},function(){});
			expect(RoleService.editRole).toHaveBeenCalled();
		});
		it('test RoleService getRoleList',function(){
			spyOn(RoleService,'getRoleList').and.callThrough();
			RoleService.getRoleList({},function(){},function(){});
			expect(RoleService.getRoleList).toHaveBeenCalled();
		});
	});
});