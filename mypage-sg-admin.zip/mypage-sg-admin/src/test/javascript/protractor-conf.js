//var ScreenShotReporter = require('protractor-screenshot-reporter');
exports.config = {
	allScriptsTimeout : 11000,

	specs : [ 'e2e/*.js' ],

	multiCapabilities: [
		{
			'browserName': 'ie'
		}, 
		{
			'browserName': 'chrome'
		}, 
		{
			'browserName': 'firefox'
		}
	],
	maxSessions: 1,

	chromeOnly : false,

	baseUrl : 'http://localhost:8080/',

	framework : 'jasmine',

	jasmineNodeOpts : {
		defaultTimeoutInterval : 60000
	}
	// },
 //   onPrepare: function() {
 //      	// Add a screenshot reporter and store screenshots to `/tmp/screnshots`:
 //      	jasmine.getEnv().addReporter(new ScreenShotReporter({
 //         	baseDirectory: 'target/site/screenshots'
 //      	}));
 //   }
};
