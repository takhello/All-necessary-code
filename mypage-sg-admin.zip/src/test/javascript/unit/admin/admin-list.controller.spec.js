'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminController', function() {
		var scope, modalInstance, controller, adminService, modal, state;
		beforeEach(inject(function($rootScope, $controller, AdminService, $modal, $state) {
			scope = $rootScope.$new();
			adminService = AdminService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('AdminController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminService: adminService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			
		});

		describe('RoleService:call', function() {
			beforeEach(inject(function() {
				spyOn(adminService, 'getAdmin');
			}));
			it('adminService:getAdminList', function() {
				controller.firstName = 'sss';
				controller.lastName = 'sss';
				controller.isEnabled = 'Y';
				controller.getAdminList();
				expect(adminService.getAdmin).toHaveBeenCalled();
			});
		});
		describe('Test:callback function', function() {
			it('should return data when run successCallback', function() {
				controller.successCallback({
					data: {
						userList: {}
					}
				});
				expect(controller.admins).toBeDefined();
			});
			it('should link to related group', function() {
				controller.getAdminGroupList();
				expect(state.go).toHaveBeenCalled();
			});
		});
		describe('Test:operation function', function() {
			it('should test delete admin', function() {
				controller.deleteAdmin();
				expect(modal.open).toBeDefined();
			});
			it('should test editAdmin', function() {
				controller.editAdmin({
					"data": {
						"isEnabled": "Y"
					}
				});
				expect(modal.open).toBeDefined();
			});
			it('should test addAdmin', function() {
				controller.addAdmin();
				expect(modal.open).toBeDefined();
			});
		});

	});
});