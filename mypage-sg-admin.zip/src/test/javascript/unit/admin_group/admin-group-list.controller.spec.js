'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminGroupController', function() {
		var scope, modalInstance, controller, adminToGroupService, groupService, modal, state;
		beforeEach(inject(function($rootScope, $controller, AdminToGroupService, GroupService, $modal, $state) {
			scope = $rootScope.$new();
			adminToGroupService = AdminToGroupService;
			groupService = GroupService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('AdminGroupController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminToGroupService: adminToGroupService,
				GroupService: groupService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('should back to home.role status', function() {
				controller.backToAdmin();
				expect(state.go).toHaveBeenCalledWith('home.admin');
			});
		});
		describe('Test callback function', function() {
			beforeEach(inject(function() {
				spyOn(groupService, 'getGroupList');
			}));
			it('test:loadSuccessCallback', function() {
				controller.loadSuccessCallback({
					"data": {
						"adminUserGroupList": [{
							"userGroupId": "1",
							"isDefault": "Y",
							"groupId": "1",
							"groupName": "Group1",
							"groupDesc": "Group1 Desc",
							"groupStatus": "Y",
							"userId": "1",
							"isEnabled": "Y"
						}]
					}
				});
				expect(controller.currentGroups).toBeDefined();
			});
			it('test:adminGroupSelected', function() {
				controller.adminGroupSelected();
				expect(groupService.getGroupList).toHaveBeenCalled();
			});
			it('test:selectedSuccessCallback--case1', function() {
				controller.currentGroups = [];
				controller.selectedSuccessCallback({
					"data": {
						"groupList": [{
							"groupId": "1",
							"groupName": "Group1",
							"groupDesc": "Group1 Desc",
							"groupStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.currentGroups.length).toBe(0);
				expect(controller.selectedGroups).toBe(controller.allGroups);
			});
			it('test:selectedSuccessCallback--case2', function() {
				controller.currentGroups = [{
					"userGroupId": "1",
					"isDefault": "Y",
					"groupId": "1",
					"groupName": "Group1",
					"groupDesc": "Group1 Desc",
					"groupStatus": "Y",
					"userId": "1",
					"isEnabled": "Y"
				}];
				controller.selectedSuccessCallback({
					"data": {
						"groupList": [{
							"groupId": "1",
							"groupName": "Group1",
							"groupDesc": "Group1 Desc",
							"groupStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.selectedGroups).toBeDefined();
			});
			it('test:selectedSuccessCallback--case3',function(){
				controller.currentGroups = [{
					"userGroupId": "1",
					"isDefault": "Y",
					"groupId": "2",
					"groupName": "Group1",
					"groupDesc": "Group1 Desc",
					"groupStatus": "Y",
					"userId": "1",
					"isEnabled": "Y"
				}];
				controller.selectedSuccessCallback({
					"data": {
						"groupList": [{
							"groupId": "1",
							"groupName": "Group1",
							"groupDesc": "Group1 Desc",
							"groupStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.selectedGroups).toBeDefined();
			});
			it('test;selectedFailCallback',function(){
				controller.selectedFailCallback();
				expect(controller.selectedGroups).toBe(controller.allGroups);
			});
			it('test:deleteAdminGroup',function(){
				controller.deleteAdminGroup();
				expect(modal.open).toBeDefined();
//				expect(modalInstance.ok).toHaveBeenCalled();
			});
			it('test:newAdminGroup',function(){
				controller.newAdminGroup();
				expect(modal.open).toBeDefined();
//				expect(modalInstance.ok).toHaveBeenCalled();
			});
		});
	});


});