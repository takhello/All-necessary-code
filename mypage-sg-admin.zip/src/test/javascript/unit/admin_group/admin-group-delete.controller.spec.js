'use strict';

describe('mypage-admin:controllers',function(){
	
	beforeEach(module('adminManageApp'));
	
	describe('AdminGroupDeleteController',function(){
		var scope, modalInstance, controller, adminToGroupService, adminGroupId, state;
		beforeEach(inject(function($rootScope, $controller, AdminToGroupService,$state) {
			adminToGroupService = AdminToGroupService;
			state = $state;
			adminGroupId = "12345";
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('AdminGroupDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminToGroupService: adminToGroupService,
				adminGroupId: adminGroupId
			});
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		describe('Test two case about delete adminGroup && test callback function',function(){
			beforeEach(inject(function(){
				spyOn(state,'reload');
				spyOn(adminToGroupService,'deleteAdminGroup');
			}));
			it('test:deleteSuccessCallback',function(){
				controller.deleteSuccessCallback();
				expect(state.reload).toHaveBeenCalledWith('home.admin.admin-group');
			});
			it('test:deleteFailCallback',function(){
				controller.deleteFailCallback();
				expect(state.reload).toHaveBeenCalledWith('home.admin.admin-group');
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('test confirm delete adminGroup',function(){
				controller.deleteAdminGroupCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test cancel delete adminGroup',function(){
				controller.deleteAdminGroupConfirm();
				expect(adminToGroupService.deleteAdminGroup).toHaveBeenCalled();
			});
		});
	});
});