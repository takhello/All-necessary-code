'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('PermissionAddController', function() {
		var scope, modalInstance, controller , PermissionSer;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, PermissionService) {
			PermissionSer = PermissionService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('PermissionAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				PermissionService: PermissionService
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('should dismiss the modal with the result "false" when rejected',function(){
				controller.addPermissionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});			
		});

		describe('Test callback function',function(){
			it('test:close error message callback function',function(){
				controller.errorClose();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback',function(){
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback',function(){
				controller.failCallback({
					data:{
						message:"",
						code:550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('PermissionService:call',function(){
			beforeEach(inject(function(){
				spyOn(PermissionSer,'newPermission');
			}));
			it('permissionService:newPermission',function(){
				controller.addPermissionConfirm();
				expect(PermissionSer.newPermission).toHaveBeenCalled();
			});
		});

	});


});