'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('VersionAddController', function() {
		var scope, modalInstance, controller , versionService;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, VersionService) {
			versionService = VersionService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('VersionAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				VersionService: versionService
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			
		});

		describe('Test callback function',function(){
			it('should dismiss the modal with the result "false" when rejected',function(){
				controller.addVersionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});			
			it('test:close error message callback function',function(){
				controller.closeError();
				expect(controller.isAlertHide).toBe(true);
			});
			it('addSuccessCallback',function(){
				controller.addSuccessCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback',function(){
				controller.addFailCallback({
					data:{
						message:"",
						code:550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('VersionService:call',function(){
			beforeEach(inject(function(){
				spyOn(versionService,'newVersion');
			}));
			it('VersionService:newVersion',function(){
				controller.addVersionConfirm();
				expect(versionService.newVersion).toHaveBeenCalled();
			});
		});

	});


});