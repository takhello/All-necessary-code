package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.RolePermissionDAO;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class RolePermissionDAOImpl extends JPABaseRepImpl<RolePermission> implements RolePermissionDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public RolePermission addRolePermission(RolePermission rolePermission) {
        rolePermission = super.create(rolePermission);
        return rolePermission;
    }

    public boolean deleteRolePermissionById(Integer rolePermissionId) {
        super.remove(rolePermissionId);
        return true;
    }

    public List<RolePermission> getRolePermissionListByPermissionId(String permissionId) {
        StringBuffer sql = new StringBuffer("from RolePermission where permissionId = :permissionId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("permissionId", permissionId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    public List<RolePermission> getRolePermissionListByRoleId(String roleId, String isDefault) {
        StringBuffer sql = new StringBuffer("from RolePermission where roleId = :roleId and isDefault =:isDefault");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("roleId", roleId);
        parameters.put("isDefault", isDefault);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    public RolePermission hasSameRolePermission(String permissionId) {
        StringBuffer sql = new StringBuffer("from RolePermission where permissionId =:permissionId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("permissionId", permissionId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    @Override
    public List<RolePermission> getRolePermissionList() {

        return queryByNoParamters("from RolePermission");
    }

    @Override
    public List<RolePermission> getRolePermissionListByRoleId(String roleId) {
        StringBuffer sql = new StringBuffer("from RolePermission where roleId = :roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("roleId", roleId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    @Override
    public RolePermission getRolePermissionListById(Integer rolePermissionId) {

        return super.find(rolePermissionId);
    }

}
