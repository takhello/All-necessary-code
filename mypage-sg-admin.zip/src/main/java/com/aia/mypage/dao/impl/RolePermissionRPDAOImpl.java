package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.RolePermissionRPDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class RolePermissionRPDAOImpl extends JPABaseRepImpl<RolePermissionRP> implements RolePermissionRPDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<RolePermissionRP> getList(Role role, Permission permission) {
        String roleId = role.getRoleId();
        String permissionId = permission.getPermissionId();
        StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.RolePermissionRP");
        sql.append(
                " (rolePermission.rolePermissionId, rolePermission.isDefault, role.roleId, role.roleName, role.roleDesc, role.roleStatus,");
        sql.append(" permission.permissionId, permission.permissionName,"
                + " permission.permissionDesc, permission.permissionType, permission.permissionPattern,"
                + " permission.permissionMethod, permission.permissionStatus, permission.isOTP)");
        sql.append(
                " from Role role, Permission permission, RolePermission rolePermission where permission.permissionId=rolePermission.permissionId and rolePermission.roleId=role.roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(roleId) && roleId != null) {
            sql.append(" and role.roleId =:roleId");
            parameters.put("roleId", roleId);
        }
        if (!"".equals(permissionId) && permissionId != null) {
            sql.append(" and permission.permissionId =:permissionId");
            parameters.put("permissionId", permissionId);
        }
        String roleStatus = role.getRoleStatus();
        if (!"".equals(roleStatus) && roleStatus != null) {
            sql.append(" and role.roleStatus =:roleStatus");
            parameters.put("roleStatus", roleStatus);
        }
        String permissionMethod = permission.getPermissionMethod();
        if (!"".equals(permissionMethod) && permissionMethod != null) {
            sql.append(" and permission.permissionMethod = :permissionMethod");
            parameters.put("permissionMethod", permissionMethod);
        }
        String permissionType = permission.getPermissionType();
        if (!"".equals(permissionType) && permissionType != null) {
            sql.append(" and permission.permissionType =:permissionType");
            parameters.put("permissionType", permissionType);
        }
        String permissionStatus = permission.getPermissionStatus();
        if (!"".equals(permissionStatus) && permissionStatus != null) {
            sql.append(" and permission.permissionStatus =:permissionStatus");
            parameters.put("permissionStatus", permissionStatus);
        }
        String isOTP = permission.getIsOTP();
        if (!"".equals(isOTP) && isOTP != null) {
            sql.append(" and permission.isOTP =:isOTP");
            parameters.put("isOTP", isOTP);
        }

        String roleName = role.getRoleName();
        if (!"".equals(roleName) && roleName != null) {
            sql.append(" and lower(role.roleName) like :roleName");
            parameters.put("roleName", "%" + roleName.toLowerCase() + "%");
        }

        String permissionName = permission.getPermissionName();
        if (!"".equals(permissionName) && permissionName != null) {
            sql.append(" and lower(permission.permissionName) like :permissionName");
            parameters.put("permissionName", "%" + permissionName.toLowerCase() + "%");
        }
        String permissionPattern = permission.getPermissionPattern();
        if (!"".equals(permissionPattern) && permissionPattern != null) {
            sql.append(" and lower(permission.permissionPattern) like :permissionPattern");
            parameters.put("permissionPattern", "%" + permissionPattern.toLowerCase() + "%");
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<RolePermissionRP> list = super.query(sqlParameters);
        return list;
    }

    public List<RolePermissionRP> getAllRolePermission() {

        StringBuffer sql = new StringBuffer();
        sql.append(
                "select new com.aia.mypage.entity.RolePermissionRP(role.roleName, permission.permissionPattern, permission.permissionMethod, permission.isOTP)");
        sql.append(" from Permission permission, Role role, RolePermission rolePermission ");
        sql.append(
                " where role.roleId=rolePermission.roleId and permission.permissionId=rolePermission.permissionId and permission.permissionType='00'");
        sql.append(" and role.roleStatus='Y'");

        Map<String, Object> parameters = new HashMap<String, Object>();
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

}
