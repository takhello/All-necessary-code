package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AccountDAO;
import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AccountDAOImpl extends JPABaseRepImpl<Account> implements AccountDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public Account getAccountByAccountName(String accountName) {

        StringBuffer sql = new StringBuffer("from Account where lower(accountName) = :accountName");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("accountName", accountName.toLowerCase());
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

}
