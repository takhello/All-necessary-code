package com.aia.mypage.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.aia.mypage.dao.AdminUserDAO;
import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.AdminUserInfoVO;
import com.aia.mypage.entity.GroupRoleMapVO;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.util.BaseUtil;

public class MyPageUserDetailsService implements UserDetailsService {

    private static final Log LOG = LogFactory.getLog(MyPageUserDetailsService.class);

    @Autowired
    @Qualifier("adminUserDAOImpl")
    private AdminUserDAO adminUserDAO;

    @Autowired
    @Qualifier("userGroupDAOImpl")
    private UserGroupDAO userGroupDAO;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        AdminUserInfoVO adminInfo = adminUserDAO.getAdminUserInfoByAccountName(username);
        if (adminInfo == null) {
            throw new UsernameNotFoundException("admin not found");
        }

        boolean isEnabled = true;
        if (!"y".equalsIgnoreCase(adminInfo.getIsEnabled())) {
            isEnabled = false;
        }

        Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        // default role for login
        authorities.add(new SimpleGrantedAuthority(BaseUtil.DEFAULT_ROLE_FOR_LOGIN));

        List<UserGroup> groupIds = userGroupDAO.getUserGroupsListByUserId(adminInfo.getUserId());

        LOG.info("groupIds == " + groupIds);
        if (groupIds != null && groupIds.size() > 0) {

            for (int i = 0; i < groupIds.size(); i++) {
                List<GroupRoleMapVO> groupRoleMap = BaseUtil.groupIdRoleListMapping.get(groupIds.get(i).getGroupId());
                if (groupRoleMap != null && groupRoleMap.size() > 0) {
                    for (int j = 0; j < groupRoleMap.size(); j++) {
                        authorities.add(new SimpleGrantedAuthority("ROLE_" + groupRoleMap.get(j).getRoleName()));
                    }
                }
            }

        }
        LOG.info("authorities == " + authorities);

        return new MyPageUser(username, adminInfo.getPassword(), isEnabled, true, true, true, authorities,
                adminInfo.getUserId());
    }

}
