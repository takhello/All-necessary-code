package com.aia.mypage.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.aia.mypage.dao.RolePermissionRPDAO;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.util.BaseUtil;

public class MypageFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource {

    protected final Log logger = LogFactory.getLog(super.getClass());
    public static Map<RequestMatcher, Collection<ConfigAttribute>> requestMap;

    @Autowired
    @Qualifier("rolePermissionRPDAOImpl")
    private RolePermissionRPDAO rolePermissionRPDAO;

    public static List<RolePermissionRP> rolePermissionList;

    public void initRequestMap() {

        requestMap = new LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>();

        rolePermissionList = rolePermissionRPDAO.getAllRolePermission();

        if (rolePermissionList != null && rolePermissionList.size() > 0) {

            requestMap = new LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>();

            for (int i = 0; i < rolePermissionList.size(); i++) {

                AntPathRequestMatcher matcher = new AntPathRequestMatcher(
                        rolePermissionList.get(i).getPermissionPattern(),
                        rolePermissionList.get(i).getPermissionMethod().toUpperCase());

                List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>();
                attributes.add(new SecurityConfig("ROLE_" + rolePermissionList.get(i).getRoleName().toUpperCase()));
                requestMap.put(matcher, attributes);

            }
        }

        // default role for login
        AntPathRequestMatcher matcher4 = null;
        List<ConfigAttribute> attributes4 = null;
        matcher4 = new AntPathRequestMatcher("/**", "GET");
        attributes4 = new ArrayList<ConfigAttribute>();
        attributes4.add(new SecurityConfig(BaseUtil.DEFAULT_ROLE_FOR_LOGIN));
        requestMap.put(matcher4, attributes4);

        // hard code several permission/pattern for test
        /*
         * AntPathRequestMatcher matcher = null; List<ConfigAttribute>
         * attributes = null; matcher = new
         * AntPathRequestMatcher("/app/group/group-list.html", "GET");
         * attributes = new ArrayList<ConfigAttribute>(); attributes.add(new
         * SecurityConfig("ROLE_USER1")); requestMap.put(matcher, attributes);
         * 
         * AntPathRequestMatcher matcher2 = null; List<ConfigAttribute>
         * attributes2 = null; matcher2 = new
         * AntPathRequestMatcher("/app/role/role-list.html", "GET"); attributes2
         * = new ArrayList<ConfigAttribute>(); attributes2.add(new
         * SecurityConfig("ROLE_USER2")); requestMap.put(matcher2, attributes2);
         * 
         * AntPathRequestMatcher matcher3 = null; List<ConfigAttribute>
         * attributes3 = null; matcher3 = new
         * AntPathRequestMatcher("/admin/roles", "GET"); attributes3 = new
         * ArrayList<ConfigAttribute>(); attributes3.add(new
         * SecurityConfig("ROLE_USER2")); requestMap.put(matcher3, attributes3);
         * 
         * AntPathRequestMatcher matcher5 = null; List<ConfigAttribute>
         * attributes5 = null; matcher5 = new
         * AntPathRequestMatcher("/admin/group_roles", "GET"); attributes5 = new
         * ArrayList<ConfigAttribute>(); attributes5.add(new
         * SecurityConfig("ROLE_USER2")); requestMap.put(matcher5, attributes5);
         */

    }

    public Collection<ConfigAttribute> getAllConfigAttributes() {
        Set allAttributes = new HashSet();

        for (Map.Entry entry : this.requestMap.entrySet()) {
            allAttributes.addAll((Collection) entry.getValue());
        }

        return allAttributes;
    }

    public Collection<ConfigAttribute> getAttributes(Object object) {
        HttpServletRequest request = ((FilterInvocation) object).getRequest();
        for (Map.Entry entry : this.requestMap.entrySet()) {
            if (((RequestMatcher) entry.getKey()).matches(request)) {
                return ((Collection) entry.getValue());
            }
        }
        return null;
    }

    public boolean supports(Class<?> clazz) {
        return FilterInvocation.class.isAssignableFrom(clazz);
    }
}
