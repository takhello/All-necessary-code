package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Permission;

public interface PermissionService {

    List<Permission> getPermissionsList(Permission permission);

    Permission updatePermissionById(Permission permission);

    boolean deletePermissionById(String permissionId);

    Permission addPermission(Permission permission);

    Permission getPermissionById(String permissionId);
}
