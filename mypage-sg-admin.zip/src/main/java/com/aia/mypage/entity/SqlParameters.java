package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SqlParameters implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 8006543571309837158L;
    private StringBuffer sql;
    private Map<String, Object> parameters;

    public SqlParameters() {
        sql = new StringBuffer("");
        parameters = new HashMap<String, Object>();
    }

    public SqlParameters(StringBuffer sql, Map<String, Object> parameters) {
        this.sql = sql;
        this.parameters = parameters;
    }

    public StringBuffer getSql() {
        return sql;
    }

    public void setSql(StringBuffer sql) {
        this.sql = sql;
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }
}
