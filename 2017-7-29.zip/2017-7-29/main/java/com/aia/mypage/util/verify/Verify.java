package com.aia.mypage.util.verify;

public class Verify {

	private VerifyStrategy verifyStrategy;

	public Verify(VerifyStrategy verifyStrategy) {

		this.verifyStrategy = verifyStrategy;

	}

}
