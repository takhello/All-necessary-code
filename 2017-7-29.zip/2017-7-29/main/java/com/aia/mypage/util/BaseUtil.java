package com.aia.mypage.util;

import java.util.List;
import java.util.Map;

import com.aia.mypage.entity.GroupRoleMapVO;

public class BaseUtil {

    public static Map<String, List<GroupRoleMapVO>> groupIdRoleListMapping;

    public static final String REQUEST_JSON_DATA = "data";

    public static final String REQUEST_JSON_OTPPARAMS = "otpParams";

    public static final String REQUEST_JSON_CLIENT = "client";

    public static final String ACCOUNTTYPE_GOOGLE = "01";

    public static final String ACCOUNTTYPE_FACEBOOK = "02";

    public static final String ACCOUNTTYPE_AIA = "00";

    public static final String SUCCESS = "success";

    public static final String SUCCESS_TRUE = "true";

    public static final String SUCCESS_FALSE = "false";

    public static final String CODE_NAME = "code";

    public static final int SUCCESS_CODE = 200;

    public static final int ERROR_CODE_400 = 400;

    public static final int ERROR_CODE_550 = 550;

    public static final int ERROR_CODE_403 = 403;

    public static final int ERROR_CODE_NULL_PARTYID = 551;

    public static final int USER_NOT_FOUND_CODE = 404;

    public static final String MESSAGE = "message";
    
    public static final String ERROR_CDOE = "errorCode";
    
    public static final String ERROR_MESSAGE = "errorMessage";

    public static final String SUCCESS_MESSAGE = "Successfully processed.";

    public static final String EXCEPTION_MESSAGE = "Business exception.";

    public static final String DETAILED_MESSAGE = "detailedMessage";

    public static final String IS_DEFAULT_Y = "Y";

    public static final String IS_DEFAULT_N = "N";

    // Validation Form.

    public static final String REGEX_PASSWORD = "^\\S{8,}$";

    public static final String REGEX_MOBILE = "^\\d{11}$";

    public static final String UTF8_ENCODING = "UTF-8";

    public static final String DATA_RESULT = "data";

    public static final String REQUEST_METHOD_POST = "post";

    public static final String REQUEST_METHOD_GET = "get";

    public static final String IS_ENABLED_Y = "Y";
    
    public static final String IS_ENABLED_N = "N";

    public static final String TEMP_ACCOUNT_TYPE_SOCIAL_LOGIN = "01";

    public static final String TEMP_ACCOUNT_TYPE_FORGOT_PASSWORD = "02";

    public static final String ERROR_NAME = "error";

    public static final String ERROR_DESC = "error_description";

    /* parameters */

    public static final String COUNTRY = "country";
    
    public static final String NAME = "name";
    
    public static final String TELEPHONE = "telephone";
    
    public static final String EMAIL = "email";
    
    public static final String DEPARTMENT = "department";

    public static final String LANGUAGE = "language";

    public static final String DEFAULT_LANGUAGE = "en";

    public static final String PARAMETER_FIELD = "@field";

    public static final String PARAMETER_MESSAGE = "@message";

    public static final String PARAMETER_IS_REQUIRED = "parameter_required";

    public static final String PARAMETER_IS_NOT_DEFINED = "parameter_undefined";

    public static final String PARAMETER_VALUE_IS_NOT_CORRECT = "parameter_incorrect";

    public static final String INVALID_GRANT = "invalid_grant";

    public static final String INVALID_CODE = "invalid_code";

    public static final String INVALID_CREDENTIALS = "invalid_credentials";

    public static final String DEFAULT_ROLE_FOR_LOGIN = "ROLE_DEFAULT";
}
