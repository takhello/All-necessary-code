package com.aia.mypage.util.ldap;

/** 
 * Copyright (C) 2009 "Darwin V. Felix" <darwinfelix@users.sourceforge.net>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.springframework.stereotype.Component;

@Component
public class LdapUserInfo {

	public static void main(String[] args) throws Exception {

		// String username = "bsnpbt9";
		//
		// boolean found = verificationLanId(username);
		//
		// if (!found) { System.out.println("User " + username +
		// " NOT found in active directory"); }

		boolean bl = verificationMailPwd(USER_MAIL, USER_PASSWORD);

		System.out.println(bl);

	}

	public static boolean verificationLanId(String username) throws NamingException {

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_CONF);
		env.put(Context.SECURITY_AUTHENTICATION, "Simple");
		env.put("com.sun.jndi.ldap.connect.pool", "true");

		env.put(Context.SECURITY_PRINCIPAL, USER_MAIL);
		env.put(Context.SECURITY_CREDENTIALS, USER_PASSWORD);
		env.put(Context.PROVIDER_URL, LDAP_UTL);
		String deecee = "OU=AIA,DC=AIA,DC=BIZ";

		LdapContext context;

		context = new InitialLdapContext(env, null);

		final String filter = String.format("(&(sAMAccountType=805306368)(sAMAccountName=%1$s))", username);

		final SearchControls cons = new SearchControls();
		cons.setSearchScope(SearchControls.SUBTREE_SCOPE);
		final NamingEnumeration<SearchResult> results = context.search(deecee, filter, cons);

		boolean found = false;

		if (results.hasMoreElements()) {

			found = true;
		}

		// while (results.hasMoreElements()) {
		//
		// found = true;
		//
		// final SearchResult result = (SearchResult) results.nextElement();
		//
		//
		// Attributes attributes = result.getAttributes(); for
		// (NamingEnumeration it = attributes.getAll(); it.hasMore();) {
		// Attribute attribute = (Attribute) it.next(); System.out.println(
		// "attribute = " + attribute.getID()); String name = attribute.getID();
		// if (name.equals("displayName") || name.equals("department") ||
		// name.equals("mail")) for (NamingEnumeration e = attribute.getAll();
		// e.hasMore();) { String user = e.next().toString(); //
		// ?????????userPrincipalName???? System.out.println("---" + user); } }
		//
		// }

		return found;
	}

	public static boolean verificationMailPwd(String username, String password) {

		boolean isConnect = false;

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_CONF);
		env.put(Context.SECURITY_AUTHENTICATION, "Simple");
		env.put("com.sun.jndi.ldap.connect.pool", "true");

		env.put(Context.SECURITY_PRINCIPAL, username);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.PROVIDER_URL, LDAP_UTL);

		try {

			LdapContext context = new InitialLdapContext(env, null);

			isConnect = true;

		} catch (NamingException e) {

			e.printStackTrace();
		}

		return isConnect;
	}

	// public static boolean verificationLanId(String username){
	//
	// }

	private static final String JNDI_CONF = "com.sun.jndi.ldap.LdapCtxFactory";

	private static final String USER_MAIL =  "Henry-hf.li@aia.com";

	private static final String USER_PASSWORD =  "June2017";

	private static final String LDAP_UTL = "ldap://cncspwdom01.aia.biz:389";

}
