package com.aia.mypage.rest.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dozer.stats.Statistic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Account;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.util.BaseUtil;

@Controller
@RequestMapping(value = "admin")
public class AdminConsoleUserWorkContorller extends BaseController {

	@Autowired
	private AccountService accountService;

	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value = "/user_lock/{custId}", method = RequestMethod.PUT)
	public Map<String, Object> lockAndUnlock(@PathVariable String custId, @RequestBody Map<String, Object> jsonMap,
			HttpServletRequest request, HttpServletResponse response) {

		Account account = new Account();
		account.setUserId(Integer.valueOf(custId));

		account = accountService.lockAndUnlockUser(account);

		if (account == null) {

			return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ERROR_MASSAGE);
		}

		return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
	}

	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(value = "/user_isEnabled/{custId}", method = RequestMethod.PUT)
	public Map<String, Object> changeUserStatus(@PathVariable String custId, @RequestBody Map<String, Object> jsonMap,
			HttpServletRequest request, HttpServletResponse response) {

		Account account = new Account();
		account.setUserId(Integer.valueOf(custId));

		account = accountService.changeUserStatus(account);

		if (account == null) {

			return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ERROR_MASSAGE);
		}

		return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
	}
	
	private static final String ERROR_MASSAGE = "query fialed";

}
