package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.AdminGroup;
import com.aia.mypage.entity.AdminGroupFunction;
import com.aia.mypage.entity.AdminGroupFunctionInfo;
import com.aia.mypage.entity.AdminUserGroup;
import com.aia.mypage.service.AdminGroupFunctionService;
import com.aia.mypage.service.AdminGroupService;
import com.aia.mypage.service.AdminUserAdminGroupService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorCodeUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class AdminGroupController extends BaseController {

    @Autowired
    @Qualifier("adminGroupServiceImpl")
    private AdminGroupService adminGroupService;

    @Autowired
    @Qualifier("adminGroupFunctionServiceImpl")
    private AdminGroupFunctionService adminGroupFunctionService;

    @Autowired
    @Qualifier("adminUserAdminGroupServiceImpl")
    private AdminUserAdminGroupService adminUserAdminGroupService;

    @ResponseBody
    @RequestMapping(value = "/admin_groups", method = RequestMethod.GET)
    public Map<String, Object> getAdminGroupsList(HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> data = new LinkedHashMap<String, Object>();

        List<AdminGroup> adminGroupList = adminGroupService.getAdminGroupsList();
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        data.put("adminGroupList", adminGroupList);
        successJson.put("data", data);

        return successJson;

    }

    @ResponseBody
    @RequestMapping(value = "/admin_group/{group_id}", method = RequestMethod.GET)
    public Map<String, Object> getAdminGroupFunctionByGroupId(@PathVariable String group_id, HttpServletRequest request,
            HttpServletResponse response) {

        if (StringUtils.isEmpty(group_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("group_id"));
        }
        Map<String, Object> data = new LinkedHashMap<String, Object>();

        AdminGroupFunctionInfo adminGroupFunctionInfo = adminGroupFunctionService.getAdminGroupFunctionInfo(group_id);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        data.put("adminGroupFunctionInfo", adminGroupFunctionInfo);
        successJson.put("data", data);

        return successJson;

    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_group", method = RequestMethod.POST)
    public Map<String, Object> addGroup(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);

        String groupName = (String) data.get("groupName");
        String groupDesc = (String) data.get("groupDesc");
        if (StringUtils.isEmpty(groupName)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("groupName"));
        }

        AdminGroup adminGroup = new AdminGroup();
        adminGroup.setGroupName(groupName);
        adminGroup.setGroupDesc(groupDesc);
        adminGroup.setGroupStatus("Y");
        try {
            adminGroupService.addAdminGroup(adminGroup);

            List<String> functionIdList = (List<String>) data.get("functionIdList");
            for (String functionId : functionIdList) {
                AdminGroupFunction adminGroupFunction = new AdminGroupFunction();
                adminGroupFunction.setGroupId(adminGroup.getGroupId());
                adminGroupFunction.setFunctionId(functionId);

                adminGroupFunctionService.addAdminGroupFunction(adminGroupFunction);
            }
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52001,
                    ErrorMessageUtil.ERROR_MESSAGE_52001);
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

    @ResponseBody
    @RequestMapping(value = "/admin_group/{group_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteGroup(@PathVariable String group_id, HttpServletRequest request,
            HttpServletResponse response) {

        if (StringUtils.isEmpty(group_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("group_id"));
        }

        AdminGroup adminGroup = adminGroupService.getAdminGroupById(group_id);
        if (adminGroup == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52101,
                    ErrorMessageUtil.ERROR_MESSAGE_52101);
        }

        List<AdminUserGroup> adminUserGroupList = adminUserAdminGroupService.getAdminUserGroupByGroupId(group_id);

        if (adminUserGroupList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52101,
                    ErrorMessageUtil.ERROR_MESSAGE_52102);
        }

        try {
            adminGroupService.deleteAdminGroupById(group_id);

            adminGroupFunctionService.deleteAdminGroupFunction(group_id);
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52004,
                    ErrorMessageUtil.ERROR_MESSAGE_52004);
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_group/{group_id}", method = RequestMethod.PUT)
    public Map<String, Object> updateGroup(@PathVariable String group_id, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) {

        if (StringUtils.isEmpty(group_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("group_id"));
        }

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        String groupName = (String) data.get("groupName");
        String groupDesc = (String) data.get("groupDesc");
        if (StringUtils.isEmpty(groupName)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("groupName"));
        }

        AdminGroup newAdminGroup = adminGroupService.getAdminGroupById(group_id);
        if (newAdminGroup == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52101,
                    ErrorMessageUtil.ERROR_MESSAGE_52101);
        }

        newAdminGroup.setGroupName(groupName);
        newAdminGroup.setGroupDesc(groupDesc);

        try {
            adminGroupService.updateAdminGroupById(newAdminGroup);

            adminGroupFunctionService.deleteAdminGroupFunction(group_id);

            List<String> functionIdList = (List<String>) data.get("functionIdList");
            for (String functionId : functionIdList) {
                AdminGroupFunction adminGroupFunction = new AdminGroupFunction();
                adminGroupFunction.setGroupId(group_id);
                adminGroupFunction.setFunctionId(functionId);

                adminGroupFunctionService.addAdminGroupFunction(adminGroupFunction);
            }
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52005,
                    ErrorMessageUtil.ERROR_MESSAGE_52005);
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }
}
