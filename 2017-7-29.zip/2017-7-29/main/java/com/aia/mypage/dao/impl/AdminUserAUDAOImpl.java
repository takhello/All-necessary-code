package com.aia.mypage.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserAUDAOImpl extends JPABaseRepImpl<AdminUser> implements AdminUserAUDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AdminUser addAdminUser(AdminUser adminUser) {

        return super.create(adminUser);
    }

    @Override
    public int updateAdmin(AdminUser adminUser) {

        StringBuffer sql = new StringBuffer(
                "update AdminUser set name =:name, telephone =:telephone, email =:email, department =:department, updateTime =:updateTime where userId= :userId");
        Map<String, Object> parameters = new HashMap<String, Object>();

        parameters.put("name", adminUser.getName());
        parameters.put("telephone", adminUser.getTelephone());
        parameters.put("email", adminUser.getEmail());
        parameters.put("department", adminUser.getDepartment());
        parameters.put("updateTime", new Date());
        parameters.put("userId", adminUser.getUserId());
        
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return newUpdate(sqlParameters);
    }

    @Override
    public boolean deleteAdminByUserId(String userId) {
        super.remove(userId);
        return true;
    }

    @Override
    public AdminUser getAdminUserByUserId(String userId) {

        return super.find(userId);
    }

}
