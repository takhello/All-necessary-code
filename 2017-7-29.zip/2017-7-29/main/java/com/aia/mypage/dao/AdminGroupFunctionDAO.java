package com.aia.mypage.dao;

import com.aia.mypage.entity.AdminGroupFunction;

public interface AdminGroupFunctionDAO {
    
    AdminGroupFunction addAdminGroupFunction(AdminGroupFunction adminGroupFunction);
    
    boolean deleteAdminGroupFunction(String groupId);
}
