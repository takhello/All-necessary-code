package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.RolePermission;

public interface RolePermissionDAO {

    RolePermission addRolePermission(RolePermission rolePermission);

    boolean deleteRolePermissionById(Integer rolePermissionId);

    List<RolePermission> getRolePermissionListByPermissionId(String permissionId);

    List<RolePermission> getRolePermissionListByRoleId(String roleId, String isDefault);

    RolePermission hasSameRolePermission(String permissionId);

    List<RolePermission> getRolePermissionList();

    List<RolePermission> getRolePermissionListByRoleId(String roleId);

    RolePermission getRolePermissionListById(Integer rolePermissionId);

}
