package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AuditLog;

public interface AuditLogDAO {

    void addAuditLog(AuditLog auditLog);

    List<AuditLog> getAuditLogList(int userId);

}
