package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.entity.User;
import com.aia.mypage.entity.UserWorkInfo;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class UserDAOImpl extends JPABaseRepImpl<User> implements UserDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<User> getList() {
        return super.queryByNoParamters("from User");
    }

    public User getUserById(int userId) {
        return super.find(userId);
    }

    @Override
    public List<User> getgetUserList(String partyId, String firstName) {
        StringBuffer sql = new StringBuffer();
        sql.append(" from User u where 1=1");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(partyId) && partyId != null) {
            sql.append(" and lower(partyId) like:partyId");
            parameters.put("partyId", "%" + partyId.toLowerCase() + "%");
        }
        if (!"".equals(firstName) && firstName != null) {
            sql.append(" and lower(firstName) like:firstName");
            parameters.put("firstName", "%" + firstName.toLowerCase() + "%");
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<User> userList = super.query(sqlParameters);
        return userList;
    }

}
