package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminUserInfo;

public interface AdminUserInfoDAO {

    List<AdminUserInfo> getAdminUserListByAccountName(AdminUserInfo adminUserInfo);

    AdminUserInfo getAdminProfile(String accountName);

}
