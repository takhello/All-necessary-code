package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.UserWorkAuditLogDAO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.entity.UserWorkAuditLog;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class UserWorkAuditLogDAOImpl extends JPABaseRepImpl<UserWorkAuditLog> implements UserWorkAuditLogDAO {

    @Override
    protected EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<UserWorkAuditLog> getAuditLogList(int userId) {
        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.UserWorkAuditLog");
        sql.append(" (a.logId, a.logType, a.logDesc, a.userIp, a.createTime)");
        sql.append(" from AuditLog a where a.userId= userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        sql.append(" and userId =:userId");
        parameters.put("userId", userId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<UserWorkAuditLog> auditLogList = super.query(sqlParameters);
        return auditLogList;
    }

}
