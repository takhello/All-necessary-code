package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AuditLogDAO;
import com.aia.mypage.entity.AuditLog;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AuditLogDAOImpl extends JPABaseRepImpl<AuditLog> implements AuditLogDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public void addAuditLog(AuditLog auditLog) {
        super.create(auditLog);
    }

    @Override
    public List<AuditLog> getAuditLogList(int userId) {

        StringBuffer sql = new StringBuffer("from AuditLog where userId = :userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("userId", userId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return query(sqlParameters);
    }

}
