package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserGroupInfoDAO;
import com.aia.mypage.entity.AdminUserGroupInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserGroupInfoDAOImpl extends JPABaseRepImpl<AdminUserGroupInfo> implements AdminUserGroupInfoDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<AdminUserGroupInfo> getAdminUserGroupListByAdminUserId(int adminUserId) {
        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.AdminUserGroupInfo");
        sql.append(
                " (ug.userGroupId, ug.isDefault, ug.groupId, g.groupName, g.groupDesc, g.groupStatus, ug.userId, au.isEnabled)");
        sql.append(" from UserGroup ug, AdminUser au, Group g where ug.userId=au.userId and g.groupId =ug.groupId");
        sql.append(" and au.userId = :adminUserId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("adminUserId", adminUserId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return query(sqlParameters);
    }

}
