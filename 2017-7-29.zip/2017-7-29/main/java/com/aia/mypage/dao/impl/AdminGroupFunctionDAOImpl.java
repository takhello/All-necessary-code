package com.aia.mypage.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminGroupFunctionDAO;
import com.aia.mypage.entity.AdminGroupFunction;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminGroupFunctionDAOImpl extends JPABaseRepImpl<AdminGroupFunction> implements AdminGroupFunctionDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AdminGroupFunction addAdminGroupFunction(AdminGroupFunction adminGroupFunction) {
        adminGroupFunction.setCreateTime(new Date());
        adminGroupFunction.setUpdateTime(new Date());
        return create(adminGroupFunction);
    }

    @Override
    public boolean deleteAdminGroupFunction(String groupId) {
        StringBuffer sql = new StringBuffer("delete from AdminGroupFunction where groupId=:groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        super.execute(sqlParameters);
        return true;
    }

}
