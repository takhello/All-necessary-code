package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.aia.mypage.dao.ConfigDAO;
import com.aia.mypage.entity.Config;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

@Repository
public class ConfigDAOImpl extends JPABaseRepImpl<Config> implements ConfigDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public Config queryByKey(String keyCode) {
        StringBuffer sql = new StringBuffer("from Config where keyCode = :keyCode");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("keyCode", keyCode);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return querySingleResult(sqlParameters);
    }

    public List<Config> queryConfigList() {

        String hql = "from Config";
        return super.queryByNoParamters(hql);
    }
}
