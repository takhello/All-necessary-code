package com.aia.mypage.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.dao.AdminUserDAO;
import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.GroupRoleMapVO;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.ldap.LdapUserInfo;

public class MyPageUserDetailsService implements UserDetailsService {

    private static final Log LOG = LogFactory.getLog(MyPageUserDetailsService.class);

    @Autowired
    @Qualifier("adminUserDAOImpl")
    private AdminUserDAO adminUserDAO;

    @Autowired
    @Qualifier("userGroupDAOImpl")
    private UserGroupDAO userGroupDAO;
    
    @Autowired
    private AdminUserAUDAO adminUserAUDAO;

    @Override
    public UserDetails loadUserByUsername(String username){

    	boolean isEnabled = true;

		/*try {

			AdminUser adminUser = adminUserAUDAO.getAdminUserByUserId(username);

			if (adminUser == null || !"y".equalsIgnoreCase(adminUser.getStatus())) {

				isEnabled = false;
			}

			
			if (!LdapUserInfo.verificationLanId(username)) { 

				throw new UsernameNotFoundException("Validation failure");

			}

		} catch (NamingException e) {

			e.printStackTrace();
		}*/

        Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        // default role for login
        authorities.add(new SimpleGrantedAuthority(BaseUtil.DEFAULT_ROLE_FOR_LOGIN));

        List<UserGroup> groupIds = userGroupDAO.getUserGroupsListByUserId(1);

        LOG.info("groupIds == " + groupIds);
        if (groupIds != null && groupIds.size() > 0) {

            for (int i = 0; i < groupIds.size(); i++) {
                List<GroupRoleMapVO> groupRoleMap = BaseUtil.groupIdRoleListMapping.get(groupIds.get(i).getGroupId());
                if (groupRoleMap != null && groupRoleMap.size() > 0) {
                    for (int j = 0; j < groupRoleMap.size(); j++) {
                        authorities.add(new SimpleGrantedAuthority("ROLE_" + groupRoleMap.get(j).getRoleName()));
                    }
                }
            }

        }
        LOG.info("authorities == " + authorities);

        return new MyPageUser(username, "", isEnabled, true, true, true, authorities,
                1);
    }

}
