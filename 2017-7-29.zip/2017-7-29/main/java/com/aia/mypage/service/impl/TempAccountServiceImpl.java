package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.TempAccountDAO;
import com.aia.mypage.entity.TempAccount;
import com.aia.mypage.service.TempAccountService;
import com.aia.mypage.util.BaseUtil;

public class TempAccountServiceImpl implements TempAccountService {

    @Autowired
    @Qualifier("tempAccountDAOImpl")
    private TempAccountDAO tempAccountDAO;

    public TempAccount addTempAccount(Integer accountId) {
        TempAccount tempAccount = new TempAccount();
        Date now = new Date();
        tempAccount.setCreateTime(now);
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(now);
        gc.add(java.util.Calendar.MINUTE, 5); // set 5 minutes timeout

        tempAccount.setExpireTime(gc.getTime());
        tempAccount.setAccountId(accountId);
        tempAccount.setVerifyString(getUUID());
        tempAccount.setCreateTime(now);
        tempAccount.setExpireTime(gc.getTime());
        tempAccount.setIsEnabled(BaseUtil.IS_ENABLED_Y);
        tempAccount.setType(BaseUtil.TEMP_ACCOUNT_TYPE_FORGOT_PASSWORD);
        tempAccount = tempAccountDAO.addTempAccount(tempAccount);
        return tempAccount;
    }

    private String getUUID() {

        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }

    public TempAccount getTempAccountByVerifyString(String verifyString) {

        return tempAccountDAO.getTempAccountByVerifyString(verifyString);
    }

    public int updatePasswordVerifyString(int id) {

        return tempAccountDAO.updateTempAccount(id);
    }

}
