package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.ErrorMessageDAO;
import com.aia.mypage.entity.ErrorMessage;
import com.aia.mypage.service.ErrorMessageService;

public class ErrorMessageServiceImpl implements ErrorMessageService {

    @Autowired
    @Qualifier("errorMessageDAOImpl")
    private ErrorMessageDAO errorMessageDAO;

    @Override
    public List<ErrorMessage> getErrorMessageList() {

        return errorMessageDAO.getErrorMessageList();
    }

}
