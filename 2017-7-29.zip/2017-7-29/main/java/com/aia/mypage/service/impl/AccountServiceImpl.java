package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.aia.mypage.dao.AccountDAO;
import com.aia.mypage.dao.AccountUserWorkDAO;
import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.UserWorkInfo;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.util.BaseUtil;

@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    @Qualifier("accountUserWorkDAOImpl")
    private AccountUserWorkDAO userWorkDAO;

    @Autowired
    @Qualifier("accountDAOImpl")
    private AccountDAO accountDAO;

    @Override
    public Account getAccountByAccountName(String accountName) {

        return accountDAO.getAccountByAccountName(accountName);
    }

    @Override
    public Account lockAndUnlockUser(Account account) {

        Account newaccount = accountDAO.getAccountByUserId(account.getUserId());

        if (newaccount == null) {

            return null;
        }

        int dataBaseFailedTime = newaccount.getFailedCounter();

        if (!checkFailedCount(dataBaseFailedTime)) {

            return null;
        }

        newaccount.setFailedCounter(0);

        newaccount = accountDAO.updateAccount(newaccount);

        return newaccount;
    }

    @Override
    public Account changeUserStatus(Account account) {

        Account newaccount = accountDAO.getAccountByUserId(account.getUserId());

        if (newaccount == null) {

            return null;
        }

        newaccount.setIsEnabled(changeStr(newaccount.getIsEnabled()));

        newaccount = accountDAO.updateAccount(newaccount);

        return newaccount;
    }

    private static boolean checkFailedCount(int dataBaseTimes) {

        return (dataBaseTimes >= getPramTimes()) ? true : false;
    }

    private static String changeStr(String str) {

        if (BaseUtil.IS_ENABLED_Y.equals(str)) {

            return BaseUtil.IS_ENABLED_N;
        }

        return BaseUtil.IS_ENABLED_Y;

    }

    private static int getPramTimes() {

        return FAILED_TIMES;
    }

    private static final int FAILED_TIMES = 5;

    @Override
    public List<UserWorkInfo> getAccountListByIdName(String custId, String custName) {

        return userWorkDAO.getAccountListByIdName(custId, custName);
    }

    @Override
    public Account getAccountByUserId(Integer userId) {

        return accountDAO.getAccountByUserId(userId);
    }

}
