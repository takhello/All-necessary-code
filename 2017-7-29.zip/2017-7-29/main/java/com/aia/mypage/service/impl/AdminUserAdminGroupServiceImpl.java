package com.aia.mypage.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AdminUserAdminGroupDAO;
import com.aia.mypage.dao.AdminUserGroupDAO;
import com.aia.mypage.entity.AdminUserAdminGroupInfo;
import com.aia.mypage.entity.AdminUserGroup;
import com.aia.mypage.service.AdminUserAdminGroupService;

public class AdminUserAdminGroupServiceImpl implements AdminUserAdminGroupService {

    @Autowired
    @Qualifier("adminUserAdminGroupDAOImpl")
    private AdminUserAdminGroupDAO adminUserAdminGroupDAO;

    @Autowired
    @Qualifier("adminUserGroupDAOImpl")
    private AdminUserGroupDAO adminUserGroupDAO;

    @Override
    public List<AdminUserAdminGroupInfo> getAdminUserAdminGroupList(String userId) {
        List<AdminUserAdminGroupInfo> result = new ArrayList<AdminUserAdminGroupInfo>();
        Map<String, AdminUserAdminGroupInfo> resultMap = new HashMap<String, AdminUserAdminGroupInfo>();
        List<AdminUserAdminGroupInfo> list = adminUserAdminGroupDAO.getAllAdminUserAdminGroup(userId);
        for (AdminUserAdminGroupInfo adminUserAdminGroupInfo : list) {

            String key = adminUserAdminGroupInfo.getUserId();
            if (resultMap.containsKey(key)) {
                AdminUserAdminGroupInfo auag = resultMap.get(key);
                auag.addAdminGroupList(adminUserAdminGroupInfo.getAdminGroupList());
            } else {
                resultMap.put(key, adminUserAdminGroupInfo);
            }
        }
        Iterator<AdminUserAdminGroupInfo> iterator = resultMap.values().iterator();
        while (iterator.hasNext()) {
            AdminUserAdminGroupInfo adminUserAdminGroupInfo = (AdminUserAdminGroupInfo) iterator.next();
            result.add(adminUserAdminGroupInfo);
        }
        return result;
    }

    @Override
    public AdminUserGroup addAdminUserGroup(AdminUserGroup aug) {
        aug.setCreateTime(new Date());
        AdminUserGroup adminUserGroup = adminUserGroupDAO.addAdminUserGroup(aug);
        return adminUserGroup;
    }

    @Override
    public boolean deleteAdminUserGroup(String user_id) {
        return adminUserGroupDAO.deleteAdminUserGroup(user_id);
    }

    @Override
    public List<AdminUserGroup> getAdminUserGroupByGroupId(String groupId) {
        return adminUserGroupDAO.getAdminUserGroupByGroupId(groupId);
    }

}
