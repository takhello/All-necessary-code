package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AdminUserGroupInfoDAO;
import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.AdminUserGroupInfo;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.UserGroupService;
import com.aia.mypage.util.BaseUtil;

public class UserGroupServiceImpl implements UserGroupService {

    @Autowired
    @Qualifier("userGroupDAOImpl")
    private UserGroupDAO userGroupDAO;

    @Autowired
    @Qualifier("adminUserGroupInfoDAOImpl")
    private AdminUserGroupInfoDAO adminUserGroupInfoDAO;

    public boolean deleteUserGroupByGroupId(String groupId) {
        List<UserGroup> userGroupListByGroupId = userGroupDAO.getUserGroupListByGroupId(groupId);
        if (userGroupListByGroupId.size() == 0) {
            return false;
        }
        for (UserGroup userGroup : userGroupListByGroupId) {
            userGroupDAO.deleteUserGroupById(userGroup.getUserGroupId());
        }
        return true;
    }

    public UserGroup addUserGroup(int userId, String groupId) {
        UserGroup userGroup = new UserGroup();
        userGroup.setUserId(userId);
        userGroup.setGroupId(groupId);
        userGroup.setCreateTime(new Date());
        userGroup.setIsDefault(BaseUtil.IS_DEFAULT_N);
        userGroup = userGroupDAO.addUserGroup(userGroup);
        return userGroup;
    }

    @Override
    public UserGroup getSameUserGroup(int userId, String groupId) {

        return userGroupDAO.getSameUserGroup(userId, groupId);
    }

    @Override
    public boolean deleteUserGroupById(Integer userGroupId) {

        return userGroupDAO.deleteUserGroupById(userGroupId);
    }

    @Override
    public List<AdminUserGroupInfo> getAdminUserGroupListByAdminUserId(int adminUserId) {

        return adminUserGroupInfoDAO.getAdminUserGroupListByAdminUserId(adminUserId);
    }

    @Override
    public List<UserGroup> getUserGroupByGroupId(String groupId) {

        return userGroupDAO.getUserGroupListByGroupId(groupId);
    }

    @Override
    public UserGroup getUserGroupById(Integer userGroupId) {

        return userGroupDAO.getUserGroupById(userGroupId);
    }

}
