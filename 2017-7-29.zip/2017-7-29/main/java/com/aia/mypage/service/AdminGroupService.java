package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.AdminGroup;

public interface AdminGroupService {

    List<AdminGroup> getAdminGroupsList();
    
    AdminGroup addAdminGroup(AdminGroup group);

    boolean deleteAdminGroupById(String group_id);

    AdminGroup updateAdminGroupById(AdminGroup group);

    AdminGroup getAdminGroupById(String groupId);

}
