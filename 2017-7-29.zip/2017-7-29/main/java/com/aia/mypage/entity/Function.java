package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Table(name = "T_FUNCTION")
@Entity
public class Function implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 2789631618655679791L;

    /** group_id. */
    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    @Column(name = "function_id")
    private String functionId;

    /** function_name. */
    @Column(name = "function_name")
    private String functionName;

    /** url. */
    @Column(name = "url")
    private String url;

    /** function_desc. */
    @Column(name = "function_desc")
    private String functionDesc;

    /** function_level. */
    @Column(name = "function_level")
    private String functionLevel;

    /** parent_function_id. */
    @Column(name = "parent_function_id")
    private String parentFunctionId;

    /** function_status. */
    @Column(name = "function_status")
    private String functionStatus;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** update_time. */
    @Column(name = "update_time")
    private Date updateTime;

    public Function() {
    }
    
    public Function(String functionId, String functionName, String url, String functionDesc, String functionLevel,
            String parentFunctionId, String functionStatus) {
        this.functionId = functionId;
        this.functionName = functionName;
        this.url = url;
        this.functionDesc = functionDesc;
        this.functionLevel = functionLevel;
        this.parentFunctionId = parentFunctionId;
        this.functionStatus = functionStatus;
    }

    public Function(String functionId, String functionName, String functionLevel, String parentFunctionId) {
        this.functionId = functionId;
        this.functionName = functionName;
        this.functionLevel = functionLevel;
        this.parentFunctionId = parentFunctionId;
    }


    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFunctionDesc() {
        return functionDesc;
    }

    public void setFunctionDesc(String functionDesc) {
        this.functionDesc = functionDesc;
    }

    public String getFunctionLevel() {
        return functionLevel;
    }

    public void setFunctionLevel(String functionLevel) {
        this.functionLevel = functionLevel;
    }

    public String getParentFunctionId() {
        return parentFunctionId;
    }

    public void setParentFunctionId(String parentFunctionId) {
        this.parentFunctionId = parentFunctionId;
    }

    public String getFunctionStatus() {
        return functionStatus;
    }

    public void setFunctionStatus(String functionStatus) {
        this.functionStatus = functionStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
