package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "T_ADMIN_USER_GROUP")
@Entity
public class AdminUserGroup implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 863924501011053034L;

    /** user_group_id. */
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "user_group_id")
    private String userGroupId;

    /** user_id. */
    @Column(name = "user_id")
    private String userId;

    /** group_id. */
    @Column(name = "group_id")
    private String groupId;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** create_time. */
    @Column(name = "update_time")
    private Date updateTime;

    public String getUserGroupId() {
        return userGroupId;
    }

    public void setUserGroupId(String userGroupId) {
        this.userGroupId = userGroupId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    
}
