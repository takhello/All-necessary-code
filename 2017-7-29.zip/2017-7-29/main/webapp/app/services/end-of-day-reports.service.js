(function() {
	"use strict";
	angular.module("adminManageApp").service("EndOfDayService", EndOfDayService);
	EndOfDayService.$injector = ["$resource"];

	function EndOfDayService($resource) {
		var services = {
			getGroupRoleList: getGroupRoleList,
			newGroupRole: newGroupRole,
			deleteGroupRole: deleteGroupRole
		};
		return services;

		function getGroupRoleList(id,onSuccess,onError) {
			var url = SERVICE_URL + 'admin/group_roles';
			var _resource = $resource(url, {
				"groupId": id
			},{
				get:{
					"method":"GET"
				}
			});
			return _resource.get(id).$promise.then(onSuccess,onError);
		}

		function newGroupRole(params, onSuccess, onError) {
			var url = SERVICE_URL + 'admin/group_role';
			var _resource = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess, onError);
		}

		function deleteGroupRole(groupRoleId,onSuccess,onError) {
			var url = SERVICE_URL + 'admin/group_role/' + groupRoleId;
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}
	}
})();