(function() {
	"use strict";

	angular.module("adminManageApp").service('ManageService', ManageService);

	ManageService.$injector = ['$resource'];

	function ManageService($resource) {
		var services = {
			getManageList: getManageList
		};
		console.log('调用服务');
		return services;
		//update role service
		function getManageList(params,onSuccess,onError) {
			var url = SERVICE_URL + "/v1/admin/admin_users";
		//	var url = "http://cangzdwcis01:8699/mypage-admin/v1/admin/admin_users";
			console.log("地址变量:"+url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
	}
})();