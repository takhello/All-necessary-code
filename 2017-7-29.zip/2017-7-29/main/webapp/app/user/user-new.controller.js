(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserAddController', UserAddController);
	UserAddController.$injector = ['$scope', 'RoleService', '$modal', '$modalInstance'];

	function UserAddController($scope, RoleService, $modal, $modalInstance) {
		var vm = this;
		vm.addRoleCancel = addRoleCancel;
		vm.addUser = addUser;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;
		vm.userGroup =testData();

		function testData(){
			console.log('测试数据 success');
			return [

					{
						"userId": "bsnpb12",
						"name": "Jack",
						"department": "MyPage",
						"adminGroupList": [{
							"groupId": "8ac885275d5e6d4b015d5e6df6ad0000",
							"groupName": "AdminGroup",
							"groupDesc": null,
							"groupStatus": null,
							"createTime": null,
							"updateTime": null
						}]
					}, 
					{
						"userId": "bsnpc15",
						"name": "winger",
						"department": "IT",
						"adminGroupList": [{
							"groupId": "8ac885275d5e6d4b015d5e6df6ad0000",
							"groupName": "AdminGroup",
							"groupDesc": null,
							"groupStatus": null,
							"createTime": null,
							"updateTime": null
						}]
					}, 
					{
						"userId": "bsnpb2h",
						"name": "john",
						"department": "IT",
						"adminGroupList": [{
							"groupId": "8ac885275d5e6d4b015d5e6df6ad0000",
							"groupName": "AdminGroup",
							"groupDesc": null,
							"groupStatus": null,
							"createTime": null,
							"updateTime": null
						}]
					}, 
					{
						"userId": "bsnpb11",
						"name": "Jason",
						"department": "MyPage",
						"adminGroupList": [{
							"groupId": "8ac885275d5e6d4b015d5e6df6ad0000",
							"groupName": "AdminGroup",
							"groupDesc": null,
							"groupStatus": null,
							"createTime": null,
							"updateTime": null
						}]
					}

				];
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addUser() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
						"userLANID":vm.userLANID,
						"userName":vm.userName,
						"userTelephon":vm.userTelephon,
						"userEmail":vm.userEmail,
						"userDepartment":vm.userDepartment
					// "roleName": vm.roleName,
					// "roleDesc": vm.roleDesc,
					// "roleStatus": vm.roleStatus
				}
			};
			console.log(obj);
			RoleService.newRole(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();