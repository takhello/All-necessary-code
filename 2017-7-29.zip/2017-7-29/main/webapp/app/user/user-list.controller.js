(function() {
	"use strict";
	angular.module('adminManageApp').controller("UserController", UserController);
	UserController.$injector = ['$scope', 'ManageService', '$modal', '$state'];

	function UserController($scope, ManageService, $modal, $state) {
		var vm = this;
		vm.deleteRole = deleteRole;
		vm.editRole = editRole;
		vm.addRole = addRole;
		vm.getFunction = getFunction;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.getManageList = getManageList;

		getManageList();
		// function getUserToFunction(id) {
		// 	console.log('getUserToFunction');
		// 	$state.go('home.user.user-function', {
		// 		id: id
		// 	});
		// }

		function getManageList() {
			var obj = {
				userId:"",
				country:"",
				language:"",
				sessionId:""
			};
			ManageService.getManageList(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			console.log('1');
			console.log(result)
			vm.ManageList = result.data.adminUserList;
			console.log(vm.ManageList.adminGroupList);
			console.log('2');

		}

		function failCallback(error) {
			if (error.data.code === 403) {
				$state.go('home.403');
			}
		}

		function deleteRole(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "RoleDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					roleData: function() {
						return vm.roles;
					},
					roleId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getManageList);
		}

		function editRole(role) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "RoleEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editRoleIdItem: function() {
						return role.roleId;
					},

					RoleData: function() {
						return role;
					}
				}
			});
			modalInstance.result.then(getManageList);
		}

		function addRole() {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getManageList);
		}
		function getFunction(UserId) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-function.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserFunctionController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getManageList);
		}
	}

})();