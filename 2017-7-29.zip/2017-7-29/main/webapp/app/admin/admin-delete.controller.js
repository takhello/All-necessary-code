(function() {
	"use strict";

	angular.module("adminManageApp").controller("AdminDeleteController", AdminDeleteController);
	AdminDeleteController.$injector = ['$scope', '$modalInstance', 'AdminService', 'adminId', 'adminData'];

	function AdminDeleteController($scope, $modalInstance, AdminService, adminId, adminData) {
		var vm = this;
		vm.deleteAdminCancel = deleteAdminCancel;
		vm.deleteAdminConfirm = deleteAdminConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;
		function deleteAdminCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteAdminConfirm() {
			AdminService.deleteAdmin(adminId,vm.successCallback,vm.failCallback);
		}

		function successCallback(result){
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error){
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

	}

})();