(function(){
	"use strict";
	angular.module("adminManageApp").directive("checkboxDirective", function() {
		return {
			template: '<label>'+
		               	'<input type="checkbox" class="flat-red">'+
		               '</label>',

			controller: function() {
				$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
			      	checkboxClass: 'icheckbox_flat-green',
			      	radioClass: 'iradio_flat-green'
			    });
			}
		};
	});

})();