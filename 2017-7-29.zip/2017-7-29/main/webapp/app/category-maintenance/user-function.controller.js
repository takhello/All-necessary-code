(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserFunctionController', UserFunctionController);
	UserFunctionController.$injector = ['$scope', 'RoleService', '$modal', '$modalInstance'];

	function UserFunctionController($scope, RoleService, $modal, $modalInstance) {
		var vm = this;
		vm.addRoleCancel = addRoleCancel;
		vm.addRoleConfirm = addRoleConfirm;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;
		vm.userAdmin =testData();
		vm.reportAdmin =testData1();
		
		// getRoleList();

		function testData(){
			console.log('user-Lisr测试数据 success');
			return {
					data1:{userAdmin:"User List"},
					data2:{userAdmin:"Group List1"},
					data3:{userAdmin:"Group List2"}
				};
		}
		function testData1(){
			console.log('user-Lisr测试数据 success');
			return {
					data1:{reportAdmin:"Statical Reports"},
					data2:{reportAdmin:"Statical1 "},
					data3:{reportAdmin:"Statical2 "},
					data4:{reportAdmin:"Statical Reports"},
					data5:{reportAdmin:"End of Day Reports"}
				};
		}
		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addRoleConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
						"userLANID":vm.userLANID,
						"userName":vm.userName,
						"userTelephon":vm.userTelephon,
						"userEmail":vm.userEmail,
						"userDepartment":vm.userDepartment
					// "roleName": vm.roleName,
					// "roleDesc": vm.roleDesc,
					// "roleStatus": vm.roleStatus
				}
			};
			RoleService.newRole(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();