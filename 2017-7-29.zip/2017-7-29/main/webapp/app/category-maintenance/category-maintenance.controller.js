(function() {
	"use strict";
	angular.module('adminManageApp').controller("CategoryMaintenanceController", CategoryMaintenanceController);
	CategoryMaintenanceController.$injector = ['$scope', 'RoleService', '$modal', '$state'];

	function CategoryMaintenanceController($scope, RoleService, $modal, $state) {
		var vm = this;
		vm.getRoleList = getRoleList;
		vm.deleteCategory = deleteCategory;
		vm.editCategory = editCategory;
		vm.Category = Category;
		// vm.getFunction = getFunction;
		// console.log('getUserToFunctionaaaaa');

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		vm.roles =testData();
		vm.productName =testProductNameData();
		// 有效函数
		vm.SearchProduct = SearchProduct;
		
		// getRoleList();

		function testData(){
			return {
					data:{
							data1:{UserId:"1231230",UserName:"bbb",Department:"ccc",Group:"ddd"},
							data2:{UserId:"1231230",UserName:"bbb",Department:"ccc",Group:"ddd"},
							data3:{UserId:"1231230",UserName:"bbb",Department:"ccc",Group:"ddd"},
							data4:{UserId:"1231230",UserName:"bbb",Department:"ccc",Group:"ddd"},
					},
					
				};
		}
		function testProductNameData(){
			console.log('user-Lisr测试数据 success');
		return {
				data1:{productName:"Life Protection"},
				data2:{productName:"Medical Protection"},
				data3:{productName:"Critical Illness Protection"},
				data4:{productName:"Accident Protection"},
				data5:{productName:"Savings"},
				data6:{productName:"Investments"},
				data7:{productName:"Disability Income Protection"},
				data8:{productName:"Travel & Lifestyle"}
			};
		}
		//处理数据
		function SearchProduct(){
			var $productName=$(".productName").val();	
			var $productCode=$(".productCode").val();	
			vm.isProductName = $productName;
			vm.isProductCode = $productCode;
			console.log($productName);
			console.log($productCode);
		}
		

		// function getUserToFunction(id) {
		// 	console.log('getUserToFunction');
		// 	$state.go('home.user.user-function', {
		// 		id: id
		// 	});
		// }

		
		function getRoleList() {
			var obj = {
				roleName: vm.roleName,
				roleStatus: vm.roleStatus
			};
			RoleService.getRoleList(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.roles = result.data.roleList;
			
		}

		function failCallback(error) {
			if (error.data.code === 403) {
				$state.go('home.403');
			}
		}

		function deleteCategory(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/category-maintenance/category-maintenance-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "CategoryMaintenanceDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					roleData: function() {
						return vm.roles;
					},
					roleId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getRoleList);
		}

		function editCategory(role) {
			
			var modalInstance = $modal.open({
				templateUrl: "app/category-maintenance/category-maintenance-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "CategoryMaintenanceEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editRoleIdItem: function() {
						return role.UserId;
					},

					RoleData: function() {
						return role;
					}
				}
			});
			modalInstance.result.then(getRoleList);
		}

		function Category() {
			var modalInstance = $modal.open({
				templateUrl: "app/category-maintenance/category-maintenance-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "CategoryMaintenanceNewController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getRoleList);
		}
		// function getFunction(UserId) {
		// 	var modalInstance = $modal.open({
		// 		templateUrl: "app/user/user-function.html"+"?datestamp="+(new Date()).getTime(),
		// 		backdrop: false,
		// 		controller: "UserFunctionController",
		// 		controllerAs: "vm",
		// 		size: 'md'
		// 	});
		// 	modalInstance.result.then(getRoleList);
		// }
	}

})();