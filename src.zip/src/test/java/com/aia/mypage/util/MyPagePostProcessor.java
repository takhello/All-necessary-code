package com.aia.mypage.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.aia.mypage.service.ConfigService;
import com.aia.mypage.service.UserFunctionService;
import com.aia.mypage.service.UserRoleService;
import com.aia.mypage.service.impl.ConfigServiceImpl;

public class MyPagePostProcessor implements BeanPostProcessor {

    Log LOG = LogFactory.getLog(MyPagePostProcessor.class);

    @Mock
    private UserRoleService userRoleService;

    @Mock
    private UserFunctionService userFunctionService;

    @Mock
    private ConfigService mockConfigSrv;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {

        if (beanName.equals("userRoleService")) {
            LOG.info("initial to mock UserRoleServiceImpl");
            MockitoAnnotations.initMocks(this);
            try {
                Mockito.doNothing().when(userRoleService).initGroupRoleMap();
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return userRoleService;
        }

        if (beanName.equals("userFunctionService")) {
            LOG.info("initial to mock UserRoleServiceImpl");
            MockitoAnnotations.initMocks(this);
            try {
                Mockito.doNothing().when(userFunctionService).initGroupFunctionMap();
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return userFunctionService;
        }

        if (beanName.equals("configServiceImpl")) {
            LOG.info("initial to mock ConfigServiceImpl");
            MockitoAnnotations.initMocks(this);
            try {
                Mockito.doNothing().when(mockConfigSrv).initParamData();
            }
            catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return mockConfigSrv;
        }

        return bean;

    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

        return bean;
    }

}
