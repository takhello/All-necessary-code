package com.aia.mypage.rest.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.service.AdminUserService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AdminUserControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AdminUserService mockAdminUserService;

    @InjectMocks
    private AdminUserController mockAdminUserController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockAdminUserController).build();
    }

    @Test
    public void testGetAdminUserSuccess() throws Exception {
//        List<AdminUserInfo> mockList = new ArrayList<AdminUserInfo>();
//        Mockito.when(mockAdminUserService.getAdminUserListByAccountName(Mockito.any(AdminUserInfo.class)))
//                .thenReturn(mockList);
//       // @formatter:off  
//       mockMvc
//           .perform(
//               get("/admin/admin_users")
//               .param("accountName","name")
//           )
//           .andExpect(status().isOk())
//           .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//       // @formatter:on
    }

    @Test
    public void testGetAccountUserFailedNoAccountName() throws Exception {
//       // @formatter:off  
//       mockMvc
//           .perform(
//               get("/admin/user")
//           )
//           .andExpect(status().is(550))
//           .andExpect(jsonPath("$.message", equalTo(paramRequired("accountName"))));
//       // @formatter:on
    }

    @Test
    public void testGetAccountUserFailedNullAccountName() throws Exception {
//       // @formatter:off  
//       mockMvc
//           .perform(
//               get("/admin/user")
//               .param("accountName","")
//           )
//           .andExpect(status().is(550))
//           .andExpect(jsonPath("$.message", equalTo(paramRequired("accountName"))));
//       // @formatter:on
    }

    @Test
    public void testGetAccountUserFailedNoUser() throws Exception {
//        Mockito.when(mockAdminUserService.getAccountUserByAccountName(Mockito.anyString())).thenReturn(null);
//       // @formatter:off  
//       mockMvc
//           .perform(
//               get("/admin/user")
//               .param("accountName","s")
//           )
//           .andExpect(status().is(550))
//           .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.USER_UNREGISTERED)));
//       // @formatter:on
    }

    @Test
    public void testGetAccountUserSuess() throws Exception {
//        AccountUserInfo mockAccountUser = new AccountUserInfo();
//        mockAccountUser.setAccountId(1);
//        Mockito.when(mockAdminUserService.getAccountUserByAccountName(Mockito.anyString())).thenReturn(mockAccountUser);
//       // @formatter:off  
//       mockMvc
//           .perform(
//               get("/admin/user")
//               .param("accountName","s")
//           )
//           .andExpect(status().isOk())
//           .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//       // @formatter:on
    }

    @Test
    public void testAddAdminNoUserId() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        errorjsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testAddAdminNullUserId() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "");
//        errorjsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testAddAdminFailed() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "111");
//        errorjsonMap.put("data", data);
//        Mockito.when(mockAdminUserService.addAdminUser(Mockito.anyString())).thenReturn(null);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.USER_UNREGISTERED)));
//        // @formatter:on
    }

    @Test
    public void testAddAdminSuccess() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "111");
//        errorjsonMap.put("data", data);
//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setCreateTime(new Date());
//        Mockito.when(mockAdminUserService.addAdminUser(Mockito.anyString())).thenReturn(mockAdminUser);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    @Test
    public void testDeleteAdminisDefault() throws Exception {

//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setIsDefault("Y");
//        Mockito.when(mockAdminUserService.getAdminUserByUserId(Mockito.anyInt())).thenReturn(mockAdminUser);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                delete("/admin/admin_user/1")
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(isDefault("adminUser"))));
//        // @formatter:on
    }

    @Test
    public void testDeleteAdminSuccess() throws Exception {
//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setIsDefault("N");
//        Mockito.when(mockAdminUserService.getAdminUserByUserId(Mockito.anyInt())).thenReturn(mockAdminUser);
//        Mockito.when(mockAdminUserService.deleteAdminByUserId(Mockito.anyInt())).thenReturn(true);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                delete("/admin/admin_user/1")
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    @Test
    public void testUpdateAdminNoIsEnabled() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("isEnabled", "");
//        errorjsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                put("/admin/admin_user/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("isEnabled"))));
//        // @formatter:on
    }

    @Test
    public void testUpdateAdminNullIsEnabled() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        errorjsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                put("/admin/admin_user/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("isEnabled"))));
//        // @formatter:on
    }

    @Test
    public void testUpdateAdminisDefault() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("isEnabled", "Y");
//        errorjsonMap.put("data", data);
//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setIsDefault("Y");
//        Mockito.when(mockAdminUserService.getAdminUserByUserId(Mockito.anyInt())).thenReturn(mockAdminUser);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                put("/admin/admin_user/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(isDefault("adminUser"))));
//        // @formatter:on
    }

    @Test
    public void testUpdateAdminFailed() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("isEnabled", "Y");
//        errorjsonMap.put("data", data);
//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setIsDefault("N");
//        Mockito.when(mockAdminUserService.getAdminUserByUserId(Mockito.anyInt())).thenReturn(mockAdminUser);
//        Mockito.when(mockAdminUserService.updateAdmin(Mockito.any(AdminUser.class))).thenReturn(false);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                put("/admin/admin_user/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.UPDATE_FAILED)));
//        // @formatter:on
    }

    @Test
    public void testUpdateAdminSuccess() throws Exception {
//        Map<String, Object> errorjsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("isEnabled", "Y");
//        errorjsonMap.put("data", data);
//        AdminUser mockAdminUser = new AdminUser();
//        mockAdminUser.setIsDefault("N");
//        Mockito.when(mockAdminUserService.getAdminUserByUserId(Mockito.anyInt())).thenReturn(mockAdminUser);
//        Mockito.when(mockAdminUserService.updateAdmin(Mockito.any(AdminUser.class))).thenReturn(true);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                put("/admin/admin_user/1")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(errorjsonMap))
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }

}
