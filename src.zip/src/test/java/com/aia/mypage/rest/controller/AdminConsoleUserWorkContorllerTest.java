package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import org.hibernate.exception.ViolatedConstraintNameExtracter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Account;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.util.BaseUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
		"file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AdminConsoleUserWorkContorllerTest {

	private MockMvc mockMvc;

	@InjectMocks
	private AdminConsoleUserWorkContorller mockAdminConsoleUserWorkContorller;

	@Mock
	private AccountService mockAccountService;


	private Map<String, Object> successjsonMap;

	@Before
	public void init() {

		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(mockAdminConsoleUserWorkContorller).build();

	}

	@Test
	public void testLockAndUnlockSuccess() throws Exception {

		Account mockAccount = new Account();
		mockAccount.setFailedCounter(6);
		mockAccount.setUserId(1);

		Mockito.when(mockAccountService.lockAndUnlockUser(Mockito.any(Account.class))).thenReturn(mockAccount);

		mockMvc
			.perform
				(put("/admin/user_lock/{custId}", 1).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(JSONObject.toJSONString(successjsonMap)))
				.andExpect(status().is(200)).andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
		// @formatter:off
	}

	@Test
	public void testLockAndUnlockError() throws Exception {

		mockMvc.perform(put("/admin/user_lock/{custId}", 0).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(JSONObject.toJSONString(successjsonMap)))
				.andExpect(status().is(550)).andExpect(jsonPath("$.message", equalTo("query fialed")));

	}

	@Test
	public void testChangeUserStatusSuccess() throws Exception {
		Account mockAccount = new Account();
		mockAccount.setFailedCounter(6);
		mockAccount.setUserId(1);
		mockAccount.setIsEnabled("Y");

		Mockito.when(mockAccountService.changeUserStatus(Mockito.any(Account.class))).thenReturn(mockAccount);

		mockMvc.perform(put("/admin/user_isEnabled/{custId}", 11).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(JSONObject.toJSONString(successjsonMap)))
				.andExpect(status().is(200)).andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
	}

	@Test
	public void testChangeUserStatusError() throws Exception {

		mockMvc.perform(put("/admin/user_isEnabled/{custId}", 1).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON).content(JSONObject.toJSONString(successjsonMap)))
				.andExpect(status().is(550)).andExpect(jsonPath("$.message", equalTo("query fialed")));
	}

}
