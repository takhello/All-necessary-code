'use strict';

describe('mypage-admin:controllers',function(){
	
	beforeEach(module('adminManageApp'));
	
	describe('GroupRoleDeleteController',function(){
		var scope, modalInstance, controller, groupToRoleService, groupRoleId, state;
		beforeEach(inject(function($rootScope, $controller, GroupToRoleService,$state) {
			groupToRoleService = GroupToRoleService;
			state = $state;
			groupRoleId = "12345";
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('GroupRoleDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupToRoleService: groupToRoleService,
				groupRoleId: groupRoleId
			});
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		describe('Test two case about delete groupRole && test callback function',function(){
			beforeEach(inject(function(){
				spyOn(state,'reload');
				spyOn(groupToRoleService,'deleteGroupRole');
			}));
			it('test:deleteSuccessCallback',function(){
				controller.callback();
				expect(state.reload).toHaveBeenCalledWith('home.group.group-role');
			});
			it('test confirm delete groupRole',function(){
				controller.deleteGroupRoleCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test cancel delete groupRole',function(){
				controller.deleteGroupRoleConfirm();
				expect(groupToRoleService.deleteGroupRole).toHaveBeenCalled();
			});
		});
	});
});