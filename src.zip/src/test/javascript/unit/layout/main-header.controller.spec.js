"use strict";

describe('mypage-admin:controllers', function() {
	beforeEach(module('adminManageApp'));
	describe('MainHeaderController', function() {
		var scope, controller, userProfileService;
		beforeEach(inject(function($rootScope, $controller, UserProfileService) {
			userProfileService = UserProfileService;
			scope = $rootScope.$new();
			controller = $controller('MainHeaderController', {
				$scope: scope,
				UserProfileService: UserProfileService
			});
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback({
					"success": true,
					"code": 200,
					"message": "Successfully processed. ",
					"detailedMessage": "",
					"data": {
						"profile": {
							"userId": "100003",
							"firstName": "John",
							"lastName": "Mu",
							"isEnabled": "Y"
						}
					}
				});
				expect(controller.firstName).toBeDefined();
				expect(controller.lastName).toBeDefined();
			});
			it('failCallback', function() {
				controller.failCallback();
				expect(controller.firstName).toBe('Default');
				expect(controller.lastName).toBe('User');
			});
		});
	});
});