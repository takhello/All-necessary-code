'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminEditController', function() {
		var scope, modalInstance, controller, adminService;
		beforeEach(inject(function($rootScope, $controller, AdminService) {
			adminService = AdminService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('AdminEditController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminService: adminService,
				adminData: {
					"userId": "",
					"partyId": "",
					"sessionId": "123456",
					"country": "en",
					"language": "en-SG",
					"data": {
						"isEnabled": "Y"
					}
				},
				adminId: "888"
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});

		describe('Test callback function', function() {
			it('test:close error message callback function', function() {
				controller.closeError();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about edit Admin', function() {
			beforeEach(inject(function() {
				spyOn(adminService, 'editAdmin');
			}));
			it('should confirm save edit Admin data', function() {
				controller.editAdminConfirm();
				expect(adminService.editAdmin).toHaveBeenCalled();
			});
			it('should cancel edit Admin data', function() {
				controller.editAdminCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});

	});


});