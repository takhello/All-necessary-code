'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('PermissionController', function() {
		var scope, modalInstance, controller, permissionService, modal;
		beforeEach(inject(function($rootScope, $controller, PermissionService, $modal) {
			scope = $rootScope.$new();
			permissionService = PermissionService;
			modal = $modal;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('PermissionController', {
				$scope: scope,
				$modalInstance: modalInstance,
				PermissionService: permissionService,
			});
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		describe('Test:Callback function', function() {
			it('should test successCallback', function() {
				controller.successCallback({
					"data": {
						"permissionList": [{
							"permissionId": "1",
							"permissionName": "Policy",
							"permissionDesc": "Get Policy List",
							"permissionType": "API",
							"permissionPattern": "/customer/policies",
							"permissionMethod": "GET",
							"permissionStatus": "Y",
							"isOtp": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.permissions).toBeDefined();
			});
		});

		describe('PermissionService:call', function() {
			beforeEach(inject(function() {
				spyOn(permissionService, 'getPermission');
			}));
			it('permissionService:getPermissionList', function() {
				controller.name = 'sss';
				controller.type = '01';
				controller.pattern = 'sss';
				controller.method = 'GET';
				controller.status = 'Y';
				controller.isOTP = 'Y';
				controller.getPermissionList();
				expect(permissionService.getPermission).toHaveBeenCalled();
			});
		});
		describe('Test:callback function', function() {
			it('should return data when run successCallback', function() {
				controller.successCallback({
					data: {
						permissionList: {}
					}
				});
				expect(controller.permissions).toBeDefined();
			});
		});
		describe('Test:operation function', function() {
			it('should test deletePermission', function() {
				controller.deletePermission();
				expect(modal.open).toBeDefined();
			});
			it('should test editPermission', function() {
				controller.editPermission({
					"permissionName": "Policy",
					"permissionDesc": "Get Policy list",
					"permissionType": "01",
					"permissionPattern": "/custome/policies",
					"permissionMethod": "GET",
					"permissionStatus": "Y",
					"isOTP": "Y"
				});
				expect(modal.open).toBeDefined();
			});
			it('should test addPermission', function() {
				controller.addPermission();
				expect(modal.open).toBeDefined();
			});
		});
	});
});