(function() {
	"use strict";
	angular.module('adminManageApp').controller("UserController", UserController);
	UserController.$injector = ['$scope', 'UserManageAccessService', '$modal', '$state'];

	function UserController($scope, UserManageAccessService, $modal, $state) {
		var vm = this;
		vm.deleteUser = deleteUser;
		vm.editUserManage = editUserManage;
		vm.newUser = newUser;
		vm.getFunction = getFunction;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.getManageList = getManageList;
		vm.roles = roles;
		getManageList();
		// function getUserToFunction(id) {
		// 	$state.go('home.user.user-function', {
		// 		id: id
		// 	});
		// }
		function roles(){

		}
		function getManageList() {
			var obj = {
				userId:"",
				country:"",
				language:"",
				sessionId:""
			};
			UserManageAccessService.getManageList(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.ManageList = result.data.adminUserList;
		}

		function failCallback(error) {
			if (error.data.code === 403) {
				$state.go('home.403');
			}
		}

		function deleteUser(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					roleData: function() {
						return vm.roles;
					},
					roleId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getManageList);
		}

		function editUserManage(user) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editUserIdItem: function() {
						return user.userId;
					},

					UserData: function() {
						return user;
					}
				}
			});
			modalInstance.result.then(getManageList);
		}

		function newUser() {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserNewController",
				controllerAs: "vm",
				size: 'md'
			});

			modalInstance.result.then(getManageList);
		}

		function getFunction(user) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-function.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserFunctionController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					getIdViewFunction: function() {
						return user.userId;
					}
				}
			});
			modalInstance.result.then(getManageList);
		}
	}

})();