(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserFunctionController', UserFunctionController);
	UserFunctionController.$injector = ['$scope', 'UserManageAccessService', '$modal', '$modalInstance','getIdViewFunction'];

	function UserFunctionController($scope, UserManageAccessService, $modal, $modalInstance,getIdViewFunction) {
		var vm = this;
		console.log('1');
	
		console.log('2');

		vm.nullFunction = "No function is assigned";
		vm.addRoleCancel = addRoleCancel;
		vm.getIdFunction = getIdFunction;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		vm.userAdmin =testData();
		vm.reportAdmin =testData1();
		
		// vm.hiddenFunction = hiddenFunction;
		getIdFunction();
		// getRoleList();

		function testData(){
			console.log('user-Lisr测试数据 success');
			return {
					data1:{userAdmin:"User List"},
					data2:{userAdmin:"Group List1"},
					data3:{userAdmin:"Group List2"}
				};
		}
		function testData1(){
			console.log('user-Lisr测试数据 success');
			return {
					data1:{reportAdmin:"Statical Reports"},
					data2:{reportAdmin:"Statical1 "},
					data3:{reportAdmin:"Statical2 "},
					data4:{reportAdmin:"Statical Reports"},
					data5:{reportAdmin:"End of Day Reports"}
				};
		}
		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}
		function getIdFunction() {
			$(".functionList5").hide();
			$(".viewShow").hide();
			$("#functionList5").hide();
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"language": USER_LANGUAGE
			};
			UserManageAccessService.getIdFunction(getIdViewFunction,obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			$(".viewShow").show();
			vm.userIdFunction = result.data.functionList;

			vm.FunctionList = result.data.functionList;
			console.log(result.data.functionList);
			vm.checkedFunctionLevel = serializeData(result.data.functionList,"parentFunctionId","10","20","30","40");
			console.log(vm.checkedFunctionLevel);

			vm.functionList1 = vm.checkedFunctionLevel._obj1;
			vm.functionList2 = vm.checkedFunctionLevel._obj2;
			vm.functionList3 = vm.checkedFunctionLevel._obj3;
			vm.functionList4 = vm.checkedFunctionLevel._obj4;

			console.log(vm.functionList1);
			console.log(vm.functionList2);
			console.log(vm.functionList3);
			console.log(vm.functionList4);
			function serializeData(data,key,val1,val2,val3,val4){
				var obj ={
					_obj1:[],
					_obj2:[],
					_obj3:[],
					_obj4:[]
				};
				var index = 0;

				for (var i=0; i < data.length;  i++) {

					if(data[i][key] == val1){
						obj._obj1.push({functionName:data[i].functionName}); 
					}else if(data[i][key] == val2){
						obj._obj2.push({functionName:data[i].functionName});
					}else if(data[i][key] == val3){
						obj._obj3.push({functionName:data[i].functionName}); 
					}else if(data[i][key] == val4){
						obj._obj4.push({functionName:data[i].functionName}); 
					}
				}

				return obj;
			}

			vm.isAlertHide = true;
			// $modalInstance.close('cancel');
			hiddenFunction();
			}

		function hiddenFunction(){
			if( JSON.stringify(vm.functionList1) === '[]' && JSON.stringify(vm.functionList2) === '[]' && JSON.stringify(vm.functionList3) === '[]' && JSON.stringify(vm.functionList4) === '[]'){
				$(".functionList5").show();
				$("#functionList5").show();
				console.log('3');
			}
			if(JSON.stringify(vm.functionList1) === '[]'){
				$(".functionList1").hide();
			}
			 if(JSON.stringify(vm.functionList2) === '[]'){
				$(".functionList2").hide();
			}
			 if(JSON.stringify(vm.functionList3) === '[]'){
				$(".functionList3").hide();
			}
			 if(JSON.stringify(vm.functionList4) === '[]'){
				$(".functionList4").hide();
			}
			
			
		}

		function failCallback(error) {
			$(".viewShow").show();
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}




	}
})();