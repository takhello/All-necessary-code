(function() {
	"use strict";

	angular.module("adminManageApp").controller('CategoryMaintenanceEditController', CategoryMaintenanceEditController);
	CategoryMaintenanceEditController.$injector = ['$scope', '$modal', '$modalInstance', 'editRoleIdItem', 'RoleData', 'RoleService'];

	function CategoryMaintenanceEditController($scope, $modal, $modalInstance, editRoleIdItem, RoleData, RoleService) {
		var vm = this;
		vm.RoleData = RoleData;
		vm.closeError = closeError;
		vm.editRoleCancel = editRoleCancel;
		vm.editRoleConfirm = editRoleConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;
		vm.modalVal = angular.copy(RoleData);

		vm.productCategory =userGroup();
		vm.searchNewProduct =searchNewProduct();
		vm.policvDetail = policvDetail();

		function userGroup(){
			return {
					data1:{productCategory:"Life Protection"},
					data2:{productCategory:"Medical Protection"},
					data3:{productCategory:"Critical Illness Protection"},
					data4:{productCategory:"Accident Protection"},
					data5:{productCategory:"Savings"},
					data6:{productCategory:"Investments"},
					data7:{productCategory:"Disability Income Protection"},
					data8:{productCategory:"Travel & Lifestyle"}
				};
		}

		function searchNewProduct(){
			return {

					data1:{searchNewProduct:"Life Protection "}
				};
		}
		function policvDetail(){
			return {
					data1:{policvDetail:"Traditional List"},
					data2:{policvDetail:"Investment Linked"},
					data3:{policvDetail:"Annuity"},
					data4:{policvDetail:"Hospitalization"},
					data5:{policvDetail:"Others"}
				};
		}
		function closeError(){
			vm.isAlertHide = true;
		}

		function editRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function editRoleConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.modalVal
			};
			RoleService.editRole(editRoleIdItem, object, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();