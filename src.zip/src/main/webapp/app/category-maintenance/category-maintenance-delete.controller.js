(function() {
	"use strict";

	angular.module("adminManageApp").controller("CategoryMaintenanceDeleteController", CategoryMaintenanceDeleteController);
	CategoryMaintenanceDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'RoleService', 'roleId', 'roleData'];

	function CategoryMaintenanceDeleteController($scope, $modal, $modalInstance, RoleService, roleId, roleData) {
		var vm = this;
		vm.deleteRoleCancel = deleteRoleCancel;
		vm.deleteRoleConfirm = deleteRoleConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;

		function deleteRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteRoleConfirm() {
			RoleService.deleteRole(roleId,vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();