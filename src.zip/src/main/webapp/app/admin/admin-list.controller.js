(function() {
	"use strict";
	angular.module("adminManageApp").controller("AdminController", AdminController);
	AdminController.$injector = ['$scope', 'AdminService', '$modal', '$rootScope','$state'];

	function AdminController($scope, AdminService, $modal, $rootScope, $state) {
		var vm = this;
		vm.addAdmin = addAdmin;
		vm.deleteAdmin = deleteAdmin;
		vm.editAdmin = editAdmin;
		vm.getAdminList = getAdminList;
		vm.getAdminGroupList = getAdminGroupList;
		vm.successCallback = successCallback;
		vm.isAlertHide = true;
		getAdminList();

		function successCallback(result) {
			vm.admins = result.data.userList;
		}

		function getAdminGroupList(id){
			$state.go("home.admin.admin-group", {
				id: id
			});
		}

		function addAdmin(){
			var modalInstance = $modal.open({
				templateUrl: "app/admin/admin-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "AdminAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getAdminList);
		}

		function deleteAdmin(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/admin/admin-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "AdminDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					adminId: function() {
						return id;
					},
					adminData: function() {
						return vm.admins;
					}
				}
			});
			modalInstance.result.then(getAdminList);
		}


		function editAdmin(admin) {
			var modalInstance = $modal.open({
				templateUrl: "app/admin/admin-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "AdminEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					adminId: function() {
						return admin.userId;
					},
					adminData: function() {
						return admin;
					}
				}
			});
			modalInstance.result.then(getAdminList);
		}

		function getAdminList() {
			var obj = {
				"firstName": vm.firstName,
				"lastName": vm.lastName,
				"isEnabled": vm.isEnabled
			};
			AdminService.getAdmin(obj,vm.successCallback);
		}


	}
})();