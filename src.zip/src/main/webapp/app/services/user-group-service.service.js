(function(){
	"use strict";
	angular.module("adminManageApp").service("UserGroupService",UserGroupService);
	UserGroupService.$injector = ['$resource'];
	function UserGroupService($resource){
		var _service = {
			getGroupList:getGroupList,
			createUser:createUser,
			editUserConfirm:editUserConfirm,
			deleteUser:deleteUser,
			getIdUser:getIdUser
		};
		return _service;


		function getGroupList(params,onSuccess,onError){
			var url = SERVICE_URL + "v1/admin/admin_groups";
			// var url ="http://cangzdwcis01:8699/mypage-admin/v1/admin/admin_groups";
			console.log(url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}

		function createUser(params, onSuccess, onError) {
			var url = SERVICE_URL + "v1/admin/admin_user";
			// var url ="http://cangzdwcis01:8699/mypage-admin/v1/admin/admin_user";

			var _resources = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resources.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}

		//edit User service
		function editUserConfirm(id, params, onSuccess, onError) {
			console.log(params);
			var url = SERVICE_URL + "v1/admin/admin_user/" + id;
			// v1/admin/admin_user/{user_id}
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params,
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}

		//delete an existed role service
		function deleteUser(id,onSuccess,onError) {
			console.log(id);
			var url = SERVICE_URL + "v1/admin/admin_user/" + id;
			// /v1/admin/admin_user/{user_id}
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}

		//get id user
		function getIdUser(id,params, onSuccess, onError){
			var url = SERVICE_URL + "v1/admin/admin_user/" + id;
			// /v1/admin/admin_user/{user_id}
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
		}

	}


})();