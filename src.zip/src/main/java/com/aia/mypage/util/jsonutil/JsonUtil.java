package com.aia.mypage.util.jsonutil;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class JsonUtil {
    public static <T> Object JSONToObj(String jsonStr, Class<T> obj) {
        T t = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            t = objectMapper.readValue(jsonStr, obj);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return t;
    }

    public static Map<String, String> toHashMap(String JSONStr) {

        Map<String, String> data = new LinkedHashMap<String, String>();
        JSONObject obj = JSONObject.parseObject(JSONStr);
        Iterator<String> iter = obj.keySet().iterator();
        while (iter.hasNext()) {
            String key = iter.next();
            data.put(key, obj.getString(key));
        }
        return data;
    }

    public static Map<String, Object> getHashMapfromJsonString(String jsonStr) {

        Map<String, Object> dataMap = new LinkedHashMap<String, Object>();
        if (StringUtils.isBlank(jsonStr)) {
            return dataMap;
        }
        JSONObject obj = JSONObject.parseObject(jsonStr);
        Iterator<String> iter = obj.keySet().iterator();
        String key;
        while (iter.hasNext()) {
            key = iter.next();
            Object value = obj.get(key);
            if (value instanceof JSONObject) {
                getDataFromJsonObject((JSONObject) value, dataMap);
            } else if (value instanceof JSONArray) {
                getDataFromJSONArray(key, (JSONArray) value, dataMap);
            } else {
                dataMap.put(key, value);
            }
        }
        return dataMap;
    }

    private static void getDataFromJsonObject(JSONObject jsonObject, Map<String, Object> dataMap) {

        Set<String> keyset = jsonObject.keySet();
        for (String key : keyset) {
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                getDataFromJsonObject((JSONObject) value, dataMap);
            } else if (value instanceof JSONArray) {
                getDataFromJSONArray(key, (JSONArray) value, dataMap);
            } else {
                dataMap.put(key, value);
            }
        }

    }

    private static void getDataFromJSONArray(String key, JSONArray jsonArray, Map<String, Object> dataMap) {

        int size = jsonArray.size();
        for (int i = 0; i < size; i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONObject) {
                getDataFromJsonObject((JSONObject) value, dataMap);
            } else if (value instanceof JSONArray) {
                getDataFromJSONArray(key, (JSONArray) value, dataMap);
            } else {
                dataMap.put(key, jsonArray);
                return;
            }
        }

    }

}
