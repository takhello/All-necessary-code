package com.aia.mypage.util.errorMessage;

public class ErrorCodeUtil {
    // Admininistration work-User Management
    // Add failed.
    public static final int ERROR_CODE_52001 = 52001;
    
    // User Id already exists.
    public static final int ERROR_CODE_52002 = 52002;
    
    // The association of admin and user doesn't exist.
    public static final int ERROR_CODE_52003 = 52003;
    
    // Delete failed.
    public static final int ERROR_CODE_52004 = 52004;
    
    // Update failed.
    public static final int ERROR_CODE_52005 = 52005;
    
    
    // Admin Group doesn't exist.
    public static final int ERROR_CODE_52101 = 52101;
    
    // The association of user and group already exist. if you want to delete this user, please delete all associations first.
    public static final int ERROR_CODE_52102 = 52102;
}
