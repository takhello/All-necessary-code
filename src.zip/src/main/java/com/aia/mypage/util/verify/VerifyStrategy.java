package com.aia.mypage.util.verify;

public interface VerifyStrategy {
	
	public boolean paramVerify(String[] paramArray);

}
