package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.FunctionDAO;
import com.aia.mypage.entity.Function;
import com.aia.mypage.service.FunctionService;

public class FunctionServiceImpl implements FunctionService {

    @Autowired
    @Qualifier("functionDAOImpl")
    private FunctionDAO functionDAO;

    @Override
    public List<Function> getFunctionsList(String functionId) {
        return functionDAO.getFunctionsList(functionId);
    }

    @Override
    public List<Function> getFunctionsListByUserId(String userId) {
        return functionDAO.getFunctionsListByUserId(userId);
    }

}
