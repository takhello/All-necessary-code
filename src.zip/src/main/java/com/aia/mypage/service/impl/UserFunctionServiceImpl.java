package com.aia.mypage.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.GroupFunctionMapDAO;
import com.aia.mypage.entity.GroupFunctionMapVO;
import com.aia.mypage.service.UserFunctionService;
import com.aia.mypage.util.BaseUtil;

public class UserFunctionServiceImpl implements UserFunctionService {

	@Autowired
	@Qualifier("groupFunctionMapDAOImpl")
	private GroupFunctionMapDAO groupFunctionMapDAO;

	@Override
	public void initGroupFunctionMap() throws Exception {

		BaseUtil.groupIdFunctionListMapping = initGroupFunctionMapping();
	}

	public Map<String, List<GroupFunctionMapVO>> initGroupFunctionMapping() {

		Map<String, List<GroupFunctionMapVO>> groupFunction = new HashMap<String, List<GroupFunctionMapVO>>();

		List<GroupFunctionMapVO> groupFunctionMapVOs = groupFunctionMapDAO.getAllGroupFunctionMap();

		List<GroupFunctionMapVO> functionList = null;

		String groupIdOrg = "";

		if (groupFunctionMapVOs != null && groupFunctionMapVOs.size() > 0) {

			for (int i = 0; i < groupFunctionMapVOs.size(); i++) {
				GroupFunctionMapVO groupRoleVO = groupFunctionMapVOs.get(i);
				String groupId = groupRoleVO.getGroupId();

				if (!groupIdOrg.equals(groupId)) {
					groupIdOrg = groupId;
				} else {
					continue;
				}

				functionList = new ArrayList<GroupFunctionMapVO>();
				functionList.add(groupRoleVO);
				for (int j = i + 1; j < groupFunctionMapVOs.size(); j++) {
					GroupFunctionMapVO groupFunctionVO2 = groupFunctionMapVOs.get(j);
					if (groupFunctionVO2.getGroupId().equals(groupIdOrg)) {
						functionList.add(groupFunctionVO2);
					}

				}
				groupFunction.put(groupIdOrg, functionList);
			}
		}

		return groupFunction;

	}
}
