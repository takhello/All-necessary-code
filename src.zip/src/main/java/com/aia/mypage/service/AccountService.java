package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.UserWorkInfo;

public interface AccountService {

    Account getAccountByAccountName(String accountName);

    Account lockAndUnlockUser(Account account);

    Account changeUserStatus(Account account);

    List<UserWorkInfo> getAccountListByIdName(String custId, String custName);

    Account getAccountByUserId(Integer userId);

}
