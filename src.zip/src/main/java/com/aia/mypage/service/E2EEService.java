package com.aia.mypage.service;

import java.net.MalformedURLException;

import org.apache.xmlrpc.XmlRpcException;

public interface E2EEService {

    void unLockeUser(String custId) throws MalformedURLException, XmlRpcException;

}
