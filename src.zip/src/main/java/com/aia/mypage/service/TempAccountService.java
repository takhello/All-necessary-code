package com.aia.mypage.service;

import com.aia.mypage.entity.TempAccount;

public interface TempAccountService {

    TempAccount addTempAccount(Integer accountId);

    TempAccount getTempAccountByVerifyString(String verifyString);

    int updatePasswordVerifyString(int id);

}
