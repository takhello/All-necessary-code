package com.aia.mypage.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.ConfigDAO;
import com.aia.mypage.entity.Config;
import com.aia.mypage.service.ConfigService;
import com.aia.mypage.util.constant.ConfigConstant;

public class ConfigServiceImpl implements ConfigService {

    @Autowired
    @Qualifier("configDAOImpl")
    private ConfigDAO configDAO;

    @Override
    public List<Config> getConfigList() {

        return configDAO.queryConfigList();
    }

    public void initParamData() throws Exception {

        ConfigConstant.configMap = getConfigLists();

    }

    public Map<String, String> getConfigLists() {

        List<Config> configList = configDAO.queryConfigList();
        Map<String, String> configMap = new HashMap<String, String>();
        if (configList.isEmpty()) {
            return configMap;
        }
        for (Config config : configList) {
            configMap.put(config.getKeyCode(), config.getValue());
        }

        return configMap;
    }
}
