package com.aia.mypage.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.GroupRoleMapDAO;
import com.aia.mypage.entity.GroupRoleMapVO;
import com.aia.mypage.service.UserRoleService;
import com.aia.mypage.util.BaseUtil;

public class UserRoleServiceImpl implements UserRoleService {

//    @Autowired
//    @Qualifier("userDAOImpl")
//    private UserDAO userDAO;
//
//    @Autowired
//    @Qualifier("userRoleDAOImpl")
//    private UserRoleDAO userRoleDAO;

    @Autowired
    @Qualifier("groupRoleMapDAOImpl")
    private GroupRoleMapDAO groupRoleMapDAO;

    public void initGroupRoleMap() throws Exception {
        BaseUtil.groupIdRoleListMapping = initGroupRoleMapping();
    }

    public Map<String, List<GroupRoleMapVO>> initGroupRoleMapping() {

        Map<String, List<GroupRoleMapVO>> groupRole = new HashMap<String, List<GroupRoleMapVO>>();
        List<GroupRoleMapVO> groupRoleMap = groupRoleMapDAO.getAllGroupRoleMap();
        List<GroupRoleMapVO> roleList = null;
        String groupIdOrg = "";

        if (groupRoleMap != null && groupRoleMap.size() > 0) {

            for (int i = 0; i < groupRoleMap.size(); i++) {
                GroupRoleMapVO groupRoleVO = groupRoleMap.get(i);
                String groupId = groupRoleVO.getGroupId();

                if (!groupIdOrg.equals(groupId)) {
                    groupIdOrg = groupId;
                } else {
                    continue;
                }

                roleList = new ArrayList<GroupRoleMapVO>();
                roleList.add(groupRoleVO);
                for (int j = i + 1; j < groupRoleMap.size(); j++) {
                    GroupRoleMapVO groupRoleVO2 = groupRoleMap.get(j);
                    if (groupRoleVO2.getGroupId().equals(groupIdOrg)) {
                        roleList.add(groupRoleVO2);
                    }

                }
                groupRole.put(groupIdOrg, roleList);
            }
        }

        return groupRole;
    }

}
