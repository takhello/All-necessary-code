package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Function;

public interface FunctionService {

    List<Function> getFunctionsList(String functionId);
    
    List<Function> getFunctionsListByUserId(String userId);

}
