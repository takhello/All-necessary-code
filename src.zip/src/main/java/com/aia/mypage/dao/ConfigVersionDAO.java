package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.ConfigVersion;

public interface ConfigVersionDAO {

    List<ConfigVersion> getConfigVersionList();

    ConfigVersion addConfigVersion(ConfigVersion configVersion);

}
