package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class UserGroupDAOImpl extends JPABaseRepImpl<UserGroup> implements UserGroupDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public List<UserGroup> getUserGroupListByGroupId(String groupId) {
        StringBuffer sql = new StringBuffer("from UserGroup where groupId = :groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    public boolean deleteUserGroupById(Integer userGroupId) {
        super.remove(userGroupId);
        return true;
    }

    @Override
    public UserGroup addUserGroup(UserGroup userGroup) {
        return super.create(userGroup);
    }

    @Override
    public UserGroup getSameUserGroup(int userId, String groupId) {
        StringBuffer sql = new StringBuffer("from UserGroup where groupId = :groupId and userId =:userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        parameters.put("userId", userId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public List<UserGroup> getUserGroupsListByUserId(int userId) {
        StringBuffer sql = new StringBuffer("from UserGroup where userId = :userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("userId", userId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);
    }

    @Override
    public UserGroup getUserGroupById(Integer userGroupId) {

        return super.find(userGroupId);
    }

}
