package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminGroupFunctionInfoDAO;
import com.aia.mypage.entity.AdminGroupFunctionInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminGroupFunctionInfoDAOImpl extends JPABaseRepImpl<AdminGroupFunctionInfo>
        implements AdminGroupFunctionInfoDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<AdminGroupFunctionInfo> getAdminGroupFunctionInfo(String groupId) {
        StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.AdminGroupFunctionInfo")
                .append("(ag.groupId,ag.groupName,ag.groupDesc,ag.groupStatus,")
                .append("f.functionId,f.functionName,f.functionLevel,f.parentFunctionId) ")
                .append(" from AdminGroup ag,AdminGroupFunction agf,Function f ")
                .append(" where ag.groupId = agf.groupId")
                .append("   and agf.functionId  = f.functionId")
                .append("   and ag.groupId =:groupId");

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);

        return query(sqlParameters);
    }

}
