package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.GroupRole;

public interface GroupRoleDAO {

    List<GroupRole> getGroupRoleListByRoleId(String roleId);

    boolean deleteGroupRoleById(int groupRoleId);

    List<GroupRole> getGroupRoleListByGroupId(String groupId);

    GroupRole addGroupRole(GroupRole groupRole);

    GroupRole hasSameGroupRole(String groupId, String roleId);

    List<GroupRole> getGroupRoleList();

    GroupRole getGroupRoleListById(Integer groupRoleId);

}
