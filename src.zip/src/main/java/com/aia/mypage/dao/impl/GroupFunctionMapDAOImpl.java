package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.GroupFunctionMapDAO;
import com.aia.mypage.entity.GroupFunctionMapVO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class GroupFunctionMapDAOImpl extends JPABaseRepImpl<GroupFunctionMapVO> implements GroupFunctionMapDAO{
	
	@Override
	protected EntityManager getEntityManager() {
		return null;
	}

	@Override
	public List<GroupFunctionMapVO> getAllGroupFunctionMap() {
		StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.GroupFunctionMapVO(gf.groupId,f.functionId,f.functionName)");
		sql.append("from AdminGroupFunction gf,Function f where gf.functionId = f.functionId order by gf.groupId");

		 Map<String, Object> parameters = new HashMap<String, Object>();
	        SqlParameters sqlParameters = new SqlParameters(sql, parameters);

	        return super.query(sqlParameters);
	}

	

	
}
