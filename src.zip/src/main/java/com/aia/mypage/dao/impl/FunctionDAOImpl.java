package com.aia.mypage.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.aia.mypage.dao.FunctionDAO;
import com.aia.mypage.entity.Function;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class FunctionDAOImpl extends JPABaseRepImpl<Function> implements FunctionDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<Function> getFunctionsList(String functionId) {
        StringBuffer sql = new StringBuffer("from Function ");

        Map<String, Object> parameters = new HashMap<String, Object>();
        if (StringUtils.isNotEmpty(functionId)) {
            sql.append(" where functionId =:functionId");
            parameters.put("functionId", functionId);
        }

        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<Function> functionList = super.query(sqlParameters);
        return functionList;
    }

    @Override
    public List<Function> getFunctionsListByUserId(String userId) {

        if (StringUtils.isEmpty(userId)) {
            return new ArrayList<Function>();
        }
        StringBuffer sql = new StringBuffer();
        sql.append(
                "select new Function(f.functionId,f.functionName,f.url,f.functionDesc,f.functionLevel,f.parentFunctionId,f.functionStatus)")
                .append(" from Function f,AdminUserGroup aug,AdminGroup ag,AdminGroupFunction agf")
                .append(" where aug.userId=:userId")
                .append("   and aug.groupId=ag.groupId")
                .append("   and ag.groupId=agf.groupId")
                .append("   and agf.functionId=f.functionId");

        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("userId", userId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<Function> functionList = super.query(sqlParameters);
        return functionList;
    }

}
