package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfoVO;

public interface AdminUserDAO {

    AdminUserInfoVO getAdminUserInfoByAccountName(String accountName);
    
    List<AdminUser> getAllAdminUsers();

}
