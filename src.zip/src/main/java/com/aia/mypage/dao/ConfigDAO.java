package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Config;

public interface ConfigDAO {

    Config queryByKey(String keyCode);
    
    List<Config> queryConfigList();
}
