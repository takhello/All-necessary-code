package com.aia.mypage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.UserRoleDAO;
import com.aia.mypage.entity.UserRole;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class UserRoleDAOImpl extends JPABaseRepImpl<UserRole> implements UserRoleDAO {

    @Override
    public List<UserRole> getList() {
        String sql = "select new com.aia.mypage.entity.UserRole"
                + " (user.userId, userGroup.groupId, role.roleId, role.roleName)"
                + " from User user, UserGroup userGroup, GroupRole groupRole, Role role "
                + "where user.userId=userGroup.userId and userGroup.groupId = groupRole.groupId and role.roleId=groupRole.roleId order by user.userId asc ";
        return super.queryByNoParamters(sql);
    }

    @Override
    protected EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return null;
    }
}
