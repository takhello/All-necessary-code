package com.aia.mypage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminFunctionDAO;
import com.aia.mypage.entity.Function;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminFunctionDAOImpl extends JPABaseRepImpl<Function> implements AdminFunctionDAO{

	@Override
	public List<Function> getAllFunction() {
		
		return super.queryByNoParamters("from Function");
	}

	@Override
	protected EntityManager getEntityManager() {
		return null;
	}

}
