package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "T_ERROR_MESSAGE")
public class ErrorMessage implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -3315434601741402519L;

    @Id
    @SequenceGenerator(name = "SEQ_T_ERROR_MESSAGE_ID", sequenceName = "SEQ_T_ERROR_MESSAGE_ID", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ_T_ERROR_MESSAGE_ID")
    @Column(name = "id")
    private String id;

    @Column(name = "language", nullable = false)
    private String language;

    @Column(name = "error_code", nullable = false)
    private String errorCode;

    @Column(name = "error_content", nullable = false)
    private String errorContent;

    @Transient
    @Column(name = "error_description")
    private String errorDescription;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorContent() {
        return errorContent;
    }

    public void setErrorContent(String errorContent) {
        this.errorContent = errorContent;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String toString() {
        return "ErrorMessage [id=" + id + ", language=" + language + ", errorCode=" + errorCode + ", errorContent="
                + errorContent + ", errorDescription=" + errorDescription + "]";
    }
}
