package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "T_AUDIT_LOG")
@Entity
public class AuditLog implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -7283269817525045515L;

    /** log_id. */
    @Id
    @SequenceGenerator(name = "SEQ_T_AUDIT_LOG_ID", sequenceName = "SEQ_T_AUDIT_LOG_ID", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ_T_AUDIT_LOG_ID")
    @Column(name = "log_id")
    private Integer logId;

    /** user_id. */
    @Column(name = "user_id")
    private Integer userId;

    /** log_type. */
    @Column(name = "log_type")
    private String logType;

    /** log_desc. */
    @Column(name = "log_desc")
    private String logDesc;

    /** user_ip. */
    @Column(name = "user_ip")
    private String userIp;

    /** request_method */
    @Column(name = "request_method")
    private String requestMethod;

    /** request_header. */
    @Column(name = "request_header")
    private String requestHeader;

    /** request_uri. */
    @Column(name = "request_uri")
    private String requestUri;

    /** request_body. */
    @Column(name = "request_body")
    private String requestBody;

    /** response_result_code. */
    @Column(name = "response_result_code")
    private String responseResultCode;

    /** response_result. */
    @Column(name = "response_result")
    private String responseResult;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * Constructor.
     */
    public AuditLog() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getLogDesc() {
        return logDesc;
    }

    public void setLogDesc(String logDesc) {
        this.logDesc = logDesc;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public Integer getLogId() {
        return this.logId;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getLogType() {
        return this.logType;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getCreateTime() {
        return this.createTime;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getRequestHeader() {
        return requestHeader;
    }

    public void setRequestHeader(String requestHeader) {
        this.requestHeader = requestHeader;
    }

    public String getRequestUri() {
        return requestUri;
    }

    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public String getResponseResultCode() {
        return responseResultCode;
    }

    public void setResponseResultCode(String responseResultCode) {
        this.responseResultCode = responseResultCode;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

}
