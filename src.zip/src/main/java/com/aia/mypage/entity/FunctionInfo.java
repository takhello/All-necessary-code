package com.aia.mypage.entity;

import java.io.Serializable;

public class FunctionInfo implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 3067753721570650581L;

    private String functionId;

    private String functionName;

    public FunctionInfo(String functionId, String functionName) {
        this.functionId = functionId;
        this.functionName = functionName;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(String functionName) {
        this.functionName = functionName;
    }

}
