package com.aia.mypage.entity;

public class AdminPermission {
	
	private String userid;
	
	private String userName;
	
	private String functionId;
	
	private String permissionStatus;
	
	private String permissionPattern;
	
	private String url;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPermissionStatus() {
		return permissionStatus;
	}

	public void setPermissionStatus(String permissionStatus) {
		this.permissionStatus = permissionStatus;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getPermissionPattern() {
		return permissionPattern;
	}

	public void setPermissionPattern(String permissionPattern) {
		this.permissionPattern = permissionPattern;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
	

}
