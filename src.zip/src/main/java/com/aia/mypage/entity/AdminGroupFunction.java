package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "T_ADMIN_GROUP_FUNCTION")
@Entity
public class AdminGroupFunction implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -4278617519261030751L;

    /** group_function_id. */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "group_function_id")
    private String groupFunctionId;

    /** group_id. */
    @Column(name = "group_id")
    private String groupId;

    /** function_id. */
    @Column(name = "function_id")
    private String functionId;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** create_time. */
    @Column(name = "update_time")
    private Date updateTime;

    public String getGroupFunctionId() {
        return groupFunctionId;
    }

    public void setGroupFunctionId(String groupFunctionId) {
        this.groupFunctionId = groupFunctionId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
