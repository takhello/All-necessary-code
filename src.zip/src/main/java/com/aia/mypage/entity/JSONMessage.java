package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Map;

public class JSONMessage implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -7057677934008828739L;
    private String userId;
    private String partyId;
    private String sessionId;
    private String country;
    private String language;
    private Map<Object, Object> data;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Map<Object, Object> getData() {
        return data;
    }

    public void setData(Map<Object, Object> data) {
        this.data = data;
    }

}
