package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Function;
import com.aia.mypage.service.FunctionService;
import com.aia.mypage.util.BaseUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class FunctionController extends BaseController {

    @Autowired
    @Qualifier("functionServiceImpl")
    private FunctionService functionService;

    @ResponseBody
    @RequestMapping(value = "/functions", method = RequestMethod.GET)
    public Map<String, Object> getFunctionList(HttpServletRequest request, HttpServletResponse response) {
        String functionId = request.getParameter("functionId");

        List<Function> functionList = functionService.getFunctionsList(functionId);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("functionList", functionList);
        successJson.put("data", data);
        return successJson;

    }

    @ResponseBody
    @RequestMapping(value = "/function/{user_id}", method = RequestMethod.GET)
    public Map<String, Object> getFunctionsListByUserId(@PathVariable String user_id, HttpServletRequest request,
            HttpServletResponse response) {

        if (StringUtils.isEmpty(user_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("user_id"));
        }

        List<Function> functionList = functionService.getFunctionsListByUserId(user_id);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("functionList", functionList);
        successJson.put("data", data);
        return successJson;

    }
}
