package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class PermissionController extends BaseController {

    @Autowired
    @Qualifier("permissionServiceImpl")
    private PermissionService permissionService;

    @Autowired
    @Qualifier("rolePermissionServiceImpl")
    private RolePermissionService rolePermissionService;

    /**
     * Get permissions list.
     * 
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unused")
    @ResponseBody
    @RequestMapping(value = "/permissions", method = RequestMethod.GET)
    public Map<String, Object> getPermissionsList(HttpServletRequest request, HttpServletResponse response) {

        String userId = request.getParameter("userId");
        String sessionId = request.getParameter("sessionId");
        String country = request.getParameter("country");
        String language = request.getParameter("language");
        String permissionId = request.getParameter("permissionId");
        String permissionName = request.getParameter("permissionName");
        String permissionType = request.getParameter("permissionType");
        String permissionPattern = request.getParameter("permissionPattern");
        String permissionMethod = request.getParameter("permissionMethod");
        String permissionStatus = request.getParameter("permissionStatus");
        String isOTP = request.getParameter("isOTP");

        Permission permission = new Permission();
        permission.setPermissionId(permissionId);
        permission.setPermissionName(permissionName);
        permission.setPermissionType(permissionType);
        permission.setPermissionPattern(permissionPattern);
        permission.setPermissionStatus(permissionStatus);
        permission.setPermissionMethod(permissionMethod);
        permission.setIsOTP(isOTP);

        List<Permission> permissionList = permissionService.getPermissionsList(permission);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("permissionList", permissionList);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * Add permission.
     * 
     * @param jsonMessage
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/permission", method = RequestMethod.POST)
    public Map<String, Object> addPermission(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyPermission(data);
        Object object = verifyMap.get("permission");
        if (object == null) {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

        Permission permission = (Permission) verifyMap.get("permission");
        permissionService.addPermission(permission);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * Delete permission by permission_id.
     * 
     * @param permission_id
     * @param request
     * @param response
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/permission/{permission_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deletePermission(@PathVariable String permission_id, HttpServletRequest request,
            HttpServletResponse response) {

        Permission permission = permissionService.getPermissionById(permission_id);
        if (permission == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.PERMISSION_UNREGISTERED);
        }
        String isDefault = permission.getIsDefault();
        if (BaseUtil.IS_DEFAULT_Y.equals(isDefault)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("permission"));
        }

        List<RolePermission> rolePermissionList = rolePermissionService.getRolePermissionByPermissionId(permission_id);
        if (rolePermissionList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ROLE_PERMISSION_MAPPING);
        }

        permissionService.deletePermissionById(permission_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * update permission by permission_id.
     * 
     * @param jsonMessage
     * @param permission_id
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/permission/{permission_id}", method = RequestMethod.PUT)
    public Map<String, Object> updatePermission(@PathVariable String permission_id,
            @RequestBody Map<String, Object> jsonMap, HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyPermission(data);
        Object object = verifyMap.get("permission");
        if (object == null) {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

        Permission permission = permissionService.getPermissionById(permission_id);
        if (permission == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.PERMISSION_UNREGISTERED);
        }

        String isDefault = permission.getIsDefault();
        if (BaseUtil.IS_DEFAULT_Y.equals(isDefault)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("permission"));
        }

        permission = (Permission) verifyMap.get("permission");
        permission.setPermissionId(permission_id);
        permissionService.updatePermissionById(permission);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * verify input if Null.
     * 
     * @param data
     * @return
     */
    public Map<String, Object> verifyPermission(Map<String, Object> data) {
        Map<String, Object> errorjson = new LinkedHashMap<String, Object>();
        String permissionName = (String) data.get("permissionName");
        if ("".equals(permissionName) || permissionName == null) {
            errorjson.put("errorKey", "permissionName");
            return errorjson;
        }
        String permissionDesc = (String) data.get("permissionDesc");
        if ("".equals(permissionDesc) || permissionDesc == null) {
            errorjson.put("errorKey", "permissionDesc");
            return errorjson;
        }
        String permissionType = (String) data.get("permissionType");
        if ("".equals(permissionType) || permissionType == null) {
            errorjson.put("errorKey", "permissionType");
            return errorjson;
        }
        String permissionPattern = (String) data.get("permissionPattern");
        if ("".equals(permissionPattern) || permissionPattern == null) {
            errorjson.put("errorKey", "permissionPattern");
            return errorjson;
        }
        String permissionMethod = (String) data.get("permissionMethod");
        if ("".equals(permissionMethod) || permissionMethod == null) {
            errorjson.put("errorKey", "permissionMethod");
            return errorjson;
        }
        String permissionStatus = (String) data.get("permissionStatus");
        if ("".equals(permissionStatus) || permissionStatus == null) {
            errorjson.put("errorKey", "permissionStatus");
            return errorjson;
        }
        String isOTP = (String) data.get("isOTP");
        if ("".equals(isOTP) || isOTP == null) {
            errorjson.put("errorKey", "isOTP");
            return errorjson;
        }
        Permission permission = new Permission();
        permission.setPermissionName(permissionName);
        permission.setPermissionDesc(permissionDesc);
        permission.setPermissionType(permissionType);
        permission.setPermissionPattern(permissionPattern);
        permission.setPermissionMethod(permissionMethod);
        permission.setPermissionStatus(permissionStatus);
        permission.setIsOTP(isOTP);
        errorjson.put("permission", permission);
        return errorjson;
    }
}
