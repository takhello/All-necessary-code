package com.aia.mypage.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.dao.AdminUserAdminGroupDAO;
import com.aia.mypage.dao.AdminUserDAO;
import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.AdminGroup;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserAdminGroupInfo;
import com.aia.mypage.entity.GroupFunctionMapVO;
import com.aia.mypage.entity.GroupRoleMapVO;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.ldap.LdapUserInfo;

public class MyPageUserDetailsService implements UserDetailsService {

	private static final Log LOG = LogFactory.getLog(MyPageUserDetailsService.class);
	
	@Autowired
	@Qualifier("adminUserDAOImpl")
	private AdminUserDAO adminUserDAO;

	@Autowired
	@Qualifier("userGroupDAOImpl")
	private UserGroupDAO userGroupDAO;

	@Autowired
	@Qualifier("adminUserAdminGroupDAOImpl")
	private AdminUserAdminGroupDAO adminUserAdminGroupDAO;

	@Autowired
	@Qualifier("adminUserAUDAOImpl")
	private AdminUserAUDAO adminUserAUDAO;

	@SuppressWarnings("null")
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		boolean isEnabled = true;

		AdminUser adminUser = adminUserAUDAO.getAdminUserByUserId(username);

		if (adminUser == null || !"y".equalsIgnoreCase(adminUser.getStatus())) {

			isEnabled = false;
		}

		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		
		// default role for login
		authorities.add(new SimpleGrantedAuthority(BaseUtil.DEFAULT_ROLE_FOR_LOGIN));

		List<UserGroup> groupIds = userGroupDAO.getUserGroupsListByUserId(1);

		LOG.info("groupIds == " + groupIds);
		if (groupIds != null && groupIds.size() > 0) {

			for (int i = 0; i < groupIds.size(); i++) {
				List<GroupRoleMapVO> groupRoleMap = BaseUtil.groupIdRoleListMapping.get(groupIds.get(i).getGroupId());
				if (groupRoleMap != null && groupRoleMap.size() > 0) {
					for (int j = 0; j < groupRoleMap.size(); j++) {
						authorities.add(new SimpleGrantedAuthority("ROLE_" + groupRoleMap.get(j).getRoleName()));
					}
				}
			}

		}

		List<AdminUserAdminGroupInfo> adminGroupIds = adminUserAdminGroupDAO.getAllAdminUserAdminGroup(username);

		LOG.info("adminGroupIds == " + adminGroupIds);
		if (isListEmpty(adminGroupIds)) {

			for (AdminUserAdminGroupInfo adminGroupInfo : adminGroupIds) {

				List<AdminGroup> adminUserGroups = adminGroupInfo.getAdminGroupList();
				
				if (!isListEmpty(adminUserGroups)) {
					break;
				}

				for (int i = 0; i < adminUserGroups.size(); i++) {

					//authorities.add(new SimpleGrantedAuthority("ROLE_"+adminUserGroups.get(i).getGroupName()));

					List<GroupFunctionMapVO> groupFunctionMap = BaseUtil.groupIdFunctionListMapping
							.get(adminUserGroups.get(i).getGroupId());

					if (!isListEmpty(groupFunctionMap)) {
						break;
					}

					for (int j = 0; j < groupFunctionMap.size(); j++) {

						authorities.add(

								new SimpleGrantedAuthority("ROLE_" + groupFunctionMap.get(j).getFunctionName()));
					}
				}

			}

		}

		LOG.info("authorities == " + authorities);

		return new MyPageUser(username, "", isEnabled, true, true, true, authorities, username);
	}

	public static boolean isListEmpty(List<?> lis) {

		if (lis == null || lis.size() <= 0) {

			return false;
		}

		return true;
	}

}
