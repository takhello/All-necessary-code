package com.aia.mypage.framework;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.oauth2.provider.error.AbstractOAuth2SecurityExceptionHandler;
import org.springframework.security.web.access.AccessDeniedHandler;

import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

public class MyPageAccessDeniedHandler extends AbstractOAuth2SecurityExceptionHandler implements AccessDeniedHandler {

    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException authException)
            throws IOException, ServletException {

        Map errorJson = new HashedMap();

        errorJson.put(BaseUtil.SUCCESS, BaseUtil.SUCCESS_FALSE);
        errorJson.put(BaseUtil.MESSAGE, ErrorMessageUtil.ACCESS_DENIED);
        errorJson.put(BaseUtil.CODE_NAME, "403");

        response.setStatus(403);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(JSONObject.toJSONString(errorJson));

    }
}
