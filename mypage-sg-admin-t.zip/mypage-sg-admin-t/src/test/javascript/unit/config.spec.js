'use strict';

describe('test:config module',function(){
	beforeEach(module('adminManageApp'));
	it('_debugMode',function(){

	});
	it('_enableDebugMode',function(){

	});
	it('_disableDebugMode',function(){

	});
	it('_checkLogStatus',function(){
		
	});
});