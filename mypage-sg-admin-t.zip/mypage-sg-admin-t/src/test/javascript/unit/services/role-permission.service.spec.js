'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:RoleToPermissionService service', function() {
		var $resource, RoleToPermissionService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_RoleToPermissionService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			RoleToPermissionService = _RoleToPermissionService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test RoleToPermissionService newRolePermission',function(){
			spyOn(RoleToPermissionService,'newRolePermission').and.callThrough();
			RoleToPermissionService.newRolePermission({},function(){},function(){});
			expect(RoleToPermissionService.newRolePermission).toHaveBeenCalled();
		});
		it('test RoleToPermissionService deleteRolePermission',function(){
			spyOn(RoleToPermissionService,'deleteRolePermission').and.callThrough();
			RoleToPermissionService.deleteRolePermission('123',function(){},function(){});
			expect(RoleToPermissionService.deleteRolePermission).toHaveBeenCalled();
		});
		it('test RoleToPermissionService getRolePermissionList',function(){
			spyOn(RoleToPermissionService,'getRolePermissionList').and.callThrough();
			RoleToPermissionService.getRolePermissionList();
			expect(RoleToPermissionService.getRolePermissionList).toHaveBeenCalled();
		});
		it('test RoleToPermissionService getAllRolePermission',function(){
			spyOn(RoleToPermissionService,'getAllRolePermission').and.callThrough();
			RoleToPermissionService.getAllRolePermission({},function(){},function(){});
			expect(RoleToPermissionService.getAllRolePermission).toHaveBeenCalled();
		});
	});
});