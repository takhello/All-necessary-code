'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:VersionService service', function() {
		var $resource, VersionService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_VersionService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			VersionService = _VersionService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test VersionService newVersion',function(){
			spyOn(VersionService,'newVersion').and.callThrough();
			VersionService.newVersion({},function(){},function(){});
			expect(VersionService.newVersion).toHaveBeenCalled();
		});
		it('test VersionService getVersion',function(){
			spyOn(VersionService,'getVersion').and.callThrough();
			VersionService.getVersion({},function(){},function(){});
			expect(VersionService.getVersion).toHaveBeenCalled();
		});
	});
});