'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:AdminToGroupService service', function() {
		var $resource, AdminToGroupService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_AdminToGroupService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			AdminToGroupService = _AdminToGroupService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test AdminToGroupService newAdminGroup',function(){
			spyOn(AdminToGroupService,'newAdminGroup').and.callThrough();
			AdminToGroupService.newAdminGroup({},function(){},function(){});
			expect(AdminToGroupService.newAdminGroup).toHaveBeenCalled();
		});
		it('test AdminToGroupService deleteAdminGroup',function(){
			spyOn(AdminToGroupService,'deleteAdminGroup').and.callThrough();
			AdminToGroupService.deleteAdminGroup('123',function(){},function(){});
			expect(AdminToGroupService.deleteAdminGroup).toHaveBeenCalled();
		});
		it('tset AdminToGroupService getAdminGroupList',function(){
			spyOn(AdminToGroupService,'getAdminGroupList').and.callThrough();
			AdminToGroupService.getAdminGroupList();
			expect(AdminToGroupService.getAdminGroupList).toHaveBeenCalled();
		});
	});
});