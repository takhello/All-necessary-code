'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupRoleController', function() {
		var scope, modalInstance, controller, groupToRoleService, roleService, modal, state;
		beforeEach(inject(function($rootScope, $controller, GroupToRoleService, RoleService, $modal, $state) {
			scope = $rootScope.$new();
			groupToRoleService = GroupToRoleService;
			roleService = RoleService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('GroupRoleController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupToRoleService: groupToRoleService,
				RoleService: roleService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('should back to home.group status', function() {
				controller.backToGroup();
				expect(state.go).toHaveBeenCalledWith('home.group');
			});
		});
		describe('Test callback function', function() {
			beforeEach(inject(function() {
				spyOn(roleService, 'getRoleList');
			}));
			it('test:loadSuccessCallback', function() {
				controller.loadSuccessCallback({
					"data": {
						"groupRoleList": [{
							"groupRoleId": "1",
							"isDefault": "Y",
							"groupId": "1",
							"groupName": "Group1",
							"groupDesc": "Group1 Desc",
							"groupStatus": "Y",
							"roleId": "1",
							"roleName": "Role1",
							"roleDesc": "Role1 Desc",
							"roleStatus": "Y"
						}]
					}

				});
				expect(controller.currentRoles).toBeDefined();
			});
			it('test:groupRoleSelected', function() {
				controller.groupRoleSelected();
				expect(roleService.getRoleList).toHaveBeenCalled();
			});
			it('test:selectedSuccessCallback--case1', function() {
				controller.currentRoles = [];
				controller.selectedSuccessCallback({
					"data": {
						"roleList": [{
							"roleId": "1",
							"roleName": "Role1",
							"roleDesc": "Role1 Desc",
							"roleStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}

				});
				expect(controller.currentRoles.length).toBe(0);
				expect(controller.selectedRoles).toBe(controller.allRoles);
			});
			it('test:selectedSuccessCallback--case2', function() {
				controller.currentRoles = [{
					"roleId": "1",
					"roleName": "Role1",
					"roleDesc": "Role1 Desc",
					"roleStatus": "Y",
					"isDefault": "Y",
					"createTime": "",
					"updateTime": ""
				}];
				controller.selectedSuccessCallback({
					"data": {
						"roleList": [{
							"roleId": "1",
							"roleName": "Role1",
							"roleDesc": "Role1 Desc",
							"roleStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.selectedRoles).toBeDefined();
			});
			it('test:selectedSuccessCallback--case3', function() {
				controller.currentRoles = [{
					"roleId": "2",
					"roleName": "Role1",
					"roleDesc": "Role1 Desc",
					"roleStatus": "Y",
					"isDefault": "Y",
					"createTime": "",
					"updateTime": ""
				}];
				controller.selectedSuccessCallback({
					"data": {
						"roleList": [{
							"roleId": "1",
							"roleName": "Role1",
							"roleDesc": "Role1 Desc",
							"roleStatus": "Y",
							"isDefault": "Y",
							"createTime": "",
							"updateTime": ""
						}]
					}
				});
				expect(controller.selectedRoles).toBeDefined();
			});
			it('test;selectedFailCallback', function() {
				controller.selectedFailCallback();
				expect(controller.selectedRoles).toBe(controller.allRoles);
			});
			it('test:deleteGroupRole', function() {
				controller.deleteGroupRole();
				expect(modal.open).toBeDefined();
				//				expect(modalInstance.ok).toHaveBeenCalled();
			});
			it('test:addGroupRole', function() {
				controller.addGroupRole();
				expect(modal.open).toBeDefined();
				//				expect(modalInstance.ok).toHaveBeenCalled();
			});
		});
	});


});