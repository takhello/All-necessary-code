'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('VersionController', function() {
		var scope, modalInstance, controller, versionService, modal, state;
		beforeEach(inject(function($rootScope, $controller, VersionService, $modal, $state) {
			scope = $rootScope.$new();
			versionService = VersionService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('VersionController', {
				$scope: scope,
				$modalInstance: modalInstance,
				VersionService: versionService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		
		 describe('VersionService:call', function() {
		 	beforeEach(inject(function() {
		 		spyOn(versionService, 'getVersion');
		 	}));
		 	it('VersionService:getVersionList', function() {
		 		controller.getVersionList();
		 		expect(versionService.getVersion).toHaveBeenCalled();
		 	});
		 });
		 describe('Test:callback function', function() {
		 	it('should return data when run successCallback', function() {
		 		controller.successCallback({
		 			data: {
		 				versionList: {}
		 			}
		 		});
		 		expect(controller.versions).toBeDefined();
		 	});
		 });
		 describe('Test:operation function', function() {
		 	it('should test addVersion', function() {
		 		controller.addVersion();
		 		expect(modal.open).toBeDefined();
		 	});
		 });

	});
});