'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupController', function() {
		var scope, modalInstance, controller, groupService, modal, state;
		beforeEach(inject(function($rootScope, $controller, GroupService, $modal, $state) {
			scope = $rootScope.$new();
			groupService = GroupService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('GroupController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupService: groupService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});
		
		 describe('RoleService:call', function() {
		 	beforeEach(inject(function() {
		 		spyOn(groupService, 'getGroupList');
		 	}));
		 	it('groupService:getGroupList', function() {
		 		controller.groupName = 'sss';
		 		controller.groupDesc = 'sss';
		 		controller.groupStatus = 'Y';
		 		controller.getGroupList();
		 		expect(groupService.getGroupList).toHaveBeenCalled();
		 	});
		 });
		 describe('Test:callback function', function() {
		 	it('should return data when run successCallback', function() {
		 		controller.successCallback({
		 			data: {
		 				groupList: {}
		 			}
		 		});
		 		expect(controller.groups).toBeDefined();
		 	});
		 	it('should link to related role', function() {
		 		controller.getGroupRoleList();
		 		expect(state.go).toHaveBeenCalled();
		 	});
		 });
		 describe('Test:operation function', function() {
		 	it('should test delete group', function() {
		 		controller.deleteGroup();
		 		expect(modal.open).toBeDefined();
		 	});
		 	it('should test editGroup', function() {
		 		controller.editGroup({
		 			"groupName": 'sss',
		 			"groupDesc": 'sss',
		 			"groupStatus": 'Y'
		 		});
		 		expect(modal.open).toBeDefined();
		 	});
		 	it('should test addGroup', function() {
		 		controller.addGroup();
		 		expect(modal.open).toBeDefined();
		 	});
		 });

	});
});