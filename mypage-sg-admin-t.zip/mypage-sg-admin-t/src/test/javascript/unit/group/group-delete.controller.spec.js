'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupDeleteController', function() {
		var scope, modalInstance, controller, groupService, groupId, groupData;
		beforeEach(inject(function($rootScope, $controller, GroupService) {
			groupService = GroupService;
			groupId = "12345";
			groupData = {
				"groupId": "1",
				"groupName": "Group1",
				"groupDesc": "Group1 Desc",
				"groupStatus": "Y",
				"isDefault": "Y",
				"createTime": "",
				"updateTime": ""
			};

			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('GroupDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupService: groupService,
				groupId: groupId,
				groupData: groupData
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about delete group', function() {
			beforeEach(inject(function() {
				spyOn(groupService, 'deleteGroup');
			}));
			it('should confirm save delete group data', function() {
				controller.deleteGroupConfirm();
				expect(groupService.deleteGroup).toHaveBeenCalled();
			});
			it('should cancel delete group data', function() {
				controller.deleteGroupCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});
	});
});