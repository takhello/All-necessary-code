'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupAddController', function() {
		var scope, modalInstance, controller , groupService;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, GroupService) {
			groupService = GroupService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('GroupAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupService: groupService
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			
		});

		describe('Test callback function',function(){
			it('should dismiss the modal with the result "false" when rejected',function(){
				controller.addGroupCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});			
			it('test:close error message callback function',function(){
				controller.errorClose();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback',function(){
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback',function(){
				controller.failCallback({
					data:{
						message:"",
						code:550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('GroupService:call',function(){
			beforeEach(inject(function(){
				spyOn(groupService,'newGroup');
			}));
			it('GroupService:newGroup',function(){
				controller.addGroupConfirm();
				expect(groupService.newGroup).toHaveBeenCalled();
			});
		});

	});


});