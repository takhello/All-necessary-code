'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('RolePermissionAddController', function() {
		var scope, modalInstance, controller, roleToPermissionService,state;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, RoleToPermissionService,$state) {
			roleToPermissionService = RoleToPermissionService;
			scope = $rootScope.$new();
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('RolePermissionAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				RoleToPermissionService: roleToPermissionService,
				roleId:"111",
				permissionid:"222"
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('Test callback function', function() {
			beforeEach(inject(function(){
				spyOn(state,'reload');
				spyOn(roleToPermissionService,'newRolePermission');
			}));
			it('should dismiss the modal with the result "false" when rejected', function() {
				controller.addRolePermissionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('Callback function', function() {
				controller.callBack();
				expect(state.reload).toHaveBeenCalledWith('home.role.role-permission');
			});
			it('roleToPermissionService:newRolePermission',function(){
				controller.addRolePermissionConfirm();
				expect(roleToPermissionService.newRolePermission).toHaveBeenCalled();
			});
		});

	});


});