'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('RolePermissionController', function() {
		var scope, modalInstance, controller, roleToPermissionService, permissionService, modal, state;
		beforeEach(inject(function($rootScope, $controller, RoleToPermissionService, PermissionService, $modal, $state) {
			scope = $rootScope.$new();
			roleToPermissionService = RoleToPermissionService;
			permissionService = PermissionService;
			modal = $modal;
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};
			controller = $controller('RolePermissionController', {
				$scope: scope,
				$modalInstance: modalInstance,
				RoleToPermissionService: roleToPermissionService,
				PermissionService: permissionService,
				$state: $state
			});
			spyOn(state, 'go');
		}));
		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('should back to home.role status', function() {
				controller.backToRole();
				expect(state.go).toHaveBeenCalledWith('home.role');
			});
		});
		describe('Test callback function', function() {
			beforeEach(inject(function() {
				spyOn(roleToPermissionService, 'getRolePermissionList');
				spyOn(roleToPermissionService, 'getAllRolePermission');
			}));
			it('test:loadSuccessCallback', function() {
				controller.loadSuccessCallback({
					"data": {
						permissionList: {}
					}
				});
				expect(controller.allPermissions).toBeDefined();
			});
			it('test:rolePermissionRelated', function() {
				controller.rolePermissionRelated();
				expect(roleToPermissionService.getRolePermissionList).toHaveBeenCalled();
			});
			it('test:relatedSuccessCallback', function() {
				controller.relatedSuccessCallback({
					"data": {
						"rolePermissionList": [{
							"rolePermissionId": "1",
							"isDefault": "Y",
							"permissionId": "1",
							"permissionName": "Policy",
							"permissionDesc": "Get Policy List",
							"permissionType": "API",
							"permissionPattern": "/customer/policies",
							"permissionMethod": "GET",
							"isOtp": "Y",
							"permissionStatus": "Y",
							"rlelId": "100001",
							"rlelName": "Policy",
							"roleDesc": "100001",
							"roleStatus": "Y"
						}]
					}
				});
				expect(controller.currentPermissions).toBeDefined();
			});
			it('test:rolePermissionSelected', function() {
				controller.rolePermissionSelected();
				expect(roleToPermissionService.getAllRolePermission).toHaveBeenCalled();
			});
			it('test:selectedSuccessCallback--case1', function() {
				controller.allPermissions = [{
					"rolePermissionId": "1",
					"isDefault": "Y",
					"permissionId": "1",
					"permissionName": "Policy",
					"permissionDesc": "Get Policy List",
					"permissionType": "API",
					"permissionPattern": "/customer/policies",
					"permissionMethod": "GET",
					"isOtp": "Y",
					"permissionStatus": "Y",
					"rlelId": "100001",
					"rlelName": "Policy",
					"roleDesc": "100001",
					"roleStatus": "Y"
				}];
				controller.selectedSuccessCallback({
					"data": {
						"rolePermissionList": [{
							"rolePermissionId": "1",
							"isDefault": "Y",
							"permissionId": "1",
							"permissionName": "Policy",
							"permissionDesc": "Get Policy List",
							"permissionType": "API",
							"permissionPattern": "/customer/policies",
							"permissionMethod": "GET",
							"isOtp": "Y",
							"permissionStatus": "Y",
							"rlelId": "100001",
							"rlelName": "Policy",
							"roleDesc": "100001",
							"roleStatus": "Y"
						}]
					}
				});
				expect(controller.selectedPermissions).toBeDefined();
				expect(controller.currentRolePermissions.length).not.toBe(0);
				expect(controller.selectedPermissions).toBeDefined();
			});
			it('test:selectedSuccessCallback--case2',function(){
				controller.allPermissions = [{
					"rolePermissionId": "1",
					"isDefault": "Y",
					"permissionId": "1",
					"permissionName": "Policy",
					"permissionDesc": "Get Policy List",
					"permissionType": "API",
					"permissionPattern": "/customer/policies",
					"permissionMethod": "GET",
					"isOtp": "Y",
					"permissionStatus": "Y",
					"rlelId": "100001",
					"rlelName": "Policy",
					"roleDesc": "100001",
					"roleStatus": "Y"
				}];
				controller.selectedSuccessCallback({
					"data": {
						"rolePermissionList": []
					}
				});
				expect(controller.selectedPermissions).toBe(controller.allPermissions);
			});
			it('test:selectedSuccessCallback--case3',function(){
				controller.allPermissions = [{
					"rolePermissionId": "1",
					"isDefault": "Y",
					"permissionId": "2",
					"permissionName": "Policy",
					"permissionDesc": "Get Policy List",
					"permissionType": "API",
					"permissionPattern": "/customer/policies",
					"permissionMethod": "GET",
					"isOtp": "Y",
					"permissionStatus": "Y",
					"rlelId": "100001",
					"rlelName": "Policy",
					"roleDesc": "100001",
					"roleStatus": "Y"
				}];
				controller.selectedSuccessCallback({
					"data": {
						"rolePermissionList": [{
							"rolePermissionId": "1",
							"isDefault": "Y",
							"permissionId": "1",
							"permissionName": "Policy",
							"permissionDesc": "Get Policy List",
							"permissionType": "API",
							"permissionPattern": "/customer/policies",
							"permissionMethod": "GET",
							"isOtp": "Y",
							"permissionStatus": "Y",
							"rlelId": "100001",
							"rlelName": "Policy",
							"roleDesc": "100001",
							"roleStatus": "Y"
						}]
					}
				});
				expect(controller.selectedPermissions).toBeDefined();
			});
			it('test:selectedFailCallback',function(){
				controller.allPermissions = [{
					"rolePermissionId": "1",
					"isDefault": "Y",
					"permissionId": "2",
					"permissionName": "Policy",
					"permissionDesc": "Get Policy List",
					"permissionType": "API",
					"permissionPattern": "/customer/policies",
					"permissionMethod": "GET",
					"isOtp": "Y",
					"permissionStatus": "Y",
					"rlelId": "100001",
					"rlelName": "Policy",
					"roleDesc": "100001",
					"roleStatus": "Y"
				}];
				controller.selectedFailCallback();
				expect(controller.selectedPermissions).toBe(controller.allPermissions);
			});			
		});
		describe('Test:operation function',function(){
			it('test:addRolePermission',function(){
				controller.addRolePermission(111);
				expect(modal.open).toBeDefined();
			});
			it('test:deleteRolePermission',function(){
				controller.deleteRolePermission(111);
				expect(modal.open).toBeDefined();
			});
		});
	});
});