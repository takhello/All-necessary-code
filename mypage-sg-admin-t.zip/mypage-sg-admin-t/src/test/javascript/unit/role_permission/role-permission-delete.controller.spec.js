'use strict';

describe('mypage-admin:controllers',function(){
	
	beforeEach(module('adminManageApp'));
	
	describe('RolePermissionDeleteController',function(){
		var scope, modalInstance, controller, roleToPermissionService, rolePermissionId, state;
		beforeEach(inject(function($rootScope, $controller, RoleToPermissionService,$state) {
			roleToPermissionService = RoleToPermissionService;
			state = $state;
			rolePermissionId = "12345";
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('RolePermissionDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				RoleToPermissionService: roleToPermissionService,
				rolePermissionId: rolePermissionId
			});
		}));
		describe('Initial state', function() {
			beforeEach(inject(function(){
				spyOn(state,'reload');
			}));
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('callBack function',function(){
				controller.callBack();
				expect(state.reload).toHaveBeenCalledWith('home.role.role-permission');
			});
		});
		describe('Test two case about delete rolePermission',function(){
			beforeEach(inject(function(){
				spyOn(roleToPermissionService,'deleteRolePermission');
			}));
			it('test confirm delete rolePermission',function(){
				controller.deleteRolePermissionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test cancel delete rolePermission',function(){
				controller.deleteRolePermissionConfirm();
				expect(roleToPermissionService.deleteRolePermission).toHaveBeenCalled();
			});
		});
	});
});