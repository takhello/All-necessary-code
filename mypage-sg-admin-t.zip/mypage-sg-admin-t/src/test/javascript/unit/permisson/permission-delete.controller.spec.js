'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('PermissionDeleteController', function() {
		var scope, modalInstance, controller, PermissionSer, perId, perData;
		beforeEach(inject(function($rootScope, $controller, PermissionService) {
			PermissionSer = PermissionService;
			perId = "12345";
			perData =  {
					"permissionName": "Policy",
					"permissionDesc": "Get Policy list",
					"permissionType": "01",
					"permissionPattern": "/custome/policies",
					"permissionMethod": "GET",
					"permissionStatus": "Y",
					"isOTP": "Y"
				};
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('PermissionDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				PermissionService: PermissionSer,
				permissionId: perId,
				permissionData: perData
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about delete permission', function() {
			beforeEach(inject(function() {
				spyOn(PermissionSer, 'deletePermission');
			}));
			it('should confirm save delete permission data', function() {
				controller.deletePermissionConfirm();
				expect(PermissionSer.deletePermission).toHaveBeenCalled();
			});
			it('should cancel delete permission data', function() {
				controller.deletePermissionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});
	});
});