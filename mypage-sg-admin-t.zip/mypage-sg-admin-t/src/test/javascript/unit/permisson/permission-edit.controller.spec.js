'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('PermissionEditController', function() {
		var scope, modalInstance, controller, PermissionSer;
		beforeEach(inject(function($rootScope, $controller, PermissionService) {
			PermissionSer = PermissionService;
			scope = $rootScope.$new();
			// editPermissionIdItem = editPermissionIdItem.$get();
			// permissionData = permissionData.$get();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('PermissionEditController', {
				$scope: scope,
				$modalInstance: modalInstance,
				PermissionService: PermissionSer,
				permissionData: {
					"permissionName": "Policy",
					"permissionDesc": "Get Policy list",
					"permissionType": "01",
					"permissionPattern": "/custome/policies",
					"permissionMethod": "GET",
					"permissionStatus": "Y",
					"isOTP": "Y"
				},
				editPermissionIdItem: '123'
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});

		describe('Test callback function', function() {
			it('test:close error message callback function',function(){
				controller.errorClose();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about edit permission', function() {
			beforeEach(inject(function() {
				spyOn(PermissionSer, 'editPermission');
			}));
			it('should confirm save edit permission data', function() {
				controller.editPermissionConfirm();
				expect(PermissionSer.editPermission).toHaveBeenCalled();
			});
			it('should cancel edit permission data',function(){
				controller.editPermissionCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});

	});


});