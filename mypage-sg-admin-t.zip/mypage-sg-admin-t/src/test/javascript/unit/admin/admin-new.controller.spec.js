'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminAddController', function() {
		var scope, modalInstance, controller, adminService;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, AdminService) {
			adminService = AdminService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('AdminAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminService: adminService
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('Test callback function', function() {
			it('test:close error message callback function', function() {
				controller.errorClose();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback', function() {
				controller.successCallback({
					"data": {
						"account": {
							"accountId": "100001",
							"userId": "100003",
							"accountName": "",
							"accountType": "00",
							"email": "email@example.com",
							"isEnabled": "Y",
							"registerType": "00",
							"picture": ""
						}
					}

				});
				expect(controller.userId).toBe("100003");
			});
			it('failCallback', function() {
				controller.failCallback({
					"success": false,
					"code": 550,
					"message": "Business exception. ",
					"detailedMessage": "",
					"data": {
						/* Application-specific data would go here. */
					}
				});
				expect(controller.isAlertHide).toBe(false);
				expect(controller.isShow).toBe(false);
			});
		});

		describe('AdminService:call && test related callback function', function() {
			beforeEach(inject(function() {
				spyOn(adminService, 'newAdmin');
				spyOn(adminService, 'getUserByAccountName');
			}));
			it('adminService:newAdmin--confirm', function() {
				controller.addAdminConfirm();
				expect(adminService.newAdmin).toHaveBeenCalled();
			});
			it('adminService:newAdmin--cancel', function() {
				controller.addAdminCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test:addSuccessCallback', function() {
				controller.addSuccessCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('test:addFailCallback', function() {
				controller.addFailCallback({
					"success": true,
					"code": 200,
					"message": "Successfully processed. ",
					"detailedMessage": "",
					"data": {}
				});
				expect(controller.isAlertHide).toBe(false);
			});
			it('adminService:getUserByAccountName', function() {
				controller.searchGeneralUser();
				expect(adminService.getUserByAccountName).toHaveBeenCalled();
			});
		});


	});


});