"use strict";

describe('mypage-admin:controllers', function() {
	beforeEach(module('adminManageApp'));
	describe('SidebarController', function() {
		var scope, modalInstance, controller, userProfileService;
		beforeEach(inject(function($rootScope, $controller, UserProfileService) {
			userProfileService = UserProfileService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('SidebarController', {
				$scope: scope,
				$modalInstance: modalInstance,
				UserProfileService: UserProfileService
			});
		}));
		describe('Initial state && test checkLogStatus', function() {
			beforeEach(inject(function(){
				spyOn(userProfileService, 'getUserProfile');
			}));
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
			it('activeMenu', function() {
				controller.activeMenu("val");
				expect(controller.isMenuStatus).toBe("val");
			});
			it('checkLogStatus when userId has value', function() {
				USER_PROFILE = {
					"userId": "100003",
					"firstName": "John",
					"lastName": "Mu",
					"isEnabled": "Y"
				};
				controller.checkLogStatus();
			});
			it('checkLogStatus when userId has not value', function() {
				USER_PROFILE = {
					"firstName": "",
					"lastName": "",
					"userId": "",
					"IsEnabled": ""
				};
				controller.checkLogStatus();
				expect(userProfileService.getUserProfile).toHaveBeenCalled();
			});
		});
		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback({
					"success": true,
					"code": 200,
					"message": "Successfully processed. ",
					"detailedMessage": "",
					"data": {
						"profile": {
							"userId": "100003",
							"firstName": "John",
							"lastName": "Mu",
							"isEnabled": "Y"
						}
					}
				});
				expect(controller.firstName).toBeDefined();
				expect(controller.lastName).toBeDefined();
			});
			it('failCallback', function() {
				controller.failCallback();
				expect(controller.firstName).toBe('Default');
				expect(controller.lastName).toBe('User');
			});
		});
	});
});