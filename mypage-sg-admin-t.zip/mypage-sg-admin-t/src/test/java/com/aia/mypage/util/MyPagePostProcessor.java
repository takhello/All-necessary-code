package com.aia.mypage.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.aia.mypage.service.UserRoleService;

public class MyPagePostProcessor implements BeanPostProcessor {

    Log LOG = LogFactory.getLog(MyPagePostProcessor.class);

    @Mock
    private UserRoleService userRoleService;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {

        if (beanName.equals("userRoleService")) {
            LOG.info("initial to mock UserRoleServiceImpl");
            MockitoAnnotations.initMocks(this);
            try {
                Mockito.doNothing().when(userRoleService).initGroupRoleMap();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return userRoleService;
        }

        return bean;

    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

        return bean;
    }

}
