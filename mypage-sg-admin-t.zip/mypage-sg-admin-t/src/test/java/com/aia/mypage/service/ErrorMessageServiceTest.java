package com.aia.mypage.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.ConfigDAO;
import com.aia.mypage.dao.ErrorMessageDAO;
import com.aia.mypage.entity.Config;
import com.aia.mypage.entity.ErrorMessage;
import com.aia.mypage.service.impl.ConfigServiceImpl;
import com.aia.mypage.service.impl.ErrorMessageServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class ErrorMessageServiceTest {

    @Mock
    private ErrorMessageDAO mockErrorMessageDAO;

    @InjectMocks
    private ErrorMessageServiceImpl mockErrorMessageServiceImpl = new ErrorMessageServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetErrorMessageList() {

        Mockito.when(mockErrorMessageDAO.getErrorMessageList()).thenReturn(null);
        List<ErrorMessage> errorMessageList = mockErrorMessageServiceImpl.getErrorMessageList();
        Assert.assertEquals(errorMessageList, null);
    }
}
