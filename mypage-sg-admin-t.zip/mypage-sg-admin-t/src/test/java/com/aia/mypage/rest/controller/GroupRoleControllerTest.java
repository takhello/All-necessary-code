package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class GroupRoleControllerTest {

    private MockMvc mockMvc;

    @Mock
    private GroupRoleService mockGroupRoleService;

    @Mock
    private GroupService mockGroupService;

    @Mock
    private RoleService mockRoleService;

    @InjectMocks
    private GroupRoleController mockGroupRoleController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockGroupRoleController).build();
    }

    @Test
    public void testGetGroupRolesListSuccess() throws Exception {
        List<GroupRoleGR> mockGroupRoleGRsList = new ArrayList<GroupRoleGR>();
        GroupRoleGR mockGroupRoleGR = new GroupRoleGR();
        mockGroupRoleGRsList.add(mockGroupRoleGR);
        Mockito.when(mockGroupRoleService.getGroupRoleGRsList(Mockito.any(Group.class), Mockito.any(Role.class)))
                .thenReturn(mockGroupRoleGRsList);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/group_roles")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNullGroupId() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        jsonMap.put("data", data);
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupId"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNullGroupId01() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "");
        data.put("roleId", "");
        jsonMap.put("data", data);
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupId"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNullRoleId() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "123");
        jsonMap.put("data", data);
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleId"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNullRoleId01() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "123");
        data.put("roleId", "");
        jsonMap.put("data", data);
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleId"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNoGroup() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "132");
        data.put("roleId", "123");
        jsonMap.put("data", data);
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleNoRole() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "132");
        data.put("roleId", "123");
        jsonMap.put("data", data);
        Group mockGroup = new Group();
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.ROLE_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleSuccess() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "132");
        data.put("roleId", "123");
        jsonMap.put("data", data);
        Group mockGroup = new Group();
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Role mockRole = new Role();
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Mockito.when(mockGroupRoleService.hasSameGroupRole(Mockito.anyString(), Mockito.anyString())).thenReturn(false);
        GroupRole mockGroupRole = new GroupRole();
        Mockito.when(mockGroupRoleService.addGroupRole(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockGroupRole);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testAddGroupRoleFalse() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("groupId", "132");
        data.put("roleId", "123");
        jsonMap.put("data", data);
        Group mockGroup = new Group();
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Role mockRole = new Role();
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Mockito.when(mockGroupRoleService.hasSameGroupRole(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group_role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_ROLE_REGISTERED)));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupRoleIsDeFault() throws Exception {
        GroupRole mockGroupRole = new GroupRole();
        mockGroupRole.setIsDefault("Y");
        Mockito.when(mockGroupRoleService.getGroupRoleListById(Mockito.anyInt())).thenReturn(mockGroupRole);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group_role/{group_role_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("group_role"))));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupRoleSuccess() throws Exception {
        GroupRole mockGroupRole = new GroupRole();
        mockGroupRole.setIsDefault("N");
        Mockito.when(mockGroupRoleService.getGroupRoleListById(Mockito.anyInt())).thenReturn(mockGroupRole);
        Mockito.when(mockGroupRoleService.deleteGroupRoleById(Mockito.anyInt())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group_role/{group_role_id}",1)
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
