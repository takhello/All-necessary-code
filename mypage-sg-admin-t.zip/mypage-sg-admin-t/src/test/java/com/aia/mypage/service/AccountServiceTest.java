package com.aia.mypage.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.AccountDAO;
import com.aia.mypage.entity.Account;
import com.aia.mypage.service.impl.AccountServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AccountServiceTest {

    @Mock
    private AccountDAO mockAccountDAO;

    @InjectMocks
    private AccountServiceImpl mockAccountServiceImpl;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAccountByAccountName() {

        Mockito.when(mockAccountDAO.getAccountByAccountName(Mockito.anyString())).thenReturn(null);
        Account account = mockAccountServiceImpl.getAccountByAccountName("name");
        Assert.assertEquals(account, null);
    }

}
