package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class RolePermissionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RolePermissionService mockRolePermissionService;

    @Mock
    private RoleService mockRoleService;

    @Mock
    private PermissionService mockPermissionService;

    @InjectMocks
    private RolePermissionController mockRolePermissionController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockRolePermissionController).build();
    }

    @Test
    public void testGetRolePermissionsSuccess() throws Exception {
        RolePermissionRP mockRolePermissionRP = new RolePermissionRP();
        List<RolePermissionRP> mockRolePermissionsList = new ArrayList<RolePermissionRP>();
        mockRolePermissionsList.add(mockRolePermissionRP);
        Mockito.when(mockRolePermissionService.getRolePermissionsRPList(Mockito.any(Role.class),
                Mockito.any(Permission.class))).thenReturn(mockRolePermissionsList);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/role_permissions")
                .param("roleId", "123")
                .param("permissionId", "111")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionSuccess() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        data.put("roleId", "123");
        data.put("permissionId", "132132");
        jsonMap.put("data", data);
        Role mockRole = new Role();
        mockRole.setRoleId("123");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Permission mockPermission = new Permission();
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        Mockito.when(mockRolePermissionService.hasSameRolePermission(Mockito.anyString())).thenReturn(false);
        RolePermission mockRolePermission = new RolePermission();
        Mockito.when(mockRolePermissionService.addRolePermission(Mockito.any(RolePermission.class)))
                .thenReturn(mockRolePermission);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionHasSame() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        data.put("roleId", "123");
        data.put("permissionId", "132132");
        jsonMap.put("data", data);
        Role mockRole = new Role();
        mockRole.setRoleId("123");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Permission mockPermission = new Permission();
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(mockPermission);
        Mockito.when(mockRolePermissionService.hasSameRolePermission(Mockito.anyString())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message",equalTo(ErrorMessageUtil.ROLE_PERMISSION_REGISTERED)));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNullRoleId() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        jsonMap.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleId"))));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNullRoleId01() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        data.put("roleId", "");
        jsonMap.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleId"))));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNullPermissionId() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        jsonMap.put("data", data);
        data.put("roleId", "132");
        data.put("permissionId", "");
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionId"))));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNullPermissionId01() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        jsonMap.put("data", data);
        data.put("roleId", "132");
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("permissionId"))));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNoRole() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        jsonMap.put("data", data);
        data.put("roleId", "132");
        data.put("permissionId", "11");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.ROLE_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testAddRolePermissionNoPermission() throws Exception {
        Map<Object, Object> jsonMap = new LinkedHashMap<Object, Object>();
        Map<Object, Object> data = new HashMap<Object, Object>();
        jsonMap.put("data", data);
        data.put("roleId", "132");
        data.put("permissionId", "11");
        Role mockRole = new Role();
        mockRole.setRoleId("123");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Mockito.when(mockPermissionService.getPermissionById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role_permission")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.PERMISSION_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testDeleteRolePermissionSuccess() throws Exception {
        RolePermission mockRolePermission = new RolePermission();
        mockRolePermission.setIsDefault("N");
        Mockito.when(mockRolePermissionService.getRolePermissionById(Mockito.anyInt())).thenReturn(mockRolePermission);
        Mockito.when(mockRolePermissionService.deleteRolePermissionById(Mockito.anyInt())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role_permission/{role_permission_id}",1)
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testDeleteRolePermissionIsDefault() throws Exception {
        RolePermission mockRolePermission = new RolePermission();
        mockRolePermission.setIsDefault("Y");
        Mockito.when(mockRolePermissionService.getRolePermissionById(Mockito.anyInt())).thenReturn(mockRolePermission);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role_permission/{role_permission_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("role_permission"))));
        // @formatter:on
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
