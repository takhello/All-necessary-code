package com.aia.mypage.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.RolePermissionDAO;
import com.aia.mypage.dao.RolePermissionRPDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.service.impl.RolePermissionServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class RolePermissionServiceTest {

    @Mock
    private RolePermissionRPDAO mockRolePermissionRPDAO;

    @Mock
    private RolePermissionDAO mockRolePermissionDAO;

    @InjectMocks
    private RolePermissionServiceImpl mockRolePermissionServiceImpl = new RolePermissionServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetRolePermissionsRPList() {
        Mockito.when(mockRolePermissionRPDAO.getList(Mockito.any(Role.class), Mockito.any(Permission.class)))
                .thenReturn(null);
        Role mockRole = new Role();
        Permission mockPermission = new Permission();
        List<RolePermissionRP> result = mockRolePermissionServiceImpl.getRolePermissionsRPList(mockRole,
                mockPermission);
        Assert.assertEquals(result, null);
    }

    @Test
    public void testAddRolePermission() {
        Mockito.when(mockRolePermissionDAO.addRolePermission(Mockito.any(RolePermission.class))).thenReturn(null);
        RolePermission mockRolePermission = new RolePermission();
        RolePermission result = mockRolePermissionServiceImpl.addRolePermission(mockRolePermission);
        Assert.assertEquals(result, null);
    }

    @Test
    public void testDeleteRolePermissionById() {
        Mockito.when(mockRolePermissionDAO.deleteRolePermissionById(Mockito.anyInt())).thenReturn(true);
        Integer mockRolePermissionId = 111;
        boolean result = mockRolePermissionServiceImpl.deleteRolePermissionById(mockRolePermissionId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testDeleteRolePermissionByPermissionIdNull() {
        List<RolePermission> mockRolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionDAO.getRolePermissionListByPermissionId(Mockito.anyString()))
                .thenReturn(mockRolePermissionList);
        String mockPermissionId = "111";
        boolean result = mockRolePermissionServiceImpl.deleteRolePermissionByPermissionId(mockPermissionId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteRolePermissionByPermissionId() {
        List<RolePermission> mockRolePermissionList = new ArrayList<RolePermission>();
        RolePermission mockRolePermission = new RolePermission();
        mockRolePermissionList.add(mockRolePermission);
        Mockito.when(mockRolePermissionDAO.getRolePermissionListByPermissionId(Mockito.anyString()))
                .thenReturn(mockRolePermissionList);
        Integer mockRolePermissionId = 123;
        Mockito.when(mockRolePermissionDAO.deleteRolePermissionById(mockRolePermissionId)).thenReturn(true);
        String mockPermissionId = "111";
        boolean result = mockRolePermissionServiceImpl.deleteRolePermissionByPermissionId(mockPermissionId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testDeleteRolePermissionByRoleIdNull() {
        List<RolePermission> mockRolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionDAO.getRolePermissionListByRoleId(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockRolePermissionList);
        String mockRoleId = "111";
        boolean result = mockRolePermissionServiceImpl.deleteRolePermissionByRoleId(mockRoleId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteRolePermissionByRoleId() {
        List<RolePermission> mockRolePermissionList = new ArrayList<RolePermission>();
        RolePermission mockRolePermission = new RolePermission();
        mockRolePermissionList.add(mockRolePermission);
        Mockito.when(mockRolePermissionDAO.getRolePermissionListByRoleId(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(mockRolePermissionList);
        Integer mockRolePermissionId = 123;
        Mockito.when(mockRolePermissionDAO.deleteRolePermissionById(mockRolePermissionId)).thenReturn(true);
        String mockRoleId = "111";
        boolean result = mockRolePermissionServiceImpl.deleteRolePermissionByRoleId(mockRoleId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testHasSameRolePermissionFalse() {
        String mockPermissionId = "1234";
        Mockito.when(mockRolePermissionDAO.hasSameRolePermission(mockPermissionId)).thenReturn(null);
        boolean result = mockRolePermissionServiceImpl.hasSameRolePermission(mockPermissionId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testHasSameRolePermissionTrue() {
        String mockPermissionId = "1234";
        String mockRoleId = "1234";
        RolePermission mockRolePermission = new RolePermission();
        mockRolePermission.setPermissionId(mockPermissionId);
        mockRolePermission.setRoleId(mockRoleId);
        Mockito.when(mockRolePermissionDAO.hasSameRolePermission(mockPermissionId)).thenReturn(mockRolePermission);
        boolean result = mockRolePermissionServiceImpl.hasSameRolePermission(mockPermissionId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testGetRolePermissionList() {
        Mockito.when(mockRolePermissionDAO.getRolePermissionList()).thenReturn(null);
        List<RolePermission> rolePermissionList = mockRolePermissionServiceImpl.getRolePermissionList();
        Assert.assertEquals(rolePermissionList, null);
    }

    @Test
    public void testGetRolePermissionByPermissionId() {
        Mockito.when(mockRolePermissionDAO.getRolePermissionListByPermissionId(Mockito.anyString())).thenReturn(null);
        List<RolePermission> rolePermission = mockRolePermissionServiceImpl.getRolePermissionByPermissionId("qqqq");
        Assert.assertEquals(rolePermission, null);
    }

    @Test
    public void testGetRolePermissionListByRoleId() {

        Mockito.when(mockRolePermissionDAO.getRolePermissionListByRoleId(Mockito.anyString())).thenReturn(null);
        List<RolePermission> rolePermissionList = mockRolePermissionServiceImpl.getRolePermissionListByRoleId("111");
        Assert.assertEquals(rolePermissionList, null);
    }

    @Test
    public void testGetRolePermissionById() {

        Mockito.when(mockRolePermissionDAO.getRolePermissionListById(Mockito.anyInt())).thenReturn(null);
        RolePermission rolePermission = mockRolePermissionServiceImpl.getRolePermissionById(1);
        Assert.assertEquals(rolePermission, null);
    }
}
