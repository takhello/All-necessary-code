package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class RoleControllerTest {

    private MockMvc mockMvc;

    @Mock
    private RoleService mockRoleService;

    @Mock
    private RolePermissionService mockRolePermissionService;

    @Mock
    private GroupRoleService mockGroupRoleService;

    @InjectMocks
    private RoleController mockRoleController;

    private Map<String, Object> errorjsonMap;

    private Map<String, Object> successjsonMap;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockRoleController).build();
    }

    @Test
    public void testGetRolesList() throws Exception {
        List<Role> mockRolesList = new ArrayList<Role>();
        Role mockRole = new Role();
        mockRole.setCreateTime(new Date());
        mockRolesList.add(mockRole);
        Mockito.when(mockRoleService.getRolesList(Mockito.any(Role.class))).thenReturn(mockRolesList);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/roles")
                .param("roleName", "values")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testAddRoleSuccess() throws Exception {
        successJson();
        Mockito.when(mockRoleService.addRole(Mockito.any(Role.class))).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleName() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("roleName", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleName"))));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleName01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleName"))));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleDesc() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("roleName", "name");
        data.put("roleDesc", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleDesc01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("roleName", "name");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleStatus() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("roleName", "name");
        data.put("roleDesc", "desc");
        data.put("roleStatus", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleStatus"))));
        // @formatter:on
    }

    @Test
    public void testAddRoleNullRoleStatus01() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("roleName", "name");
        data.put("roleDesc", "desc");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/role")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleStatus"))));
        // @formatter:on
    }

    @Test
    public void testDeleteRoleRoleIsDefault() throws Exception {
        Role mockRole = new Role();
        mockRole.setIsDefault("Y");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role/{role_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("role"))));
        // @formatter:on
    }

    @Test
    public void testDeleteRoleRolePermissionMapping() throws Exception {
        Role mockRole = new Role();
        mockRole.setIsDefault("N");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);

        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        RolePermission rolePermission = new RolePermission();
        rolePermissionList.add(rolePermission);
        Mockito.when(mockRolePermissionService.getRolePermissionListByRoleId(Mockito.anyString()))
                .thenReturn(rolePermissionList);

        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role/{role_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.ROLE_PERMISSION_MAPPING)));
        // @formatter:on
    }

    @Test
    public void testDeleteRoleGroupRoleMapping() throws Exception {
        Role mockRole = new Role();
        mockRole.setIsDefault("N");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);

        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionService.getRolePermissionListByRoleId(Mockito.anyString()))
                .thenReturn(rolePermissionList);

        List<GroupRole> GroupRoleList = new ArrayList<GroupRole>();
        GroupRole groupRole = new GroupRole();
        GroupRoleList.add(groupRole);
        Mockito.when(mockGroupRoleService.getGroupRoleListByRoleId(Mockito.anyString())).thenReturn(GroupRoleList);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role/{role_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_ROLE_MAPPING)));
        // @formatter:on
    }

    @Test
    public void testDeleteRoleSuccess() throws Exception {
        Role mockRole = new Role();
        mockRole.setIsDefault("N");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);

        List<RolePermission> rolePermissionList = new ArrayList<RolePermission>();
        Mockito.when(mockRolePermissionService.getRolePermissionListByRoleId(Mockito.anyString()))
                .thenReturn(rolePermissionList);

        List<GroupRole> GroupRoleList = new ArrayList<GroupRole>();
        Mockito.when(mockGroupRoleService.getGroupRoleListByRoleId(Mockito.anyString())).thenReturn(GroupRoleList);
        Mockito.when(mockRoleService.deleteRoleById(Mockito.anyString())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/role/{role_id}",1)
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testUpdateRoleSuccess() throws Exception {
        successJson();
        Role mockRole = new Role();
        mockRole.setCreateTime(new Date());
        mockRole.setIsDefault("N");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Mockito.when(mockRoleService.updateRole(Mockito.any(Role.class))).thenReturn(mockRole);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/role/{role_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testUpdateRoleNull() throws Exception {
        errorJson();
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/role/{role_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(errorjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("roleName"))));
        // @formatter:on
    }

    @Test
    public void testUpdateRoleIsDefault() throws Exception {
        successJson();
        Role mockRole = new Role();
        mockRole.setCreateTime(new Date());
        mockRole.setIsDefault("Y");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/role/{role_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("role"))));
        // @formatter:on
    }

    @Test
    public void testUpdateRoleFalse() throws Exception {
        successJson();
        Role mockRole = new Role();
        mockRole.setCreateTime(new Date());
        mockRole.setIsDefault("N");
        Mockito.when(mockRoleService.getRoleById(Mockito.anyString())).thenReturn(mockRole);
        Mockito.when(mockRoleService.updateRole(Mockito.any(Role.class))).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/role/{role_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.ROLE_UNREGISTERED)));
        // @formatter:on
    }

    public void errorJson() {
        errorjsonMap = new LinkedHashMap<String, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("roleId", "");
        data.put("roleName", "");
        data.put("roleDesc", "");
        data.put("roleStatus", "");
        errorjsonMap.put("data", data);
    }

    public void successJson() {
        successjsonMap = new LinkedHashMap<String, Object>();
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        data.put("roleId", "111");
        data.put("roleName", "roleNmae");
        data.put("roleDesc", "roleDesc");
        data.put("roleStatus", "roleStatu");
        successjsonMap.put("data", data);
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
