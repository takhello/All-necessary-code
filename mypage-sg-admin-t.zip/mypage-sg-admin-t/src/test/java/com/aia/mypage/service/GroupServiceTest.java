package com.aia.mypage.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.GroupDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.service.impl.GroupServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class GroupServiceTest {

    @Mock
    private GroupDAO mockGroupDAO;

    @InjectMocks
    private GroupServiceImpl mockGroupServiceImpl = new GroupServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetGroupsList() {
        List<Group> mockGroupsList = new ArrayList<Group>();
        Group mockGroup = new Group();
        mockGroup.setGroupId("123");
        mockGroupsList.add(mockGroup);
        Mockito.when(mockGroupDAO.getGroupsList(Mockito.any(Group.class))).thenReturn(mockGroupsList);
        List<Group> groupsList = mockGroupServiceImpl.getGroupsList(mockGroup);
        Assert.assertEquals(groupsList.get(0).getGroupId(), "123");
    }

    @Test
    public void testAddGroup() {
        Group mockGroup = new Group();
        mockGroup.setGroupDesc("desc");
        Mockito.when(mockGroupDAO.addGroup(Mockito.any(Group.class))).thenReturn(mockGroup);
        Group newGroup = mockGroupServiceImpl.addGroup(mockGroup);
        Assert.assertEquals(newGroup.getGroupDesc(), "desc");
    }

    @Test
    public void testDeleteGroupById() {
        Mockito.when(mockGroupDAO.deleteGroupById(Mockito.anyString())).thenReturn(true);
        String mockGroupId = "1111";
        boolean result = mockGroupServiceImpl.deleteGroupById(mockGroupId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testUpdateGroupByIdNull() {
        Mockito.when(mockGroupDAO.getGroupById(Mockito.anyString())).thenReturn(null);
        Group mockGroup = new Group();
        Group result = mockGroupServiceImpl.updateGroupById(mockGroup);
        Assert.assertEquals(result, null);
    }

    @Test
    public void testUpdateGroupByIdSuccess() {
        Group mockGroup = new Group();
        mockGroup.setGroupDesc("desc");
        Mockito.when(mockGroupDAO.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Mockito.when(mockGroupDAO.updateGroup(Mockito.any(Group.class))).thenReturn(mockGroup);
        Group result = mockGroupServiceImpl.updateGroupById(mockGroup);
        Assert.assertEquals(result.getGroupDesc(), "desc");
    }

    @Test
    public void testGetGroupById() {
        String mockGroupId = "1234";
        Mockito.when(mockGroupDAO.getGroupById(mockGroupId)).thenReturn(null);
        Group group = mockGroupServiceImpl.getGroupById(mockGroupId);
        Assert.assertEquals(group, null);
    }
}
