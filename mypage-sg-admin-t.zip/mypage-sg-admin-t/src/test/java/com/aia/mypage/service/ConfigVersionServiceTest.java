package com.aia.mypage.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.ConfigVersionDAO;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.service.impl.ConfigVersionServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class ConfigVersionServiceTest {

    @Mock
    private ConfigVersionDAO mockConfigVersionDAO;

    @InjectMocks
    private ConfigVersionServiceImpl mockConfigVersionServiceImpl = new ConfigVersionServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetConfigVersionList() {

        Mockito.when(mockConfigVersionDAO.getConfigVersionList()).thenReturn(null);
        List<ConfigVersion> configVersions = mockConfigVersionServiceImpl.getConfigVersionList();
        Assert.assertEquals(configVersions, null);
    }

    @Test
    public void testAddConfigVersion() {
        Mockito.when(mockConfigVersionDAO.addConfigVersion(Mockito.any(ConfigVersion.class))).thenReturn(null);
        ConfigVersion mockConfigVersion = new ConfigVersion();
        ConfigVersion configVersion = mockConfigVersionServiceImpl.addConfigVersion(mockConfigVersion);
        Assert.assertEquals(configVersion, null);
    }
}
