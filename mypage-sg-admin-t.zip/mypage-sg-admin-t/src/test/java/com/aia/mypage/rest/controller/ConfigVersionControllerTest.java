package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.service.ConfigService;
import com.aia.mypage.service.ConfigVersionService;
import com.aia.mypage.service.ErrorMessageService;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;
import com.alibaba.fastjson.JSONObject;

import mockit.NonStrictExpectations;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class ConfigVersionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ConfigVersionService mockConfigVersionService;

    @Mock
    private AccountService mockAccountService;

    @Mock
    private PermissionService mockPermissionService;

    @Mock
    private RoleService mockRoleService;

    @Mock
    private GroupService mockGroupService;

    @Mock
    private RolePermissionService mockRolePermissionService;

    @Mock
    private GroupRoleService mockGroupRoleService;

    @Mock
    private ConfigService mockConfigService;

    @Mock
    private ErrorMessageService mockErrorMessageService;

    @InjectMocks
    private ConfigVersionController mockConfigVersionController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockConfigVersionController).build();
    }

    @Test
    public void testGetVersionList() throws Exception {
        Mockito.when(mockConfigVersionService.getConfigVersionList()).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/versions")
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
        // @formatter:on
    }

    @Test
    public void testAddVersionNoVersionDesc() throws Exception {
        Map<String, Object> jsonMap = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        jsonMap.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/version")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("versionDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddVersionNullVersionDesc() throws Exception {
        Map<String, Object> jsonMap = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("versionDesc", "");
        jsonMap.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/version")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("versionDesc"))));
        // @formatter:on
    }

    public void setupMockBaseController() throws IOException {
        final BaseController baseController = new BaseController();

        new NonStrictExpectations(BaseController.class) {
            {
                baseController.getUserName();
                result = "name";
            }
        };
    }

    @Test
    public void testAddVersionSuccess() throws Exception {
        setupMockBaseController();
        Map<String, Object> jsonMap = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("versionDesc", "123");
        jsonMap.put("data", data);
        Mockito.when(mockConfigVersionService.addConfigVersion(Mockito.any(ConfigVersion.class))).thenReturn(null);
        Account mockAccount = new Account();
        Mockito.when(mockAccountService.getAccountByAccountName(Mockito.anyString())).thenReturn(mockAccount);
        Mockito.when(mockPermissionService.getPermissionsList(Mockito.any(Permission.class))).thenReturn(null);
        Mockito.when(mockRoleService.getRolesList(Mockito.any(Role.class))).thenReturn(null);
        Mockito.when(mockGroupService.getGroupsList(Mockito.any(Group.class))).thenReturn(null);
        Mockito.when(mockRolePermissionService.getRolePermissionList()).thenReturn(null);
        Mockito.when(mockGroupRoleService.getGroupRoleList()).thenReturn(null);
        Mockito.when(mockConfigService.getConfigList()).thenReturn(null);
        Mockito.when(mockErrorMessageService.getErrorMessageList()).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/version")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMap))
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
        // @formatter:on
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }
}
