package com.aia.mypage.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.AdminUserGroupInfoDAO;
import com.aia.mypage.dao.UserGroupDAO;
import com.aia.mypage.entity.AdminUserGroupInfo;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.impl.UserGroupServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class UserGroupServiceTest {

    @Mock
    private UserGroupDAO mockUserGroupDAO;

    @Mock
    private AdminUserGroupInfoDAO mockAdminUserGroupInfoDAO;

    @InjectMocks
    private UserGroupServiceImpl mockUserGroupServiceImpl = new UserGroupServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDeleteUserGroupByGroupIdNull() {
        List<UserGroup> mockUserGroupList = new ArrayList<UserGroup>();
        Mockito.when(mockUserGroupDAO.getUserGroupListByGroupId(Mockito.anyString())).thenReturn(mockUserGroupList);
        String mockGroupId = "234";
        boolean result = mockUserGroupServiceImpl.deleteUserGroupByGroupId(mockGroupId);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteUserGroupByGroupId() {

        List<UserGroup> mockUserGroupList = new ArrayList<UserGroup>();
        UserGroup mockUserGroup = new UserGroup();
        mockUserGroupList.add(mockUserGroup);
        Mockito.when(mockUserGroupDAO.getUserGroupListByGroupId(Mockito.anyString())).thenReturn(mockUserGroupList);
        Integer mockUserGroupId = 111;
        Mockito.when(mockUserGroupDAO.deleteUserGroupById(mockUserGroupId)).thenReturn(true);
        String mockGroupId = "234";
        boolean result = mockUserGroupServiceImpl.deleteUserGroupByGroupId(mockGroupId);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testAddUserGroup() {

        Mockito.when(mockUserGroupDAO.addUserGroup(Mockito.any(UserGroup.class))).thenReturn(null);
        UserGroup userGroup = mockUserGroupServiceImpl.addUserGroup(1, "1");
        Assert.assertEquals(userGroup, null);
    }

    @Test
    public void testGetSameUserGroup() {

        Mockito.when(mockUserGroupDAO.getSameUserGroup(Mockito.anyInt(), Mockito.anyString())).thenReturn(null);
        UserGroup userGroup = mockUserGroupServiceImpl.getSameUserGroup(1, "1");
        Assert.assertEquals(userGroup, null);
    }

    @Test
    public void testDeleteUserGroupById() {

        Mockito.when(mockUserGroupDAO.deleteUserGroupById(Mockito.anyInt())).thenReturn(true);
        boolean result = mockUserGroupServiceImpl.deleteUserGroupById(1);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testGetAdminUserGroupListByAdminUserId() {

        Mockito.when(mockAdminUserGroupInfoDAO.getAdminUserGroupListByAdminUserId(Mockito.anyInt())).thenReturn(null);
        List<AdminUserGroupInfo> result = mockUserGroupServiceImpl.getAdminUserGroupListByAdminUserId(1);
        Assert.assertEquals(result, null);
    }

    @Test
    public void testGetUserGroupByGroupId() {

        Mockito.when(mockUserGroupDAO.getUserGroupListByGroupId(Mockito.anyString())).thenReturn(null);
        List<UserGroup> userGroupByGroupId = mockUserGroupServiceImpl.getUserGroupByGroupId("1");
        Assert.assertEquals(userGroupByGroupId, null);
    }

    @Test
    public void testGetUserGroupById() {
        Mockito.when(mockUserGroupDAO.getUserGroupById(Mockito.anyInt())).thenReturn(null);
        UserGroup userGroupById = mockUserGroupServiceImpl.getUserGroupById(1);
        Assert.assertEquals(userGroupById, null);

    }
}
