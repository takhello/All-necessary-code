package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.AdminUserGroupInfo;
import com.aia.mypage.entity.UserGroup;

public interface UserGroupService {

    boolean deleteUserGroupByGroupId(String groupId);

    UserGroup addUserGroup(int userId, String groupId);

    UserGroup getSameUserGroup(int parseInt, String groupId);

    boolean deleteUserGroupById(Integer userGroupId);

    List<AdminUserGroupInfo> getAdminUserGroupListByAdminUserId(int adminUserId);

    List<UserGroup> getUserGroupByGroupId(String groupId);

    UserGroup getUserGroupById(Integer user_group_id);

}
