package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;

public interface GroupRoleGRDAO {

    List<GroupRoleGR> getGroupRoleGRsList(Group group, Role role);

}
