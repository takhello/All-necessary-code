package com.aia.mypage.dao.impl;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AuditLogDAO;
import com.aia.mypage.entity.AuditLog;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AuditLogDAOImpl extends JPABaseRepImpl<AuditLog> implements AuditLogDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public void addAuditLog(AuditLog auditLog) {
        super.create(auditLog);
    }

}
