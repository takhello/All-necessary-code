package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "T_CONFIG_VERSION")
@Entity
public class ConfigVersion implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 2178747711088551847L;

    @Id
    @SequenceGenerator(name = "SEQ_T_CONFIG_VERSION_ID", sequenceName = "SEQ_T_CONFIG_VERSION_ID", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ_T_CONFIG_VERSION_ID")
    @Column(name = "version_id")
    private int versionId;

    @Column(name = "version_desc")
    private String versionDesc;

    @Column(name = "version_content")
    private String versionContent;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "create_by")
    private int createBy;

    public ConfigVersion() {
        super();
    }

    public ConfigVersion(int versionId, String versionDesc, Date createTime, int createBy) {
        super();
        this.versionId = versionId;
        this.versionDesc = versionDesc;
        this.createTime = createTime;
        this.createBy = createBy;
    }

    public int getVersionId() {
        return versionId;
    }

    public void setVersionId(int versionId) {
        this.versionId = versionId;
    }

    public String getVersionDesc() {
        return versionDesc;
    }

    public void setVersionDesc(String versionDesc) {
        this.versionDesc = versionDesc;
    }

    public String getVersionContent() {
        return versionContent;
    }

    public void setVersionContent(String versionContent) {
        this.versionContent = versionContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public int getCreateBy() {
        return createBy;
    }

    public void setCreateBy(int createBy) {
        this.createBy = createBy;
    }

}
