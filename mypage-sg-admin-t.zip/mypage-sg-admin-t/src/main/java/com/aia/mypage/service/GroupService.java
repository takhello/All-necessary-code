package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Group;

public interface GroupService {

    List<Group> getGroupsList(Group group);

    Group addGroup(Group group);

    boolean deleteGroupById(String group_id);

    Group updateGroupById(Group group);

    Group getGroupById(String groupId);

}
