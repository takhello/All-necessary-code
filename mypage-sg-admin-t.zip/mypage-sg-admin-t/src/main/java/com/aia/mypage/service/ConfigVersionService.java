package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.ConfigVersion;

public interface ConfigVersionService {

    List<ConfigVersion> getConfigVersionList();

    ConfigVersion addConfigVersion(ConfigVersion configVersion);

}
