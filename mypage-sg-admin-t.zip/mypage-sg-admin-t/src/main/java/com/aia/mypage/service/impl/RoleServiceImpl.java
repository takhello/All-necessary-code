package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.RoleDAO;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;

public class RoleServiceImpl implements RoleService {

    @Autowired
    @Qualifier("roleDAOImpl")
    private RoleDAO roleDAO;

    public List<Role> getRolesList(Role role) {
        List<Role> rolesList = roleDAO.getRolesList(role);
        return rolesList;
    }

    public Role addRole(Role role) {
        role.setIsDefault(BaseUtil.IS_DEFAULT_N);
        role.setCreateTime(new Date());
        role = roleDAO.addRole(role);
        return role;
    }

    public boolean deleteRoleById(String roleId) {
        boolean result = roleDAO.deleteRoleById(roleId);
        return result;
    }

    public Role updateRole(Role role) {
        Role newRole = roleDAO.getRoleById(role.getRoleId());
        if (newRole == null) {
            return null;
        }
        newRole.setRoleName(role.getRoleName());
        newRole.setRoleDesc(role.getRoleDesc());
        newRole.setRoleStatus(role.getRoleStatus());
        newRole.setUpdateTime(new Date());
        role = roleDAO.updateRoleById(newRole);
        return role;
    }

    public Role getRoleById(String roleId) {
        Role role = roleDAO.getRoleById(roleId);
        return role;
    }
}
