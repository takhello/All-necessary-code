package com.aia.mypage.entity;

import java.io.Serializable;

public class GroupRoleGR implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -2172438181768220046L;

    public GroupRoleGR() {
        super();
    }

    public GroupRoleGR(int groupRoleId, String isDefault, String groupId, String groupName, String groupDesc,
            String groupStatus, String roleId, String roleName, String roleDesc, String roleStatus) {
        super();
        this.groupRoleId = groupRoleId;
        this.isDefault = isDefault;
        this.groupId = groupId;
        this.groupName = groupName;
        this.groupDesc = groupDesc;
        this.groupStatus = groupStatus;
        this.roleId = roleId;
        this.roleName = roleName;
        this.roleDesc = roleDesc;
        this.roleStatus = roleStatus;
    }

    /** group_role_id. */
    private int groupRoleId;

    /** is_default. */
    private String isDefault;

    /** group_id. */
    private String groupId;

    /** group_name. */
    private String groupName;

    /** group_desc. */
    private String groupDesc;

    /** group_status. */
    private String groupStatus;

    /** role_id. */
    private String roleId;

    /** role_name. */
    private String roleName;

    /** role_desc. */
    private String roleDesc;

    /** role_status. */
    private String roleStatus;

    public int getGroupRoleId() {
        return groupRoleId;
    }

    public void setGroupRoleId(int groupRoleId) {
        this.groupRoleId = groupRoleId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public String getGroupStatus() {
        return groupStatus;
    }

    public void setGroupStatus(String groupStatus) {
        this.groupStatus = groupStatus;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getRoleStatus() {
        return roleStatus;
    }

    public void setRoleStatus(String roleStatus) {
        this.roleStatus = roleStatus;
    }

}
