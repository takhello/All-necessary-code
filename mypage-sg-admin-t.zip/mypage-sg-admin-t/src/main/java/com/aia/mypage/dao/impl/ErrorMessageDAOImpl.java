package com.aia.mypage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.ErrorMessageDAO;
import com.aia.mypage.entity.ErrorMessage;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class ErrorMessageDAOImpl extends JPABaseRepImpl<ErrorMessage> implements ErrorMessageDAO {

    @Override
    protected EntityManager getEntityManager() {

        return null;
    }

    @Override
    public List<ErrorMessage> getErrorMessageList() {

        return queryByNoParamters("from ErrorMessage");
    }

}
