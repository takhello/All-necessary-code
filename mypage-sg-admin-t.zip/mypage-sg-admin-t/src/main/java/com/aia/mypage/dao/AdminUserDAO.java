package com.aia.mypage.dao;

import com.aia.mypage.entity.AdminUserInfoVO;

public interface AdminUserDAO {

    AdminUserInfoVO getAdminUserInfoByAccountName(String accountName);

}
