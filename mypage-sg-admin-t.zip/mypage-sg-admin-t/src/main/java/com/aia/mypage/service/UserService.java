package com.aia.mypage.service;

import com.aia.mypage.entity.User;

public interface UserService {

    User getUserById(int userId);

}
