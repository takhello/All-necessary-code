package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermissionRP;

public interface RolePermissionRPDAO {

    List<RolePermissionRP> getList(Role role, Permission permission);
    
    List<RolePermissionRP> getAllRolePermission();
}
