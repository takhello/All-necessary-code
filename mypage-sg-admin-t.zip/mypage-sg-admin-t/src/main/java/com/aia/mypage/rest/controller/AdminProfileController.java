package com.aia.mypage.rest.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.service.AdminUserService;
import com.aia.mypage.util.BaseUtil;

@Controller
@RequestMapping(value = "admin")
public class AdminProfileController extends BaseController {

    @Autowired
    @Qualifier("adminUserServiceImpl")
    private AdminUserService adminUserService;

    @ResponseBody
    @RequestMapping(value = "/profile", method = RequestMethod.GET)
    public Map<String, Object> getAdminUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        String userName = getUserName();
        AdminUserInfo adminUserInfo = adminUserService.getAdminProfile(userName);
        if (adminUserInfo == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, BaseUtil.EXCEPTION_MESSAGE);
        }

        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("profile", adminUserInfo);
        successJson.put("data", data);
        return successJson;
    }
}
