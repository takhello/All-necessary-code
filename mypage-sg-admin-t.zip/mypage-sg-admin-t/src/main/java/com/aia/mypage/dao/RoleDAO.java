package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Role;

public interface RoleDAO {

    Role getRoleById(String roleId);

    List<Role> getRolesList(Role role);

    Role addRole(Role role);

    boolean deleteRoleById(String roleId);

    Role updateRoleById(Role role);

}
