package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.UserGroup;

public interface UserGroupDAO {

    List<UserGroup> getUserGroupListByGroupId(String groupId);

    boolean deleteUserGroupById(Integer userGroupId);

    UserGroup addUserGroup(UserGroup userGroup);

    UserGroup getSameUserGroup(int userId, String groupId);
    
    List<UserGroup> getUserGroupsListByUserId(int userId);

    UserGroup getUserGroupById(Integer userGroupId);

}
