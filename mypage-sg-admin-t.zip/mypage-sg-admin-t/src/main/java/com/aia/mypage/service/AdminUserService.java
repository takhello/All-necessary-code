package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;

public interface AdminUserService {

    List<AdminUserInfo> getAdminUserListByAccountName(AdminUserInfo adminUserInfo);

    AccountUserInfo getAccountUserByAccountName(String accountName);

    AdminUser addAdminUser(int userId);

    boolean updateAdmin(AdminUser adminUser);

    boolean deleteAdminByUserId(Integer user_id);

    AdminUserInfo getAdminProfile(String accountName);

    AdminUser getAdminUserByUserId(Integer user_id);

}
