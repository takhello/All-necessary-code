package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Config;

public interface ConfigService {

    List<Config> getConfigList();

}
