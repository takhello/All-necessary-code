package com.aia.mypage.dao;

import com.aia.mypage.entity.Account;

public interface AccountDAO {

    Account getAccountByAccountName(String accountName);

}
