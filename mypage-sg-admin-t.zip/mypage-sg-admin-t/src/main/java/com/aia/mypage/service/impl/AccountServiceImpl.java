package com.aia.mypage.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AccountDAO;
import com.aia.mypage.entity.Account;
import com.aia.mypage.service.AccountService;

public class AccountServiceImpl implements AccountService {

    @Autowired
    @Qualifier("accountDAOImpl")
    private AccountDAO accountDAO;

    @Override
    public Account getAccountByAccountName(String accountName) {

        return accountDAO.getAccountByAccountName(accountName);
    }

}
