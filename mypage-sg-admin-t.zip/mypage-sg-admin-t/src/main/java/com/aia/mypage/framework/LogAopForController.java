package com.aia.mypage.framework;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aia.mypage.dao.AuditLogDAO;
import com.aia.mypage.entity.AuditLog;
import com.aia.mypage.entity.JSONMessage;

@Aspect
@Component
public class LogAopForController {

    private static Log logging = LogFactory.getLog(LogAopForController.class);
    @Autowired
    @Qualifier("auditLogDAOImpl")
    private AuditLogDAO auditLogDAO;

    @Pointcut(value = "execution(* com.aia.mypage.rest.controller.*Controller.*(..))")
    public void controllerPointcut() {

    }

    @Around("controllerPointcut()")
    public Object auditLogHandler(ProceedingJoinPoint point) throws Throwable {

        AuditLog auditLog = new AuditLog();

        MyPageUser user = (MyPageUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Integer userId = user.getUserId();

        auditLog.setCreateTime(new Date());
        auditLog.setUserId(userId);

        logging.info("args length======" + point.getArgs().length);
        logging.info("method======" + point.getSignature().getName());
        auditLog.setLogType(point.getSignature().getName());

        MethodSignature method = (MethodSignature) point.getSignature();
        RequestMapping annotation = method.getMethod().getAnnotation(RequestMapping.class);
        RequestMethod reqMethod = annotation.method()[0];

        if (reqMethod == RequestMethod.POST) {
            auditLog.setRequestMethod(RequestMethod.POST.name());
        } else if (reqMethod == RequestMethod.DELETE) {
            auditLog.setRequestMethod(RequestMethod.DELETE.name());
        } else if (reqMethod == RequestMethod.PUT) {
            auditLog.setRequestMethod(RequestMethod.PUT.name());
        } else if (reqMethod == RequestMethod.GET) {
            auditLog.setRequestMethod(RequestMethod.GET.name());
        } else if (reqMethod == RequestMethod.OPTIONS) {
            auditLog.setRequestMethod(RequestMethod.OPTIONS.name());
        } else if (reqMethod == RequestMethod.PATCH) {
            auditLog.setRequestMethod(RequestMethod.PATCH.name());
        }

        String requestBody = "";
        Object[] args = point.getArgs();

        // method's args
        for (Object obj : args) {

            // logging.info("request para***********" + obj.toString());

            if (obj instanceof HttpServletRequest) {

                HttpServletRequest request = (HttpServletRequest) obj;
                auditLog.setUserIp(request.getRemoteAddr());
                auditLog.setRequestHeader(request.getHeader("Authorization"));
                auditLog.setRequestUri(request.getRequestURL().toString());

            }

            if (obj instanceof JSONMessage) {
                JSONMessage jsonMsg = (JSONMessage) obj;
                requestBody = jsonMsg.getData().toString() + "," + requestBody;
            } else if (!(obj instanceof HttpServletRequest) && !(obj instanceof HttpServletResponse)) {
                requestBody = obj.toString() + "," + requestBody;
            }
        }

        auditLog.setRequestBody(requestBody);

        Object retObj = point.proceed();
        if (retObj instanceof Map) {

            Map retMap = (Map) retObj;

            auditLog.setResponseResultCode(((Integer) retMap.get("code")).toString());
            auditLog.setResponseResult(retMap.toString());

        } else if (retObj instanceof Exception) {
            // handle unexpected exception thrown from controller
            // or add this in base controller, need to confirm the execute order
            // of base controller and aop

        }

        auditLogDAO.addAuditLog(auditLog);

        return retObj;
    }

}
