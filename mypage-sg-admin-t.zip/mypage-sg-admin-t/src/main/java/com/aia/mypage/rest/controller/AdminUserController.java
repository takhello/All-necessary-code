package com.aia.mypage.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.service.AdminUserService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class AdminUserController extends BaseController {

    @Autowired
    @Qualifier("adminUserServiceImpl")
    private AdminUserService adminUserService;

    /**
     * retrieving admin user list.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_users", method = RequestMethod.GET)
    public Map<String, Object> getAdminUser(HttpServletRequest request, HttpServletResponse response) throws Exception {

        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String isEnabled = request.getParameter("isEnabled");
        AdminUserInfo adminUserInfo = new AdminUserInfo();
        adminUserInfo.setFirstName(firstName);
        adminUserInfo.setLastName(lastName);
        adminUserInfo.setIsEnabled(isEnabled);

        List<AdminUserInfo> adminUserList = adminUserService.getAdminUserListByAccountName(adminUserInfo);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("userList", adminUserList);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * retrieving user information by account name.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public Map<String, Object> getAccountUser(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        String accountName = request.getParameter("accountName");
        if ("".equals(accountName) || accountName == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("accountName"));
        }

        AccountUserInfo account = adminUserService.getAccountUserByAccountName(accountName);
        if (account == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
        }

        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("account", account);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * creating admin user.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_user", method = RequestMethod.POST)
    public Map<String, Object> addAdmin(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String userId = (String) data.get("userId");
        if ("".equals(userId) || userId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("userId"));
        }
        AdminUser adminUser = new AdminUser();
        try {
            adminUser = adminUserService.addAdminUser(Integer.parseInt(userId));
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ADD_FAILED);
        }

        if (adminUser == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
        }
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * deleting admin user.
     * 
     * @param user_id
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_user/{user_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteAdmin(@PathVariable Integer user_id, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        AdminUser adminUser = adminUserService.getAdminUserByUserId(user_id);
        if (adminUser == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ADMIN_USER_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(adminUser.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("adminUser"));
        }

        adminUserService.deleteAdminByUserId(user_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * updating admin user.
     * 
     * @param user_id
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_user/{user_id}", method = RequestMethod.PUT)
    public Map<String, Object> updateAdmin(@PathVariable Integer user_id, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) throws Exception {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String isEnabled = (String) data.get("isEnabled");
        if ("".equals(isEnabled) || isEnabled == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("isEnabled"));
        }

        AdminUser adminUser = adminUserService.getAdminUserByUserId(user_id);
        if (adminUser == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ADMIN_USER_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(adminUser.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("adminUser"));
        }
        adminUser.setUserId(user_id);
        adminUser.setIsEnabled(isEnabled);
        boolean result = adminUserService.updateAdmin(adminUser);
        if (!result) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.UPDATE_FAILED);
        }
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

}
