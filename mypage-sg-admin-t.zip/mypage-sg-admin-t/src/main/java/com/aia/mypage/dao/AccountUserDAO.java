package com.aia.mypage.dao;

import com.aia.mypage.entity.AccountUserInfo;

public interface AccountUserDAO {

    AccountUserInfo getAccountUserByAccountName(String accountName);

}
