package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "T_ADMIN_USER")
@Entity
public class AdminUser implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 3238772071521697863L;

    /** user_id. */
    @Id
    @Column(name = "user_id")
    private Integer userId;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** create_time. */
    @Column(name = "update_time")
    private Date updateTime;

    /** is_enabled. */
    @Column(name = "is_enabled")
    private String isEnabled;

    /** is_default. */
    @Column(name = "is_default")
    private String isDefault;

    /**
     * Constructor.
     */
    public AdminUser() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

}
