package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.UserGroupService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class GroupController extends BaseController {

    @Autowired
    @Qualifier("groupServiceImpl")
    private GroupService groupService;

    @Autowired
    @Qualifier("groupRoleServiceImpl")
    private GroupRoleService groupRoleService;

    @Autowired
    @Qualifier("userGroupServiceImpl")
    private UserGroupService userGroupService;

    @ResponseBody
    @RequestMapping(value = "/groups", method = RequestMethod.GET)
    public Map<String, Object> getGroupsList(HttpServletRequest request, HttpServletResponse response) {

        String groupId = request.getParameter("groupId");
        String groupName = request.getParameter("groupName");
        String groupStatus = request.getParameter("groupStatus");
        Group group = new Group();
        group.setGroupId(groupId);
        group.setGroupName(groupName);
        group.setGroupStatus(groupStatus);

        List<Group> groupList = groupService.getGroupsList(group);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("groupList", groupList);
        successJson.put("data", data);
        return successJson;

    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/group", method = RequestMethod.POST)
    public Map<String, Object> addGroup(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyGroup(data);
        Object object = verifyMap.get("group");
        if (object != null) {
            Group group = (Group) verifyMap.get("group");
            groupService.addGroup(group);
            return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        } else {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

    }

    @ResponseBody
    @RequestMapping(value = "/group/{group_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteGroup(@PathVariable String group_id, HttpServletRequest request,
            HttpServletResponse response) {

        Group group = groupService.getGroupById(group_id);
        if (group == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_UNREGISTERED);
        }

        String isDefault = group.getIsDefault();
        if (BaseUtil.IS_DEFAULT_Y.equals(isDefault)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("group"));
        }

        List<GroupRole> groupRoleList = groupRoleService.getGroupRoleListByGroupId(group_id);
        if (groupRoleList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_ROLE_MAPPING);
        }

        List<UserGroup> userGroupList = userGroupService.getUserGroupByGroupId(group_id);
        if (userGroupList.size() != 0) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_GROUP_MAPPING);
        }

        groupService.deleteGroupById(group_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/group/{group_id}", method = RequestMethod.PUT)
    public Map<String, Object> updateGroup(@PathVariable String group_id, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        Map<String, Object> verifyMap = verifyGroup(data);
        Object object = verifyMap.get("group");
        if (object == null) {
            String errorKey = (String) verifyMap.get("errorKey");
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired(errorKey));
        }

        Group group = (Group) verifyMap.get("group");
        group.setGroupId(group_id);
        Group newGroup = groupService.getGroupById(group_id);
        if (newGroup == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_UNREGISTERED);
        }

        String isDefault = newGroup.getIsDefault();
        if (BaseUtil.IS_DEFAULT_Y.equals(isDefault)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("group"));
        }
        group = groupService.updateGroupById(group);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    private Map<String, Object> verifyGroup(Map<String, Object> data) {
        Map<String, Object> errorjson = new LinkedHashMap<String, Object>();
        String groupName = (String) data.get("groupName");
        System.out.println(groupName);
        if ("".equals(groupName) || groupName == null) {
            errorjson.put("errorKey", "groupName");
            return errorjson;
        }
        String groupDesc = (String) data.get("groupDesc");
        if ("".equals(groupDesc) || groupDesc == null) {
            errorjson.put("errorKey", "groupDesc");
            return errorjson;
        }
        String groupStatus = (String) data.get("groupStatus");
        if ("".equals(groupStatus) || groupStatus == null) {
            errorjson.put("errorKey", "groupStatus");
            return errorjson;
        }
        Group group = new Group();
        group.setGroupName(groupName);
        group.setGroupDesc(groupDesc);
        group.setGroupStatus(groupStatus);
        errorjson.put("group", group);
        return errorjson;

    }
}
