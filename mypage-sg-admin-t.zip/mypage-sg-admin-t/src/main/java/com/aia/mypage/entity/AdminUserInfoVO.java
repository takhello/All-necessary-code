package com.aia.mypage.entity;

import java.io.Serializable;

public class AdminUserInfoVO implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 4284519387564322201L;

    private Integer userId;

    private String password;

    private String isEnabled;

    public AdminUserInfoVO(String password, int userId, String isEnabled) {
        super();
        this.password = password;
        this.userId = userId;
        this.isEnabled = isEnabled;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
