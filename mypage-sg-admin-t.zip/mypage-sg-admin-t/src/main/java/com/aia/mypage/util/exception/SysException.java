package com.aia.mypage.util.exception;

/**
 * User: dengrunquan. Date: 12-1-18 Time: afternonn 6:02
 */
public class SysException extends RuntimeException {

    /**
     * No information exception constructor.
     */
    public SysException() {
        super();
    }

    /**
     * Specify information exception constructor.
     * 
     * @param message
     */
    public SysException(String message) {
        super(message);
    }

    /**
     * specified information exceptions and exceptions Constructor.
     * 
     * @param message
     * @param cause
     */
    public SysException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * specified exceptions Constructor.
     * 
     * @param cause
     */
    public SysException(Throwable cause) {
        super(cause);
    }
}
