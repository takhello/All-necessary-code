(function() {
	"use strict";

	angular.module('adminManageApp').controller('NewFunctionController', NewFunctionController);
	NewFunctionController.$injector = ['$scope', '$modalInstance', 'PermissionService'];

	function NewFunctionController($scope, $modalInstance, PermissionService) {
		var vm = this;
		vm.permissionTypeMap = PERMISSION_TYPE;
		vm.addPermissionCancel = addPermissionCancel;
		vm.addPermissionConfirm = addPermissionConfirm;
		vm.isAlertHide = true;
		vm.permissionStatus = 'Y';
		vm.isOTP = 'N';
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.errorClose = errorClose;


		function errorClose() {
			vm.isAlertHide = true;
		}

		function addPermissionCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addPermissionConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"permissionName": vm.permissionName,
					"permissionDesc": vm.permissionDesc,
					"permissionType": vm.permissionType,
					"permissionPattern": vm.permissionPattern,
					"permissionMethod": vm.permissionMethod,
					"permissionStatus": vm.permissionStatus,
					"isOTP": vm.isOTP
				}
			};
			PermissionService.newPermission(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

	}

})();