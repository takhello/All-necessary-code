(function() {
	"use strict";
	angular.module("adminManageApp").controller("VersionAddController", VersionAddController);
	VersionAddController.$injector = ['$scope', '$modalInstance', 'VersionService'];

	function VersionAddController($scope, $modalInstance, VersionService) {
		var vm = this;
		vm.addVersionCancel = addVersionCancel;
		vm.addVersionConfirm = addVersionConfirm;
		vm.isAlertHide = true;
		vm.addSuccessCallback = addSuccessCallback;
		vm.addFailCallback = addFailCallback;
		vm.closeError = closeError;

		function closeError() {
			vm.isAlertHide = true;
		}

		function addVersionCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addVersionConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"versionDesc": vm.versionDesc
				}
			};
			VersionService.newVersion(obj, vm.addSuccessCallback, vm.addFailCallback);
		}

		function addSuccessCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function addFailCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();