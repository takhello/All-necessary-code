(function() {
	"use strict";
	angular.module('adminManageApp').controller("UserController", UserController);
	UserController.$injector = ['$scope', 'RoleService', '$modal', '$state'];

	function UserController($scope, RoleService, $modal, $state) {
		var vm = this;
		vm.getRoleList = getRoleList;
		vm.deleteRole = deleteRole;
		vm.editRole = editRole;
		vm.addRole = addRole;
		vm.getUserToFunction = getUserToFunction;
			console.log('getUserToFunctionaaaaa');

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roles =testData();
		// getRoleList();

		function testData(){
			console.log('user-Lisr测试数据 success');
		return {
				data1:{UserId:"1231230",UserName:"bbb",Department:"ccc",Group:"ddd"},
				data2:{UserId:"1231231",UserName:"bbb",Department:"ccc",Group:"ddd"},
				data3:{UserId:"1231232",UserName:"bbb",Department:"ccc",Group:"ddd"},
				data4:{UserId:"1231233",UserName:"bbb",Department:"ccc",Group:"ddd"}
			};
		}


		function getUserToFunction(id) {
			console.log('getUserToFunction');
			$state.go('home.user.user-function', {
				id: id
			});
		}

		
		function getRoleList() {
			var obj = {
				roleName: vm.roleName,
				roleStatus: vm.roleStatus
			};
			RoleService.getRoleList(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.roles = result.data.roleList;
			
		}

		function failCallback(error) {
			if (error.data.code === 403) {
				$state.go('home.403');
			}
		}

		function deleteRole(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "RoleDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					roleData: function() {
						return vm.roles;
					},
					roleId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getRoleList);
		}

		function editRole(role) {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "RoleEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editRoleIdItem: function() {
						return role.roleId;
					},

					RoleData: function() {
						return role;
					}
				}
			});
			modalInstance.result.then(getRoleList);
		}

		function addRole() {
			var modalInstance = $modal.open({
				templateUrl: "app/user/user-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop: false,
				controller: "UserAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getRoleList);
		}
	}

})();