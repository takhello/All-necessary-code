(function(){
	"use strict";
	angular.module("adminManageApp").service("VersionService",VersionService);
	VersionService.$injector = ['$resource'];
	function VersionService($resource){
		var services = {
			getVersion:getVersion,
			newVersion:newVersion
		};
		return services;
		function getVersion(params,onSuccess,onError){
			var url = SERVICE_URL + "admin/versions";
			var _resource = $resource(url,{},{
				get:{
					"method":"GET"
				}
			});
			return _resource.get().$promise.then(onSuccess,onError);
		}
		function newVersion(params, onSuccess, onError){
			var url = SERVICE_URL+'admin/version';
			var _resource = $resource(url,{},{
				create:{
					method:"POST",
					params:{}
				}
			});
			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}
	}
})();