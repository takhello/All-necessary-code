(function() {
	"use strict";

	angular.module("adminManageApp").controller('HomeController', HomeController);
	HomeController.$injector = [];

	function HomeController() {
		
	}
})();