module.exports = function(grunt) {
	/**
	 * Load grunt module
	 */
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-csslint');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    //grunt.loadNpmTasks('grunt-jsdoc');
    grunt.loadNpmTasks('grunt-replace');
    
    /**
     * Grunt configuration
     */
    grunt.initConfig({
    	pkg: grunt.file.readJSON('package.json'),
    	webapp_path: 'src/main/webapp',
    	jsdoc_path: 'jsdoc',
    	csslint: {
    		strict: {
    		    options: {
    		    	import: 2
    		    },
    		    src: ['<%=webapp_path%>/app/**/*.css']
    		}
    	},
        jshint: {
            mypage: [
             	'Gruntfile.js', 
                '<%=webapp_path%>/app/**/*.js'
           	]
        }
    });
    /**
     * Register grunt task
     */
    grunt.registerTask('dev', ['csslint','jshint:mypage']);
    grunt.registerTask('release', ['csslint','jshint:mypage']);
};