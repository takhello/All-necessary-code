package com.aia.mypage.util.errorMessage;

public class ErrorMessageUtil {

    public static final String ACCESS_DENIED = "Access denied.";

    public static final String USER_UNREGISTERED = "User doesn't exist.";

    public static final String GROUP_UNREGISTERED = "Group doesn't exist.";

    public static final String ADMIN_GROUP_UNREGISTERED = "Admin Group doesn't exist.";

    public static final String ROLE_UNREGISTERED = "Role doesn't exist.";

    public static final String PERMISSION_UNREGISTERED = "Permission doesn't exist.";

    public static final String ADMIN_USER_UNREGISTERED = "The association of admin and user doesn't exist.";

    public static final String USER_GROUP_UNREGISTERED = "The association of user and group doesn't exist.";

    public static final String GROUP_ROLE_UNREGISTERED = "The association of group and role doesn't exist.";

    public static final String ROLE_PERMISSION_UNREGISTERED = "The association of role and permission doesn't exist.";

    public static final String ADMIN_USER_REGISTERED = "The association of admin and user already exist.";

    public static final String USER_GROUP_REGISTERED = "The association of user and group already exist.";

    public static final String GROUP_ROLE_REGISTERED = "The association of group and role already exist.";

    public static final String ROLE_PERMISSION_REGISTERED = "The association of role and permission already exist.";

    public static final String UPDATE_FAILED = "Update failed.";

    public static final String ADD_FAILED = "Add failed.";

    public static final String PARAMETER_IS_REQUIRED = "@param is required.";

    public static final String IS_DEFAULT = "@default is default, cannot be deleted or updated.";

    public static final String ROLE_PERMISSION_MAPPING = "The association of role and permission already exist. if you want to delete this role, please delete all associations first.";

    public static final String GROUP_ROLE_MAPPING = "The association of group and role already exist. if you want to delete this group, please delete all associations first.";

    public static final String USER_GROUP_MAPPING = "The association of user and group already exist. if you want to delete this user, please delete all associations first.";

    // // Admininistration work-User Management
    public static final String ERROR_MESSAGE_52001 = "Add failed.";

    public static final String ERROR_MESSAGE_52002 = "User Id already exists.";

    public static final String ERROR_MESSAGE_52003 = "The association of admin and user doesn't exist.";

    public static final String ERROR_MESSAGE_52004 = "Delete failed.";

    public static final String ERROR_MESSAGE_52005 = "Update failed.";

    public static final String ERROR_MESSAGE_52101 = "Admin Group doesn't exist.";

    public static final String ERROR_MESSAGE_52102 = "The association of user and group already exist. if you want to delete this user, please delete all associations first.";

    public static final String USER_UNLOCK = "This customer ID didn't locked, please double check and then input the ID to search.";

}