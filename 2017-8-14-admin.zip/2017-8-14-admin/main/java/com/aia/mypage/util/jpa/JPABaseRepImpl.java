package com.aia.mypage.util.jpa;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.sql.DataSource;

import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.beanutil.ReflectUtil;
import com.aia.mypage.util.exception.SysException;

public abstract class JPABaseRepImpl<T> implements JPABaseRep<T> {

    private Class<T> persistentClass;

    protected abstract EntityManager getEntityManager();

    private static EntityManagerFactory entityManagerFactory;

    private static EntityManagerFactory getFactoryInstance() {

        if (entityManagerFactory == null) {
            Context context;
            DataSource ds = null;
            Map<String, String> properties = new HashMap<String, String>();
            Connection conn = null;
            try {

                context = new InitialContext();
                ds = (DataSource) context.lookup("java:comp/env/jdbc/sg_policy");
                conn = ds.getConnection();

                String dbType = conn.getMetaData().getDatabaseProductName();
                if (dbType.toLowerCase().contains("adaptive server enterprise")) {
                    properties.put("hibernate.dialect", "org.hibernate.dialect.Sybase11Dialect");
                } else if (dbType.toLowerCase().contains("sql server")) {
                    properties.put("hibernate.dialect", "org.hibernate.dialect.SQLServerDialect");
                } else if (dbType.toLowerCase().contains("db2")) {
                    properties.put("hibernate.dialect", "org.hibernate.dialect.DB2Dialect");
                } else if (dbType.toLowerCase().contains("oracle")) {
                    properties.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");
                } else {
                    // query database
                    Statement stmt = conn.createStatement();
                    String value = null;
                    ResultSet rs = stmt.executeQuery("select * from t_config where key_code='dbtype'");
                    while (rs.next()) {
                        value = rs.getString("value");
                        properties.put("hibernate.dialect", value);
                    }
                    if (value == null) {
                        throw new SQLException(
                                "[ERROR] You should configure key 'dbtype' in table t_config in database mypage!");
                    }
                }
            }
            catch (NamingException e) {
                e.printStackTrace();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    conn.close();
                }
                catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            entityManagerFactory = Persistence.createEntityManagerFactory("persistenceUnit", properties);
        }
        return entityManagerFactory;
    }

    public JPABaseRepImpl() {
        this.persistentClass = ReflectUtil.getGenericTypeArgument(this.getClass());
    }

    private EntityManager createEntityManager() {
        EntityManager entityManager = getFactoryInstance().createEntityManager();
        return entityManager;
    }

    private void closeEntityManager(EntityManager entityManager) {
        if (entityManager != null) {
            entityManager.close();
        }
    }

    public T create(T t) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            entityManager.persist(t);
            entityManager.getTransaction().commit();
            return t;
        }
        catch (Exception e) {
            if (entityManager != null) {
                entityManager.getTransaction().rollback();
            }
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public T update(T t) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            entityManager.merge(t);
            entityManager.getTransaction().commit();
            return t;
        }
        catch (Exception e) {
            if (entityManager != null) {
                entityManager.getTransaction().rollback();
            }
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public void remove(Serializable id) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            T t = (T) entityManager.find(persistentClass, id);
            if (t != null) {
                t = entityManager.merge(t);
                entityManager.remove(t);
            }
            entityManager.getTransaction().commit();
        }
        catch (Exception e) {
            if (entityManager != null) {
                entityManager.getTransaction().rollback();
            }
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public void remove(T t) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            t = entityManager.merge(t);
            entityManager.remove(t);
            entityManager.getTransaction().commit();
        }
        catch (Exception e) {
            if (entityManager != null) {
                entityManager.getTransaction().rollback();
            }
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public T find(Serializable id) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            T t = (T) entityManager.find(persistentClass, id);
            if (t == null) {
                return null;
            }
            return t;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public T getReference(Serializable id) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            T t = (T) entityManager.getReference(persistentClass, id);
            return t;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    @SuppressWarnings("unchecked")
    public List<T> query(SqlParameters sqlParameters) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            Query query = createQuery(entityManager, sqlParameters);
            List<T> resultList = query.getResultList();
            return resultList;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public int newUpdate(SqlParameters sqlParameters) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            Query query = createQuery(entityManager, sqlParameters);
            int executeUpdate = query.executeUpdate();
            entityManager.getTransaction().commit();
            return executeUpdate;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public T querySingleResult(SqlParameters sqlParameters) {
        List<T> resultList = query(sqlParameters);
        if (resultList.size() == 0) {
            return null;
        } else {
            return resultList.get(0);
        }
    }

    @SuppressWarnings("unchecked")
    public List<T> queryByNoParamters(String sql) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            return entityManager.createQuery(sql).getResultList();
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public T querySingleResultByNoParamters(String sql) {
        return queryByNoParamters(sql).get(0);
    }

    public long count(SqlParameters sqlParameters) {
        SqlParameters countSqlParameters = new SqlParameters();
        StringBuffer countSql = buildCountSql(sqlParameters.getSql());

        countSqlParameters.setSql(countSql);
        countSqlParameters.setParameters(sqlParameters.getParameters());
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            Query query = createQuery(entityManager, countSqlParameters);
            long count = (Long) query.getSingleResult();
            return count;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    @SuppressWarnings("unchecked")
    public List<T> queryPage(SqlParameters sqlParameters, int pageNumber, int pageSize) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            Query query = createQuery(entityManager, sqlParameters);
            int start = (pageNumber - 1) * pageSize;
            query.setFirstResult(start);
            query.setMaxResults(pageSize);
            List<T> resultList = query.getResultList();
            return resultList;
        }
        catch (Exception e) {
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    public int execute(SqlParameters sqlParameters) {
        EntityManager entityManager = null;
        try {
            entityManager = createEntityManager();
            entityManager.getTransaction().begin();
            Query query = createQuery(entityManager, sqlParameters);
            int row = query.executeUpdate();
            entityManager.getTransaction().commit();
            return row;
        }
        catch (Exception e) {
            if (entityManager != null) {
                entityManager.getTransaction().rollback();
            }
            throw new SysException(e);
        }
        finally {
            closeEntityManager(entityManager);
        }
    }

    private Query createQuery(EntityManager em, SqlParameters sqlParameters) {

        StringBuffer sql = sqlParameters.getSql();
        Map<String, Object> parameters = sqlParameters.getParameters();
        Query query = em.createQuery(sql.toString());
        Set<String> keys = parameters.keySet();
        Iterator<String> iterator = keys.iterator();
        String key;
        Object data;
        while (iterator.hasNext()) {
            key = iterator.next();
            data = parameters.get(key);
            query.setParameter(key, data);
        }

        return query;
    }

    private StringBuffer buildCountSql(StringBuffer sql) {

        int beginIndex_from = sql.toString().indexOf("from");
        String sql_from_ex = sql.substring(0, beginIndex_from);
        sql_from_ex = sql_from_ex.replaceAll("select", "");
        sql_from_ex = sql_from_ex.replaceAll("distinct", "");
        sql_from_ex = sql_from_ex.trim();

        String sql_where_rear = "";
        int beginIndex_where = sql.toString().indexOf("where");
        if (beginIndex_where != -1) {
            sql_where_rear = sql.substring(beginIndex_where).trim();
            sql_where_rear = sql_where_rear.replaceAll("1=1 and", "");
            sql_where_rear = sql_where_rear.replaceAll("1=1", "");

            int beginIndex_orderby = sql_where_rear.toString().indexOf("order by");
            if (beginIndex_orderby != -1) {
                sql_where_rear = sql_where_rear.substring(0, beginIndex_orderby);
            }

            if (sql_where_rear.trim().length() == "where".length()) {
                sql_where_rear = "";
            }
        }

        String sql_from_where = "";
        if (beginIndex_where != -1) {
            sql_from_where = sql.substring(beginIndex_from, beginIndex_where);
        } else {
            sql_from_where = sql.substring(beginIndex_from);
        }

        StringBuffer countSql = new StringBuffer(
                "select count(" + sql_from_ex + ") " + sql_from_where + sql_where_rear);
        return countSql;
    }

}