package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Function;

public interface AdminFunctionDAO {
	
	List<Function> getAllFunction();

}
