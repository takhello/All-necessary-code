package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminFunctionPermissionFP;

public interface AdminFunctionPermissionFPDAO {
	
	List<AdminFunctionPermissionFP> getAllFunctionPermission();

}
