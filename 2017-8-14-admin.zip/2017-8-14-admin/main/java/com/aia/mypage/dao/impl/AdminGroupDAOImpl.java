package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminGroupDAO;
import com.aia.mypage.entity.AdminGroup;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminGroupDAOImpl extends JPABaseRepImpl<AdminGroup> implements AdminGroupDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public AdminGroup getAdminGroupById(String groupId) {
        StringBuffer sql = new StringBuffer("from AdminGroup where groupId =:groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public List<AdminGroup> getAdminGroupsList() {
        StringBuffer sql = new StringBuffer("from AdminGroup");
        return queryByNoParamters(sql.toString());
    }

    public AdminGroup addAdminGroup(AdminGroup adminGroup) {
        adminGroup = super.create(adminGroup);
        return adminGroup;
    }

    public boolean deleteAdminGroupById(String groupId) {
        super.remove(groupId);
        return true;
    }

    public AdminGroup updateAdminGroup(AdminGroup adminGroup) {
        adminGroup = super.update(adminGroup);
        return adminGroup;
    }

}
