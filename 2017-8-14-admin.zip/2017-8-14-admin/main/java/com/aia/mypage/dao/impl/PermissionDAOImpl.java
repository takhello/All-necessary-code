package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.PermissionDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class PermissionDAOImpl extends JPABaseRepImpl<Permission> implements PermissionDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public Permission getPermissionById(String permissionId) {
        StringBuffer sql = new StringBuffer("from Permission where permissionId = :permissionId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("permissionId", permissionId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public List<Permission> getPermissionsList(Permission permission) {
        String permissionId = permission.getPermissionId();
        StringBuffer sql = new StringBuffer("from Permission where 1=1");
        Map<String, Object> parameters = new HashMap<String, Object>();
        String permissionMethod = permission.getPermissionMethod();
        if (!"".equals(permissionMethod) && permissionMethod != null) {
            sql.append(" and permissionMethod = :permissionMethod");
            parameters.put("permissionMethod", permissionMethod);
        }
        if (!"".equals(permissionId) && permissionId != null) {
            sql.append(" and permissionId = :permissionId");
            parameters.put("permissionId", permissionId);
        }
        String permissionName = permission.getPermissionName();
        if (!"".equals(permissionName) && permissionName != null) {
            sql.append(" and lower(permissionName) like :permissionName");
            parameters.put("permissionName", "%" + permissionName.toLowerCase() + "%");
        }
        String permissionPattern = permission.getPermissionPattern();
        if (!"".equals(permissionPattern) && permissionPattern != null) {
            sql.append(" and lower(permissionPattern) like:permissionPattern");
            parameters.put("permissionPattern", "%" + permissionPattern.toLowerCase() + "%");
        }
        String permissionType = permission.getPermissionType();
        if (!"".equals(permissionType) && permissionType != null) {
            sql.append(" and permissionType =:permissionType");
            parameters.put("permissionType", permissionType);
        }
        String permissionStatus = permission.getPermissionStatus();
        if (!"".equals(permissionStatus) && permissionStatus != null) {
            sql.append(" and permissionStatus =:permissionStatus");
            parameters.put("permissionStatus", permissionStatus);
        }
        String isOTP = permission.getIsOTP();
        if (!"".equals(isOTP) && isOTP != null) {
            sql.append(" and isOTP =:isOTP");
            parameters.put("isOTP", isOTP);
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<Permission> permissionList = super.query(sqlParameters);
        return permissionList;

    }

    public boolean deletePermissionById(String permissionId) {
        super.remove(permissionId);
        return true;
    }

    public Permission updatePermissionById(Permission permission) {
        permission = super.update(permission);
        return permission;
    }

    public Permission addPermission(Permission permission) {
        permission = super.create(permission);
        return permission;
    }
}
