package com.aia.mypage.dao;

import com.aia.mypage.entity.TempAccount;

public interface TempAccountDAO {

    TempAccount addTempAccount(TempAccount tempAccount);

    TempAccount getTempAccountByVerifyString(String verifyString);

    int updateTempAccount(int id);

}
