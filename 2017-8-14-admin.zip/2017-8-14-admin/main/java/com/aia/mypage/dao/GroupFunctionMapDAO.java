package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.GroupFunctionMapVO;

public interface GroupFunctionMapDAO {
	
	List<GroupFunctionMapVO> getAllGroupFunctionMap();

}
