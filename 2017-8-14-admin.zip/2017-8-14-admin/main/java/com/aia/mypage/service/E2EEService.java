package com.aia.mypage.service;

import java.net.MalformedURLException;

import org.apache.xmlrpc.XmlRpcException;

import com.aia.mypage.entity.RegisterHistory;
import com.aia.mypage.entity.ReponseResult;

public interface E2EEService {

    ReponseResult unLockeUser(String custId);

    RegisterHistory queryRegHistory(String partyId);

    public boolean isLocked(String custId) throws MalformedURLException, XmlRpcException;

}
