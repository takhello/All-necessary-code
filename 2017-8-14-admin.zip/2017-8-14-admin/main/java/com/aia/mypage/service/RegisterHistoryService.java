package com.aia.mypage.service;

public interface RegisterHistoryService {

    void updateStatus(String custId);

}
