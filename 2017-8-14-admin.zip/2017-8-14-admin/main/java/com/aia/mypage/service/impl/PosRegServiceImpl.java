package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.PosRegDAO;
import com.aia.mypage.entity.ActiveUserInfo;
import com.aia.mypage.service.PosRegSerice;

public class PosRegServiceImpl implements PosRegSerice {

    @Autowired
    @Qualifier("posRegDAOImpl")
    private PosRegDAO posRegDAO;

    @Override
    public List<ActiveUserInfo> getUserList(String custId, String name) {

        return posRegDAO.getUserList(custId, name);
    }

}
