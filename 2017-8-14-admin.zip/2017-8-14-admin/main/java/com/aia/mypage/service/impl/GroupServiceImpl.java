package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.GroupDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.util.BaseUtil;

public class GroupServiceImpl implements GroupService {

    @Autowired
    @Qualifier("groupDAOImpl")
    private GroupDAO groupDAO;

    public List<Group> getGroupsList(Group group) {

        return groupDAO.getGroupsList(group);
    }

    public Group addGroup(Group group) {
        group.setCreateTime(new Date());
        group.setIsDefault(BaseUtil.IS_DEFAULT_N);
        group = groupDAO.addGroup(group);
        return group;
    }

    public boolean deleteGroupById(String groupId) {
        boolean result = groupDAO.deleteGroupById(groupId);
        return result;
    }

    @Override
    public Group updateGroupById(Group group) {
        Group newGroup = groupDAO.getGroupById(group.getGroupId());
        if (newGroup == null) {
            return null;
        }
        newGroup.setGroupName(group.getGroupName());
        newGroup.setGroupStatus(group.getGroupStatus());
        newGroup.setGroupDesc(group.getGroupDesc());
        newGroup.setUpdateTime(new Date());
        group = groupDAO.updateGroup(newGroup);
        return group;
    }

    public Group getGroupById(String groupId) {
        Group group = groupDAO.getGroupById(groupId);
        return group;
    }

}
