package com.aia.mypage.service;

import com.aia.mypage.entity.AdminGroupFunction;
import com.aia.mypage.entity.AdminGroupFunctionInfo;

public interface AdminGroupFunctionService {

    AdminGroupFunctionInfo getAdminGroupFunctionInfo(String groupId);
    
    AdminGroupFunction addAdminGroupFunction(AdminGroupFunction adminGroupFunction);
    
    boolean deleteAdminGroupFunction(String groupId);
}
