package com.aia.mypage.service;

public interface UserFunctionService {

	 void initGroupFunctionMap() throws Exception;
}
