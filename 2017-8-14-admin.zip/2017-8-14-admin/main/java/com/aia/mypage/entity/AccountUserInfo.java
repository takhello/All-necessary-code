package com.aia.mypage.entity;

import java.io.Serializable;

public class AccountUserInfo implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -7859013597019470488L;

    /** account_id. */
    private int accountId;

    /** user_id. */
    private int userId;

    /** account_name. */
    private String accountName;

    /** account_type. */
    private String accountType;

    /** email. */
    private String email;

    /** is_enabled. */
    private String isEnabled;

    /** register_type. */
    private String registerType;

    /** picture. */
    private String picture;

    public AccountUserInfo(int accountId, int userId, String accountName, String accountType, String email,
            String isEnabled, String registerType, String picture) {
        super();
        this.accountId = accountId;
        this.userId = userId;
        this.accountName = accountName;
        this.accountType = accountType;
        this.email = email;
        this.isEnabled = isEnabled;
        this.registerType = registerType;
        this.picture = picture;
    }

    public AccountUserInfo() {
        super();
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

    public String getRegisterType() {
        return registerType;
    }

    public void setRegisterType(String registerType) {
        this.registerType = registerType;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

}
