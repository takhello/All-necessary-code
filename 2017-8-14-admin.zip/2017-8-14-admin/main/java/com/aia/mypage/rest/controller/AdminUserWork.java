package com.aia.mypage.rest.controller;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.xmlrpc.XmlRpcException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.ActiveUserInfo;
import com.aia.mypage.entity.RegisterHistory;
import com.aia.mypage.entity.ReponseResult;
import com.aia.mypage.entity.TempAccount;
import com.aia.mypage.entity.User;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.service.AuditLogService;
import com.aia.mypage.service.E2EEService;
import com.aia.mypage.service.PosRegSerice;
import com.aia.mypage.service.RegisterHistoryService;
import com.aia.mypage.service.TempAccountService;
import com.aia.mypage.service.UserService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class AdminUserWork extends BaseController {

    @Autowired
    @Qualifier("tempAccountServiceImpl")
    private TempAccountService tempAccountService;

    @Autowired
    @Qualifier("accountServiceImpl")
    private AccountService accountService;

    @Autowired
    @Qualifier("auditLogServiceImpl")
    private AuditLogService auditLogService;

    @Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;

    @Autowired
    @Qualifier("e2EEServiceImpl")
    private E2EEService e2EEService;

    @Autowired
    @Qualifier("posRegSericeImpl")
    private PosRegSerice posRegSerice;

    @Autowired
    @Qualifier("registerHistoryServiceImpl")
    private RegisterHistoryService registerHistoryService;

    @ResponseBody
    @RequestMapping(value = "/user/{custId}/pre_login", method = RequestMethod.GET)
    public Map<String, Object> adminLogin(@PathVariable String custId, HttpServletRequest request,
            HttpServletResponse response) {

        User user = userService.getUserByPartyId(custId);
        if (user == null) {
            returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, "account not found");
        }
        Account account = accountService.getAccountByUserId(user.getUserId());
        TempAccount tempAccount = tempAccountService.addTempAccount(account.getAccountId());
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("custId", account.getAccountName());
        data.put("loginUUID", tempAccount.getVerifyString());
        successJson.put("data", data);
        return successJson;
    }

    @ResponseBody
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public Map<String, Object> getUsers(HttpServletRequest request, HttpServletResponse response) {
        String custId = request.getParameter("custId");
        String name = request.getParameter("custName");
        if (StringUtils.isBlank(custId) || StringUtils.isBlank(name)) {
            returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, "You must input the ID or name.");
        }
        List<ActiveUserInfo> userList = posRegSerice.getUserList(custId, name);

        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        successJson.put("data", userList);
        return successJson;
    }

    @ResponseBody
    @RequestMapping(value = "/locked_user", method = RequestMethod.GET)
    public Map<String, Object> getLockUser(HttpServletRequest request, HttpServletResponse response)
            throws MalformedURLException, XmlRpcException {

        String custId = request.getParameter("custId");
        if (StringUtils.isBlank(custId)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("custId"));
        }

        User user = userService.getUserByPartyId(custId);
        if (user == null) {
            RegisterHistory regHistory = e2EEService.queryRegHistory(custId);
            if (regHistory == null) {
                return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
            }
            if (regHistory.getIsLockedAccount().equals("N")) {
                return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNLOCK);
            }
            Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
            Map<String, Object> data = new HashMap<String, Object>();
            data.put("custId", regHistory.getCustId());
            data.put("custName", "");
            data.put("status", regHistory.getIsLockedAccount());
            data.put("lockType", "00");
            data.put("dataSource", "Manual Registration");
            data.put("failedReason", "No matching record in account table");
            data.put("lcokTime", regHistory.getRegDateTime());
            successJson.put("data", data);
            return successJson;

        }
        boolean locked = e2EEService.isLocked(custId);
        if (locked) {
            List<ActiveUserInfo> userList = posRegSerice.getUserList(custId, null);
            ActiveUserInfo activeUserInfo = userList.get(0);
            Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
            Map<String, Object> data = new HashMap<String, Object>();
            data.put("custId", activeUserInfo.getCustId());
            data.put("custName", activeUserInfo.getName());
            data.put("status", "Y");
            data.put("lockType", "01");
            data.put("dataSource", "Login");
            data.put("failedReason", "Password 5 attemps failed");
            data.put("lcokTime", "");
            successJson.put("data", data);
            return successJson;
        } else {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNLOCK);
        }
    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/user/status", method = RequestMethod.PUT)
    public Map<String, Object> editUsers(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String custId = (String) data.get("custId");
        String status = (String) data.get("status");
        Account account = new Account();
        account.setAccountName(custId);
        account.setIsEnabled(status);
        account = accountService.changeUserStatus(account);
        if (account == null) {
            returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
        }
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/user/unlock_stauts", method = RequestMethod.PUT)
    public Map<String, Object> lockAndUnlock(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String custId = (String) data.get("custId");
        String lockType = (String) data.get("lockType");

        if (StringUtils.isBlank(custId)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("cust id"));
        }
        if (lockType.equals("00")) {
            RegisterHistory regHistory = e2EEService.queryRegHistory(custId);
            if (regHistory == null) {
                returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
            }
            if (regHistory.getIsLockedAccount().equals("N")) {
                return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNLOCK);
            }
            registerHistoryService.updateStatus(custId);
        }

        ReponseResult result = e2EEService.unLockeUser(custId);
        if (!result.isSuccess()) {
            returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, result.getMessage());
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

}
