package com.aia.mypage.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.dao.AdminUserAdminGroupDAO;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserAdminGroupInfo;
import com.aia.mypage.entity.AdminUserGroup;
import com.aia.mypage.service.AdminUserAdminGroupService;
import com.aia.mypage.service.AdminUserService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.beanutil.ReflectUtil;
import com.aia.mypage.util.errorMessage.ErrorCodeUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class AdminUserController extends BaseController {

    @Autowired
    @Qualifier("adminUserServiceImpl")
    private AdminUserService adminUserService;

    @Autowired
    @Qualifier("adminUserAdminGroupServiceImpl")
    private AdminUserAdminGroupService adminUserAdminGroupService;

    @Autowired
    @Qualifier("adminUserAdminGroupDAOImpl")
    private AdminUserAdminGroupDAO adminUserAdminGroupDAO;

    /**
     * retrieving admin user list.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_users", method = RequestMethod.GET)
    public Map<String, Object> getAdminUserList(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        List<AdminUserAdminGroupInfo> list = adminUserAdminGroupService.getAdminUserAdminGroupList(null);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("adminUserList", list);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * get admin user by userId.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_user/{user_id}", method = RequestMethod.GET)
    public Map<String, Object> getAdminUserByUserId(@PathVariable String user_id, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        if (StringUtils.isEmpty(user_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("user_id"));
        }
        List<AdminUserAdminGroupInfo> list = adminUserAdminGroupService.getAdminUserAdminGroupList(user_id);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("adminUserList", list);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * creating admin user.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_user", method = RequestMethod.POST)
    public Map<String, Object> addAdmin(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        Map<String, Object> dataMap = (Map<String, Object>) jsonMap.get("data");
        String userId = (String) dataMap.get("userId");
        if (StringUtils.isEmpty(userId)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("userId"));
        }
        AdminUser adminUserExist = adminUserService.getAdminUserByUserId(userId);

        if (adminUserExist != null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52002,
                    ErrorMessageUtil.ERROR_MESSAGE_52002);
        }
        AdminUser adminUser = ReflectUtil.convertMaptoBean(AdminUser.class, dataMap);

        // insert into T_ADMIN_USER
        try {
            adminUser = adminUserService.addAdminUser(adminUser);

            // insert into T_ADMIN_USER_GROUP
            List<String> groupIdList = (List<String>) dataMap.get("groupIdList");
            for (String groupId : groupIdList) {
                AdminUserGroup aug = new AdminUserGroup();
                aug.setUserId(userId);
                aug.setGroupId(groupId);

                adminUserAdminGroupService.addAdminUserGroup(aug);
            }
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52001,
                    ErrorMessageUtil.ERROR_MESSAGE_52001);
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * deleting admin user.
     * 
     * @param user_id
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_user/{user_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteAdmin(@PathVariable String user_id, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        if (StringUtils.isEmpty(user_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("user_id"));
        }

        AdminUser adminUser = adminUserService.getAdminUserByUserId(user_id);
        if (adminUser == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52003,
                    ErrorMessageUtil.ERROR_MESSAGE_52003);
        }

        try {
            // delete AdminUser
            adminUserService.deleteAdminByUserId(user_id);

            // delete AdminUserGroup
            adminUserAdminGroupService.deleteAdminUserGroup(user_id);
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52004,
                    ErrorMessageUtil.ERROR_MESSAGE_52004);
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * updating admin user.
     * 
     * @param user_id
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_user/{user_id}", method = RequestMethod.PUT)
    public Map<String, Object> updateAdmin(@PathVariable String user_id, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) throws Exception {

        if (StringUtils.isEmpty(user_id)) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("user_id"));
        }

        AdminUser adminUser = adminUserService.getAdminUserByUserId(user_id);
        if (adminUser == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52003,
                    ErrorMessageUtil.ERROR_MESSAGE_52003);
        }

        Map<String, Object> dataMap = (Map<String, Object>) jsonMap.get("data");
        String name = (String) dataMap.get(BaseUtil.NAME);
        String telephone = (String) dataMap.get(BaseUtil.TELEPHONE);
        String email = (String) dataMap.get(BaseUtil.EMAIL);
        String department = (String) dataMap.get(BaseUtil.DEPARTMENT);

        adminUser.setName(name);
        adminUser.setTelephone(telephone);
        adminUser.setEmail(email);
        adminUser.setDepartment(department);

        boolean result = false;
        try {
            result = adminUserService.updateAdmin(adminUser);

            // delete AdminUserGroup
            adminUserAdminGroupService.deleteAdminUserGroup(user_id);

            // insert into T_ADMIN_USER_GROUP
            List<String> groupIdList = (List<String>) ((Map<String, Object>) jsonMap.get("data")).get("groupIdList");
            for (String groupId : groupIdList) {
                AdminUserGroup aug = new AdminUserGroup();
                aug.setUserId(user_id);
                aug.setGroupId(groupId);

                adminUserAdminGroupService.addAdminUserGroup(aug);
            }
        }
        catch (Exception e) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52005,
                    ErrorMessageUtil.ERROR_MESSAGE_52005);
        }

        if (!result) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorCodeUtil.ERROR_CODE_52005,
                    ErrorMessageUtil.ERROR_MESSAGE_52005);
        }
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

}
