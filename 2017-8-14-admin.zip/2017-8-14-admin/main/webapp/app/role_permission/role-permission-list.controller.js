(function() {
	"use strict";
	angular.module("adminManageApp").controller('RolePermissionController', RolePermissionController);
	RolePermissionController.$injector = ['$scope', '$stateParams', '$state', 'RoleToPermissionService', 'PermissionService', '$modal'];

	function RolePermissionController($scope, $stateParams, $state, RoleToPermissionService, PermissionService, $modal) {
		var vm = this;
		vm.backToRole = backToRole;
		vm.addRolePermission = addRolePermission;
		vm.deleteRolePermission = deleteRolePermission;

		vm.loadSuccessCallback = loadSuccessCallback;
		vm.relatedSuccessCallback = relatedSuccessCallback;
		vm.rolePermissionSelected = rolePermissionSelected;
		vm.selectedSuccessCallback = selectedSuccessCallback;
		vm.selectedFailCallback = selectedFailCallback;

		vm.rolePermissionRelated = rolePermissionRelated;
		vm.rolePermissionSelected = rolePermissionSelected;
		
		PermissionService.getPermission(vm.loadSuccessCallback);

		function backToRole() {
			$state.go('home.role');
		}

		function loadSuccessCallback(result) {
			vm.allPermissions = result.data.permissionList;
			rolePermissionRelated();
		}

		function rolePermissionRelated() {
			RoleToPermissionService.getRolePermissionList($stateParams.id,vm.relatedSuccessCallback, vm.rolePermissionSelected);
		}

		function relatedSuccessCallback(result) {

			vm.currentPermissions = result.data.rolePermissionList;
			rolePermissionSelected();
		}

		function rolePermissionSelected() {
			RoleToPermissionService.getAllRolePermission({},vm.selectedSuccessCallback, vm.selectedFailCallback);
		}

		function selectedSuccessCallback(result) {
			var arr = [];
			vm.currentRolePermissions = result.data.rolePermissionList;
			if (vm.currentRolePermissions.length === 0) {
				vm.selectedPermissions = vm.allPermissions;
			} else {

				angular.forEach(vm.allPermissions, function(item) {
					var flag = vm.currentRolePermissions.length;
					angular.forEach(vm.currentRolePermissions, function(value) {
						if (item.permissionId === value.permissionId) {
							return;
						} else {
							flag -= 1;
							if (flag === 0) {
								arr.push(item);
							}
						}
					});
				});
				vm.selectedPermissions = arr;
			}

		}

		function selectedFailCallback() {
			vm.selectedPermissions = vm.allPermissions;
		}

		function addRolePermission(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/role_permission/role-permission-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "RolePermissionAddController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					permissionid: function() {
						return id;
					},
					roleId: function() {
						return $stateParams.id;
					}
				}
			});
			modalInstance.result.then(PermissionService.getPermission(vm.loadSuccessCallback));
		}

		function deleteRolePermission(rolePermissionId) {
			var modalInstance = $modal.open({
				templateUrl: "app/role_permission/role-permission-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "RolePermissionDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					rolePermissionId: function() {
						return rolePermissionId;
					}
				}
			});
			modalInstance.result.then(PermissionService.getPermission(vm.loadSuccessCallback));

		}

	}
})();