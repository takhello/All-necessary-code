(function() {
	"use strict";

	angular.module("adminManageApp").service('NoticeService', NoticeService);
	NoticeService.$injector = ['$resource'];
	function NoticeService($resource) {
		var services = {
			newNotice:newNotice,
			getNoticeList:getNoticeList	
		};
		return services;
		//update role service
		function getNoticeList(params,onSuccess,onError) {
            console.log('3.1');
			var url = SERVICE_URL + "v1/admin/customer/notices";
			// /v1/admin/customer/notices 
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
            console.log('3.2');
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
		function newNotice(params, onSuccess, onError){
			console.log('3.1');
			var url = SERVICE_URL + "v1/admin/customer/notice";
			// v1/admin/customer/notice 
			console.log('3.2');
			
          	var _resources = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resources.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
			
		}
	}
})();