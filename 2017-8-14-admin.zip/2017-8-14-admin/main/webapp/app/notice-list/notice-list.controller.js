(function() {
    "use strict";
    angular.module('adminManageApp').controller("NoticeListController", NoticeListController);
    NoticeListController.$injector = ['$scope', 'NoticeService', '$modal', '$state'];

    function NoticeListController($scope, NoticeService, $modal, $state) {
        var vm = this;
        vm.notice = testData();
        vm.addNotice = addNotice;
        vm.editNotice = editNotice;
    
        vm.deleteRole = deleteRole;
        vm.getUserToFunction = getUserToFunction;

        vm.successCallback = successCallback;
        vm.failCallback = failCallback;
        vm.getNoticeList = getNoticeList;
        getNoticeList();
        console.log('开始');

        function testData() {
            console.log('user-Lisr测试数据 success');
            return {
                data1: { From: "1", To: "111", Page: "ccc1", NoticeMessage: "ddd1",Status:"asd1",LastUpdateBy:"qwe1",noticeId:"1"},
                data2: { From: "2", To: "112", Page: "ccc2", NoticeMessage: "ddd2",Status:"asd2",LastUpdateBy:"qwe2",noticeId:"1"},
                data3: { From: "3", To: "113", Page: "ccc3", NoticeMessage: "ddd3",Status:"asd3",LastUpdateBy:"qwe3",noticeId:"1"},
                data4: { From: "4", To: "114", Page: "ccc4", NoticeMessage: "ddd4",Status:"asd4",LastUpdateBy:"qwe4",noticeId:"1"},
                data5: { From: "5", To: "115", Page: "ccc5", NoticeMessage: "ddd5",Status:"asd5",LastUpdateBy:"qwe5",noticeId:"1"},
                data6: { From: "6", To: "116", Page: "ccc6", NoticeMessage: "ddd6",Status:"asd6",LastUpdateBy:"qwe6",noticeId:"1"},
                data7: { From: "7", To: "117", Page: "ccc7", NoticeMessage: "ddd7",Status:"asd7",LastUpdateBy:"qwe7",noticeId:"1"},
                data8: { From: "8", To: "118", Page: "ccc8", NoticeMessage: "ddd8",Status:"asd8",LastUpdateBy:"qwe8",noticeId:"1"},
                data9: { From: "9", To: "119", Page: "ccc9", NoticeMessage: "ddd9",Status:"asd9",LastUpdateBy:"qwe9",noticeId:"1"},
                data10: { From: "10", To: "121", Page: "ccc10", NoticeMessage: "ddd10",Status:"asd10",LastUpdateBy:"qwe10",noticeId:"2"},
                data11: { From: "11", To: "122", Page: "ccc11", NoticeMessage: "ddd11",Status:"asd11",LastUpdateBy:"qwe11",noticeId:"2"},
                data12: { From: "12", To: "123", Page: "ccc12", NoticeMessage: "ddd12",Status:"asd12",LastUpdateBy:"qwe12",noticeId:"2"},
                data13: { From: "13", To: "124", Page: "ccc13", NoticeMessage: "ddd13",Status:"asd13",LastUpdateBy:"qwe13",noticeId:"2"},
            };
        }
        $('#reservation').daterangepicker();
  
 
        
        function getUserToFunction(id) {
            console.log('getUserToFunction');
            $state.go('home.user.user-function', {
                id: id
            });
        }

        //getNoticeList
        function getNoticeList() {
            console.log('2');
            var obj = {
                    "userId":"test",
                    "sessionId":"test",
                    "country":"test",
                    "language":"test",
                    "partyId":"01",
                    "type":"test",
                    "noticeFromDate":"01-Jan-2014",
                    "noticeToDate":"01-Jan-2017"
            };
            console.log('3');
            console.log('debug');
            console.log(obj);
            NoticeService.getNoticeList(obj, vm.successCallback, vm.failCallback);
        }

        function successCallback(result) {
            console.log('4');
            // $scope.$apply();
            console.log(result);  
            console.log('5');
            $('#example01').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });

        }

        function failCallback(error) {
                console.log('6');
                // $scope.$apply();
                console.log(result);            
        }

        function deleteRole(id) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-delete.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleDeleteController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    roleData: function() {
                        return vm.roles;
                    },
                    roleId: function() {
                        return id;
                    }
                }
            });
            modalInstance.result.then(getNoticeList);
        }

        function editNotice(notice) {
            var modalInstance = $modal.open({
                templateUrl: "app/notice-list/notice-edit.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "NoticeEditController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    editNoticeIdItem: function() {
                        return notice.noticeId;
                    },

                    NoticeData: function() {
                        return notice;
                    }
                }
            });
            modalInstance.result.then(getNoticeList);
        }


        function addNotice() {
            var modalInstance = $modal.open({
                templateUrl: "app/notice-list/notice-new.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "NoticeAddController",
                controllerAs: "vm",
                size: 'md'
            });
            modalInstance.result.then(getNoticeList);
        }
    }

})();
