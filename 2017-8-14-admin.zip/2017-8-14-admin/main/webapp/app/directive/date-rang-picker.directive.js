(function(){
	"use strict";
	angular.module("adminManageApp").directive("daterangpickerDirective", function() {
		return {
			template: '<div class="input-group">'+
		                  '<button type="button" class="btn btn-default pull-right" id="daterange-btn">'+
		                    '<span>'+
		                      '<i class="fa fa-calendar"></i> Date range picker'+
		                    '</span>'+
		                    '<i class="fa fa-caret-down"></i>'+
		                  '</button>'+
		                '</div>',

			controller: function() {
				$('#daterange-btn').daterangepicker(
			        {
			          ranges: {
			            
			            'Over the past week': [moment().subtract(6, 'days'), moment()],
			            'Over the past month': [moment().subtract(29, 'days'), moment()],
			            'Over the past 6 month': [moment().subtract(6, 'month'), moment()],
			            'Over the past 1 year': [moment().subtract(12, 'month'), moment()]
			            
			          },
			          startDate: moment().subtract(29, 'days'),
			          endDate: moment()
			        },
			        function (start, end) {
			          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
			          console.log(start._d);
			        }
			    );
			}
		};
	});
})();
