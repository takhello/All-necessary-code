(function() {
	"use strict";

	angular.module("adminManageApp").controller('EditGroupController', EditGroupController);
	EditGroupController.$injector = ['$scope', '$modal', '$modalInstance', 'editGroupIdItem', 'groupData', 'GroupsFunctionsService'];

	function EditGroupController($scope, $modal, $modalInstance, editGroupIdItem, groupData, GroupsFunctionsService) {
		var vm = this;
		vm.groupData = groupData;
		vm.editGroupCancel = editGroupCancel;
		vm.editGroupConfirm = editGroupConfirm;
		vm.closeError = closeError;
		vm.isAlertHide = true;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.groupVal = angular.copy(groupData);

		// vm.isUserAccessManagement = isUserAccessManagement();
		// vm.isUserWork = isUserWork();
		// vm.isSummaryReports = isSummaryReports();
		// vm.isNoticeMessageManagement = isNoticeMessageManagement();
		// get ID function
		vm.getIdFunction = getIdFunction;
		vm.getIdFunctionSuccessCallback = getIdFunctionSuccessCallback;
		vm.getIdFunctionsFailCallback = getIdFunctionsFailCallback;
		
		//getFunctionList
		vm.getFunctionList = getFunctionList;
		vm.getFunctionListSuccessCallback = getFunctionListSuccessCallback;
		vm.getFunctionListFailCallback = getFunctionListFailCallback;

		getIdFunction();
		getFunctionList();
		//存储 数据回显
	

		
		function closeError(){
			vm.isAlertHide = true;
		}

		function editGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function editGroupConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"groupName": vm.groupName,
					"groupDesc": vm.Description,
					"functionIdList": vm.selected
				}
			};
			GroupsFunctionsService.editGroup(editGroupIdItem, object, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

		function getIdFunction(){
			var obj={
					"userId": USER_ID,
					"sessionId": USER_SESSIONID,
					"country": USER_COUNTRY,
					"language": USER_LANGUAGE
				};
			GroupsFunctionsService.getIdFunction(editGroupIdItem,obj, vm.getIdFunctionSuccessCallback, vm.getIdFunctionsFailCallback);
		}
		function getIdFunctionSuccessCallback(result){
			vm.FunctionList = result.data.functionList;
			vm.checkedFunctionLevel = serializeData(result.data.adminGroupFunctionInfo.functionList,"functionLevel","2");
			function serializeData(data,key,val){
				var obj=[];
				var index = 0;
				for (var i=0; i < data.length;  i++) {
					if(data[i][key] == val){
						// var a  = {name:data[i].functionName,data:data[i].functionName};
						obj.push(data[i].functionId); 
					}
				}
				return obj;
			}

			vm.selected = vm.checkedFunctionLevel;
	    	vm.selectedTags = [];
	    	vm.updateSelection = updateSelection;
		    vm.isSelected = isSelected;
	    	vm.updateSelected =updateSelected;
		}
		
		function getIdFunctionsFailCallback(result){
		}
		//getFunctionList
		function getFunctionList() {
			var obj = {
				"userId": USER_ID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
			};
			GroupsFunctionsService.getFunctionList(obj, vm.getFunctionListSuccessCallback, vm.getFunctionListFailCallback);
		}
		function getFunctionListSuccessCallback(result) {
			vm.FunctionList = result.data.functionList;
			vm.functionLevel = serializeData(result.data.functionList,"functionLevel","1");
			vm.parentFunction1 = serializeData(result.data.functionList,"parentFunctionId","10");
			vm.parentFunction2 = serializeData(result.data.functionList,"parentFunctionId","20");
			vm.parentFunction3 = serializeData(result.data.functionList,"parentFunctionId","30");
			vm.parentFunction4 = serializeData(result.data.functionList,"parentFunctionId","40");
			function serializeData(data,key,val){
				var obj=[];
				var index = 0;
				for (var i=0; i < data.length;  i++) {
					if(data[i][key] == val){
						// var a  = {name:data[i].functionName,data:data[i].functionName};
						obj.push({isName:data[i].functionName,isId:data[i].functionId});
					}
				}
				return obj;
			}
		}
		function getFunctionListFailCallback(error) {
		
		}
		function isUserAccessManagement(){
			
		}
		
		function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}
	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	    function isSelected(id){
	        return vm.selected.indexOf(id)>=0;
	    }
	    
	}
})();