for(var i=0; i<4; i++){

	(function(i){
		images[i].onclick = function(){
			console.log(i)
		}


	})(i)




}