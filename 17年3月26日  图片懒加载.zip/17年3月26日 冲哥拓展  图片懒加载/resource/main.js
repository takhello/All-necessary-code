/*路径是 调用配置文件的 页面 位置为基准的*/
//加载方法
//作者： 童彪

// 
//函数配置 开始 
require.config({

	baseUrl:'resource/app',   /*自己常用小模块儿*/
	paths:{

		//项目 需要文件 路径配置
		//
		//
		"jquery" :"../lib/jquery-1.11.1",/*以 前面定义的 app 为基准位置 */
		//响应式框架bootstrap 地址
		"bootstrap":"../lib/bootstrap",
		//主JS文件 地址
		"index"  :"../js/index",
		//设置JQ动画插件 地址
 		"easing":"../js/easing",
		//设置返回顶层插件 地址
		"move_top":"../js/move-top",
		


		//比例环 地址
		"bi_li_huan":"bi_li_huan",
		//字符去重 地址
		"zi_fu_qu_chong":"zi_fu_qu_chong",

		//设置 选项卡插件ResponsiveTabs 路径
		"easyResponsiveTabs":"easyResponsiveTabs",
		//设置 jQuery灯箱效果插件-Swipebox swipe box js 路径
		"swipebox":"jquery.swipebox.min",


	},

	shim:{/*多层依赖*/
		/*"某个模块儿":"依赖于哪个模块儿"*/
		//配置 模块儿的依赖关系
		'easyResponsiveTabs':["jquery"],

		'swipebox':["jquery"],

		'index':["jquery"],

		'bootstrap':["jquery"],

		'easing':["jquery"],

		'move_top':["jquery"]
	}

});
/*函数配置结束*/

//需要立即执行 的 函数放这儿

/*自己的  程序 启动 */
require(['jquery']);

//调用 比例环 
require(['bi_li_huan']);

//调用响应式框架bootstrap
require(['bootstrap']);

//调用 选项卡插件ResponsiveTabs
require(['easyResponsiveTabs']);

//调用jQuery灯箱效果插件
require(['swipebox']);

//调用 返回顶层插件
require(['move_top']);

//调用 设置JQ动画插件
require(['easing']);

//调用 index.js
require(['index']);





