/*
*	@author tongbiao
*	@email 
*	@qq  
*   @lastdate 
* 插件功能 描述，代码结构要求
*/

;(function ($) {
  var pluginName = 'mytab',  //定义插件名
  	  //插件的参数默认值
      defaults = 
      {
      	nav:"#nav",
      	con:"#con",
      	eve:"mouseenter"
      };
  //... 插件主体功能代码 ...
  $.fn[ pluginName ] = function (options) 
  {
  	  var that =this;
	  var settings = $.extend({}, defaults, options);//将默认值,参数值合并到setting
		//主体代码开始
		$(settings.nav).on(settings.eve,"li",_clicFunc);
			function _clicFunc()
			{
				var _this = this;
			    outtime = setTimeout(_outtab,400);
				function _outtab()
				{
					var index_nav = $(_this).index();
					$(_this).siblings("li").removeClass('act');
					$(_this).addClass('act');

					$(settings.con).children('li').css({"opacity":"0"});
					$(settings.con).children('li').eq(index_nav).animate({
						"opacity":"1"
					})
					$(that).children("#bottom_nav").text($(_this).text());	
				}
			}
		if(settings.eve == "mouseenter")
		{
			$(settings.nav).on("mouseleave","li",_clicFunc1);
			function _clicFunc1()
			{
				clearTimeout(outtime);	
				console.log(1);	
			}
		}
  }

})(jQuery);

