/*
*	@author enter
*	@email 
*	@qq 
*   @lastdate 
* 插件功能 描述，代码结构要求
*/

;(function ($) {
  var pluginName = 'enter',  //定义插件名
  	  //插件的参数默认值
      defaults = {
      	eve:"click",
      	backgrund:"#popupBaground",
      	popup:"#popup",
      	enter:"#enter",
      	close:"#close",
      	enterform:"#enterform",
      	password:"#password",
      	num:"#num"
      };

  //... 插件主体功能代码 ...
  $.fn[ pluginName ] = function (options) {

	  var settings = $.extend({}, defaults, options);//将默认值,参数值合并到setting

	  //主体代码开始
	  $("#enter").on("click",_funcPopup);
		function _funcPopup()
		{
			$(settings.backgrund).fadeIn();
			$(settings.popup).fadeIn();
			$(settings.enter).fadeOut();
		}
		$(settings.backgrund).on("click",_popupFadeout);
		$(settings.close).on("click",_popupFadeout);
		function _popupFadeout(){
			$(settings.popup).fadeOut();
			$(settings.backgrund).fadeOut();
			$(settings.enter).fadeIn();
		}
		 $(settings.enterform).on("submit",_funcSubmit);
			 function _funcSubmit()
			 {
			 	 var num=$(settings.num).val();
				 var password=$(settings.password).val();
			 	if(num=="" || password=="")
			 	{
			 		alert("请填写全部内容");
			 		return false;
			 	}
			 }
  }

})(jQuery);

