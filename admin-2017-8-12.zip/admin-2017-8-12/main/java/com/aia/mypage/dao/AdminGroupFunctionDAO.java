package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminGroupFunction;
import com.aia.mypage.entity.GroupFunctionMapVO;

public interface AdminGroupFunctionDAO {
    
    AdminGroupFunction addAdminGroupFunction(AdminGroupFunction adminGroupFunction);
    
    boolean deleteAdminGroupFunction(String groupId);
    
 
}
