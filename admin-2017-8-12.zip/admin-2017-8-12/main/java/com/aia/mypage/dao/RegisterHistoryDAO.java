package com.aia.mypage.dao;

import com.aia.mypage.entity.RegisterHistory;

public interface RegisterHistoryDAO {

    RegisterHistory queryRegHistory(String partyId);

    void updateStatus(String custId);
}
