package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserGroupDAO;
import com.aia.mypage.entity.AdminUserGroup;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserGroupDAOImpl extends JPABaseRepImpl<AdminUserGroup> implements AdminUserGroupDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AdminUserGroup addAdminUserGroup(AdminUserGroup aug) {

        return super.create(aug);
    }

    @Override
    public boolean deleteAdminUserGroup(String user_id) {
        StringBuffer sql = new StringBuffer("delete from AdminUserGroup where userId=:userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("userId", user_id);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        super.execute(sqlParameters);
        return true;
    }

    @Override
    public List<AdminUserGroup> getAdminUserGroupByGroupId(String groupId) {
        StringBuffer sql = new StringBuffer("from AdminUserGroup where groupId=:groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return query(sqlParameters);
    }

}
