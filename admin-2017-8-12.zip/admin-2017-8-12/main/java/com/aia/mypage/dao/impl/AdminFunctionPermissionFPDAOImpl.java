package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminFunctionPermissionFPDAO;
import com.aia.mypage.entity.AdminFunctionPermissionFP;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminFunctionPermissionFPDAOImpl extends JPABaseRepImpl<AdminFunctionPermissionFP>
		implements AdminFunctionPermissionFPDAO {

	@Override
	protected EntityManager getEntityManager() {
		return null;
	}

	@Override
	public List<AdminFunctionPermissionFP> getAllFunctionPermission() {

		StringBuffer sql = new StringBuffer(
				"select new com.aia.mypage.entity.AdminFunctionPermissionFP(f.url,f.functionName,p.permissionPattern,p.permissionMethod,p.isOTP) ");
		sql.append("from Function f , Permission p , FunctionPermission fp ");
		sql.append("where fp.functionId = f.functionId ");
		sql.append("and  fp.permissionId = p.permissionId ");
		sql.append("and f.functionStatus = 'Y'");

		Map<String, Object> parameters = new HashMap<String, Object>();
		SqlParameters sqlParameters = new SqlParameters(sql, parameters);

		return super.query(sqlParameters);
	}

}
