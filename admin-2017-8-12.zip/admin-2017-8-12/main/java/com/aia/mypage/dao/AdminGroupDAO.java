package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminGroup;

public interface AdminGroupDAO {

    List<AdminGroup> getAdminGroupsList();

    AdminGroup addAdminGroup(AdminGroup adminGroup);

    boolean deleteAdminGroupById(String groupId);

    AdminGroup getAdminGroupById(String groupId);

    AdminGroup updateAdminGroup(AdminGroup group);
    
}
