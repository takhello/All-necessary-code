package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.User;

public interface UserDAO {

    List<User> getList();

    User getUserById(int userId);

    List<User> getgetUserList(String partyId, String firstName);

    User getUserByPartyId(String partyId);
}
