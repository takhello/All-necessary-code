package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.UserWorkAuditLog;

public interface UserWorkAuditLogDAO {

    List<UserWorkAuditLog> getAuditLogList(int userId);

}
