package com.aia.mypage.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.ConfigVersionDAO;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class ConfigVersionDAOImpl extends JPABaseRepImpl<ConfigVersion> implements ConfigVersionDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<ConfigVersion> getConfigVersionList() {

        String sql = "select new ConfigVersion(a.versionId, a.versionDesc, a.createTime, a.createBy) from ConfigVersion a order by a.versionId desc";
        return queryByNoParamters(sql);
    }

    @Override
    public ConfigVersion addConfigVersion(ConfigVersion configVersion) {

        return create(configVersion);
    }
}
