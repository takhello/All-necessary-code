package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.TempAccountDAO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.entity.TempAccount;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class TempAccountDAOImpl extends JPABaseRepImpl<TempAccount> implements TempAccountDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public TempAccount addTempAccount(TempAccount tempAccount) {
        tempAccount = super.create(tempAccount);
        return tempAccount;
    }

    public TempAccount getTempAccountByVerifyString(String verifyString) {
        StringBuffer sql = new StringBuffer(
                "from TempAccount a where a.verifyString=:verifyString and isEnabled=:isEnabled");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("isEnabled", BaseUtil.IS_ENABLED_Y);
        parameters.put("verifyString", verifyString);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public int updateTempAccount(int id) {
        StringBuffer sql = new StringBuffer("update TempAccount set isEnabled =:isEnabled where id=:id");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("isEnabled", BaseUtil.IS_ENABLED_N);
        parameters.put("id", id);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        int result = super.newUpdate(sqlParameters);
        return result;
    }

}
