package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.ActiveUserInfo;

public interface PosRegDAO {

    List<ActiveUserInfo> getUserList(String custId, String name);

}
