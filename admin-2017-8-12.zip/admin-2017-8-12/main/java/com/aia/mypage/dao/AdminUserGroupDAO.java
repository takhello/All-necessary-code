package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminUserGroup;

public interface AdminUserGroupDAO {
    
    AdminUserGroup addAdminUserGroup(AdminUserGroup aug);

    boolean deleteAdminUserGroup(String user_id);
    
    List<AdminUserGroup> getAdminUserGroupByGroupId(String groupId);

}
