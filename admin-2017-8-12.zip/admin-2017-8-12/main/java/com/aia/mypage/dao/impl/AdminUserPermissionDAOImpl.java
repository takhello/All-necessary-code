package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserPermissionDAO;
import com.aia.mypage.entity.AdminUserPermissionVO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserPermissionDAOImpl extends JPABaseRepImpl<AdminUserPermissionVO>
		implements AdminUserPermissionDAO {

	@Override
	public List<AdminUserPermissionVO> getPermissionListByUserId(String userId) {

//		StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.AdminUserPermissionVO");
//		sql.append((fp2.permissionPattern, fp2.permissionMethod, fp2.isOTP, fp2.permissionStatus) ");
//		sql.append(
//				"from select u.userId, u.name, g.groupId from AdminUser u,AdminGroup g, AdminUserGroup ug where u.userId = ug.userId and g.groupId = ug.groupId as ug2 ,");
//		sql.append(
//				"select f.functionId, f.url, f.functionLevel, f.functionStatus, p.permissionId, p.permissionType,p.permissionPattern, p.permissionMethod, p.permissionStatus, p.isOTP, p.isDefault from Function f, Permission p, FunctionPermission fp where f.functionId = fp.functionId and p.permissionId = fp.permissionId as fp2 ");
//		sql.append("where ug2.userId =:userId");
		
		//sql.append("and f_p.permissionStatus = 'Y'");
		
		StringBuffer sql = new StringBuffer("from AdminUserPermissionVO where userId=:userId");

		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userId", userId);

		SqlParameters sqlParameters = new SqlParameters(sql, parameters);

		return super.query(sqlParameters);
	}

	@Override
	protected EntityManager getEntityManager() {
		return null;
	}

}
