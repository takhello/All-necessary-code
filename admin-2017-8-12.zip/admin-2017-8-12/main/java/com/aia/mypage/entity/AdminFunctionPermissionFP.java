package com.aia.mypage.entity;

import java.io.Serializable;

public class AdminFunctionPermissionFP implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7148230173416645639L;

	public AdminFunctionPermissionFP() {
		super();
	}

	public AdminFunctionPermissionFP(String functionPermissionId, String isDefault, String functionDesc,
			String functionStatus, String permissionId, String permissionName, String permissionDesc,
			String permissionType, String permissionStatus) {
		super();
		this.functionPermissionId = functionPermissionId;
		this.isDefault = isDefault;
		this.functionDesc = functionDesc;
		this.functionStatus = functionStatus;
		this.permissionId = permissionId;
		this.permissionName = permissionName;
		this.permissionDesc = permissionDesc;
		this.permissionType = permissionType;
		this.permissionStatus = permissionStatus;
	}

	public AdminFunctionPermissionFP(String url ,String functionName, String permissionPattern, String permissionMethod,
			String isOTP) {
		super();
		this.url = url;
		this.functionName = functionName;
		this.permissionPattern = permissionPattern;
		this.permissionMethod = permissionMethod;
		this.isOTP = isOTP;
	}

	private String functionPermissionId;

	private String isDefault;

	private String functionId;

	private String functionName;

	private String functionDesc;

	private String functionStatus;

	private String permissionId;

	private String permissionName;

	private String permissionDesc;

	private String permissionType;

	private String permissionPattern;

	private String permissionMethod;

	private String permissionStatus;

	private String isOTP;
	
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFunctionPermissionId() {
		return functionPermissionId;
	}

	public void setFunctionPermissionId(String functionPermissionId) {
		this.functionPermissionId = functionPermissionId;
	}

	public String getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getFunctionDesc() {
		return functionDesc;
	}

	public void setFunctionDesc(String functionDesc) {
		this.functionDesc = functionDesc;
	}

	public String getFunctionStatus() {
		return functionStatus;
	}

	public void setFunctionStatus(String functionStatus) {
		this.functionStatus = functionStatus;
	}

	public String getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(String permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	public String getPermissionDesc() {
		return permissionDesc;
	}

	public void setPermissionDesc(String permissionDesc) {
		this.permissionDesc = permissionDesc;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	public String getPermissionPattern() {
		return permissionPattern;
	}

	public void setPermissionPattern(String permissionPattern) {
		this.permissionPattern = permissionPattern;
	}

	public String getPermissionMethod() {
		return permissionMethod;
	}

	public void setPermissionMethod(String permissionMethod) {
		this.permissionMethod = permissionMethod;
	}

	public String getPermissionStatus() {
		return permissionStatus;
	}

	public void setPermissionStatus(String permissionStatus) {
		this.permissionStatus = permissionStatus;
	}

	public String getIsOTP() {
		return isOTP;
	}

	public void setIsOTP(String isOTP) {
		this.isOTP = isOTP;
	}

}
