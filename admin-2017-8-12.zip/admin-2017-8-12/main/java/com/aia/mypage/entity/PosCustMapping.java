package com.aia.mypage.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "db_cus..pos_cusmap")
@Entity
public class PosCustMapping implements Serializable {

    private static final long serialVersionUID = 1525910433247325669L;

    @Id
    @Column(name = "usr_id")
    private String userId;

    @Column(name = "cust_id")
    private String custId;

    @Column(name = "suffix_id")
    private String suffixId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getSuffixId() {
        return suffixId;
    }

    public void setSuffixId(String suffixId) {
        this.suffixId = suffixId;
    }

}
