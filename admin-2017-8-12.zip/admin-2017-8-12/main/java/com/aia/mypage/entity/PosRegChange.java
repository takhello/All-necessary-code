package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name = "POS_REG_CHANGE")
@Entity
public class PosRegChange implements Serializable{

	/**
	 * serialVersionUID.
	 */
	private static final long serialVersionUID = -1795597908002955350L;
	/** reg_id. */
    @Id
    @Column(name = "reg_id")
    private String regId;
    /** name. */
    @Column(name = "name")
    private String name;
    
    @Column(name = "first_name")
	private String firstName;
    
    @Column(name = "last_name")
	private String lastName;
    @Column(name = "sex")
	private String sex;
    @Column(name = "dob")
    private Date dob;
    @Column(name = "pol_no")
    private String polNo;
    @Column(name = "res_phone")
    private String resPhone;
    @Column(name = "off_phone")
    private String offPhone;
    @Column(name = "pager")
    private String pager;
    @Column(name = "mobile_phone")
    private String mobilePhone;
    @Column(name = "fax_no")
    private String faxNo;
    @Column(name = "parent_name")
    private String parentName;
    @Column(name = "svc_ind")
    private String svcInd;
    @Column(name = "timreg")
    private Date timReg;
    @Column(name = "timsvc")
    private Date timSvc;
    @Column(name = "f_id1")
    private String fId1;
    @Column(name = "f_id2")
    private String fId2;
    @Column(name = "updated_dte")
    private Date updatedDte;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "why")
    private String why;
    @Column(name = "new_pol_no")
    private String newPolNo;
    @Column(name = "new_f_id1")
    private String newFid1;
    @Column(name = "new_f_id2")
    private String newFid2;
    @Column(name = "new_svc_ind")
    private String newSvcInd;
    @Column(name = "new_name")
    private String newName;
    @Column(name = "new_sex")
    private String newSex;
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPolNo() {
		return polNo;
	}
	public void setPolNo(String polNo) {
		this.polNo = polNo;
	}
	public String getResPhone() {
		return resPhone;
	}
	public void setResPhone(String resPhone) {
		this.resPhone = resPhone;
	}
	public String getOffPhone() {
		return offPhone;
	}
	public void setOffPhone(String offPhone) {
		this.offPhone = offPhone;
	}
	public String getPager() {
		return pager;
	}
	public void setPager(String pager) {
		this.pager = pager;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getFaxNo() {
		return faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getSvcInd() {
		return svcInd;
	}
	public void setSvcInd(String svcInd) {
		this.svcInd = svcInd;
	}
	public Date getTimReg() {
		return timReg;
	}
	public void setTimReg(Date timReg) {
		this.timReg = timReg;
	}
	public Date getTimSvc() {
		return timSvc;
	}
	public void setTimSvc(Date timSvc) {
		this.timSvc = timSvc;
	}
	public String getfId1() {
		return fId1;
	}
	public void setfId1(String fId1) {
		this.fId1 = fId1;
	}
	public String getfId2() {
		return fId2;
	}
	public void setfId2(String fId2) {
		this.fId2 = fId2;
	}
	public Date getUpdatedDte() {
		return updatedDte;
	}
	public void setUpdatedDte(Date updatedDte) {
		this.updatedDte = updatedDte;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getWhy() {
		return why;
	}
	public void setWhy(String why) {
		this.why = why;
	}
	public String getNewPolNo() {
		return newPolNo;
	}
	public void setNewPolNo(String newPolNo) {
		this.newPolNo = newPolNo;
	}
	public String getNewFid1() {
		return newFid1;
	}
	public void setNewFid1(String newFid1) {
		this.newFid1 = newFid1;
	}
	public String getNewFid2() {
		return newFid2;
	}
	public void setNewFid2(String newFid2) {
		this.newFid2 = newFid2;
	}
	public String getNewSvcInd() {
		return newSvcInd;
	}
	public void setNewSvcInd(String newSvcInd) {
		this.newSvcInd = newSvcInd;
	}
	public String getNewName() {
		return newName;
	}
	public void setNewName(String newName) {
		this.newName = newName;
	}
	public String getNewSex() {
		return newSex;
	}
	public void setNewSex(String newSex) {
		this.newSex = newSex;
	}
}
