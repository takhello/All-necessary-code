package com.aia.mypage.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "PERMISSION_VIEW")
@Entity
public class AdminUserPermissionVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7946823513724533488L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private String userId;

	@Column(name = "permission_pattern")
	private String permissionPattern;

	@Column(name = "permission_method")
	private String permissionMethod;

	@Column(name = "is_otp")
	private String isOTP;

	@Column(name = "permission_status")
	private String permissionStatus;

	public AdminUserPermissionVO(String userId, String permissionPattern, String permissionMethod, String isOTP,
			String permissionStatus) {
		super();
		this.userId = userId;
		this.permissionPattern = permissionPattern;
		this.permissionMethod = permissionMethod;
		this.isOTP = isOTP;
		this.permissionStatus = permissionStatus;
	}

	public AdminUserPermissionVO() {

	}

	public String getPermissionPattern() {
		return permissionPattern;
	}

	public void setPermissionPattern(String permissionPattern) {
		this.permissionPattern = permissionPattern;
	}

	public String getPermissionMethod() {
		return permissionMethod;
	}

	public void setPermissionMethod(String permissionMethod) {
		this.permissionMethod = permissionMethod;
	}

	public String getIsOTP() {
		return isOTP;
	}

	public void setIsOTP(String isOTP) {
		this.isOTP = isOTP;
	}

	public String getPermissionStatus() {
		return permissionStatus;
	}

	public void setPermissionStatus(String permissionStatus) {
		this.permissionStatus = permissionStatus;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
