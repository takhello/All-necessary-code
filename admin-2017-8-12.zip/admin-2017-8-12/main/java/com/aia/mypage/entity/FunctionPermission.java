package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "T_FUNCTION_PERMISSION")
@Entity
public class FunctionPermission implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4933133223338886540L;

	/** functionPermissionId. */
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "function_permission_id")
    private String functionPermissionId;
    
    /** functionId. */
    @Column(name = "function_id")
    private String functionId;
    
    /** permissionId. */
    @Column(name = "permission_id")
    private String permissionId;
    
    /** isDefult. */
    @Column(name="is_defult")
    private String isDefult;
    
    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;
    
    /** create_time. */
    @Column(name = "update_time")
    private Date updateTime;

	public String getFunctionPermissionId() {
		return functionPermissionId;
	}

	public void setFunctionPermissionId(String functionPermissionId) {
		this.functionPermissionId = functionPermissionId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(String permissionId) {
		this.permissionId = permissionId;
	}

	public String getIsDefult() {
		return isDefult;
	}

	public void setIsDefult(String isDefult) {
		this.isDefult = isDefult;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
    
    

}
