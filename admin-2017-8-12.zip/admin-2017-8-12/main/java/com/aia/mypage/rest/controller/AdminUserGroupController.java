package com.aia.mypage.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.AdminUserGroupInfo;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.User;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.UserGroupService;
import com.aia.mypage.service.UserService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class AdminUserGroupController extends BaseController {

    @Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;

    @Autowired
    @Qualifier("groupServiceImpl")
    private GroupService groupService;

    @Autowired
    @Qualifier("userGroupServiceImpl")
    private UserGroupService userGroupService;

    /**
     * retrieving associations of User and Group list.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_user_groups", method = RequestMethod.GET)
    public Map<String, Object> getAdminUsers(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        String adminUserId = request.getParameter("adminUserId");
        if ("".equals(adminUserId) || adminUserId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("userId"));
        }

        List<AdminUserGroupInfo> adminUserList = userGroupService
                .getAdminUserGroupListByAdminUserId(Integer.parseInt(adminUserId));
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("adminUserGroupList", adminUserList);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * creating associations of User and Group.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/admin_user_group", method = RequestMethod.POST)
    public Map<String, Object> addUserGroup(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String userId = (String) data.get("userId");
        String groupId = (String) data.get("groupId");
        if ("".equals(userId) || userId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("userId"));
        }
        if ("".equals(groupId) || groupId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("groupId"));
        }

        User user = userService.getUserById(Integer.parseInt(userId));
        if (user == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_UNREGISTERED);
        }
        Group group = groupService.getGroupById(groupId);
        if (group == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_UNREGISTERED);
        }

        UserGroup usergroup = userGroupService.getSameUserGroup(Integer.parseInt(userId), groupId);
        if (usergroup != null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.USER_GROUP_REGISTERED);
        }
        userGroupService.addUserGroup(Integer.parseInt(userId), groupId);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

    /**
     * deleting associations of User and Group.
     * 
     * @param user_group_id
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/admin_user_group/{user_group_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteUserGroup(@PathVariable Integer user_group_id, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        UserGroup userGroup = userGroupService.getUserGroupById(user_group_id);
        if (userGroup == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.USER_GROUP_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(userGroup.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("user_group"));
        }

        userGroupService.deleteUserGroupById(user_group_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }
}
