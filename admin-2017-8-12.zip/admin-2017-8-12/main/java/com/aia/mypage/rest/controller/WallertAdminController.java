package com.aia.mypage.rest.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.util.constant.ConfigConstant;
import com.aia.mypage.util.forwarder.AesOperator;
import com.aia.mypage.util.forwarder.ForwarderUtil;
import com.aia.mypage.util.jsonutil.JsonUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class WallertAdminController {

    private final static String path = "v1";
    private final static Log logging = LogFactory.getLog(WallertAdminController.class);
    private final static CloseableHttpClient httpClient = HttpClients.createDefault();

    @ResponseBody
    @RequestMapping(value = "/customer/mapping", method = RequestMethod.GET)
    public void getCustomer(HttpServletRequest request, HttpServletResponse response) throws IOException {

        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/mapping", method = RequestMethod.POST)
    public void addCustomer(@RequestBody String reqBody, HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doPost(request, reqBody, response);
    }

    @ResponseBody
    @RequestMapping(value = "/report/statistical", method = RequestMethod.GET)
    public void statistical(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/report/endofday", method = RequestMethod.GET)
    public void endofday(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/notices", method = RequestMethod.GET)
    public void notices(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/notice", method = RequestMethod.POST)
    public void addNotice(@RequestBody String reqBody, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, reqBody, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/notice", method = RequestMethod.PUT)
    public void editNotice(@RequestBody String reqBody, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPut(request, reqBody, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/notice", method = RequestMethod.GET)
    public void getNotice(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/customer/notices_bytype", method = RequestMethod.GET)
    public void getNoticesByType(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    @ResponseBody
    @RequestMapping(value = "/report/auditlog", method = RequestMethod.GET)
    public void getAuditLog(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String user = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_USERNAME);
        String password = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_PASSWORD);
        String targetUrl = ConfigConstant.configMap.get(ConfigConstant.ADMIN_FORWARDER_ECARE_TARGET_URL);

        logging.debug("Start processing doGet...");
        String url = ForwarderUtil.getInstance().getUrl(request, path, targetUrl);
        /************** URL ***************/
        logging.debug("Url:" + url);
        logging.debug("Method:" + "GET");

        String result = null;
        Integer status = null;
        CloseableHttpResponse wmResponse = null;

        try {
            HttpGet get = new HttpGet(new URI(url));
            get.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());
            String valueAuthorization = ForwarderUtil.getInstance().getAuthHead(user,
                    AesOperator.getInstance().decrypt(password));
            valueAuthorization = valueAuthorization.replace("\n", "");
            get.addHeader("Authorization", valueAuthorization);
            get.addHeader("_role", "F");

            logging.debug("Start processing httpClient execute...");
            wmResponse = httpClient.execute(get);

            result = EntityUtils.toString(wmResponse.getEntity());
            status = wmResponse.getStatusLine().getStatusCode();
            if (status == null)
                status = 550;

            get.abort();
            EntityUtils.consume(wmResponse.getEntity());

        }
        catch (Exception e) {

            e.printStackTrace();
            result = "{\"success\":\"false\",\"message\":\"" + e.toString() + "\"}";
            status = 550;
            logging.error("Call request fail:" + e.toString());
        }
        finally {
            if (wmResponse != null)
                wmResponse.close();
        }
        logging.info("Status code:" + status);
        logging.info("Response result:" + result);

        response.setContentType("application/json;charset=utf-8");
        response.setStatus(status);
        if (status == 401) {
            result = "{\"success\":\"false\",\"message\":\"" + "Access Denied" + "\"}";
        }
        PrintWriter out = response.getWriter();
        out.print(result);
        out.close();
    }

    public void doPost(HttpServletRequest request, @RequestBody String reqBody, HttpServletResponse response)
            throws ServletException, IOException {
        String user = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_USERNAME);
        String password = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_PASSWORD);
        String targetUrl = ConfigConstant.configMap.get(ConfigConstant.ADMIN_FORWARDER_ECARE_TARGET_URL);

        logging.debug("Start processing doPost...");
        String url = ForwarderUtil.getInstance().getUrl(request, path, targetUrl);
        logging.debug("Url:" + url);
        logging.debug("Method:" + "POST");
        logging.debug("Request body:" + reqBody);
        /************** URL ***************/

        String result = null;
        Integer status = null;
        CloseableHttpResponse wmResponse = null;

        Map<String, Object> map = JsonUtil.getHashMapfromJsonString(reqBody);
        StringBuilder params = new StringBuilder();
        for (String key : map.keySet()) {
            params.append("&" + key + "=" + map.get(key));
        }
        params.replace(0, 1, "?");

        url = url + params;

        try {
            HttpPost post = new HttpPost(url);
            post.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());

            post.setHeader("Content-Type", "application/json");
            StringEntity stringEntity = new StringEntity(reqBody, "utf-8");

            post.setEntity(stringEntity);

            String valueAuthorization = ForwarderUtil.getInstance()
                    .getAuthHead(user, AesOperator.getInstance().decrypt(password)).replace("\r", "");
            valueAuthorization = valueAuthorization.replace("\n", "");
            post.addHeader("Authorization", valueAuthorization);
            post.addHeader("_role", "F");

            logging.debug("Start processing httpClient execute...");
            wmResponse = httpClient.execute(post);

            result = EntityUtils.toString(wmResponse.getEntity());
            status = wmResponse.getStatusLine().getStatusCode();
            if (status == null)
                status = 550;

            post.abort();
            EntityUtils.consume(wmResponse.getEntity());

        }
        catch (Exception e) {
            e.printStackTrace();
            result = "{\"success\":\"false\",\"message\":\"" + e.toString() + "\"}";
            status = 550;
            logging.error("Call request fail:" + e.toString());
        }
        finally {
            if (wmResponse != null)
                wmResponse.close();
        }
        logging.info("Status code:" + status);
        logging.info("Response result:" + result);

        response.setContentType("application/json;charset=utf-8");
        response.setStatus(status);
        if (status == 401) {
            result = "{\"success\":\"false\",\"message\":\"" + "Access Denied" + "\"}";
        }
        PrintWriter out = response.getWriter();
        out.print(result);
        out.close();
    }

    @RequestMapping(value = { "/**" }, method = RequestMethod.PUT)
    @ResponseBody
    protected void doPut(HttpServletRequest request, @RequestBody String reqBody, HttpServletResponse response)
            throws ServletException, IOException {
        String user = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_USERNAME);
        String password = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_PASSWORD);
        String targetUrl = ConfigConstant.configMap.get(ConfigConstant.ADMIN_FORWARDER_ECARE_TARGET_URL);

        logging.debug("Start processing doPut...");
        String url = ForwarderUtil.getInstance().getUrl(request, path, targetUrl);
        logging.debug("Url:" + url);
        logging.debug("Method:" + "PUT");
        logging.debug("Request body:" + reqBody);
        /************** URL ***************/

        String result = null;
        Integer status = null;
        CloseableHttpResponse wmResponse = null;

        try {
            HttpPut put = new HttpPut(url);
            put.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());

            put.setHeader("Content-Type", "application/json");
            put.setEntity(new StringEntity(reqBody, "utf-8"));
            String valueAuthorization = ForwarderUtil.getInstance()
                    .getAuthHead(user, AesOperator.getInstance().decrypt(password)).replace("\r", "");
            valueAuthorization = valueAuthorization.replace("\n", "");
            put.addHeader("Authorization", valueAuthorization);
            put.addHeader("_role", "F");

            logging.debug("Start processing httpClient execute...");
            wmResponse = httpClient.execute(put);

            result = EntityUtils.toString(wmResponse.getEntity());
            status = wmResponse.getStatusLine().getStatusCode();
            if (status == null)
                status = 550;

            put.abort();
            EntityUtils.consume(wmResponse.getEntity());

        }
        catch (Exception e) {
            e.printStackTrace();
            result = "{\"success\":\"false\",\"message\":\"" + e.toString() + "\"}";
            status = 550;
            logging.error("Call request fail:" + e.toString());
        }
        finally {
            if (wmResponse != null)
                wmResponse.close();
        }
        logging.info("Status code:" + status);
        logging.info("Response result:" + result);

        response.setContentType("application/json;charset=utf-8");
        response.setStatus(status);
        if (status == 401) {
            result = "{\"success\":\"false\",\"message\":\"" + "Access Denied" + "\"}";
        }

        PrintWriter out = response.getWriter();
        out.print(result);
        out.close();
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String user = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_USERNAME);
        String password = ConfigConstant.configMap.get(ConfigConstant.ESB_FORWARDER_ESB_PASSWORD);
        String targetUrl = ConfigConstant.configMap.get(ConfigConstant.ADMIN_FORWARDER_ECARE_TARGET_URL);
        logging.debug("Start processing doDelete...");
        String url = ForwarderUtil.getInstance().getUrl(request, path, targetUrl);
        /************** URL ***************/
        logging.debug("Url:" + url);
        logging.debug("Method:" + "DELETE");

        String result = null;
        Integer status = null;
        CloseableHttpResponse wmResponse = null;

        try {
            HttpDelete delete = new HttpDelete(url);
            delete.setConfig(RequestConfig.custom().setCookieSpec(CookieSpecs.STANDARD).build());

            String valueAuthorization = ForwarderUtil.getInstance()
                    .getAuthHead(user, AesOperator.getInstance().decrypt(password)).replace("\r", "");
            valueAuthorization = valueAuthorization.replace("\n", "");
            delete.addHeader("Authorization", valueAuthorization);
            delete.addHeader("_role", "F");

            logging.debug("Start processing httpClient execute...");
            wmResponse = httpClient.execute(delete);
            result = EntityUtils.toString(wmResponse.getEntity());
            status = wmResponse.getStatusLine().getStatusCode();
            if (status == null)
                status = 550;

            delete.abort();
            EntityUtils.consume(wmResponse.getEntity());

        }
        catch (Exception e) {
            e.printStackTrace();
            result = "{\"success\":\"false\",\"message\":\"" + e.toString() + "\"}";
            status = 550;
            logging.error("Call request fail:" + e.toString());
        }
        finally {
            if (wmResponse != null)
                wmResponse.close();
        }
        logging.info("Status code:" + status);
        logging.info("Response result:" + result);

        response.setContentType("application/json;charset=utf-8");
        response.setStatus(status);
        if (status == 401) {
            result = "{\"success\":\"false\",\"message\":\"" + "Access Denied" + "\"}";
        }

        PrintWriter out = response.getWriter();
        out.print(result);
        out.close();
    }

}
