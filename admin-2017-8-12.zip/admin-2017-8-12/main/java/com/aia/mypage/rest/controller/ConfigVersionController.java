package com.aia.mypage.rest.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.Config;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.entity.ErrorMessage;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.service.ConfigService;
import com.aia.mypage.service.ConfigVersionService;
import com.aia.mypage.service.ErrorMessageService;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;
import com.alibaba.fastjson.JSONObject;

@Controller
@RequestMapping(value = "admin")
public class ConfigVersionController extends BaseController {

    @Autowired
    @Qualifier("configVersionServiceImpl")
    private ConfigVersionService configVersionService;

    @Autowired
    @Qualifier("accountServiceImpl")
    private AccountService accountService;

    @Autowired
    @Qualifier("permissionServiceImpl")
    private PermissionService permissionService;

    @Autowired
    @Qualifier("roleServiceImpl")
    private RoleService roleService;

    @Autowired
    @Qualifier("groupServiceImpl")
    private GroupService groupService;

    @Autowired
    @Qualifier("rolePermissionServiceImpl")
    private RolePermissionService rolePermissionService;

    @Autowired
    @Qualifier("groupRoleServiceImpl")
    private GroupRoleService groupRoleService;

    @Autowired
    @Qualifier("configServiceImpl")
    private ConfigService configService;

    @Autowired
    @Qualifier("errorMessageServiceImpl")
    private ErrorMessageService errorMessageService;

    /**
     * get version list.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/versions", method = RequestMethod.GET)
    public Map<String, Object> getVersionList(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        List<ConfigVersion> configVersionList = configVersionService.getConfigVersionList();
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("versionList", configVersionList);
        successJson.put("data", data);
        return successJson;
    }

    /**
     * creating version.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/version", method = RequestMethod.POST)
    public Map<String, Object> addVersion(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get(BaseUtil.REQUEST_JSON_DATA);
        String versionDesc = (String) data.get("versionDesc");
        if ("".equals(versionDesc) || versionDesc == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("versionDesc"));
        }
        ConfigVersion configVersionInfo = new ConfigVersion();
        int userId = getUserId();
        String versionContent = getVersionContent();
        configVersionInfo.setCreateTime(new Date());
        configVersionInfo.setVersionDesc(versionDesc);
        configVersionInfo.setVersionContent(versionContent);
        configVersionInfo.setCreateBy(userId);
        configVersionService.addConfigVersion(configVersionInfo);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

    // get UserId.
    public int getUserId() {
        String userName = getUserName();
        Account account = accountService.getAccountByAccountName(userName);
        return account.getUserId();
    }

    // get Version content.
    public String getVersionContent() {
        Map<String, Object> versionContent = new LinkedHashMap<String, Object>();
        List<Permission> permissionsList = permissionService.getPermissionsList(new Permission());
        versionContent.put("permissions", permissionsList);
        List<Role> rolesList = roleService.getRolesList(new Role());
        versionContent.put("roles", rolesList);
        List<Group> groupsList = groupService.getGroupsList(new Group());
        versionContent.put("groups", groupsList);
        List<RolePermission> rolePermissionList = rolePermissionService.getRolePermissionList();
        versionContent.put("rolePermissions", rolePermissionList);
        List<GroupRole> groupRoleList = groupRoleService.getGroupRoleList();
        versionContent.put("groupRoles", groupRoleList);
        List<Config> configList = configService.getConfigList();
        versionContent.put("config", configList);
        List<ErrorMessage> errorMessageList = errorMessageService.getErrorMessageList();
        versionContent.put("errorMessage", errorMessageList);
        Object json = JSONObject.toJSON(versionContent);
        return json.toString();
    }
}
