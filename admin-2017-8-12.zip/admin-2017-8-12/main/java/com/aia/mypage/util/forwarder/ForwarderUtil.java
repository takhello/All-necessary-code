package com.aia.mypage.util.forwarder;

import java.nio.charset.Charset;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.codec.binary.Base64;

import org.apache.http.util.TextUtils;

public class ForwarderUtil {
    private static ForwarderUtil instance = null;

    public ForwarderUtil() {
    }

    public static ForwarderUtil getInstance() {
        if (instance == null)
            instance = new ForwarderUtil();
        return instance;
    }

    public String getAuthHead(String user, String password) {
        String auth = user + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("utf-8")));
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }

    public String getUrl(HttpServletRequest request, String path, String targetUrl) {
        String params = request.getQueryString();
        StringBuffer sb = request.getRequestURL();
        int urlPos = sb.indexOf(path);
        String url = sb.replace(0, urlPos, targetUrl).toString() + (TextUtils.isEmpty(params) ? "" : "?" + params);
        return url;
    }
}
