package com.aia.mypage.util.captcha;

import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import cn.aia.tools.security.DESPasswordManager;

public class EnvUtil {

    private static EnvUtil EnvUtil;

    private String companyNo;
    private String adminLoginId;
    private String adminPwd;
    private String encrypedAdminPwd;
    private String adminRealmId;
    private String realmId;
    private String loginModuleId;
    private String OtpSenderName;
    private String DEPTID;
    private String USERIDENTITY;
    private String GROUPID;
    private String OPTCDE;
    private String eventNotificationPolicyId;
    private String appLaunchDate;
    private List<String> eDocCategorysInSequence;
    private String beneficiaryDetailsOfPolicyBaseInfo;
    private String e2eeRPCURL;
    private String retrievePrincipalValue;
    private String JWTSecret;
    private int JWTAvaiableTimePeriod;
    private String smtpServer;
    private String emailFrom;
    private String logonService;
    private String bannerService;

    public static EnvUtil getInstance() {
        if (EnvUtil == null) {
            EnvUtil = new EnvUtil();
            EnvUtil.setEnv();
        }
        return EnvUtil;
    }

    private EnvUtil() {
    }

    private void setEnv() {
        Properties p = new Properties();
        try {
            p.load(this.getClass().getResourceAsStream(Constant.ENVUTIL_CONFIGURATIN_PATH));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.setCompanyNo(p.getProperty("companyCode").trim());
        this.setAdminLoginId(p.getProperty("adminLoginId").trim());
        this.setEncrypedAdminPwd(p.getProperty("adminPwd").trim());
        this.setAdminRealmId(p.getProperty("adminRealmId").trim());
        this.setRealmId(p.getProperty("realmId").trim());
        this.setLoginModuleId(p.getProperty("loginModuleId").trim());
        this.setOtpSenderName(p.getProperty("OtpSenderName").trim());
        this.setDEPTID(p.getProperty("DEPTID").trim());
        this.setUSERIDENTITY(p.getProperty("USERIDENTITY").trim());
        this.setGROUPID(p.getProperty("GROUPID").trim());
        this.setOPTCDE(p.getProperty("OPTCDE").trim());
        this.setEventNotificationPolicyId(p.getProperty("eventNotificationPolicyId").trim());
        this.setAppLaunchDate(p.getProperty("appLaunchDate").trim());
        this.seteDocCategorysInSequence(p.getProperty("eDocCategorysInSequence").trim());
        this.setBeneficiaryDetailsOfPolicyBaseInfo(p.getProperty("beneficiaryDetailsOfPolicyBaseInfo").trim());
        this.setE2eeRPCURL(p.getProperty("e2eeRPCURL").trim());
        this.setRetrievePrincipalValue(p.getProperty("retrievePrincipalValue").trim());
        this.setJWTSecret(p.getProperty("JWTSecret").trim());
        this.setJWTAvaiableTimePeriod(p.getProperty("JWTAvaiableTimePeriod").trim());
        this.setSmtpServer(p.getProperty("smtpServer").trim());
        this.setEmailFrom(p.getProperty("emailFrom").trim());
        this.setLogonService(p.getProperty("logonService").trim());
        this.setBannerService(p.getProperty("bannerService").trim());
    }

    public int getJWTAvaiableTimePeriod() {
        return JWTAvaiableTimePeriod;
    }

    public void setJWTAvaiableTimePeriod(String jWTAvaiableTimePeriod) {
        String[] strs = StringUtil.isEmptyOrWhitespace(jWTAvaiableTimePeriod) ? null
                : jWTAvaiableTimePeriod.split("\\*");
        int product = 1;
        for (String str : strs) {
            int num = Integer.valueOf(str.trim());
            product = product * num;
        }
        this.JWTAvaiableTimePeriod = product;
    }

    public String getEmailFrom() {
        return emailFrom;
    }

    public void setEmailFrom(String emailFrom) {
        this.emailFrom = emailFrom;
    }

    public String getSmtpServer() {
        return smtpServer;
    }

    public void setSmtpServer(String smtpServer) {
        this.smtpServer = smtpServer;
    }

    public String getJWTSecret() {
        return JWTSecret;
    }

    public void setJWTSecret(String jWTSecret) {
        JWTSecret = jWTSecret;
    }

    public String getRetrievePrincipalValue() {
        return retrievePrincipalValue;
    }

    public void setRetrievePrincipalValue(String retrievePrincipalValue) {
        this.retrievePrincipalValue = retrievePrincipalValue;
    }

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getAdminLoginId() {
        return adminLoginId;
    }

    public void setAdminLoginId(String adminLoginId) {
        this.adminLoginId = adminLoginId;
    }

    public String getAdminPwd() {
        // Encryp
        if (!StringUtils.isNotBlank(this.adminPwd)) {
            String decryptPassword = DESPasswordManager.decryptPassword(this.getEncrypedAdminPwd());
            this.setAdminPwd(decryptPassword);
        }

        return this.adminPwd;
    }

    public void setAdminPwd(String adminPwd) {
        this.adminPwd = adminPwd;
    }

    public String getEncrypedAdminPwd() {
        return encrypedAdminPwd;
    }

    public void setEncrypedAdminPwd(String encrypedAdminPwd) {
        this.encrypedAdminPwd = encrypedAdminPwd;
    }

    public String getAdminRealmId() {
        return adminRealmId;
    }

    public void setAdminRealmId(String adminRealmId) {
        this.adminRealmId = adminRealmId;
    }

    public String getRealmId() {
        return realmId;
    }

    public void setRealmId(String realmId) {
        this.realmId = realmId;
    }

    public String getLoginModuleId() {
        return loginModuleId;
    }

    public void setLoginModuleId(String loginModuleId) {
        this.loginModuleId = loginModuleId;
    }

    public String getOtpSenderName() {
        return OtpSenderName;
    }

    public void setOtpSenderName(String otpSenderName) {
        OtpSenderName = otpSenderName;
    }

    public String getDEPTID() {
        return DEPTID;
    }

    public void setDEPTID(String dEPTID) {
        DEPTID = dEPTID;
    }

    public String getUSERIDENTITY() {
        return USERIDENTITY;
    }

    public void setUSERIDENTITY(String uSERIDENTITY) {
        USERIDENTITY = uSERIDENTITY;
    }

    public String getGROUPID() {
        return GROUPID;
    }

    public void setGROUPID(String gROUPID) {
        GROUPID = gROUPID;
    }

    public String getOPTCDE() {
        return OPTCDE;
    }

    public void setOPTCDE(String oPTCDE) {
        OPTCDE = oPTCDE;
    }

    public String getEventNotificationPolicyId() {
        return eventNotificationPolicyId;
    }

    public void setEventNotificationPolicyId(String eventNotificationPolicyId) {
        this.eventNotificationPolicyId = eventNotificationPolicyId;
    }

    public void setAppLaunchDate(String appLaunchDate) {
        this.appLaunchDate = appLaunchDate;
    }

    public Date getAppLaunchDate() throws ParseException {
        return DateUtil.parseStr2Date(this.appLaunchDate, DateUtil.yy_MM_ddHHmmss);
    }

    public List<String> geteDocCategorysInSequence() {
        return eDocCategorysInSequence;
    }

    public void seteDocCategorysInSequence(String eDocCategorysInSequence) {
        this.eDocCategorysInSequence = Arrays.asList(eDocCategorysInSequence.split(","));
    }

    public String getBeneficiaryDetailsOfPolicyBaseInfo() {
        return beneficiaryDetailsOfPolicyBaseInfo;
    }

    public void setBeneficiaryDetailsOfPolicyBaseInfo(String beneficiaryDetailsOfPolicyBaseInfo) {
        this.beneficiaryDetailsOfPolicyBaseInfo = beneficiaryDetailsOfPolicyBaseInfo;
    }

    /**
     * @return the e2eeRPCURL
     */
    public String getE2eeRPCURL() {
        return e2eeRPCURL;
    }

    /**
     * @param e2eeRPCURL
     *            the e2eeRPCURL to set
     */
    public void setE2eeRPCURL(String e2eeRPCURL) {
        this.e2eeRPCURL = e2eeRPCURL;
    }

    /**
     * @param eDocCategorysInSequence
     *            the eDocCategorysInSequence to set
     */
    public void seteDocCategorysInSequence(List<String> eDocCategorysInSequence) {
        this.eDocCategorysInSequence = eDocCategorysInSequence;
    }

    public String getLogonService() {
        return logonService;
    }

    public void setLogonService(String logonService) {
        this.logonService = logonService;
    }

    public String getBannerService() {
        return bannerService;
    }

    public void setBannerService(String bannerService) {
        this.bannerService = bannerService;
    }

}
