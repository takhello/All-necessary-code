package com.aia.mypage.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.RegisterHistoryDAO;
import com.aia.mypage.service.RegisterHistoryService;

public class RegisterHistoryServiceImpl implements RegisterHistoryService {

    @Autowired
    @Qualifier("registerHistoryDAOImpl")
    private RegisterHistoryDAO registerHistoryDAO;

    @Override
    public void updateStatus(String custId) {

        registerHistoryDAO.updateStatus(custId);
    }

}
