package com.aia.mypage.service.impl;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.xmlrpc.XmlRpcException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.aia.mypage.dao.RegisterHistoryDAO;
import com.aia.mypage.entity.RegisterHistory;
import com.aia.mypage.entity.ReponseResult;
import com.aia.mypage.service.E2EEService;
import com.aia.mypage.util.captcha.Constant;
import com.aia.mypage.util.captcha.E2EEProxyFactory;
import com.aia.mypage.util.captcha.EnvUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.isprint.am.dto.bean.AuthResultTO;
import com.isprint.am.dto.bean.AuthnAccountTO;
import com.isprint.am.dto.bean.LoginAccountTO;
import com.isprint.am.dto.bean.UserInfoBean;
import com.isprint.am.xmlrpc.api.API.Proxy;
import com.isprint.am.xmlrpc.api.API.ProxyFactory;

public class E2EEServiceImpl implements E2EEService {

    @Autowired
    @Qualifier("registerHistoryDAOImpl")
    private RegisterHistoryDAO registerHistoryDAO;

    private static Log LOG = LogFactory.getLog(E2EEServiceImpl.class);

    private static EnvUtil res = EnvUtil.getInstance();

    public ReponseResult unLockeUser(String custId) {

        ReponseResult result = new ReponseResult();
        try {
            Proxy proxy = null;
            E2EEProxyFactory.getProxyFactory();
            proxy = ProxyFactory.createProxy(E2EEProxyFactory.PROXY_FACTORY_NAME);

            UserInfoBean user = getUserById(proxy, custId);
            if (user == null) {
                result.setSuccess(false);
                result.setMessage(ErrorMessageUtil.USER_UNREGISTERED);
                return result;
            }

            String strAccountStatus = "";
            LoginAccountTO[] loginAccts = user.getLoginAccounts();
            if (loginAccts != null) {
                for (int j = 0; j < loginAccts.length; j++) {
                    String loginModuleId = loginAccts[j].getLoginModuleId();
                    if (Constant.LOGIN_MODULE_ID.equals(loginModuleId)) {
                        strAccountStatus = loginAccts[j].getStatus();
                    } else {
                        break;
                    }
                }
            }
            if (strAccountStatus != null && strAccountStatus.equals("Activated")) {
                result.setSuccess(false);
                result.setMessage("user is not locked.");
                return result;
            }

            String adminToken = getAdminToken(proxy);
            String loginModuleId = res.getLoginModuleId();
            HashMap params1 = new HashMap();
            proxy.getPasswordSvc().unlockLoginAccount(adminToken, custId, "", loginModuleId, params1);
            proxy.getAuthnSvc().logout(adminToken, params1);

        }
        catch (Exception e) {
            result.setSuccess(false);
            result.setMessage("user unlock error");
        }
        return result;
    }

    public UserInfoBean getUserById(Proxy proxy, String custId) throws XmlRpcException {

        String adminToken = getAdminToken(proxy);
        UserInfoBean templateParam = new UserInfoBean();
        templateParam.set(Constant.ID, ""); // default system defined field name
        UserInfoBean user = new UserInfoBean();

        UserInfoBean tmp = new UserInfoBean();
        tmp.set("id", "");

        AuthnAccountTO authAcct = new AuthnAccountTO();
        LoginAccountTO loginAcct = new LoginAccountTO();

        tmp.setAuthnAccounts(new AuthnAccountTO[] { authAcct });
        tmp.setLoginAccounts(new LoginAccountTO[] { loginAcct });

        user = proxy.getQuerySvc().findUserById(adminToken, "", custId, tmp);

        boolean isExited = false;
        if (user != null && user.getId().equals(custId)) {
            isExited = true;
        }
        if (!isExited) {
            return null;
        }
        return user;
    }

    public String getAdminToken(Proxy proxy) throws XmlRpcException {

        Map<String, String> params = new HashMap<String, String>();
        params.put(Constant.RETRIEVE_PRINCIPAL, Constant.RETRIEVE_PRINCIPAL_VALUE);
        params.put(Constant.REALM_ID, res.getAdminRealmId());

        AuthResultTO loginResult;
        String sessionToken = null;
        loginResult = proxy.getAuthnSvc().login("", res.getAdminLoginId(), res.getAdminPwd(), params);
        sessionToken = String.valueOf(loginResult.getMap(Constant.SESSION).get(Constant.SESSION_TOKEN));

        return sessionToken;
    }

    public boolean isLocked(String custId) throws MalformedURLException, XmlRpcException {
        Proxy proxy = null;
        E2EEProxyFactory.getProxyFactory();
        proxy = ProxyFactory.createProxy(E2EEProxyFactory.PROXY_FACTORY_NAME);

        UserInfoBean user = getUserById(proxy, custId);
        String strAccountStatus = "";
        LoginAccountTO[] loginAccts = user.getLoginAccounts();
        if (loginAccts != null) {
            for (int j = 0; j < loginAccts.length; j++) {
                String loginModuleId = loginAccts[j].getLoginModuleId();
                if (Constant.LOGIN_MODULE_ID.equals(loginModuleId)) {
                    strAccountStatus = loginAccts[j].getStatus();
                } else {
                    break;
                }
            }
        }
        if (strAccountStatus != null && strAccountStatus.equals("Activated")) {
            return false;
        }

        return true;
    }

    @Override
    public RegisterHistory queryRegHistory(String partyId) {

        return registerHistoryDAO.queryRegHistory(partyId);
    }

}
