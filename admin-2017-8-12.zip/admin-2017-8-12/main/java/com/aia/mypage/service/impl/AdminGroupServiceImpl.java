package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AdminGroupDAO;
import com.aia.mypage.entity.AdminGroup;
import com.aia.mypage.service.AdminGroupService;

public class AdminGroupServiceImpl implements AdminGroupService {

    @Autowired
    @Qualifier("adminGroupDAOImpl")
    private AdminGroupDAO adminGroupDAO;

    public List<AdminGroup> getAdminGroupsList() {

        return adminGroupDAO.getAdminGroupsList();
    }

    public AdminGroup addAdminGroup(AdminGroup adminGroup) {
        adminGroup.setCreateTime(new Date());
        adminGroup.setUpdateTime(new Date());
        adminGroup = adminGroupDAO.addAdminGroup(adminGroup);
        return adminGroup;
    }

    public boolean deleteAdminGroupById(String groupId) {
        return adminGroupDAO.deleteAdminGroupById(groupId);
    }

    @Override
    public AdminGroup updateAdminGroupById(AdminGroup adminGroup) {
        
        adminGroup.setUpdateTime(new Date());
        adminGroup = adminGroupDAO.updateAdminGroup(adminGroup);
        return adminGroup;
    }

    public AdminGroup getAdminGroupById(String groupId) {
        AdminGroup adminGroup = adminGroupDAO.getAdminGroupById(groupId);
        return adminGroup;
    }

}
