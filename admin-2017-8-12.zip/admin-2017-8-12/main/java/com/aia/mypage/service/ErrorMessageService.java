package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.ErrorMessage;

public interface ErrorMessageService {

    List<ErrorMessage> getErrorMessageList();

}
