package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AccountUserDAO;
import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.dao.AdminUserDAO;
import com.aia.mypage.dao.AdminUserInfoDAO;
import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.service.AdminUserService;

public class AdminUserServiceImpl implements AdminUserService {

    @Autowired
    @Qualifier("adminUserInfoDAOImpl")
    private AdminUserInfoDAO adminUserInfoDAO;

    @Autowired
    @Qualifier("accountUserDAOImpl")
    private AccountUserDAO accountUserDAO;
    
    @Autowired
    @Qualifier("adminUserDAOImpl")
    private AdminUserDAO adminUserDAO;

    @Autowired
    @Qualifier("adminUserAUDAOImpl")
    private AdminUserAUDAO adminUserAUDAO;

    @Autowired
    @Qualifier("userDAOImpl")
    private UserDAO userDAO;

    @Override
    public List<AdminUserInfo> getAdminUserListByAccountName(AdminUserInfo adminUserInfo) {

        return adminUserInfoDAO.getAdminUserListByAccountName(adminUserInfo);
    }

    @Override
    public AccountUserInfo getAccountUserByAccountName(String accountName) {

        return accountUserDAO.getAccountUserByAccountName(accountName);
    }

    @Override
    public AdminUser addAdminUser(AdminUser adminUser) {

        adminUser.setCreateTime(new Date());
        adminUser.setUpdateTime(new Date());
        adminUser.setStatus("Y");
        adminUser = adminUserAUDAO.addAdminUser(adminUser);
        return adminUser;
    }

    public boolean updateAdmin(AdminUser adminUser) {

        int result = adminUserAUDAO.updateAdmin(adminUser);
        return result == 1;
    }

    @Override
    public boolean deleteAdminByUserId(String userId) {

        return adminUserAUDAO.deleteAdminByUserId(userId);
    }

    @Override
    public AdminUserInfo getAdminProfile(String accountName) {

        return adminUserInfoDAO.getAdminProfile(accountName);
    }

    @Override
    public AdminUser getAdminUserByUserId(String userId) {

        return adminUserAUDAO.getAdminUserByUserId(userId);
    }

    @Override
    public List<AdminUser> getAllAdminUsers() {
        return adminUserDAO.getAllAdminUsers();
    }
}
