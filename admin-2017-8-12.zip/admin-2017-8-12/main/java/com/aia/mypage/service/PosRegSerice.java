package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.ActiveUserInfo;

public interface PosRegSerice {

    List<ActiveUserInfo> getUserList(String custId, String name);

}
