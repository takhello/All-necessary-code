(function(){
	"use strict";
	angular.module("adminManageApp").directive("noticelistDirective", function() {
		return {
		     template: '<div class="box-body">'+
                                '<table id="example01" class="table table-bordered table-hover">'+
                                    '<thead>'+
                                        '<tr>'+
                                        	'<th>From</th>'+
                                            '<th>To</th>'+
                                            '<th>Page</th>'+
                                            '<th>Notice Message</th>'+
                                            '<th>Status</th>'+
                                            '<th>Last Update By</th>'+
                                            '<th class="t-text-align-right">Action</th>'+
                                        '</tr>'+
                                    '</thead>'+
                                    '<tbody>'+
	                                    '<tr ng-repeat="x in vm.notice">'+
	                                            '<td>{{x.From}}</td>'+
	                                            '<td>{{x.To}}</td>'+
	                                            '<td>{{x.Page}}</td>'+
	                                            '<td>{{x.NoticeMessage}}</td>'+
	                                            '<td>{{x.Status}}</td>'+
	                                            '<td>{{x.LastUpdateBy}}</td>'+
	                                            '<td>'+
	                                            '<span class="pull-right">'+
	                                                    '<button class="btn btn-warning btn-sm" ng-click="vm.editNotice(x)"">Edit</button>'+
	                                                '</span>'+
	                                            '</td>'+
	                                    '</tr>'+
                                    '</tbody>'+
                                    '<tfoot>'+
                                    '</tfoot>'+
                                '</table>'+
                            '</div>',
			controller: function() {
				console.log('自动分页 ');
				$('#example01').DataTable({
			            "paging": true,
			            "lengthChange": false,
			            "searching": false,
			            "ordering": true,
			            "info": true,
			            "autoWidth": false
			        });
				}
	       		
		};
	});
})();
