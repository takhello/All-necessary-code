(function() {
	"use strict";

	angular.module("adminManageApp").controller('CategoryMaintenanceNewController', CategoryMaintenanceNewController);
	CategoryMaintenanceNewController.$injector = ['$scope', 'RoleService', '$modal', '$modalInstance'];

	function CategoryMaintenanceNewController($scope, RoleService, $modal, $modalInstance) {
		var vm = this;
		vm.addRoleCancel = addRoleCancel;
		vm.addRoleConfirm = addRoleConfirm;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		vm.productCategory =userGroup();
		vm.searchNewProduct =searchNewProduct();
		vm.policvDetail = policvDetail();
		function userGroup(){
			console.log('测试数据 success');
			return {
					data1:{productCategory:"Life Protection"},
					data2:{productCategory:"Medical Protection"},
					data3:{productCategory:"Critical Illness Protection"},
					data4:{productCategory:"Accident Protection"},
					data5:{productCategory:"Savings"},
					data6:{productCategory:"Investments"},
					data7:{productCategory:"Disability Income Protection"},
					data8:{productCategory:"Travel & Lifestyle"}
				};
		}

		function searchNewProduct(){
			console.log('测试数据 success');
			return {

					data1:{searchNewProduct:"Life Protection "}
				};
		}
		function policvDetail(){
			console.log('测试数据 success');
			return {
					data1:{policvDetail:"Traditional List"},
					data2:{policvDetail:"Investment Linked"},
					data3:{policvDetail:"Annuity"},
					data4:{policvDetail:"Hospitalization"},
					data5:{policvDetail:"Others"}
				};
		}



		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addRoleConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
						"userLANID":vm.userLANID,
						"userName":vm.userName,
						"userTelephon":vm.userTelephon,
						"userEmail":vm.userEmail,
						"userDepartment":vm.userDepartment
					// "roleName": vm.roleName,
					// "roleDesc": vm.roleDesc,
					// "roleStatus": vm.roleStatus
				}
			};
			RoleService.newRole(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();