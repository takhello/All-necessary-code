(function(){
	"use strict";
	angular.module("adminManageApp").service('AuditService',AuditService);
	AuditService.$injector = ['$resource'];
	function AuditService($resource){
        var services = {
            searchAudit: searchAudit,
        };
        return services;
        //update role service
        function searchAudit(id,params, onSuccess, onError) {
            var url = SERVICE_URL + "v1/admin/report/auditlog/" + id;
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
        }
		
	}
})();