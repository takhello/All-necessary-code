(function() {
	"use strict";

	angular.module("adminManageApp").service('RoleService', RoleService);

	RoleService.$injector = ['$resource'];

	function RoleService($resource) {
		var services = {
			newRole: newRole,
			deleteRole: deleteRole,
			editRole: editRole,
			getRoleList: getRoleList
		};
		return services;
		//create new role service
		function newRole(params, onSuccess, onError) {
			var url = SERVICE_URL + "admin/role";
			var _resources = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resources.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}
		//delete an existed role service
		function deleteRole(id,onSuccess,onError) {
			console.log(id);
			var url = SERVICE_URL + "admin/role/" + id;
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}

		//edit role service
		function editRole(id, params, onSuccess, onError) {
			console.log(params);
			var url = SERVICE_URL + "admin/role/" + id;
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params,
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}
		//update role service
		function getRoleList(params,onSuccess,onError) {
			var url = SERVICE_URL + "admin/roles";
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
	}
})();