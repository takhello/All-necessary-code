(function() {
	"use strict";

	angular.module("adminManageApp").service('UserManageAccessService', UserManageAccessService);

	UserManageAccessService.$injector = ['$resource'];

	function UserManageAccessService($resource) {
		var services = {
			getManageList: getManageList,
			getIdFunction:getIdFunction
		};
		return services;
		//update role service
		function getManageList(params,onSuccess,onError) {
			var url = SERVICE_URL + "v1/admin/admin_users";
			// var url = "http://localhost:8099/mypage-admin/v1/admin/admin_users";
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}

		function getIdFunction(id,params, onSuccess, onError){
			var url = SERVICE_URL + "v1/admin/function/" + id;
			// /v1/admin/function/{user_id}
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
		}
	}
})();