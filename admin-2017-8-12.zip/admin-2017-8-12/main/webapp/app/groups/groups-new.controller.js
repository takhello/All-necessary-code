(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupsNweController', GroupsNweController);
	GroupsNweController.$injector = ['$scope', 'GroupsFunctionsService', '$modal', '$modalInstance'];

	function GroupsNweController($scope, GroupsFunctionsService, $modal, $modalInstance) {
		var vm = this;
		vm.addGroupCancel = addGroupCancel;
		vm.errorClose = errorClose;
		vm.groupStatus = 'Y';
		vm.isDefault = 'N';
		vm.isAlertHide = true;

		vm.createGroup = createGroup;
		vm.getFunctionList = getFunctionList;
		
		vm.successCallback = successCallback;
		vm.getFunctionListSuccessCallback = getFunctionListSuccessCallback;
		vm.getFunctionListFailCallback = getFunctionListFailCallback;
		
		vm.isUserAccessManagement = isUserAccessManagement();
		getFunctionList();
		//存储checkbox
		vm.selected = [];
    	vm.selectedTags = [];
    	vm.updateSelection = updateSelection;
	    vm.isSelected = isSelected;
    	vm.updateSelected =updateSelected;

		function errorClose(){
			vm.isAlertHide = true;
		}

		function addGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		//createGroup
		function createGroup() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"groupName": vm.groupName,
					"groupDesc": vm.Description,
					"groupStatus": "",
					"functionIdList": vm.selected
				}
			};
			GroupsFunctionsService.createGroup(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

		//getFunctionList
		function getFunctionList() {
			var obj = {
				"userId": USER_ID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
			};
			GroupsFunctionsService.getFunctionList(obj, vm.getFunctionListSuccessCallback, vm.getFunctionListFailCallback);
		}
		function getFunctionListSuccessCallback(result) {
		
			vm.FunctionList = result.data.functionList;
			vm.functionLevel = serializeData(result.data.functionList,"functionLevel","1");
			vm.parentFunction1 = serializeData(result.data.functionList,"parentFunctionId","10");
			vm.parentFunction2 = serializeData(result.data.functionList,"parentFunctionId","20");
			vm.parentFunction3 = serializeData(result.data.functionList,"parentFunctionId","30");
			vm.parentFunction4 = serializeData(result.data.functionList,"parentFunctionId","40");

			function serializeData(data,key,val){
				var obj=[];
				var index = 0;
				for (var i=0; i < data.length;  i++) {
					if(data[i][key] == val){
						// var a  = {name:data[i].functionName,data:data[i].functionName};
						obj.push({isName:data[i].functionName,isId:data[i].functionId});
					}
				}
				return obj;
			}
		}

		function getFunctionListFailCallback(error) {
		
		}
	
		function isUserAccessManagement(){
		}

		function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}

	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	 
	    function isSelected(id){

	        return vm.selected.indexOf(id)>=0;
	    }

	}
})();