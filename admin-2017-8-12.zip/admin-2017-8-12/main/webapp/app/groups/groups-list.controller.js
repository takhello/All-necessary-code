(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupsController', GroupsController);
	GroupsController.$injector = ['$scope', '$modal', 'GroupsManageAccessService', '$state'];

	function GroupsController($scope, $modal, GroupsManageAccessService, $state) {
		var vm = this;
		vm.newGroups = newGroups;
		vm.deleteGroup = deleteGroup;
		vm.editGroup = editGroup;
		vm.getGroupRoleList = getGroupRoleList;

		vm.getGroupsManageList = getGroupsManageList;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		//测试数据

		getGroupsManageList();

		function getGroupRoleList(id) {
			$state.go("home.group.group-role", {
				id: id
			});
		}

		function getGroupsManageList() {
			var obj = {
					"userId":"",
					"country":"",
					"language":"",
					"sessionId":""
			};
			GroupsManageAccessService.getGroupsManageList(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.GroupManageList = result.data.adminGroupList;
		}

		function failCallback(error) {
		
		}

		function newGroups() {
			var modalInstance = $modal.open({
				templateUrl: "app/groups/groups-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupsNweController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getGroupsManageList);
		}

		function deleteGroup(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/groups/groups-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupsDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					groupsId: function() {
						return id;
					},
					groupsData: function() {
						return vm.groups;
					}

				}
			});
			modalInstance.result.then(getGroupsManageList);
		}

		function editGroup(group) {
			var modalInstance = $modal.open({
				templateUrl: "app/groups/groups-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "EditGroupController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editGroupIdItem: function() {
						return group.groupId;
					},
					groupData: function() {
						return group;
					}
				}
			});
			modalInstance.result.then(getGroupsManageList);

		}


	}
})();