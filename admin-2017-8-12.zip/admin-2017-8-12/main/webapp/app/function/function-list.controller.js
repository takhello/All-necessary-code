(function() {
	"use strict";
	angular.module("adminManageApp").controller("PermissionController", PermissionController);
	PermissionController.$injector = ['$scope', 'PermissionService', '$modal','$state'];

	function PermissionController($scope, PermissionService, $modal,$state) {
		var vm = this;
		vm.permissionTypeMap = PERMISSION_TYPE;
		vm.getPermissionList = getPermissionList;
		vm.deletePermission = deletePermission;
		vm.editPermission = editPermission;
		//--tong
		vm.newFunction = newFunction;

		vm.successCallback = successCallback;
		vm.function = detatest();
		//测试数据
	    function detatest(){
			console.log('function-Lisr测试数据 success');
	    	return {
	    		data1:{FunctionName:"function1",URL:"www.a",Discription:"ccc",Parent:"ddd"},
	    		data2:{FunctionName:"function2",URL:"ww.b",Discription:"ccc",Parent:"ddd"},
	    		data3:{FunctionName:"function3",URL:"bbb",Discription:"ccc",Parent:"ddd"},
	    		data4:{FunctionName:"function4",URL:"bbb",Discription:"ccc",Parent:"ddd"}
	    	};
	    }
	    
	    getPermissionList();
		function successCallback(result){
			vm.permissions = result.data.permissionList;
		}

		function getPermissionList() {
			var obj = {
				"permissionName": vm.name,
				"permissionType": vm.type,
				"permissionPattern": vm.pattern,
				"permissionMethod": vm.method,
				"permissionStatus": vm.status,
				"isOTP": vm.isOTP
			};
			//obj 请求体  
			PermissionService.getPermission(obj,vm.successCallback);
		}

		function deletePermission(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/function/function-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "functionDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					permissionData: function() {
						return vm.permissions;
					},
					permissionId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getPermissionList);
		}

		function editPermission(permission) {
			var modalInstance = $modal.open({
				templateUrl: "app/function/function-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "FunctionEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editPermissionIdItem: function() {
						return permission.permissionId;
					},
					permissionData: function() {
						return permission;
					}
				}
			});
			modalInstance.result.then(getPermissionList);
		}

		function newFunction() {
			var modalInstance = $modal.open({
				templateUrl: "app/function/new-function.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "NewFunctionController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getPermissionList);
		}
	}
})();