(function() {
	"use strict";

	angular.module("adminManageApp").controller('GroupEditController', GroupEditController);
	GroupEditController.$injector = ['$scope', '$modal', '$modalInstance', 'editGroupIdItem', 'groupData', 'GroupService'];

	function GroupEditController($scope, $modal, $modalInstance, editGroupIdItem, groupData, GroupService) {
		var vm = this;
		vm.groupData = groupData;
		vm.editGroupCancel = editGroupCancel;
		vm.editGroupConfirm = editGroupConfirm;
		vm.closeError = closeError;
		vm.isAlertHide = true;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.groupVal = angular.copy(groupData);

		function closeError(){
			vm.isAlertHide = true;
		}

		function editGroupCancel() {
			$modalInstance.dismiss('cancel');
			console.log(vm.groupVal);
		}

		function editGroupConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.groupVal
			};
			GroupService.editGroup(editGroupIdItem, object, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();