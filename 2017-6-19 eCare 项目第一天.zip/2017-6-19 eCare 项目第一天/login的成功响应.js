{
	"loginUUID": "f03a72e2-c230-4d6c-8862-678d488359fa",
	"social_id": "",
	"otp": {
		"sessionToken": "20001UIwFNoctAIeLatZyHDbnFJJzUvV-rqIjMuLz8RFT2CjjUtERSkfyYJVyE6PvvFrosggQc8fhfOoPlmxxDV9bdvnXWqokBk-B81rToZBCPQyCXRnhPwKl2a58bHMJZfDrslwh0KsBT6eou0vc3Uq-I6rf2U_IREcnGDB8Srfl7tdNcbc16fZgANJg9X9X-fttqPKu_1O1Ch7R6EEWqQIAN0ap-DdC4bggSRQa93l5Kh0JGIEuYx2qlJ9bf3ea32-fbf6-4f21-bcb8-b00bf9068d55",
		"isAuthenticated": "true",
		"userUUID": "0A3042E96F1E012432A03BDE9826837F",
		"tokenUUID": "MemoryTokenStore:Krq5PAaxvV"
	},
	"otpMobileMask": "**********8888",
	"otpReferenceCode": ""
}