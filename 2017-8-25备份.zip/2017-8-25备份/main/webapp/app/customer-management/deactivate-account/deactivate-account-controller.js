(function() {
	"use strict";
	angular.module("adminManageApp").controller('DeactivateAccountController', DeactivateAccountController);
	DeactivateAccountController.$injector = ['$scope', '$modal', '$state'];

	function DeactivateAccountController($scope, $modal, $state) {
		var vm = this;
		//vm.successCallback = successCallback;

		


	}
})();