(function() {
	"use strict";

	angular.module("adminManageApp").controller('SearchDetailController', SearchDetailController);
	SearchDetailController.$injector = ['$scope', '$modal', '$modalInstance', 'searchCustomerIdItem', 'searchCustomerData', 'RoleService'];

	function SearchDetailController($scope, $modal, $modalInstance, searchCustomerIdItem, searchCustomerData, RoleService) {
		var vm = this;
		vm.searchCustomerData = searchCustomerData;
		vm.closeError = closeError;
		vm.searchCustomerCancel = searchCustomerCancel;
		vm.searchCustomerConfirm = searchCustomerConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;
		vm.modalVal = angular.copy(searchCustomerData);

		function closeError(){
			vm.isAlertHide = true;
		}

		function searchCustomerCancel() {
			$modalInstance.dismiss('cancel');
		}
		function searchCustomerConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.modalVal
			};
			RoleService.editRole(searchCustomerIdItem, object, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();