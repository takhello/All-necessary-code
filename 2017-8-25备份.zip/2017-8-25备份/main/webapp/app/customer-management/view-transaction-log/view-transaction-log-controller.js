(function() {
	"use strict";
	angular.module("adminManageApp").controller('ViewTransactionLogController', ViewTransactionLogController);
	ViewTransactionLogController.$injector = ['$scope', '$modal', '$state'];

	function ViewTransactionLogController($scope, $modal, $state) {
		var vm = this;
		//vm.successCallback = successCallback;
		vm.getDetailsList = getDetailsList;


		function getDetailsList(id) {		//id
			$state.go("home.view-transaction-log.view-transaction-details", {
				id: id
			});
		}
		


	}
})();