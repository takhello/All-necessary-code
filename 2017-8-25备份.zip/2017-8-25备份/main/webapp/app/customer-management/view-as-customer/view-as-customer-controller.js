(function() {
	"use strict";
	angular.module("adminManageApp").controller('ViewAsCustomerController', ViewAsCustomerController);
	ViewAsCustomerController.$injector = ['$scope', '$modal', '$state'];

	function ViewAsCustomerController($scope, $modal, $state) {
		var vm = this;
		//vm.successCallback = successCallback;

		


	}
})();