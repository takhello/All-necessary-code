(function() {
	"use strict";
	angular.module("adminManageApp").controller('UnlockAccountController', UnlockAccountController);
	UnlockAccountController.$injector = ['$scope', '$modal', '$state'];

	function UnlockAccountController($scope, $modal, $state) {
		var vm = this;
		//vm.successCallback = successCallback;
		vm.getDetailsList = getDetailsList;


		function getDetailsList(id) {		//id
			$state.go("home.unlock-account.unlock-account-details", {
				id: id
			});
		}
		

		


	}
})();