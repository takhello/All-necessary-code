(function() {
	"use strict";
	angular.module("adminManageApp").controller("PermissionController", PermissionController);
	PermissionController.$injector = ['$scope', 'PermissionService', '$modal','$state'];

	function PermissionController($scope, PermissionService, $modal,$state) {
		var vm = this;
		vm.permissionTypeMap = PERMISSION_TYPE;
		vm.getPermissionList = getPermissionList;
		vm.deletePermission = deletePermission;
		vm.editPermission = editPermission;
		vm.addPermission = addPermission;
		vm.successCallback = successCallback;
	    getPermissionList();

		function successCallback(result){
			vm.permissions = result.data.permissionList;
		}

		function getPermissionList() {
			var obj = {
				"permissionName": vm.name,
				"permissionType": vm.type,
				"permissionPattern": vm.pattern,
				"permissionMethod": vm.method,
				"permissionStatus": vm.status,
				"isOTP": vm.isOTP
			};
			PermissionService.getPermission(obj,vm.successCallback);
		}

		function deletePermission(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/permission/permission-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "PermissionDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					permissionData: function() {
						return vm.permissions;
					},
					permissionId: function() {
						return id;
					}
				}
			});
			modalInstance.result.then(getPermissionList);
		}

		function editPermission(permission) {
			var modalInstance = $modal.open({
				templateUrl: "app/permission/permission-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "PermissionEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editPermissionIdItem: function() {
						return permission.permissionId;
					},
					permissionData: function() {
						return permission;
					}
				}
			});
			modalInstance.result.then(getPermissionList);
		}

		function addPermission() {
			var modalInstance = $modal.open({
				templateUrl: "app/permission/permission-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "PermissionAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getPermissionList);
		}
	}
})();