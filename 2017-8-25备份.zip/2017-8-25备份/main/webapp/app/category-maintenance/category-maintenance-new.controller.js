(function() {
	"use strict";

	angular.module("adminManageApp").controller('CategoryMaintenanceNewController', CategoryMaintenanceNewController);
	CategoryMaintenanceNewController.$injector = ['$scope', 'ProductService', '$modal', '$modalInstance'];

	function CategoryMaintenanceNewController($scope, ProductService, $modal, $modalInstance) {
		console.log('2');
		var vm = this;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		vm.addRoleCancel = addRoleCancel;
		vm.addRoleConfirm = addRoleConfirm;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		vm.productCategory = userGroup();
		vm.policvDetail = policvDetail();

		vm.getProductCategory = getProductCategory;
		vm.successGetProductCategoryCallback = successGetProductCategoryCallback;
		vm.failGetProductCategoryCallback = failGetProductCategoryCallback;
		vm.getTemplate = getTemplate;
		vm.successGetTemplateCallback = successGetTemplateCallback;
		vm.failGetTemplateCallback = failGetTemplateCallback;
		vm.searchNewProduct = searchNewProduct;
		vm.successSearchNewProductCallback = successSearchNewProductCallback;
		vm.failSearchNewProductCallback = failSearchNewProductCallback;


		getProductCategory();
		getTemplate();

		function userGroup(){
			return {
					data1:{productCategory:"Life Protection"},
					data2:{productCategory:"Medical Protection"},
					data3:{productCategory:"Critical Illness Protection"},
					data4:{productCategory:"Accident Protection"},
					data5:{productCategory:"Savings"},
					data6:{productCategory:"Investments"},
					data7:{productCategory:"Disability Income Protection"},
					data8:{productCategory:"Travel & Lifestyle"}
				};
		}
		function policvDetail(){
			return {
					data1:{policvDetail:"Traditional List"},
					data2:{policvDetail:"Investment Linked"},
					data3:{policvDetail:"Annuity"},
					data4:{policvDetail:"Hospitalization"},
					data5:{policvDetail:"Others"}
				};
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}
		console.log('3');

		//SearchNewProduct
		function searchNewProduct() {
			vm.fail = "";
			if(vm.productCode === "" || vm.productCode === undefined){
				vm.submitted = true;
				// vm.isAlertHide = false;
				console.log(vm.submitted);
				return false;
			}
			var obj = {
				"userId": USER_ID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"partyId": USER_ID,
				"productCode":vm.productCode
			};
			console.log(obj);
			ProductService.searchNewProduct(obj, vm.successSearchNewProductCallback, vm.failSearchNewProductCallback);
		}
		function successSearchNewProductCallback(result){
			console.log(result);
			vm.searchNewProductList = result.data.productName;
			// vm.isAlertHide = true;
			// $modalInstance.close('cancel');
		}
		function failSearchNewProductCallback(error){
			console.log(error);
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			//vm.status = error.data.code;
		}


		//getProductCategory
		function getProductCategory() {
			var obj = {
				"userId": USER_ID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"partyId": USER_ID

			};
			ProductService.getProductCategory(obj, vm.successGetProductCategoryCallback, vm.failGetProductCategoryCallback);

		}
		function successGetProductCategoryCallback(result) {
			console.log(result);
			vm.ProductList = result.data;
			// vm.isAlertHide = true;
			// $modalInstance.close('cancel');
		}

		function failGetProductCategoryCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			//vm.status = error.data.code;
		}
		//getTemplate
		function getTemplate() {
			var obj = {
				"userId": USER_ID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"partyId": "1"

			};
			ProductService.getTemplate(obj, vm.successGetTemplateCallback, vm.failGetTemplateCallback);

		}
		function successGetTemplateCallback(result) {
			vm.TemplateList = result.data;
			// vm.isAlertHide = true;
			// $modalInstance.close('cancel');
		}

		function failGetTemplateCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			//vm.status = error.data.code;
		}




		function addRoleConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
						"userLANID":vm.userLANID,
						"userName":vm.userName,
						"userTelephon":vm.userTelephon,
						"userEmail":vm.userEmail,
						"userDepartment":vm.userDepartment
					// "roleName": vm.roleName,
					// "roleDesc": vm.roleDesc,
					// "roleStatus": vm.roleStatus
				}
			};
			// ProductService.newRole(obj, vm.successCallback, vm.failCallback);

		}
		function successCallback(result) {
			console.log(result);
			vm.ProductList = result.data;
			// vm.isAlertHide = true;
			// $modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			//vm.status = error.data.code;
		}
	}
})();