(function() {
	"use strict";
	angular.module("adminManageApp").controller('AdminAddController', AdminAddController);
	AdminAddController.$injector = ['$scope', 'AdminService', '$modalInstance'];

	function AdminAddController($scope, AdminService, $modalInstance) {
		var vm = this;
		vm.isAlertHide = true;
		vm.searchGeneralUser = searchGeneralUser;
		vm.isShow = false;
		vm.addAdminCancel = addAdminCancel;
		vm.addAdminConfirm = addAdminConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.addSuccessCallback = addSuccessCallback;
		vm.addFailCallback = addFailCallback;
		vm.errorClose = errorClose;

		function errorClose(){
			vm.isAlertHide = true;
		}

		function searchGeneralUser() {
			var obj = {
				"accountName": vm.accountName
			};
			AdminService.getUserByAccountName(obj,vm.successCallback, vm.failCallback);
		}

		function addAdminCancel() {
			$modalInstance.dismiss('cancel');
		}

		function successCallback(result) {
			console.log(result);
			// console.log(result.data.account);
			vm.email = result.data.account.email;
			vm.accountType = result.data.account.accountType;
			vm.isEnabled = result.data.account.isEnabled;
			vm.userId = result.data.account.userId;
			vm.isShow = angular.copy(vm.accountName);
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.isShow = false;
			console.log(vm.isAlertHide);
		}

		function addAdminConfirm() {
			var string_userId = String(vm.userId);
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"userId": string_userId,
				}
			};
			AdminService.newAdmin(obj, vm.addSuccessCallback, vm.addFailCallback);

		}

		function addSuccessCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
			// console.log(vm.isAlertHide);
		}

		function addFailCallback(error) {
			// console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			// console.log(vm.isAlertHide);
		}

	}
})();