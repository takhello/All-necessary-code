var SERVICE_URL = '';
var SERVICE_URL1 = '';

var USER_ID = "";
var USER_PARTYID = "";
var USER_SESSIONID = "0001Xyo18aCPU5tr_8Ab_h_hORBIba1jXO3FQD5KLMu51bBsE7DfKDH7_PiPCp-M7HP-vO9z4ch7ycVNY_zOEjqYoHIvy5YunVIIyIXeu4iN-fDNAZKeA4Kd3m-esw-bH1g";
var USER_COUNTRY = "sg";
var USER_LANGUAGE = "en_SG";

var _currentDomain_ = location.host;
var _currentPathname_ = location.pathname;
var _loginServiceUrl_ = "";
//用于测试
var SERVICE_URL1 = "http://cangzdwcis01:8699/sg-ecare-admin/";
//用于测试

var USER_PROFILE = {
	"firstName": "",
	"lastName": "",
	"userId": "",
	"IsEnabled": ""
};

var PERMISSION_TYPE = {
	"00": "MyPage Admin",
	"01": "MyPage ESB",
	"02": "MyPage Login"	
};

_debugMode = function() {
	var DEBUG_SERVICE_URL = localStorage.getItem('DEBUG_SERVICE_URL');
	var DEBUG_SERVICE_URL1 = localStorage.getItem('DEBUG_SERVICE_URL1');
	var DEBUG_MODE = localStorage.getItem('DEBUG_MODE');
	if (DEBUG_MODE === 'true' && DEBUG_SERVICE_URL !== '') {
		SERVICE_URL = DEBUG_SERVICE_URL;

		//debug_tong
		SERVICE_URL1=DEBUG_SERVICE_URL1;
		//debug_tong
	}
};
_enableDebugMode = function(url) {
	var DEBUG_SERVICE_URL = localStorage.setItem('DEBUG_SERVICE_URL', url);

	//debug_tong
	var DEBUG_SERVICE_URL1 = localStorage.setItem('DEBUG_SERVICE_URL1', url) || "http://cangzdwcis01:8699/sg-ecare-admin/";
	//debug_tong
	
	var DEBUG_MODE = localStorage.setItem('DEBUG_MODE', 'true');
	_debugMode();
};

_disableDebugMode = function() {
	var DEBUG_MODE = localStorage.setItem('DEBUG_MODE', 'false');
	_debugMode();
};
_debugMode();

_checkLogStatus = function() {
	console.log(USER_PROFILE.userId.length);
	if (USER_PROFILE.userId.length === 0) {
		// console.log(USER_PROFILE.userId.length);
		USER_PROFILE.firstName = "Default";
		USER_PROFILE.lastName = "User";	
	}
};

_checkLogStatus();

