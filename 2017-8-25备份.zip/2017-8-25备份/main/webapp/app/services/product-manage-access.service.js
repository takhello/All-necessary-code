(function() {
	"use strict";

	angular.module("adminManageApp").service('ProductService', ProductService);
	ProductService.$injector = ['$resource'];
	function ProductService($resource) {
		var services = {
			getSearchProductList:getSearchProductList,
			getProductCategory:getProductCategory,
			getTemplate:getTemplate,
			searchNewProduct:searchNewProduct,

			newNotice:newNotice,
			getNoticeList:getNoticeList,
			editNotice:editNotice
			
		};
		return services;
		//getSearchProductList
		function getSearchProductList(params,onSuccess,onError) {
			var url = SERVICE_URL1 + "v1/admin/products"+"?"+params;
			// http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/products
			console.log(url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params 
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
		//getProductCategory
		function getProductCategory(params,onSuccess,onError) {
		console.log('3.3');

			var url = SERVICE_URL1 + "v1/admin/product/categories";
			// /v1/admin/product/categories
			console.log(url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params 
				}
			});
		console.log('3.4');

			return _resource.get(params).$promise.then(onSuccess,onError);
		}
		//getTemplate
		function getTemplate(params,onSuccess,onError) {
			var url = SERVICE_URL1 + "v1/admin/product/template";
			// /v1/admin/product/template
			console.log(url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params 
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
		//search New Product
		function searchNewProduct(params,onSuccess,onError){
			var url = SERVICE_URL1 + "v1/admin/product";
			// http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/product
			console.log(url);
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params 
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}










		//update role service
		function getNoticeList(params,onSuccess,onError) {
            // objSerialization
			// var url = SERVICE_URL + "v1/admin/customer/notices"+"?"+params;
			var url = SERVICE_URL1 + "v1/admin/customer/notices"+"?"+params;
			// var url = "http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/customer/notices";
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}

		function newNotice(params, onSuccess, onError){
			console.log('POST');

			// var url = SERVICE_URL + "v1/admin/customer/notice";
			var url = SERVICE_URL1 + "v1/admin/customer/notice";
			// var url = "http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/customer/notice";
          	var _resources = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resources.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
			
		}

		//edit Notice service
		function editNotice(params, onSuccess, onError) {
			console.log('PUT');
			// var url = SERVICE_URL + "v1/admin/customer/notice";
			var url = SERVICE_URL1 + "v1/admin/customer/notice";
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params,
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}

	}
})();