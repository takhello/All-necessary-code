(function() {
	"use strict";

	angular.module("adminManageApp").service('PermissionService', PermissionService);
	PermissionService.$injector = ['$resource'];

	function PermissionService($resource) {
		var services = {
			newPermission: newPermission,
			deletePermission: deletePermission,
			editPermission: editPermission,
			getPermission: getPermission //-->search and update permission-list
		};
		return services;

		function newPermission(params, onSuccess, onError) {
			var url = SERVICE_URL + "admin/permission";
			var _resource = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});

			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess, onError);
		}

		function deletePermission(id,onSuccess,onError) {
			console.log(id);
			var url = SERVICE_URL + "admin/permission/" + id;
			var _resource = $resource(url,{},{
				delete:{
					"method":"delete",
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}


		function editPermission(id, params, onSuccess, onError) {
			// console.log(params);
			var url = SERVICE_URL + "admin/permission/" + id;
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}

		function getPermission(params,onSuccess,onError) {
			var url = SERVICE_URL + "admin/permissions";
			var _resource = $resource(url,{},{
				get:{
					"method":"get",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
	}
})();