(function() {
    "use strict";
    angular.module('adminManageApp').controller("IvrsRegeneratePinController", IvrsRegeneratePinController);
    IvrsRegeneratePinController.$injector = ['$scope', 'RoleService', '$modal', '$state'];

    function IvrsRegeneratePinController($scope, RoleService, $modal, $state) {


        var vm = this;
        vm.getRoleList = getRoleList;
        vm.deleteRole = deleteRole;
        vm.editRole = editRole;
        vm.addRole = addRole;
        vm.getUserToFunction = getUserToFunction;
        console.log('getUserToFunctionaaaaa');

        vm.successCallback = successCallback;
        vm.failCallback = failCallback;
        vm.roles = testData();
        vm.productName =testProductNameData();
        vm.productName1 =testProductNameData1();

        // getRoleList();
        function testData() {
            return {
                    list:[
                    {name:"aaaaaa"},
                    {name:"aaaaaa"},
                    {name:"aaaaaa"},
                    {name:"aaaaaa"},
                    {name:"aaaaaa"},
                    {name:"aaaaaa"}
                ]};
        }
        function testProductNameData(){
            console.log('user-Lisr测试数据 success');
            return {
                data1:{productName:"Regeneration Reason"},
                data2:{productName:"Medical Protection"},
                data3:{productName:"Travel & Lifestyle"}
            };
        }
        function testProductNameData1(){
            console.log('user-Lisr测试数据 success');
            return {
                data1:{productName:"Type of Mailer"}
         
            };
        }


        //tong
        //Date range picker
        $('#reservation').daterangepicker();
        $('#example01').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
      
        //tong 
        function getUserToFunction(id) {
            console.log('getUserToFunction');
            $state.go('home.user.user-function', {
                id: id
            });
        }
        

        function getRoleList() {
            var obj = {
                roleName: vm.roleName,
                roleStatus: vm.roleStatus
            };
            RoleService.getRoleList(obj, vm.successCallback, vm.failCallback);
        }

        function successCallback(result) {
            vm.roles = result.data.roleList;

        }

        function failCallback(error) {
            if (error.data.code === 403) {
                $state.go('home.403');
            }
        }

        function deleteRole(id) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-delete.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleDeleteController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    roleData: function() {
                        return vm.roles;
                    },
                    roleId: function() {
                        return id;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function editRole(role) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-edit.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleEditController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    editRoleIdItem: function() {
                        return role.roleId;
                    },

                    RoleData: function() {
                        return role;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function addRole() {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-new.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "UserAddController",
                controllerAs: "vm",
                size: 'md'
            });
            modalInstance.result.then(getRoleList);
        }
    }

})();
