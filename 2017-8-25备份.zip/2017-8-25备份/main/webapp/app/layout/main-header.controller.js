(function() {
	"use strict";
	angular.module("adminManageApp").controller("MainHeaderController", MainHeaderController);
	MainHeaderController.$injector = ['$scope', 'UserProfileService'];

	function MainHeaderController($scope, UserProfileService) {
		var vm = this;
		vm.checkLogStatus = checkLogStatus;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		checkLogStatus();

		function checkLogStatus() {
			// console.log(USER_PROFILE.userId.length);
			if (USER_PROFILE.userId.length === 0) {
				UserProfileService.getUserProfile(vm.successCallback,vm.failCallback);
			}
		}

		function successCallback(result) {
			console.log("用户信息是:" +  result);
			sessionStorage.setItem("profile",JSON.stringify(result.data.profile));
			USER_ID = result.data.profile.userId;

			
			USER_PROFILE = result.data.profile;
			vm.firstName = USER_PROFILE.firstName;
			vm.lastName = USER_PROFILE.lastName;
		}

		 function failCallback(error){
            vm.firstName = 'Default';
            vm.lastName = 'User';
        }
	}
})();