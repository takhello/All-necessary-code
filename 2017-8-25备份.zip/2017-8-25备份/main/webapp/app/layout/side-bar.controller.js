(function() {
    "use strict";
    angular.module("adminManageApp").controller('SidebarController', SidebarController);
    SidebarController.$injector = ['$scope', 'UserProfileService'];

    function SidebarController($scope, UserProfileService) {
        var vm = this;
        vm.isMenuStatus = "";

        vm.activeMenu = activeMenu;
        vm.checkLogStatus = checkLogStatus;
        vm.successCallback = successCallback;
        vm.failCallback = failCallback;
        checkLogStatus();

        function activeMenu(val) {
            vm.isMenuStatus = val;
        }

        function checkLogStatus() {
            // console.log(USER_PROFILE.userId.length);
            if (USER_PROFILE.userId.length === 0) {
                UserProfileService.getUserProfile(vm.successCallback,vm.failCallback);
            }
        }

        function successCallback(result) {  
            USER_PROFILE = result.data.profile;
            vm.firstName = USER_PROFILE.firstName;
            vm.lastName = USER_PROFILE.lastName;
        }

        function failCallback(error){
            vm.firstName = 'Default';
            vm.lastName = 'User';
        }
    }

})();