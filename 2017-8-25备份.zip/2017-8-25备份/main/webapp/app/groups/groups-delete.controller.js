(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupsDeleteController', GroupsDeleteController);
	GroupsDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'GroupsManageAccessService', 'groupsId', 'groupsData'];

	function GroupsDeleteController($scope, $modal, $modalInstance, GroupsManageAccessService, groupsId, groupsData) {
		var vm = this;
		vm.deleteGroupCancel = deleteGroupCancel;
		vm.deleteGroupConfirm = deleteGroupConfirm;
		vm.isAlertHide = true;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		function deleteGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteGroupConfirm() {
			GroupsManageAccessService.deleteGroup(groupsId,vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.errorMessage;
			// vm.status = error.data.code;
		}
	}
})();