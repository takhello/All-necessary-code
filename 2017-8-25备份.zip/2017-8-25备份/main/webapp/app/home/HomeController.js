(function() {
	"use strict";
	angular.module("adminManageApp").controller("HomeController", HomeController);
	HomeController.$injector = ['$scope', 'UserProfileService'];

	function HomeController($scope, UserProfileService) {
		var vm = this;
		vm.checkLogStatus = checkLogStatus;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		checkLogStatus();

		function checkLogStatus() {
			UserProfileService.getUserProfile(vm.successCallback,vm.failCallback);
		}

		function successCallback(result) {
			vm.firstName = USER_PROFILE.firstName;
			vm.lastName = USER_PROFILE.lastName;
			vm.userName = result.data.profile.name;
			vm.userId = result.data.profile.userId;
		}

		 function failCallback(error){
            vm.firstName = 'Default';
            vm.lastName = 'User';
        }
	}
})();