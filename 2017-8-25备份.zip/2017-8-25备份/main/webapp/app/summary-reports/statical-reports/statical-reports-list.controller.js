(function() {
	"use strict";
	angular.module("adminManageApp").controller('StaticalReportsController', StaticalReportsController);
	StaticalReportsController.$injector = ['$scope', '$modal', 'StaticalReportsService', '$state'];

	function StaticalReportsController($scope, StaticalReportsService, $state) {
		var vm = this;
		vm.getStaticalReportsFile = getStaticalReportsFile;

		function getStaticalReportsFile() {
			var obj = {
				"partyId":"S7810384A",
				"dateFrom":vm.date.substring(0,11),
				"dateTo":vm.date.substring(14,25),
				"date":vm.date,
				"type": vm.type,
				"format":vm.format
			};

			/*console.log(obj);
			console.log(vm.date.length)*/
			
			//window.location.href="http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/report/statistical?dateFrom=30-Jul-2015&dateTo=18-Aug-2017&format=CSV&partyId=S7810384A&type=01";
			window.location.href="http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/report/statistical?"+"dateFrom="+obj.dateFrom+"&dateTo="+obj.dateTo+"&format="+obj.format+"&partyId="+obj.partyId+"&type="+obj.type;
			//StaticalReportsService.getStaticalReports(obj);			

		}

		

	}
})();