(function() {
	"use strict";
	angular.module("adminManageApp").controller('EndOfDayController', EndOfDayController);
	EndOfDayController.$injector = ['$scope', '$modal', 'EndOfDayService', '$state'];

	function EndOfDayController($scope, $modal, EndOfDayService, $state) {
		var vm = this;
		
		vm.getEndOfDayFile = getEndOfDayFile;

		function getEndOfDayFile() {
			var obj = {
				"partyId":"S7810384A",				
				"date": vm.date,
				"type": vm.type,
				"format":vm.format
			};			
			
			//window.location.href="http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/report/endofday?date=18-Aug-2017&format=CSV&partyId=S7810384A&type=01";
			
			window.location.href="http://cangzdwcis01:8699/sg-ecare-admin/v1/admin/report/endofday?"+"date="+obj.date+"&format="+obj.format+"&partyId="+obj.partyId+"&type="+obj.type;

			//StaticalReportsService.getStaticalReports(obj);			

		}	
	
	}
})();