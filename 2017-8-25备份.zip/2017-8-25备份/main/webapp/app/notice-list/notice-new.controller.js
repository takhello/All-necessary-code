(function() {
	"use strict";

	angular.module("adminManageApp").controller('NoticeAddController', NoticeAddController);
	NoticeAddController.$injector = ['$scope', 'NoticeService', '$modal', '$modalInstance',];

	function NoticeAddController($scope, NoticeService, $modal, $modalInstance) {
		var vm = this;
		vm.noticePreview = noticePreview;
		vm.addRoleCancel = addRoleCancel;
		vm.addNotice = addNotice;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		vm.messageLengthChange = messageLengthChange;//更新输入长度
		vm.inputNewMessage = "";
		vm.inputNewMessageLength = vm.inputNewMessage.length;
		function messageLengthChange(){
			
			console.log(vm.inputNewMessage.length);
			vm.inputNewMessageLength = vm.inputNewMessage.length;
		}

		// tong
		//判断
		vm.selected = [];
    	vm.selectedTags = [];
    	vm.updateSelection = updateSelection;
	    vm.isSelected = isSelected;
    	vm.updateSelected =updateSelected;

		//数据初始化
		vm.position_signUp ="signUp";
    	vm.position_logIn ="login";
    	vm.position_forgotPassword ="forgetPwd";
    	vm.position_importantNotes ="imptNote";
    	vm.position_fundSwitch ="fundSwitch";
    	vm.position_changeOfAddress ="changeAddr";
    	vm.position_CKA ="cka";
    	vm.position_home ="home";
 
  		// $('#reservation1').daterangepicker();
		function init(){
			//修改注意分隔符 
			vm.daterangepickerDirective = $(".daterangepickerDirective").val();
  			vm.noticeStatus = $(".notice-status").val();
	  		vm.dateArr = vm.daterangepickerDirective.split("  - ");
	  		vm.dateArrStartDate = vm.dateArr[0]; 
	  		vm.dateArrEndDate = vm.dateArr[1]; 
	  		vm.switchDateArrStartDate = vm.dateArrStartDate.split("-");
	  		vm.switchDateArrEndDate = vm.dateArrEndDate.split("-");
		  	var positionArr = [
	  			vm.position_signUp,
	  			vm.position_logIn,
	  			vm.position_forgotPassword,
	  			vm.position_importantNotes,
	  			vm.position_fundSwitch,
	  			vm.position_changeOfAddress,
	  			vm.position_CKA,
	  			vm.position_home
	  		];
	  		vm.positionList = {
	  			positionList:{
				    "userId" : USER_ID,
					"sessionId":USER_SESSIONID,
					"country" : USER_COUNTRY,
					"language" : USER_LANGUAGE,
					"partyId" : USER_ID,
					"data" : {
						"startDate" : "",
						"endDate" : "",
						"status" : "D",
						"signUp" : "Y",
						"login" : "N",
						"forgetPwd" : "N",
						"imptNote" : "N",
						"fundSwitch" : "N",
						"changeAddr" : "N",
						"cka" : "N",
						"home" : "N",
						"bolder" : "N",
						"redBox" : "N",
						"message" : vm.inputNewMessage
					}
			    }
		  	};
		  	//确认选中对象并赋值
	  		for (var i=0 ; i<positionArr.length; i++){
	  			for(var j=0; j<vm.selected.length; j++){
					if(positionArr[i] == vm.selected[j]){
						vm.positionList.positionList.data[positionArr[i]] = "Y";
					}
	  			}
	  		}
	  		if(vm.noticeStatus == "Active"){
	  			vm.positionList.positionList.data.status = "A";
	  		}
	  		else{
	  			vm.positionList.positionList.data.status = "D";
	  		}
	  		var switchDateArrStartDateMonth = vm.switchDateArrStartDate[1];
	  		var switchDateArrEndDateMonth = vm.switchDateArrEndDate[1];
	  		var monthArr = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
	  		var monthArrNumeral= ["01","02","03","04","05","06","07","08","09","10","11","12"];
			for (var x = 0; x < monthArr.length; x++){
				if(switchDateArrStartDateMonth == monthArrNumeral[x]){
					vm.switchDateArrStartDate.splice(1,1,monthArr[x]);
					vm.positionList.positionList.data.startDate =$.trim(vm.switchDateArrStartDate.join("-")) ;
				}
				if(switchDateArrEndDateMonth == monthArrNumeral[x]){
					vm.switchDateArrEndDate.splice(1,1,monthArr[x]);
					vm.positionList.positionList.data.endDate =$.trim( vm.switchDateArrEndDate.join("-"));
				}
			}
			
		}

		function addNotice(){
			init();
			var obj = vm.positionList.positionList;
   			console.log(obj);
			NoticeService.newNotice(obj, vm.successCallback, vm.failCallback);


		}
		function successCallback(result) {
			console.log(result);
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
			console.log('成功');
		}
		

		function failCallback(error) {
			console.log('失败');
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			// vm.status = error.data.code;
		}

		function noticePreview(){
			var modalInstance = $modal.open({
                templateUrl: "app/notice-list/notice-new-preview.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "NoticePreviewController",
                controllerAs: "vm",
                size: 'md'
            });
            // modalInstance.result.then(getRoleList);
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}


		function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}

	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	 
	    function isSelected(id){
	        return vm.selected.indexOf(id)>=0;
	    }
	}
})();