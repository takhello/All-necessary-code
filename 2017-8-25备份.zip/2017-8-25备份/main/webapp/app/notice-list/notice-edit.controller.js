(function() {
	"use strict";

	angular.module("adminManageApp").controller('NoticeEditController', NoticeEditController);
	NoticeEditController.$injector = ['$scope', '$modal', '$modalInstance', 'editNoticeIdItem', 'NoticeData', 'NoticeService'];

	function NoticeEditController($scope, $modal, $modalInstance, editNoticeIdItem, NoticeData, NoticeService) {
		var vm = this;
		vm.NoticeData = NoticeData;
		vm.closeError = closeError;
		vm.editRoleCancel = editRoleCancel;

		vm.isAlertHide = true;
		vm.modalVal = angular.copy(NoticeData);

		vm.getIdNotice = getIdNotice;
		vm.successGetIdNoticeCallback = successGetIdNoticeCallback;
		vm.failGetIdNoticeCallback = failGetIdNoticeCallback;
		vm.editNoticeConfirm = editNoticeConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		//判断
		vm.selected = [];
    	vm.selectedTags = [];
    	vm.updateSelection = updateSelection;
	    vm.isSelected = isSelected;
    	vm.updateSelected =updateSelected;

		vm.messageLengthChange = messageLengthChange;//更新输入长度
		vm.inputNewMessage = "";
		vm.inputNewMessageLength = vm.inputNewMessage.length;
		function messageLengthChange(){
		vm.inputNewMessageLength = vm.inputNewMessage.length;
		}

			

		//数据初始化
		vm.position_signUp ="signUp";
    	vm.position_logIn ="login";
    	vm.position_forgotPassword ="forgetPwd";
    	vm.position_importantNotes ="imptNote";
    	vm.position_fundSwitch ="fundSwitch";
    	vm.position_changeOfAddress ="changeAddr";
    	vm.position_CKA ="cka";
    	vm.position_home ="home";


		function init(){
			//修改注意分隔符 
			vm.daterangepickerDirective = $(".daterangepickerDirective").val();
  			vm.noticeStatus = $(".notice-status").val();
	  		vm.dateArr = vm.daterangepickerDirective.split("  - ");
	  		vm.dateArrStartDate = vm.dateArr[0]; 
	  		vm.dateArrEndDate = vm.dateArr[1]; 
	  		vm.switchDateArrStartDate = vm.dateArrStartDate.split("-");
	  		vm.switchDateArrEndDate = vm.dateArrEndDate.split("-");
		  	var positionArr = [
	  			vm.position_signUp,
	  			vm.position_logIn,
	  			vm.position_forgotPassword,
	  			vm.position_importantNotes,
	  			vm.position_fundSwitch,
	  			vm.position_changeOfAddress,
	  			vm.position_CKA,
	  			vm.position_home
	  		];
	  		vm.positionList = {
	  			positionList:{
				    "userId" : USER_ID,
					"sessionId":USER_SESSIONID,
					"country" : USER_COUNTRY,
					"language" : USER_LANGUAGE,
					"partyId" : USER_ID,
					"data" : {
						"startDate" : "",
						"endDate" : "",
						"status" : "D",
						"signUp" : "Y",
						"login" : "N",
						"forgetPwd" : "N",
						"imptNote" : "N",
						"fundSwitch" : "N",
						"changeAddr" : "N",
						"cka" : "N",
						"home" : "N",
						"bolder" : "N",
						"redBox" : "N",
						"message" : vm.inputNewMessage,
						"noticeID" : editNoticeIdItem
					}
			    }
		  	};
		  	//确认选中对象并赋值
	  		for (var i=0 ; i<positionArr.length; i++){
	  			for(var j=0; j<vm.selected.length; j++){
					if(positionArr[i] == vm.selected[j]){
						vm.positionList.positionList.data[positionArr[i]] = "Y";
					}
	  			}
	  		}
	  		if(vm.noticeStatus == "Active"){
	  			vm.positionList.positionList.data.status = "A";
	  		}
	  		else{
	  			vm.positionList.positionList.data.status = "D";
	  		}
	  		var switchDateArrStartDateMonth = vm.switchDateArrStartDate[1];
	  		var switchDateArrEndDateMonth = vm.switchDateArrEndDate[1];
	  		var monthArr = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
	  		var monthArrNumeral= ["01","02","03","04","05","06","07","08","09","10","11","12"];
			for (var x = 0; x < monthArr.length; x++){
				if(switchDateArrStartDateMonth == monthArrNumeral[x]){
					vm.switchDateArrStartDate.splice(1,1,monthArr[x]);
					vm.positionList.positionList.data.startDate =$.trim(vm.switchDateArrStartDate.join("-")) ;
				}
				if(switchDateArrEndDateMonth == monthArrNumeral[x]){
					vm.switchDateArrEndDate.splice(1,1,monthArr[x]);
					vm.positionList.positionList.data.endDate =$.trim( vm.switchDateArrEndDate.join("-"));
				}
			}
			
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function editRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

 		getIdNotice();
		//getIdNotice
		function getIdNotice() {
			var obj = {
				"userId" : USER_ID,
				"sessionId":USER_SESSIONID,
				"country" : USER_COUNTRY,
				"language" : USER_LANGUAGE,
				"partyId" : USER_ID,
				"noticeID" : editNoticeIdItem,
				"type" : "",
				"noticeFromDate": NoticeData.fromDate,
				"noticeToDate" : NoticeData.toDate
			};
			console.log("根据ID获取");
			console.log(obj);
			NoticeService.getIdNotice(obj, vm.successGetIdNoticeCallback, vm.failGetIdNoticeCallback);
		}
		function successGetIdNoticeCallback(result){
			console.log(result);
		}
		function failGetIdNoticeCallback(error){
			console.log(error);
		}

		//editNoticeConfirm
		function editNoticeConfirm() {
			init();
			var obj = vm.positionList.positionList;
			console.log("PUT数据");
			console.log(obj);
			NoticeService.editNotice(obj, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			console.log(result);
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}
		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}

		function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}
	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	    function isSelected(id){
	        return vm.selected.indexOf(id)>=0;
	    }
	}
})();