(function() {
	"use strict";

	angular.module("adminManageApp").controller("UserDeleteController", UserDeleteController);
	UserDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'UserGroupService', 'roleId', 'roleData'];

	function UserDeleteController($scope, $modal, $modalInstance, UserGroupService, roleId, roleData) {
		var vm = this;
		vm.deleteRoleCancel = deleteRoleCancel;
		vm.deleteRoleConfirm = deleteRoleConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;

		function deleteRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteRoleConfirm() {
			UserGroupService.deleteUser(roleId,vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			// vm.status = error.data.code;
		}
	}
})();