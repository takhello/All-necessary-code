(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserEditController', UserEditController);
	UserEditController.$injector = ['$scope', '$modal', '$modalInstance', 'editUserIdItem', 'UserData', 'UserGroupService'];

	function UserEditController($scope, $modal, $modalInstance, editUserIdItem, UserData, UserGroupService) {
		var vm = this;
		vm.UserData = UserData;
		vm.closeError = closeError;
		vm.editRoleCancel = editRoleCancel;

		vm.checkedData = checkedData;
		// vm.editUserConfirm = editUserConfirm;

		vm.editUserSuccessCallback = editUserSuccessCallback;
		vm.editUserFailCallback = editUserFailCallback;
		vm.isAlertHide = true;
		vm.modalVal = angular.copy(UserData);
		vm.getGroupList = getGroupList;
		vm.getGroupSuccessCallback = getGroupSuccessCallback;
		vm.getGroupsFailCallback = getGroupsFailCallback;
		//git id user
		vm.getIdUser = getIdUser;
		vm.getIdUserSuccessCallback = getIdUserSuccessCallback;
		vm.getIdUserFailCallback = getIdUserFailCallback;
		//show id
		vm.userLANID = editUserIdItem;

		vm.userName = vm.modalVal.name;
		vm.userTelephon = vm.modalVal.telephone;
		vm.userEmail = vm.modalVal.email;
		vm.userDepartment = vm.modalVal.department;
		
		console.log(vm.modalVal);
		getIdUser();
		getGroupList();
		function closeError(){
			vm.isAlertHide = true;
		}

		function editRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function checkedData(){
			console.log('进入');
			if(JSON.stringify(vm.selected) === '[]'){
				vm.submitted = true;
				vm.isAlertHide = false;
				vm.fail = "Please select a Group";
				// vm.status = "error.data.code";
				console.log('错误');
			}
			else{
				editUserConfirm();
				console.log('正确');
			}
		}

		function editUserConfirm() {
			var object = {
				"userId":"",
				"sessionId":"",
				"country":"",
				"language":"",
				"data":{
						"name":vm.userName,
						"telephone":vm.userTelephon,
						"email":vm.userEmail,
						"department":vm.userDepartment,
						"groupIdList":vm.selected
				}
			};

			UserGroupService.editUserConfirm(editUserIdItem, object, vm.editUserSuccessCallback, vm.editUserFailCallback);

		}
		function editUserSuccessCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}
		function editUserFailCallback(error) {

			console.log(error);
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.errorMessage;
			// vm.status = error.data.code;
		}
		

     	//get Group
		function getGroupList(){
			var obj={
				    "userId":"",
					"country":"",
					"language":"",
					"sessionId":""
				};
			UserGroupService.getGroupList(obj, vm.getGroupSuccessCallback, vm.getGroupsFailCallback);
		}

		function getGroupSuccessCallback(result){
			vm.GroupList = result.data.adminGroupList;
		}

		function getGroupsFailCallback(result){
			
		}

		//get id user

		function getIdUser(){
			var obj={
					    "userId":"",
						"country":"",
						"language":"",
						"sessionId":""
			};

			UserGroupService.getIdUser(editUserIdItem,obj, vm.getIdUserSuccessCallback, vm.getIdUserFailCallback);
		}

		function getIdUserSuccessCallback (result) {
			vm.adminUserList = result.data.adminUserList;
			console.log(vm.adminUserList);
			vm.checkedAdminUserList = serializeData(result.data.adminUserList,"adminGroupList","groupId");
			function serializeData(data,key,key1){
				var obj=[];
				var index = 0;
				for (var i=0; i < data.length;  i++) {
					if(data[i][key] ){
						// var a  = {name:data[i].functionName,data:data[i].functionName};
						for(var j = 0; j <data[i][key].length; j++){
							obj.push(data[i][key][j][key1]);
						}
					}
				}
				return obj;
			}
			//存储checkbox
			vm.selected = vm.checkedAdminUserList;
	    	vm.selectedTags = [];
	    	vm.updateSelection = updateSelection;
		    vm.isSelected = isSelected;
	    	vm.updateSelected =updateSelected;
		}

		function getIdUserFailCallback (result){

		}

		// checkbox
	 	function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}
	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	 
	    function isSelected(id){
	        return vm.selected.indexOf(id)>=0;
	    }
	}
})();