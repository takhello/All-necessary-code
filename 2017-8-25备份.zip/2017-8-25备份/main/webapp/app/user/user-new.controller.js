(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserNewController', UserNewController);
	UserNewController.$injector = ['$scope', 'UserGroupService','$modal', '$modalInstance'];

	function UserNewController($scope, UserGroupService, $modal, $modalInstance) {
		var vm = this;
		vm.addRoleCancel = addRoleCancel;
		// vm.createUser = createUser;
		vm.checkedData = checkedData;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
	
		vm.getGroupList = getGroupList;
		vm.getGroupSuccessCallback = getGroupSuccessCallback;
		vm.getGroupsFailCallback = getGroupsFailCallback;
		
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;
	

		getGroupList();
		
		//存储checkbox
		vm.selected = [];
    	vm.selectedTags = [];
    	vm.updateSelection = updateSelection;
	    vm.isSelected = isSelected;
    	vm.updateSelected =updateSelected;

		function getGroupList(){
			var obj={
				    "userId":"",
					"country":"",
					"language":"",
					"sessionId":""
				};
			UserGroupService.getGroupList(obj, vm.getGroupSuccessCallback, vm.getGroupsFailCallback);
		}
		function getGroupSuccessCallback(result){
			vm.GroupList = result.data.adminGroupList;
		}

		function getGroupsFailCallback(result){
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}
		function checkedData(){
			console.log('进入');
			if(JSON.stringify(vm.selected) === '[]'){
				vm.submitted = true;
				vm.isAlertHide = false;
				vm.fail = "Please select a Group";
				// vm.status = "error.data.code";
				console.log('错误');
			}
			else{
				createUser();
				console.log('正确');

			}
		}

		function createUser() {
			var obj={
				    "userId": "",
				    "sessionId": "0001Xyo18aCPU5tr_8Ab_h_hORBIba1jXO3FQD5KLMu51bBsE7DfKDH7_PiPCp-M7HP-vO9z4ch7ycVNY_zOEjqYoHIvy5YunVIIyIXeu4iN-fDNAZKeA4Kd3m-esw-bH1g",
				    "country": "sg",
				    "language": "en_SG",
				    "data": {
				        "userId": vm.userId,
				        "name": vm.name,
				        "telephone": vm.userTelephon,
				        "email": vm.userEmail,
				        "department": vm.userDepartment,
				        "groupIdList": vm.selected
				        
				    }
				};
			console.log(obj);
			UserGroupService.createUser(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.errorMessage;
			// vm.status = error.data.code;
		}

    	function updateSelected(action,id,name){
	        if(action == 'add' && vm.selected.indexOf(id) == -1){
	            vm.selected.push(id);
	            vm.selectedTags.push(name);         
	        }
	        if(action == 'remove' && vm.selected.indexOf(id)!=-1){
	             var idx = vm.selected.indexOf(id);
	             vm.selected.splice(idx,1);
	             vm.selectedTags.splice(idx,1);
            }
     	}

	    function updateSelection($event, id){
	         var checkbox = $event.target;
	         var action = (checkbox.checked?'add':'remove');
	         updateSelected(action,id,checkbox.name);
	    }
	 
	    function isSelected(id){

	        return vm.selected.indexOf(id)>=0;
	    }
	}
})();