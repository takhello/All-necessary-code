(function() {
	"use strict";
	angular.module("adminManageApp").controller("AdminGroupController", AdminGroupController);
	AdminGroupController.$injector = ['$scope', '$stateParams', '$state', 'AdminToGroupService', 'GroupService', '$modal'];

	function AdminGroupController($scope, $stateParams, $state, AdminToGroupService, GroupService, $modal) {
		var vm = this;
		vm.backToAdmin = backToAdmin;
		vm.deleteAdminGroup = deleteAdminGroup;
		vm.newAdminGroup = newAdminGroup;
		vm.adminGroupSelected = adminGroupSelected;
		vm.loadSuccessCallback = loadSuccessCallback;
		vm.selectedSuccessCallback = selectedSuccessCallback;
		vm.selectedFailCallback = selectedFailCallback;
		AdminToGroupService.getAdminGroupList($stateParams.id,vm.loadSuccessCallback);

		function loadSuccessCallback(result) {
			vm.currentGroups = result.data.adminUserGroupList;
			adminGroupSelected();
		}

		function adminGroupSelected() {
			GroupService.getGroupList({},vm.selectedSuccessCallback, vm.selectedFailCallback);
		}

		function selectedSuccessCallback(result) {
			var arr = [];
			vm.allGroups = result.data.groupList;
			if (vm.currentGroups.length === 0) {
				vm.selectedGroups = vm.allGroups;
			} else {
				angular.forEach(vm.allGroups, function(item) {
					var flag = vm.currentGroups.length;
					angular.forEach(vm.currentGroups, function(value) {

						if (item.groupId === value.groupId) {
							return;
						} else {
							flag -= 1;
							if (flag === 0) {
								arr.push(item);
							}
						}
					});
				});
				vm.selectedGroups = arr;
			}
		}

		function selectedFailCallback() {
			vm.selectedGroups = vm.allGroups;
		}

		function backToAdmin() {
			$state.go("home.admin");
		}

		function deleteAdminGroup(adminGroupId) {
			var modalInstance = $modal.open({
				templateUrl: "app/admin_group/admin-group-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "AdminGroupDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					adminGroupId:function(){
						return adminGroupId;
					}
				}

			});
			modalInstance.result.then(AdminToGroupService.getAdminGroupList($stateParams.id,vm.loadSuccessCallback));
		}

		function newAdminGroup(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/admin_group/admin-group-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "AdminGroupAddController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					groupId: function() {
						return id;
					},
					adminId: function() {
						return $stateParams.id;
					}
				}

			});
			modalInstance.result.then(AdminToGroupService.getAdminGroupList($stateParams.id,vm.loadSuccessCallback));
		}
	}
})();