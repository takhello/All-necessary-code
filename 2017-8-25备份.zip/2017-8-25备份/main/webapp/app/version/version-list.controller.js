(function(){
	"use strict";

	angular.module("adminManageApp").controller("VersionController",VersionController);
	VersionController.$injector = ['$scope','VersionService','$modal','$state'];
	function VersionController($scope,VersionService,$modal,$state){
		var vm = this;
		vm.getVersionList = getVersionList;
		vm.addVersion = addVersion;
		
		vm.successCallback = successCallback;
		getVersionList();
		
		function getVersionList(){
			VersionService.getVersion({},vm.successCallback);
		}
		function successCallback(result){
			vm.versions = result.data.versionList;
		}
		function addVersion(){
			var modalInstance = $modal.open({
				templateUrl: "app/version/version-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "VersionAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getVersionList);
		}
	}
})();