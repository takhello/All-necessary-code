package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.User;
import com.aia.mypage.service.UserService;

public class UserServiceImpl implements UserService {

    @Autowired
    @Qualifier("userDAOImpl")
    private UserDAO userDAO;

    @Override
    public User getUserById(int userId) {

        return userDAO.getUserById(userId);
    }

    @Override
    public List<User> getUserList(String partyId, String firstName) {

        return userDAO.getgetUserList(partyId, firstName);
    }

    @Override
    public User getUserByPartyId(String partyId) {

        return userDAO.getUserByPartyId(partyId);
    }

}
