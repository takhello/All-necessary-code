package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.AuditLog;
import com.aia.mypage.entity.UserWorkAuditLog;

public interface AuditLogService {

    List<UserWorkAuditLog> getAuditLogList(int userId);

}
