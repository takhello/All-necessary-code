package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.UserWorkAuditLogDAO;
import com.aia.mypage.entity.UserWorkAuditLog;
import com.aia.mypage.service.AuditLogService;

public class AuditLogServiceImpl implements AuditLogService {

    @Autowired
    @Qualifier("userWorkAuditLogDAOImpl")
    private UserWorkAuditLogDAO auditLogDAO;

    @Override
    public List<UserWorkAuditLog> getAuditLogList(int userId) {

        return auditLogDAO.getAuditLogList(userId);
    }

}
