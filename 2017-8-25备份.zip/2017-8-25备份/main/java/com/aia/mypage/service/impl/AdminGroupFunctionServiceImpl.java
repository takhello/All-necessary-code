package com.aia.mypage.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.AdminGroupFunctionDAO;
import com.aia.mypage.dao.AdminGroupFunctionInfoDAO;
import com.aia.mypage.entity.AdminGroupFunction;
import com.aia.mypage.entity.AdminGroupFunctionInfo;
import com.aia.mypage.service.AdminGroupFunctionService;

public class AdminGroupFunctionServiceImpl implements AdminGroupFunctionService {

    @Autowired
    @Qualifier("adminGroupFunctionInfoDAOImpl")
    private AdminGroupFunctionInfoDAO adminGroupFunctionInfoDAO;
    
    @Autowired
    @Qualifier("adminGroupFunctionDAOImpl")
    private AdminGroupFunctionDAO adminGroupFunctionDAO;

    @Override
    public AdminGroupFunctionInfo getAdminGroupFunctionInfo(String groupId) {
        AdminGroupFunctionInfo result = new AdminGroupFunctionInfo();
        List<AdminGroupFunctionInfo> list = adminGroupFunctionInfoDAO.getAdminGroupFunctionInfo(groupId);

        for (AdminGroupFunctionInfo adminGroupFunctionInfo : list) {
            if (!StringUtils.isEmpty(result.getGroupId())) {
                result.addFucntionList(adminGroupFunctionInfo.getFunctionList());
            } else {
                result.setGroupId(adminGroupFunctionInfo.getGroupId());
                result.setGroupName(adminGroupFunctionInfo.getGroupName());
                result.setGroupDesc(adminGroupFunctionInfo.getGroupDesc());
                result.setGroupStatus(adminGroupFunctionInfo.getGroupStatus());
                result.addFucntionList(adminGroupFunctionInfo.getFunctionList());
            }
        }
        return result;
    }

    @Override
    public AdminGroupFunction addAdminGroupFunction(AdminGroupFunction adminGroupFunction) {
        return adminGroupFunctionDAO.addAdminGroupFunction(adminGroupFunction);
    }

    @Override
    public boolean deleteAdminGroupFunction(String groupId) {
        return adminGroupFunctionDAO.deleteAdminGroupFunction(groupId);
    }

}
