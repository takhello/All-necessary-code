package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.GroupRoleDAO;
import com.aia.mypage.dao.GroupRoleGRDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.util.BaseUtil;

public class GroupRoleServiceImpl implements GroupRoleService {

    @Autowired
    @Qualifier("groupRoleDAOImpl")
    private GroupRoleDAO groupRoleDAO;

    @Autowired
    @Qualifier("groupRoleGRDAOImpl")
    private GroupRoleGRDAO groupRoleGRDAO;

    public boolean deleteGroupRoleByRoleId(String roleId) {
        List<GroupRole> groupRoleListByRoleId = groupRoleDAO.getGroupRoleListByRoleId(roleId);
        if (groupRoleListByRoleId.size() == 0) {
            return false;
        }
        for (GroupRole groupRole : groupRoleListByRoleId) {
            groupRoleDAO.deleteGroupRoleById(groupRole.getGroupRoleId());
        }
        return true;
    }

    public boolean deleteGroupRoleByGroupId(String groupId) {
        List<GroupRole> groupRoleListByGroupId = groupRoleDAO.getGroupRoleListByGroupId(groupId);
        if (groupRoleListByGroupId.size() == 0) {
            return false;
        }
        for (GroupRole groupRole : groupRoleListByGroupId) {
            groupRoleDAO.deleteGroupRoleById(groupRole.getGroupRoleId());
        }
        return true;
    }

    public List<GroupRoleGR> getGroupRoleGRsList(Group group, Role role) {
        List<GroupRoleGR> groupRoleGRsList = groupRoleGRDAO.getGroupRoleGRsList(group, role);
        return groupRoleGRsList;
    }

    public GroupRole addGroupRole(String groupId, String roleId) {
        GroupRole groupRole = new GroupRole();
        groupRole.setGroupId(groupId);
        groupRole.setRoleId(roleId);
        groupRole.setIsDefault(BaseUtil.IS_DEFAULT_N);
        groupRole.setCreateTime(new Date());
        groupRole = groupRoleDAO.addGroupRole(groupRole);
        return groupRole;
    }

    public boolean deleteGroupRoleById(Integer groupRoleId) {
        groupRoleDAO.deleteGroupRoleById(groupRoleId);
        return true;
    }

    @Override
    public boolean hasSameGroupRole(String groupId, String roleId) {
        GroupRole groupRole = groupRoleDAO.hasSameGroupRole(groupId, roleId);
        if (groupRole == null) {
            return false;
        }
        return true;
    }

    @Override
    public List<GroupRole> getGroupRoleList() {

        return groupRoleDAO.getGroupRoleList();
    }

    @Override
    public List<GroupRole> getGroupRoleListByRoleId(String roleId) {

        return groupRoleDAO.getGroupRoleListByRoleId(roleId);
    }

    @Override
    public List<GroupRole> getGroupRoleListByGroupId(String groupId) {

        return groupRoleDAO.getGroupRoleListByGroupId(groupId);
    }

    @Override
    public GroupRole getGroupRoleListById(Integer groupRoleId) {

        return groupRoleDAO.getGroupRoleListById(groupRoleId);
    }

}
