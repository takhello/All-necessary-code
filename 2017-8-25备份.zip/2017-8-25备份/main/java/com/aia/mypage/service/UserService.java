package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.User;

public interface UserService {

    User getUserById(int userId);

    List<User> getUserList(String partyId, String firstName);

    User getUserByPartyId(String partyId);

}
