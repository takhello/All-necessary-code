package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.RegisterHistoryDAO;
import com.aia.mypage.entity.RegisterHistory;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class RegisterHistoryDAOImpl extends JPABaseRepImpl<RegisterHistory> implements RegisterHistoryDAO {

    public RegisterHistory queryRegHistory(String custId) {
        
        StringBuffer sql = new StringBuffer();
        sql.append("from  RegisterHistory where custId = :custId ");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("custId", custId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);

    }

    @Override
    protected EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void updateStatus(String custId) {

        StringBuffer sql = new StringBuffer();
        sql.append("update RegisterHistory set retried_time = 0, is_locked_account='N' WHERE custId =:custId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("custId", custId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        newUpdate(sqlParameters);
    }

}
