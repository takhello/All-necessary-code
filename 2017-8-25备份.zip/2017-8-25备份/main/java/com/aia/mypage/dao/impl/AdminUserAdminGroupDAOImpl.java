package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.aia.mypage.dao.AdminUserAdminGroupDAO;
import com.aia.mypage.entity.AdminUserAdminGroupInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserAdminGroupDAOImpl extends JPABaseRepImpl<AdminUserAdminGroupInfo>
        implements AdminUserAdminGroupDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<AdminUserAdminGroupInfo> getAllAdminUserAdminGroup(String userId) {
        Map<String, Object> parameters = new HashMap<String, Object>();
       
        StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.AdminUserAdminGroupInfo")
                .append("(u.userId,u.name,u.telephone,u.email,u.department,g.groupId,g.groupName) ")
                .append("from AdminUser u,AdminGroup g, AdminUserGroup ug ")
                .append("where u.userId=ug.userId ")
                .append("  and g.groupId=ug.groupId ");
        if (StringUtils.isNotEmpty(userId)) {
            sql.append("  and u.userId=:userId ");
            parameters.put("userId", userId);
        }

        sql.append("order by u.userId Desc");
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);

        return super.query(sqlParameters);
    }
}
