package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.UserWorkInfo;

public interface AccountUserWorkDAO {

    List<UserWorkInfo> getAccountListByIdName(String custId, String custName);

}
