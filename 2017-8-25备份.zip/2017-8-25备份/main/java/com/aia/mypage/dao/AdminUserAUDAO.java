package com.aia.mypage.dao;

import org.springframework.stereotype.Service;

import com.aia.mypage.entity.AdminUser;

public interface AdminUserAUDAO {

    AdminUser addAdminUser(AdminUser adminUser);

    int updateAdmin(AdminUser adminUser);

    boolean deleteAdminByUserId(String userId);

    AdminUser getAdminUserByUserId(String userId);

}
