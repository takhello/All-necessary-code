package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Function;

public interface FunctionDAO {

    List<Function> getFunctionsList(String functionId);

    List<Function> getFunctionsListByUserId(String userId);

}
