package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminUserPermissionVO;

public interface AdminUserPermissionDAO {
	
	List<AdminUserPermissionVO> getPermissionListByUserId(String userId);

}
