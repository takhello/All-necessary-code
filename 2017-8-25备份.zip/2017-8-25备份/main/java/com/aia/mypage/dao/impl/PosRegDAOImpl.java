package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.PosRegDAO;
import com.aia.mypage.entity.ActiveUserInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class PosRegDAOImpl extends JPABaseRepImpl<ActiveUserInfo> implements PosRegDAO {

    @Override
    protected EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<ActiveUserInfo> getUserList(String custId, String name) {

        StringBuffer sql = new StringBuffer("select new com.aia.mypage.entity.ActiveUserInfo");
        sql.append(" (a.accountName, p.name, a.isEnabled, p.timReg)");
        sql.append(
                " from Account a, PosReg p,PosCustMapping pm where a.accountName = pm.custId and pm.userId=p.regId");
        Map<String, Object> parameters = new HashMap<String, Object>();

        if (custId != null) {
            sql.append(" and  a.accountName =:custId");
            parameters.put("custId", custId);
        }
        if (name != null) {
            sql.append(" and p.name like:name");
            parameters.put("name", "%" + name + "%");
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return query(sqlParameters);
    }

}
