package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.RoleDAO;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class RoleDAOImpl extends JPABaseRepImpl<Role> implements RoleDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public Role getRoleById(String roleId) {
        StringBuffer sql = new StringBuffer("from Role where roleId = :roleId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("roleId", roleId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public List<Role> getRolesList(Role role) {
        String roleId = role.getRoleId();
        StringBuffer sql = new StringBuffer("from Role where 1=1");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(roleId) && roleId != null) {
            sql.append(" and roleId = :roleId");
            parameters.put("roleId", roleId);
        }
        String roleName = role.getRoleName();
        if (!"".equals(roleName) && roleName != null) {
            sql.append(" and lower(roleName) like :roleName");
            parameters.put("roleName", "%" + roleName.toLowerCase() + "%");
        }
        String roleStatus = role.getRoleStatus();
        if (!"".equals(roleStatus) && roleStatus != null) {
            sql.append(" and roleStatus =:roleStatus");
            parameters.put("roleStatus", roleStatus);
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<Role> rolesList = super.query(sqlParameters);
        return rolesList;
    }

    public Role addRole(Role role) {
        role = super.create(role);
        return role;
    }

    public boolean deleteRoleById(String roleId) {
        super.remove(roleId);
        return true;
    }

    public Role updateRoleById(Role role) {
        role = super.update(role);
        return role;
    }

}
