package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Permission;

public interface PermissionDAO {

    Permission getPermissionById(String permissionId);

    List<Permission> getPermissionsList(Permission permission);

    Permission updatePermissionById(Permission permission);

    boolean deletePermissionById(String permissionId);

    Permission addPermission(Permission permission);
}
