package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminGroupFunctionInfo;

public interface AdminGroupFunctionInfoDAO {

    List<AdminGroupFunctionInfo> getAdminGroupFunctionInfo(String groupId);

}
