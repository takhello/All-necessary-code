package com.aia.mypage.framework;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.aia.mypage.dao.AdminFunctionDAO;
import com.aia.mypage.dao.AdminFunctionPermissionFPDAO;
import com.aia.mypage.dao.AdminUserPermissionDAO;
import com.aia.mypage.dao.RolePermissionRPDAO;
import com.aia.mypage.entity.AdminFunctionPermissionFP;
import com.aia.mypage.entity.Function;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.util.BaseUtil;


public class MypageFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource {

	protected final Log logger = LogFactory.getLog(super.getClass());
	public static Map<RequestMatcher, Collection<ConfigAttribute>> requestMap;

	@Autowired
	@Qualifier("rolePermissionRPDAOImpl")
	private RolePermissionRPDAO rolePermissionRPDAO;

	@Autowired
	@Qualifier("adminUserPermissionDAOImpl")
	private AdminUserPermissionDAO adminUserPermissionDAO;

	@Autowired
	@Qualifier("adminFunctionPermissionFPDAOImpl")
	private AdminFunctionPermissionFPDAO adminFunctionPermissionFPDAO;

	@Autowired
	@Qualifier("adminFunctionDAOImpl")
	private AdminFunctionDAO adminFunctionDAO;
	
	
	public static List<RolePermissionRP> rolePermissionList;

	public static List<AdminFunctionPermissionFP> functionPermissionList;

	public void initRequestMap() {

		requestMap = new LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>();

		rolePermissionList = rolePermissionRPDAO.getAllRolePermission();

		if (rolePermissionList != null && rolePermissionList.size() > 0) {

			requestMap = new LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>>();

			for (int i = 0; i < rolePermissionList.size(); i++) {

				AntPathRequestMatcher matcher = new AntPathRequestMatcher(
						rolePermissionList.get(i).getPermissionPattern(),
						rolePermissionList.get(i).getPermissionMethod().toUpperCase());

				List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>();
				attributes.add(new SecurityConfig("ROLE_" + rolePermissionList.get(i).getRoleName().toUpperCase()));
				requestMap.put(matcher, attributes);

			}

		}

		functionPermissionList = adminFunctionPermissionFPDAO.getAllFunctionPermission();


		if (functionPermissionList != null && functionPermissionList.size() > 0) {

			for (int i = 0; i < functionPermissionList.size(); i++) {

				AntPathRequestMatcher matcher = new AntPathRequestMatcher(
						functionPermissionList.get(i).getPermissionPattern(),
						functionPermissionList.get(i).getPermissionMethod().toUpperCase());

				List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>();
				attributes.add(
						new SecurityConfig("ROLE_" + functionPermissionList.get(i).getFunctionName().toUpperCase()));
				requestMap.put(matcher, attributes);

			}
		}

		if (functionPermissionList != null && functionPermissionList.size() > 0) {


			for (int i = 0; i < functionPermissionList.size(); i++) {

				AntPathRequestMatcher matcher = new AntPathRequestMatcher(
						functionPermissionList.get(i).getPermissionPattern(),
						functionPermissionList.get(i).getPermissionMethod().toUpperCase());

				List<ConfigAttribute> attributes = new ArrayList<ConfigAttribute>();
				attributes.add(
						new SecurityConfig("ROLE_" + functionPermissionList.get(i).getFunctionName().toUpperCase()));
				requestMap.put(matcher, attributes);

			}
		}

		List<Function> functions = adminFunctionDAO.getAllFunction();

		if (functions != null || functions.size() > 0) {

			for (int i = 0; i < functions.size(); i++) {

				AntPathRequestMatcher pageMatcher = new AntPathRequestMatcher(functions.get(i).getUrl());

				List<ConfigAttribute> pageAttributes = new ArrayList<ConfigAttribute>();
				pageAttributes.add(new SecurityConfig("ROLE_" + functions.get(i).getFunctionName().toUpperCase()));
				requestMap.put(pageMatcher, pageAttributes);
			}
		}

		// default role for login
		AntPathRequestMatcher matcher4 = null;
		List<ConfigAttribute> attributes4 = null;
		matcher4 = new AntPathRequestMatcher("/**", "GET");
		attributes4 = new ArrayList<ConfigAttribute>();
		attributes4.add(new SecurityConfig(BaseUtil.DEFAULT_ROLE_FOR_LOGIN));
		requestMap.put(matcher4, attributes4);

		
		System.out.println("");

	}
	
	

	public Collection<ConfigAttribute> getAttributes(Object object) {

		HttpServletRequest request = ((FilterInvocation) object).getRequest();
		//
		FilterInvocation filterInvocation = (FilterInvocation) object;
		//
		String url = filterInvocation.getRequestUrl();

		System.out.println(url);


		for (Map.Entry entry : this.requestMap.entrySet()) {
			if (((RequestMatcher) entry.getKey()).matches(request)) {
				return ((Collection) entry.getValue());
			}
		}
		return null;
	}

	public Collection<ConfigAttribute> getAllConfigAttributes() {
		Set allAttributes = new HashSet();

		for (Map.Entry entry : this.requestMap.entrySet()) {
			allAttributes.addAll((Collection) entry.getValue());
		}

		return allAttributes;
	}

	public boolean supports(Class<?> clazz) {
		return FilterInvocation.class.isAssignableFrom(clazz);
	}
	
}
