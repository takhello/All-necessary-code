package com.aia.mypage.framework;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jcifs.UniAddress;
import jcifs.http.NtlmHttpFilter;
import jcifs.http.NtlmSsp;
import jcifs.smb.NtlmChallenge;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbSession;
import jcifs.util.Base64;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.context.support.XmlWebApplicationContext;

public class MypageNtlmFilter extends NtlmHttpFilter {

    private static Log logging = LogFactory.getLog(MypageNtlmFilter.class);

    private String defaultDomain;
    private String domainController = "CNCSPWDOM02.AIA.BIZ";
    private String LAN_ID_DISABLED = "LAN_ID_DISABLED";
    private boolean loadBalance = false;
    private boolean enableBasic;
    private boolean insecureBasic;
    private String realm;

    private boolean ignoreNtlmFilter(HttpServletRequest req) {

        if (req.getSession().getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY) != null
                || req.getSession().getAttribute(LAN_ID_DISABLED) != null) {

            return true;
        }
        return false;
    }
    
    private void redirectLoginJspToRootPath(HttpServletRequest req,  HttpServletResponse resp) throws IOException{
        if (req.getSession().getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY) != null
                && req.getRequestURL().indexOf(req.getContextPath() + "/login.jsp") > -1) {
            resp.sendRedirect(req.getContextPath());
        }
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        NtlmPasswordAuthentication ntlm;

        logging.error("url =========" + req.getRequestURL());
        
        this.redirectLoginJspToRootPath(req, resp);
        
        if (ignoreNtlmFilter(req)) {
            chain.doFilter(req, response);
            return;
        }

        // the first request will be intercepted by NTLM and NTLM tell browser
        // to get token from AD, then a second request with token is sent to
        // mypage
        try {
            if ((ntlm = negotiate(req, resp, false)) == null) {

                // fail to get lan id
                if (ignoreNtlmFilter(req)) {
                    chain.doFilter(req, response);
                    return;
                }
                // first request
                return;
            } else {
                // successful to second request with token
                chain.doFilter(new MypageNtlmHttpServletRequest(req, ntlm), response);
            }
        } catch (Exception e) {
            req.getSession().setAttribute(LAN_ID_DISABLED, "true");
            chain.doFilter(req, response);
        }

    }

    private boolean setLanIdInfo(HttpServletRequest req, String lanid) {

        logging.error("begin to add lanid info into session: =========" + lanid);
        // get lanid info from db and add to session for spring filter
        ServletContext sc = req.getSession().getServletContext();
        XmlWebApplicationContext cxt = (XmlWebApplicationContext) WebApplicationContextUtils
                .getWebApplicationContext(sc);
        if (cxt != null && cxt.getBean("userService") != null) {

            MyPageUserDetailsService userservice = (MyPageUserDetailsService) cxt.getBean("userService");
            UserDetails userDetails = userservice.loadUserByUsername(lanid);

            if (!userDetails.isEnabled()) {
                logging.error("=======can't get lanid info form DB:" + lanid);
                return false;
            }

            WebAuthenticationDetails webDetails = new WebAuthenticationDetails(req);
            Object principal = userDetails;
            Object credentials = webDetails;
            UsernamePasswordAuthenticationToken sessionToken = new UsernamePasswordAuthenticationToken(principal,
                    credentials, userDetails.getAuthorities());
            SecurityContextImpl secContext = new SecurityContextImpl();
            secContext.setAuthentication(sessionToken);
            req.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, secContext);

        }

        return true;
    }

    protected NtlmPasswordAuthentication negotiate(HttpServletRequest req, HttpServletResponse resp,
            boolean skipAuthentication) throws IOException, ServletException {

        UniAddress dc;
        String msg;
        NtlmPasswordAuthentication ntlm = null;
        msg = req.getHeader("Authorization");
        boolean offerBasic = enableBasic && (insecureBasic || req.isSecure());

        if (msg != null && (msg.startsWith("NTLM ") || (offerBasic && msg.startsWith("Basic ")))) {

            if (msg.startsWith("NTLM ")) {
                HttpSession ssn = req.getSession();
                byte[] challenge;

                if (loadBalance) {
                    NtlmChallenge chal = (NtlmChallenge) ssn.getAttribute("NtlmHttpChal");
                    if (chal == null) {
                        chal = SmbSession.getChallengeForDomain();
                        ssn.setAttribute("NtlmHttpChal", chal);
                    }
                    dc = chal.dc;
                    challenge = chal.challenge;
                } else {
                    // mypage hits here
                    // don't add any coding here
                    dc = UniAddress.getByName(domainController, true);
                    challenge = SmbSession.getChallenge(dc);
                }

                if ((ntlm = NtlmSsp.authenticate(req, resp, challenge)) == null) {
                    // don't add any coding here
                    return null;
                }
                /* negotiation complete, remove the challenge object */
                ssn.removeAttribute("NtlmHttpChal");

                String lanid = ntlm.getUsername().toLowerCase();
                if (!this.setLanIdInfo(req, lanid)) {
                    req.getSession().setAttribute(LAN_ID_DISABLED, "true");
                    return null;
                }
                
                this.redirectLoginJspToRootPath(req, resp);

            } else {

                String auth = new String(Base64.decode(msg.substring(6)), "US-ASCII");
                int index = auth.indexOf(':');
                String user = (index != -1) ? auth.substring(0, index) : auth;
                String password = (index != -1) ? auth.substring(index + 1) : "";
                index = user.indexOf('\\');
                if (index == -1)
                    index = user.indexOf('/');
                String domain = (index != -1) ? user.substring(0, index) : defaultDomain;
                user = (index != -1) ? user.substring(index + 1) : user;
                ntlm = new NtlmPasswordAuthentication(domain, user, password);
                dc = UniAddress.getByName(domainController, true);

            }

        } else {

            if (!skipAuthentication) {
                HttpSession ssn = req.getSession(false);
                if (ssn == null || (ntlm = (NtlmPasswordAuthentication) ssn.getAttribute("NtlmHttpAuth")) == null) {
                    resp.setHeader("WWW-Authenticate", "NTLM");
                    if (offerBasic) {
                        resp.addHeader("WWW-Authenticate", "Basic realm=\"" + realm + "\"");
                    }
                    resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                    resp.setContentLength(0);
                    resp.flushBuffer();
                    return null;
                }
            }

        }

        return ntlm;
    }

}
