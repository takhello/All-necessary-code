package com.aia.mypage.framework;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class MypageNtlmHttpServletRequest extends HttpServletRequestWrapper{

    Principal principal;

    MypageNtlmHttpServletRequest( HttpServletRequest req, Principal principal ) {
        super( req );
        this.principal = principal;
    }
    public String getRemoteUser() {
        return principal.getName();
    }
    public Principal getUserPrincipal() {
        return principal;
    }
    public String getAuthType() {
        return "NTLM";
    }
    
}
