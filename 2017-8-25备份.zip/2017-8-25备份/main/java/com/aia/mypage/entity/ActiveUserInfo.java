package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

public class ActiveUserInfo implements Serializable {

    private static final long serialVersionUID = -1106472743012323044L;

    private String custId;

    private String name;

    private String isEnabled;

    private Date activeTime;

    private Date timReg;

    public ActiveUserInfo(String custId, String name, String isEnabled, Date timReg) {
        super();
        this.custId = custId;
        this.name = name;
        this.isEnabled = isEnabled;
        this.timReg = timReg;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Date getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(Date activeTime) {
        this.activeTime = activeTime;
    }

    public Date getTimReg() {
        return timReg;
    }

    public void setTimReg(Date timReg) {
        this.timReg = timReg;
    }

}
