package com.aia.mypage.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "db_cus..tbl_wal_reg_histories")
@Entity
public class RegisterHistory {
    
    @Id
    @Column(name = "cust_id")
    private String custId;
    
    @Column(name = "is_sent_firstloginmail")
    private String isSendFirstloginmail;
    
    @Column(name = "email")
    private String email;
    
    @Column(name = "reg_date_time")
    private Date regDateTime;
    
    @Column(name = "reg_status")
    private String regStatus;
    
    @Column(name = "retried_time")
    private Integer retriedTime;
    
    @Column(name = "reg_failed_date_time")
    private Date regFailedDateTime;
    
    @Column(name = "is_locked_account")
    private String isLockedAccount;

    
    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getRegDateTime() {
        return regDateTime;
    }

    public void setRegDateTime(Date regDateTime) {
        this.regDateTime = regDateTime;
    }

    public String getRegStatus() {
        return regStatus;
    }

    public void setRegStatus(String regStatus) {
        this.regStatus = regStatus;
    }

    public String getIsLockedAccount() {
        return isLockedAccount;
    }

    public void setIsLockedAccount(String isLockedAccount) {
        this.isLockedAccount = isLockedAccount;
    }

    public Integer getRetriedTime() {
        return retriedTime;
    }

    public void setRetriedTime(Integer retriedTime) {
        this.retriedTime = retriedTime;
    }

    public Date getRegFailedDateTime() {
        return regFailedDateTime;
    }

    public void setRegFailedDateTime(Date regFailedDateTime) {
        this.regFailedDateTime = regFailedDateTime;
    }

    public String getIsSendFirstloginmail() {
        return isSendFirstloginmail;
    }

    public void setIsSendFirstloginmail(String isSendFirstloginmail) {
        this.isSendFirstloginmail = isSendFirstloginmail;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "RegisterHistoryDto [custId=" + custId + ", isSendFirstloginmail=" + isSendFirstloginmail + ", email="
                + email + ", regDateTime=" + regDateTime + ", regStatus=" + regStatus + ", retriedTime=" + retriedTime
                + ", regFailedDateTime=" + regFailedDateTime + ", isLockedAccount=" + isLockedAccount + "]";
    }
}
