package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AdminGroupFunctionInfo implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = -2231609488993742902L;

    private String groupId;

    private String groupName;

    private String groupDesc;

    private String groupStatus;

    private List<Function> functionList = new ArrayList<Function>();

    public AdminGroupFunctionInfo() {
    }

    public AdminGroupFunctionInfo(String groupId, String groupName, String groupDesc, String groupStatus,
            String functionId, String functionName, String functionLevel, String parentFunctionId) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.groupDesc = groupDesc;
        this.groupStatus = groupStatus;
        this.functionList = new ArrayList<Function>();
        this.functionList.add(new Function(functionId, functionName, functionLevel, parentFunctionId));
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public String getGroupStatus() {
        return groupStatus;
    }

    public void setGroupStatus(String groupStatus) {
        this.groupStatus = groupStatus;
    }

    public List<Function> getFunctionList() {
        return functionList;
    }

    public void setFunctionList(List<Function> functionList) {
        this.functionList = functionList;
    }

    public void addFucntionList(List<Function> functionList) {
        this.functionList.addAll(functionList);
    }
}
