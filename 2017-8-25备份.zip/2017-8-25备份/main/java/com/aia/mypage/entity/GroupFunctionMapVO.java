package com.aia.mypage.entity;

import java.io.Serializable;

public class GroupFunctionMapVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7090554749219210890L;

	

	public GroupFunctionMapVO(String groupId, String functionId, String functionName) {
		super();
		this.groupId = groupId;
		this.functionId = functionId;
		this.functionName = functionName;

	}
	
	private String groupId;

	private String functionId;

	private String functionName;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

}
