package com.aia.mypage.entity;

import java.io.Serializable;

public class AdminGroupInfo implements Serializable {
    
    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 4444865498150338860L;

    private String groupId;
 
    private String groupName;

    private String groupDesc;
    
    public AdminGroupInfo(String groupId, String groupName, String groupDesc) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.groupDesc = groupDesc;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }
    
}
