package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AdminUserAdminGroupInfo implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 9159618031967969260L;

    private String userId;

    private String name;

    private String department;
    
    private String telephone;
    
    private String email;

    private List<AdminGroup> adminGroupList = new ArrayList<AdminGroup>();

    public AdminUserAdminGroupInfo() {
    }

    public AdminUserAdminGroupInfo(String userId, String name, String telephone,String email, String department, String groupId, String groupName) {
        this.userId = userId;
        this.name = name;
        this.telephone = telephone;
        this.email = email;
        this.department = department;
        AdminGroup adminGroup = new AdminGroup(groupId, groupName);
        this.adminGroupList.add(adminGroup);
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    
    

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<AdminGroup> getAdminGroupList() {
        return adminGroupList;
    }

    public void setAdminGroupList(List<AdminGroup> adminGroupList) {
        this.adminGroupList = adminGroupList;
    }
    
    public void addAdminGroupList(List<AdminGroup> adminGroupList){
        this.adminGroupList.addAll(adminGroupList);
    }

}
