package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "T_ADMIN_USER")
@Entity
public class AdminUser implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 3238772071521697863L;

    /** user_id. */
    @Id
    @Column(name = "user_id")
    private String userId;

    /** name. */
    @Column(name = "name")
    private String name;

    /** telephone. */
    @Column(name = "telephone")
    private String telephone;

    /** email. */
    @Column(name = "email")
    private String email;

    /** department. */
    @Column(name = "department")
    private String department;

    /** status. */
    @Column(name = "status")
    private String status;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** create_time. */
    @Column(name = "update_time")
    private Date updateTime;

    /**
     * Constructor.
     */
    public AdminUser() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
