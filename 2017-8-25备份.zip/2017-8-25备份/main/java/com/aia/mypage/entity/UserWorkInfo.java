package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

public class UserWorkInfo implements Serializable {

    private static final long serialVersionUID = -4620350096891879437L;

    private int accountId;

    private String accountName;

    private String isEnabled;

    private Date enabledTime;

    private Date lastFailedTime;

    private String firstName;

    private String isLocked;

    private String lockedType;

    public UserWorkInfo(int accountId, String accountName, String firstName, String isEnabled, Date enabledTime,
            Date lastFailedTime, String isLocked, String lockedType) {
        super();
        this.accountId = accountId;
        this.accountName = accountName;
        this.firstName = firstName;
        this.isEnabled = isEnabled;
        this.enabledTime = enabledTime;
        this.lastFailedTime = lastFailedTime;
        this.isLocked = isLocked;
        this.lockedType = lockedType;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(String isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Date getEnabledTime() {
        return enabledTime;
    }

    public void setEnabledTime(Date enabledTime) {
        this.enabledTime = enabledTime;
    }

    public Date getLastFailedTime() {
        return lastFailedTime;
    }

    public void setLastFailedTime(Date lastFailedTime) {
        this.lastFailedTime = lastFailedTime;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(String isLocked) {
        this.isLocked = isLocked;
    }

    public String getLockedType() {
        return lockedType;
    }

    public void setLockedType(String lockedType) {
        this.lockedType = lockedType;
    }

}
