package com.aia.mypage.util.captcha;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class DateUtil {

    public static final String yyMMddHHmm = "yyyyMMddHHmm";

    public static final String yyyyMMdd = "yyyyMMdd";

    public static final String yyMMddHHmmss = "yyyy/MM/dd HH:mm:ss";

    public static final String yy_MM_ddHHmmss = "yyyy-MM-dd HH:mm:ss";
    public static final String yyMMdd = "yyyy-MM-dd";
    public static final String yyyymmdd = "yyyy-MM-dd";

    public static final String dd_MM_yyyy = "dd-MM-yyyy";
    public static final String MMddyyyy = "MMddyyyy";
    public static final int JULIAN_DATE_LENGTH = 5;
    public static final String ddMMyyyyhhmmssa = "dd/MM/yyyy HH:mm:ss a";
    public static final String ddMMyyyy = "ddMMyyyy";

    public static String formatDate(String pattern) {
        SimpleDateFormat sd = new SimpleDateFormat(pattern);
        return sd.format(new Date());
    }

    public static String formatDate(String pattern, Date date) {
        if (date == null) {
            return null;
        } else {
            SimpleDateFormat sd = new SimpleDateFormat(pattern);
            return sd.format(date);
        }
    }

    public static Date parseStr2Date(String str, String pattern) throws ParseException {
        if (StringUtils.isEmpty(str))
            return null;
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.parse(str);
    }

    public static String pad(char padChar, String string, int padTo, boolean padRight) {
        StringBuffer buffer = padRight ? new StringBuffer(string) : new StringBuffer(string).reverse();
        for (int x = 0; x < padTo - string.length(); x++) {
            buffer.append(padChar);
        }
        return padRight ? buffer.toString() : buffer.reverse().toString();
    }

    public static String threeDigitsDate2Julian(String threeDigitsDate) {
        if (StringUtils.isBlank(threeDigitsDate) || threeDigitsDate.length() > 3) {
            return "";
        }
        long valueOf1Char = 0;
        long valueOf2Char = 0;
        long valueOf3Char = 0;
        long valueofAChar = (long) 'A';
        long valueofaChar = (long) 'a';
        valueOf1Char = (long) threeDigitsDate.charAt(0);
        valueOf2Char = (long) threeDigitsDate.charAt(1);
        valueOf3Char = (long) threeDigitsDate.charAt(2);
        valueOf1Char = valueOf1Char >= valueofaChar ? valueOf1Char - valueofaChar + 26 : valueOf1Char - valueofAChar;
        valueOf2Char = valueOf2Char >= valueofaChar ? valueOf2Char - valueofaChar + 26 : valueOf2Char - valueofAChar;
        valueOf3Char = valueOf3Char >= valueofaChar ? valueOf3Char - valueofaChar + 26 : valueOf3Char - valueofAChar;
        long resultLong = valueOf1Char * 52 * 52 + valueOf2Char * 52 + valueOf3Char;
        String result = Long.toString(resultLong);
        int startPos = result.length() - JULIAN_DATE_LENGTH;
        if (startPos < 0) {
            startPos = 0;
        }
        return pad('0', result.substring(startPos), JULIAN_DATE_LENGTH, false);
    }

    public static String threeDigitsDate2DateStr(String threeDigitsDate) {
        String fiveDigitsDate = threeDigitsDate2Julian(threeDigitsDate);
        if (fiveDigitsDate == null || fiveDigitsDate.length() < 5) {
            return null;
        }

        String yearStr = "20" + fiveDigitsDate.substring(0, 2);
        String dayOfYearStr = fiveDigitsDate.substring(2, 5);
        int year = Integer.parseInt(yearStr);
        int dayOfYear = Integer.parseInt(dayOfYearStr);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.DAY_OF_YEAR, dayOfYear);

        DateFormat df = new SimpleDateFormat(MMddyyyy);
        return df.format(calendar.getTime());
    }

    public static java.util.Date toDate(java.sql.Timestamp timestamp) {
        long milliseconds = timestamp.getTime() + (timestamp.getNanos() / 1000000);
        return new java.util.Date(milliseconds);
    }

    public static int differentDaysByMillisecond(String date1Str, String date2Str, String pattern)
            throws ParseException {

        DateFormat df = new SimpleDateFormat(pattern);
        Date date1 = df.parse(date1Str);
        Date date2 = df.parse(date2Str);

        int days = (int) ((date2.getTime() - date1.getTime()) / (1000 * 3600 * 24));

        return days;
    }

    public static void main(String[] args) throws Exception {
        // System.out.println(differentDaysByMillisecond("20170519", "20170645",
        // DateUtil.yyyyMMdd));
        java.util.Date date = new java.util.Date();
        System.out.println((new java.sql.Date(date.getTime())));
        System.out.println(new java.sql.Time(date.getTime()));
        System.out.println(new java.sql.Timestamp(date.getTime()));
    }

}
