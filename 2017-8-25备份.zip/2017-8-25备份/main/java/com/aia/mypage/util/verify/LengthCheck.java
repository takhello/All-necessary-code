package com.aia.mypage.util.verify;

public class LengthCheck implements VerifyStrategy {

	@Override
	public boolean paramVerify(String[] paramArray) {

		for (String param : paramArray) {

			if (param.length() >= MAX_LENGTH) {

				return false;
			}
		}

		return true;
	}

	private static final int MAX_LENGTH = 5;

}
