package com.aia.mypage.util.schedule;

import java.text.ParseException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.CronTrigger;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.ConfigDAO;
import com.aia.mypage.dao.ConfigVersionDAO;
import com.aia.mypage.entity.Config;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.framework.MypageFilterInvocationSecurityMetadataSource;
import com.aia.mypage.service.impl.UserFunctionServiceImpl;
import com.aia.mypage.service.impl.UserRoleServiceImpl;

public class SchedulerTask {

    private static final Log LOG = LogFactory.getLog(SchedulerTask.class);

    @Autowired
    @Qualifier("trigger-reloadRolePermission")
    private CronTrigger cronTrigger;

    @Autowired
    @Qualifier("registerQuartz")
    private Scheduler scheduler;

    @Autowired
    @Qualifier("userRoleService")
    private UserRoleServiceImpl userRoleServiceImpl;
    
    @Autowired
    @Qualifier("userFunctionService")
    private UserFunctionServiceImpl userFunctionServiceImpl;

    @Autowired
    @Qualifier("configDAOImpl")
    private ConfigDAO configDAO;

    @Autowired
    @Qualifier("configVersionDAOImpl")
    private ConfigVersionDAO configVersionDAO;

    @Autowired
    @Qualifier("securityMetadataSource")
    private MypageFilterInvocationSecurityMetadataSource metadataSource;

    public void initial() throws ParseException, SchedulerException {

        System.setProperty("org.terracotta.quartz.skipUpdateCheck", "true");
        LOG.info("successfully invoked initial method In SchedulerTask...");
        checkScheduleTime();
    }

    public static final String ADMIN_RELOAD_TIME = "ADMIN_RELOAD_TIME";
    public static int ORIGINAL_VERSION = 0;

    private void checkScheduleTime() throws ParseException, SchedulerException {

        Config scheduleTimeCro = configDAO.queryByKey(ADMIN_RELOAD_TIME);
        String scheduleTime = scheduleTimeCro.getValue();
        if (scheduleTime != null && !"".equals(scheduleTime)) {
            String oriCronExpression = cronTrigger.getCronExpression();
            if (!oriCronExpression.equals(scheduleTime)) {
                cronTrigger.setCronExpression(scheduleTime);
                scheduler.rescheduleJob("trigger-reloadRolePermission", Scheduler.DEFAULT_GROUP, cronTrigger);
                LOG.info("Successfully update cronExpression from " + oriCronExpression + " to " + scheduleTime);
            }
        }

    }

    public void reloadRolePermission() throws Exception {

    	List<ConfigVersion> versionList = configVersionDAO.getConfigVersionList();
    	if(versionList == null || versionList.size() <= 0){
    		return;
    	}
        int versionId = versionList.get(0).getVersionId();

        if (ORIGINAL_VERSION != versionId) {
            System.out.println("start reload role permission list...");
            ORIGINAL_VERSION = versionId;
            userRoleServiceImpl.initGroupRoleMap();
            userFunctionServiceImpl.initGroupFunctionMap();
            metadataSource.initRequestMap();
            System.out.println("start reload role permission list. end..");
        }

    }

}
