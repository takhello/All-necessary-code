package com.aia.mypage.util.captcha;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class StringUtil {

    public static boolean isEmptyOrWhitespace(String str) {
        if (str == null)
            return true;
        if ("".equals(str.trim()))
            return true;
        return false;
    }

    /*
     * public static List stringToList(String tags, String ch){ if(tags==null)
     * return null; ArrayList tagList = new ArrayList(); StringTokenizer st =
     * new StringTokenizer(tags, ch); while(st.hasMoreElements()){
     * tagList.add(st.nextToken()); } return tagList; }
     */

    public static List stringToList(String tags, String ch) {
        if (tags == null || tags.equals(""))
            return null;
        ArrayList list = new ArrayList();
        String[] str = tags.split(ch);

        for (int i = 0; i < str.length; i++) {
            list.add(str[i]);
        }

        return list;
    }

    public static List<String> toStringList(String tags, String ch) {
        if (tags == null || tags.equals(""))
            return null;
        ArrayList<String> list = new ArrayList<String>();
        String[] str = tags.split(ch);

        for (int i = 0; i < str.length; i++) {
            list.add(str[i]);
        }

        return list;
    }

    public static String formateFloat(float number) {
        DecimalFormat fnum = new DecimalFormat("##0.00");
        String dd = fnum.format(number);
        return dd;
    }

    public static String subStr(String str, int n) {
        if (str == null)
            return "";

        str = str.trim();

        if (str.length() < n) {
            n = str.length();
        }

        String b = str.substring(str.length() - n, str.length());
        return b;
    }

    public static String FormatObjectToString(Object o) {
        if (o == null || "null".equals(o.toString())) {
            return "";
        } else {
            return (String) o;
        }

    }

    public static String formatValue(String value) {
        if (StringUtils.isBlank(value) || "0".equals(value.trim())) {
            return "0.00";
        }

        return value;
    }

    public static void main(String args[]) {
        // System.out.println("aaa..." + subStr(str,3));
        System.out.println(FormatObjectToString(new Object()));

    }
}
