package com.aia.mypage.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.aia.mypage.dao.AccountUserDAO;
import com.aia.mypage.dao.AdminUserAUDAO;
import com.aia.mypage.dao.AdminUserInfoDAO;
import com.aia.mypage.dao.UserDAO;
import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.service.impl.AdminUserServiceImpl;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AdminUserServiceTest {

    @Mock
    private AdminUserInfoDAO mockAdminUserInfoDAO;

    @Mock
    private AccountUserDAO mockAccountUserDAO;

    @Mock
    private UserDAO mockUserDAO;

    @Mock
    private AdminUserAUDAO mockAdminUserAUDAO;

    @InjectMocks
    private AdminUserServiceImpl mockAdminUserServiceImpl = new AdminUserServiceImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAdminUserListByAccountName() {

        Mockito.when(mockAdminUserInfoDAO.getAdminUserListByAccountName(Mockito.any(AdminUserInfo.class)))
                .thenReturn(null);
        AdminUserInfo adminUserInfo = new AdminUserInfo();
        adminUserInfo.setFirstName("firstName");
        List<AdminUserInfo> list = mockAdminUserServiceImpl.getAdminUserListByAccountName(adminUserInfo);
        Assert.assertEquals(list, null);
    }

    @Test
    public void testGetAccountUserByAccountName() {

        Mockito.when(mockAccountUserDAO.getAccountUserByAccountName(Mockito.anyString())).thenReturn(null);
        AccountUserInfo accountUserInfo = mockAdminUserServiceImpl.getAccountUserByAccountName("accountName");
        Assert.assertEquals(accountUserInfo, null);
    }

    @Test
    public void testAddAdminUserNullUser() {

//        Mockito.when(mockUserDAO.getUserById(Mockito.anyInt())).thenReturn(null);
//        AdminUser addAdminUser = mockAdminUserServiceImpl.addAdminUser("11");
//        Assert.assertEquals(addAdminUser, null);
    }

    @Test
    public void testAddAdminUser() {

//        User mockUser = new User();
//        mockUser.setUserId(111);
//        Mockito.when(mockUserDAO.getUserById(Mockito.anyInt())).thenReturn(mockUser);
//        Mockito.when(mockAdminUserAUDAO.addAdminUser(Mockito.any(AdminUser.class))).thenReturn(null);
//        AdminUser addAdminUser = mockAdminUserServiceImpl.addAdminUser("11");
//        Assert.assertEquals(addAdminUser, null);
    }

    @Test
    public void testUpdateAdmin() {

        Mockito.when(mockAdminUserAUDAO.updateAdmin(Mockito.any(AdminUser.class))).thenReturn(1);
        AdminUser mockAdminUser = new AdminUser();
        boolean result = mockAdminUserServiceImpl.updateAdmin(mockAdminUser);
        Assert.assertEquals(result, true);
    }

    @Test
    public void testUpdateAdmin0() {

        Mockito.when(mockAdminUserAUDAO.updateAdmin(Mockito.any(AdminUser.class))).thenReturn(0);
        AdminUser mockAdminUser = new AdminUser();
        boolean result = mockAdminUserServiceImpl.updateAdmin(mockAdminUser);
        Assert.assertEquals(result, false);
    }

    @Test
    public void testDeleteAdminByUserId() {

//        Mockito.when(mockAdminUserAUDAO.deleteAdminByUserId(Mockito.anyInt())).thenReturn(true);
//        boolean result = mockAdminUserServiceImpl.deleteAdminByUserId(1);
//        Assert.assertEquals(result, true);
    }

    @Test
    public void testGetAdminProfile() {

        Mockito.when(mockAdminUserInfoDAO.getAdminProfile(Mockito.anyString())).thenReturn(null);
        String mockAccountName = "111";
        AdminUserInfo adminProfile = mockAdminUserServiceImpl.getAdminProfile(mockAccountName);
        Assert.assertEquals(adminProfile, null);
    }

    @Test
    public void testGetAdminUserByUserId() {

//        Mockito.when(mockAdminUserAUDAO.getAdminUserByUserId(Mockito.anyInt())).thenReturn(null);
//        AdminUser adminUser = mockAdminUserServiceImpl.getAdminUserByUserId(1);
//        Assert.assertEquals(adminUser, null);
    }
}
