package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.JSONMessage;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.UserGroupService;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class GroupControllerTest {

    private MockMvc mockMvc;

    @Mock
    private GroupService mockGroupService;

    @Mock
    private UserGroupService mockUserGroupService;

    @Mock
    private GroupRoleService mockGroupRoleService;

    @InjectMocks
    private GroupController mockGroupController;

    private Map<String, Object> errorjsonMap;

    private Map<String, Object> successjsonMap;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockGroupController).build();
    }

    @Test
    public void testGetGroupsList() throws Exception {
        List<Group> mockGroupsList = new ArrayList<Group>();
        Group mockGroup = new Group();
        mockGroup.setCreateTime(new Date());
        mockGroupsList.add(mockGroup);
        Mockito.when(mockGroupService.getGroupsList(Mockito.any(Group.class))).thenReturn(mockGroupsList);
        // @formatter:off  
        mockMvc
            .perform(
                get("/admin/groups")
            )
            .andExpect(status().isOk());
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupName() throws Exception {
        errorJson();
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(errorjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupName"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupName0() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupName"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupDesc() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("groupName", "groupName");
        data.put("groupDesc", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupDesc0() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("groupName", "groupName");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupDesc"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupStatus() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("groupName", "groupName");
        data.put("groupDesc", "groupDesc");
        data.put("groupStatus", "");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupStatus"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupNullGroupStatus0() throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("groupName", "groupName");
        data.put("groupDesc", "groupDesc");
        map.put("data", data);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(map))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupStatus"))));
        // @formatter:on
    }

    @Test
    public void testAddGroupSuccess() throws Exception {
        successJson();
        Mockito.when(mockGroupService.addGroup(Mockito.any(Group.class))).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                post("/admin/group")
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupIsDefault() throws Exception {
        Group mockGroup = new Group();
        mockGroup.setIsDefault("Y");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group/{group_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("group"))));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupNull() throws Exception {
        Group mockGroup = new Group();
        mockGroup.setIsDefault("Y");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group/{group_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupGroupRoleMapping() throws Exception {
        Group mockGroup = new Group();
        mockGroup.setIsDefault("N");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        List<GroupRole> groupRoleList = new ArrayList<GroupRole>();
        GroupRole groupRole = new GroupRole();
        groupRoleList.add(groupRole);
        Mockito.when(mockGroupRoleService.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(groupRoleList);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group/{group_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_ROLE_MAPPING)));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupUserGroupMapping() throws Exception {
        Group mockGroup = new Group();
        mockGroup.setIsDefault("N");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        List<GroupRole> groupRoleList = new ArrayList<GroupRole>();
        Mockito.when(mockGroupRoleService.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(groupRoleList);
        List<UserGroup> userGroupList = new ArrayList<UserGroup>();
        UserGroup userGroup = new UserGroup();
        userGroupList.add(userGroup);
        Mockito.when(mockUserGroupService.getUserGroupByGroupId(Mockito.anyString())).thenReturn(userGroupList);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group/{group_id}",1)
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.USER_GROUP_MAPPING)));
        // @formatter:on
    }

    @Test
    public void testDeleteGroupSuccess() throws Exception {
        Group mockGroup = new Group();
        mockGroup.setIsDefault("N");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        List<GroupRole> groupRoleList = new ArrayList<GroupRole>();
        Mockito.when(mockGroupRoleService.getGroupRoleListByGroupId(Mockito.anyString())).thenReturn(groupRoleList);
        List<UserGroup> userGroupList = new ArrayList<UserGroup>();
        Mockito.when(mockUserGroupService.getUserGroupByGroupId(Mockito.anyString())).thenReturn(userGroupList);
        Mockito.when(mockGroupService.deleteGroupById(Mockito.anyString())).thenReturn(true);
        // @formatter:off  
        mockMvc
            .perform(
                delete("/admin/group/{group_id}",1)
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testUpdateGroupSuccess() throws Exception {
        successJson();
        Group mockGroup = new Group();
        mockGroup.setCreateTime(new Date());
        mockGroup.setIsDefault("N");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Mockito.when(mockGroupService.updateGroupById(Mockito.any(Group.class))).thenReturn(mockGroup);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/group/{group_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.message", equalTo("Successfully processed.")));
        // @formatter:on
    }

    @Test
    public void testUpdateGroupNull() throws Exception {
        successJson();
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/group/{group_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_UNREGISTERED)));
        // @formatter:on
    }

    @Test
    public void testUpdateGroupIsDefault() throws Exception {
        successJson();
        Group mockGroup = new Group();
        mockGroup.setCreateTime(new Date());
        mockGroup.setIsDefault("Y");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/group/{group_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(successjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(isDefault("group"))));
        // @formatter:on
    }

    @Test
    public void testUpdateGroupError() throws Exception {
        errorJson();
        Group mockGroup = new Group();
        mockGroup.setCreateTime(new Date());
        mockGroup.setIsDefault("N");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Mockito.when(mockGroupService.updateGroupById(Mockito.any(Group.class))).thenReturn(mockGroup);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/group/{group_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(errorjsonMap))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupName"))));
        // @formatter:on
    }

    @Test
    public void testUpdateGroupError01() throws Exception {
        Map<Object, Object> data = new LinkedHashMap<Object, Object>();
        JSONMessage jsonMessage = new JSONMessage();
        jsonMessage.setData(data);
        Group mockGroup = new Group();
        mockGroup.setCreateTime(new Date());
        mockGroup.setIsDefault("n");
        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
        Mockito.when(mockGroupService.updateGroupById(Mockito.any(Group.class))).thenReturn(mockGroup);
        // @formatter:off  
        mockMvc
            .perform(
                put("/admin/group/{group_id}",1)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .content(JSONObject.toJSONString(jsonMessage))
            )
            .andExpect(status().is(550))
            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupName"))));
        // @formatter:on
    }

    public void errorJson() {
        errorjsonMap = new LinkedHashMap<String, Object>();
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("groupId", "");
        data.put("groupName", "");
        data.put("groupDesc", "");
        data.put("groupStatus", "");
        data.put("isDefault", "");
        errorjsonMap.put("data", data);
    }

    public void successJson() {
        successjsonMap = new LinkedHashMap<String, Object>();
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("groupId", "111");
        data.put("groupName", "groupName");
        data.put("groupDesc", "groupDesc");
        data.put("groupStatus", "groupStatus");
        data.put("isDefault", "isDefault");
        successjsonMap.put("data", data);
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
