package com.aia.mypage.rest.controller;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.User;
import com.aia.mypage.entity.UserGroup;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.UserGroupService;
import com.aia.mypage.service.UserService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;
import com.alibaba.fastjson.JSONObject;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/test/resources/applicationContext-test.xml",
        "file:src/main/resources/spring_config/spring-mvc.xml" })
@WebAppConfiguration
public class AdminUserGroupControllerTest {

    private MockMvc mockMvc;

    @Mock
    private UserGroupService mockUserGroupService;

    @Mock
    private UserService mockUserService;

    @Mock
    private GroupService mockGroupService;

    @InjectMocks
    private AdminUserGroupController mockUserGroupController;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mockUserGroupController).build();
    }

    @Test
    public void testGetAdminUsers() throws Exception {
//        Mockito.when(mockUserGroupService.getAdminUserGroupListByAdminUserId(Mockito.anyInt())).thenReturn(null);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                get("/admin/admin_user_groups")
//                .param("adminUserId","111")
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    @Test
    public void testGetAdminUsersNoUserId() throws Exception {
//        // @formatter:off  
//        mockMvc
//            .perform(
//                get("/admin/admin_user_groups")
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testGetAdminUsersNullUserId() throws Exception {
//        // @formatter:off  
//        mockMvc
//            .perform(
//                get("/admin/admin_user_groups")
//                .param("adminUserId","")
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNoUserId() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        jsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNullUserId() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "");
//        jsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("userId"))));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNullGroupId() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        jsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupId"))));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNoGroupId() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        data.put("groupId", "");
//        jsonMap.put("data", data);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(paramRequired("groupId"))));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNoUser() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        data.put("groupId", "222");
//        jsonMap.put("data", data);
//        Mockito.when(mockUserService.getUserById(Mockito.anyInt())).thenReturn(null);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.USER_UNREGISTERED)));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupNoGroup() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        data.put("groupId", "222");
//        jsonMap.put("data", data);
//        User mockUser = new User();
//        mockUser.setUserId(124);
//        Mockito.when(mockUserService.getUserById(Mockito.anyInt())).thenReturn(mockUser);
//        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(null);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.GROUP_UNREGISTERED)));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupFalse() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        data.put("groupId", "222");
//        jsonMap.put("data", data);
//        User mockUser = new User();
//        mockUser.setUserId(124);
//        Mockito.when(mockUserService.getUserById(Mockito.anyInt())).thenReturn(mockUser);
//        Group mockGroup = new Group();
//        mockGroup.setGroupId("222");
//        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
//        UserGroup mockUserGroup = new UserGroup();
//        Mockito.when(mockUserGroupService.getSameUserGroup(Mockito.anyInt(), Mockito.anyString()))
//                .thenReturn(mockUserGroup);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(ErrorMessageUtil.USER_GROUP_REGISTERED)));
//        // @formatter:on
    }

    @Test
    public void testAddUserGroupSuccess() throws Exception {
//        Map<String, Object> jsonMap = new HashMap<String, Object>();
//        Map<String, Object> data = new HashMap<String, Object>();
//        data.put("userId", "124");
//        data.put("groupId", "222");
//        jsonMap.put("data", data);
//        User mockUser = new User();
//        mockUser.setUserId(124);
//        Mockito.when(mockUserService.getUserById(Mockito.anyInt())).thenReturn(mockUser);
//        Group mockGroup = new Group();
//        mockGroup.setGroupId("222");
//        Mockito.when(mockGroupService.getGroupById(Mockito.anyString())).thenReturn(mockGroup);
//        Mockito.when(mockUserGroupService.getSameUserGroup(Mockito.anyInt(), Mockito.anyString())).thenReturn(null);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                post("/admin/admin_user_group")
//                    .contentType(MediaType.APPLICATION_JSON)
//                    .accept(MediaType.APPLICATION_JSON)
//                    .content(JSONObject.toJSONString(jsonMap))
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    @Test
    public void testDeleteUserGroupIsDefault() throws Exception {
//        UserGroup mockUserGroup = new UserGroup();
//        mockUserGroup.setIsDefault("Y");
//        Mockito.when(mockUserGroupService.getUserGroupById(Mockito.anyInt())).thenReturn(mockUserGroup);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                delete("/admin/admin_user_group/7")
//            )
//            .andExpect(status().is(550))
//            .andExpect(jsonPath("$.message", equalTo(isDefault("user_group"))));
//        // @formatter:on
    }

    @Test
    public void testDeleteUserGroupSuccess() throws Exception {
//        UserGroup mockUserGroup = new UserGroup();
//        mockUserGroup.setIsDefault("N");
//        Mockito.when(mockUserGroupService.getUserGroupById(Mockito.anyInt())).thenReturn(mockUserGroup);
//        Mockito.when(mockUserGroupService.deleteUserGroupById(Mockito.anyInt())).thenReturn(true);
//        // @formatter:off  
//        mockMvc
//            .perform(
//                delete("/admin/admin_user_group/7")
//            )
//            .andExpect(status().isOk())
//            .andExpect(jsonPath("$.message", equalTo(BaseUtil.SUCCESS_MESSAGE)));
//        // @formatter:on
    }

    public String paramRequired(String param) {
        BaseController baseController = new BaseController();
        String paramRequired = baseController.paramRequired(param);
        return paramRequired;
    }

    public String isDefault(String isDefault) {
        BaseController baseController = new BaseController();
        String default1 = baseController.isDefault(isDefault);
        return default1;
    }
}
