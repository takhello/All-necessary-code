'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupEditController', function() {
		var scope, modalInstance, controller, groupService;
		beforeEach(inject(function($rootScope, $controller, GroupService) {
			groupService = GroupService;
			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('GroupEditController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupService: groupService,
				groupData: {
					"groupId": "1",
					"groupName": "Group1",
					"groupDesc": "Group1 Desc",
					"groupStatus": "Y",
					"isDefault": "Y",
					"createTime": "",
					"updateTime": ""

				},
				editGroupIdItem: '123'
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});
		});

		describe('Test callback function', function() {
			it('test:close error message callback function', function() {
				controller.closeError();
				expect(controller.isAlertHide).toBe(true);
			});
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about edit Group', function() {
			beforeEach(inject(function() {
				spyOn(groupService, 'editGroup');
			}));
			it('should confirm save edit Group data', function() {
				controller.editGroupConfirm();
				expect(groupService.editGroup).toHaveBeenCalled();
			});
			it('should cancel edit Group data', function() {
				controller.editGroupCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});

	});


});