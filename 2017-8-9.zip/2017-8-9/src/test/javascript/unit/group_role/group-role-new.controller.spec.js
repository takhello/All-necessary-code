'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('GroupRoleAddController', function() {
		var scope, modalInstance, controller, groupToRoleService,state;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, GroupToRoleService,$state) {
			groupToRoleService = GroupToRoleService;
			scope = $rootScope.$new();
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('GroupRoleAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				GroupToRoleService: groupToRoleService,
				groupId:"111",
				roleId:"222"
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('Test callback function', function() {
			beforeEach(inject(function(){
				spyOn(state,'reload');
				spyOn(groupToRoleService,'newGroupRole');
			}));
			it('should dismiss the modal with the result "false" when rejected', function() {
				controller.addGroupRoleCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test:Callback', function() {
				controller.callback();
				expect(state.reload).toHaveBeenCalledWith('home.group.group-role');
			});
			it('groupToRoleService:newGroupRole',function(){
				controller.addGroupRoleConfirm();
				expect(groupToRoleService.newGroupRole).toHaveBeenCalled();
			});
		});

	});


});