'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:PermissionService service', function() {
		var $resource, PermissionService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_PermissionService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			PermissionService = _PermissionService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test PermissionService newPermission',function(){
			spyOn(PermissionService,'newPermission').and.callThrough();
			PermissionService.newPermission({},function(){},function(){});
			expect(PermissionService.newPermission).toHaveBeenCalled();
		});
		it('test PermissionService deletePermission',function(){
			spyOn(PermissionService,'deletePermission').and.callThrough();
			PermissionService.deletePermission('123',function(){},function(){});
			expect(PermissionService.deletePermission).toHaveBeenCalled();
		});
		it('tset PermissionService editPermission',function(){
			spyOn(PermissionService,'editPermission').and.callThrough();
			PermissionService.editPermission('123',function(){},function(){});
			expect(PermissionService.editPermission).toHaveBeenCalled();
		});
		it('test PermissionService getPermission',function(){
			spyOn(PermissionService,'getPermission').and.callThrough();
			PermissionService.getPermission({},function(){},function(){});
			expect(PermissionService.getPermission).toHaveBeenCalled();
		});
	});
});