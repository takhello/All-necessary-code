'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:GroupToRoleService service', function() {
		var $resource, GroupToRoleService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_GroupToRoleService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			GroupToRoleService = _GroupToRoleService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test GroupToRoleService newGroupRole',function(){
			spyOn(GroupToRoleService,'newGroupRole').and.callThrough();
			GroupToRoleService.newGroupRole({},function(){},function(){});
			expect(GroupToRoleService.newGroupRole).toHaveBeenCalled();
		});
		it('test GroupToRoleService deleteGroupRole',function(){
			spyOn(GroupToRoleService,'deleteGroupRole').and.callThrough();
			GroupToRoleService.deleteGroupRole('123',function(){},function(){});
			expect(GroupToRoleService.deleteGroupRole).toHaveBeenCalled();
		});
		it('test GroupToRoleService getGroupRoleList',function(){
			spyOn(GroupToRoleService,'getGroupRoleList').and.callThrough();
			GroupToRoleService.getGroupRoleList();
			expect(GroupToRoleService.getGroupRoleList).toHaveBeenCalled();
		});
	});
});