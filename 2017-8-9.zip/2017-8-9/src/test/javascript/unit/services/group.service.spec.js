'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:GroupService service', function() {
		var $resource, GroupService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_GroupService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			GroupService = _GroupService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test GroupService newGroup',function(){
			spyOn(GroupService,'newGroup').and.callThrough();
			GroupService.newGroup({},function(){},function(){});
			expect(GroupService.newGroup).toHaveBeenCalled();
		});
		it('test GroupService deleteGroup',function(){
			spyOn(GroupService,'deleteGroup').and.callThrough();
			GroupService.deleteGroup('123',function(){},function(){});
			expect(GroupService.deleteGroup).toHaveBeenCalled();
		});
		it('tset GroupService editGroup',function(){
			spyOn(GroupService,'editGroup').and.callThrough();
			GroupService.editGroup('123',function(){},function(){});
			expect(GroupService.editGroup).toHaveBeenCalled();
		});
		it('test GroupService getGroupList',function(){
			spyOn(GroupService,'getGroupList').and.callThrough();
			GroupService.getGroupList({},function(){},function(){});
			expect(GroupService.getGroupList).toHaveBeenCalled();
		});
	});
});