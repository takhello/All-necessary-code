'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:AdminService service', function() {
		var $resource, AdminService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_,_AdminService_,_$rootScope_,_$httpBackend_){
			$resource = _$resource_;
			AdminService = _AdminService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test AdminService newAdmin',function(){
			spyOn(AdminService,'newAdmin').and.callThrough();
			AdminService.newAdmin({},function(){},function(){});
			expect(AdminService.newAdmin).toHaveBeenCalled();
		});
		it('test AdminService deleteAdmin',function(){
			spyOn(AdminService,'deleteAdmin').and.callThrough();
			AdminService.deleteAdmin('123',function(){},function(){});
			expect(AdminService.deleteAdmin).toHaveBeenCalled();
		});
		it('tset AdminService editAdmin',function(){
			spyOn(AdminService,'editAdmin').and.callThrough();
			AdminService.editAdmin('123',function(){},function(){});
			expect(AdminService.editAdmin).toHaveBeenCalled();
		});
		it('test AdminService getUserByAccountName',function(){
			spyOn(AdminService,'getUserByAccountName').and.callThrough();
			AdminService.getUserByAccountName({},function(){},function(){});
			expect(AdminService.getUserByAccountName).toHaveBeenCalled();
		});
		it('test AdminService getAdmin',function(){
			spyOn(AdminService,'getAdmin').and.callThrough();
			AdminService.getAdmin({},function(){},function(){});
			expect(AdminService.getAdmin).toHaveBeenCalled();
		});
	});
});