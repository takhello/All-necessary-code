'use strict';

describe('Evolve:adminManageApp services', function() {
	beforeEach(module('adminManageApp'));
	describe('Evolve:UserProfileService service', function() {
		var $resource, UserProfileService, scope, $httpBackend;
		beforeEach(module('adminManageApp'));
		beforeEach(inject(function(_$resource_, _UserProfileService_, _$rootScope_, _$httpBackend_) {
			$resource = _$resource_;
			UserProfileService = _UserProfileService_;
			scope = _$rootScope_;
			$httpBackend = _$httpBackend_;
		}));
		it('test UserProfileService getUserProfile', function() {
			spyOn(UserProfileService, 'getUserProfile').and.callThrough();
			UserProfileService.getUserProfile(function() {}, function() {});
			expect(UserProfileService.getUserProfile).toHaveBeenCalled();
		});
	});
});