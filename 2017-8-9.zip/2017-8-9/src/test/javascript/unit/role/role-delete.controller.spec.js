'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('RoleDeleteController', function() {
		var scope, modalInstance, controller, roleService, roleId, roleData;
		beforeEach(inject(function($rootScope, $controller, RoleService) {
			roleService = RoleService;
			roleId = "12345";
			roleData = {
				"roleId": "1",
				"roleName": "Role1",
				"roleDesc": "Role1 Desc",
				"roleStatus": "Y",
				"createTime": "",
				"updateTime": ""
			};

			scope = $rootScope.$new();
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('RoleDeleteController', {
				$scope: scope,
				$modalInstance: modalInstance,
				RoleService: roleService,
				roleId: roleId,
				roleData: roleData
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('test callback function', function() {
			it('successCallback', function() {
				controller.successCallback();
				expect(controller.isAlertHide).toBe(true);
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('failCallback', function() {
				controller.failCallback({
					data: {
						message: "",
						code: 550
					}
				});
				expect(controller.isAlertHide).toBe(false);
			});
		});

		describe('Two cases about delete role', function() {
			beforeEach(inject(function() {
				spyOn(roleService, 'deleteRole');
			}));
			it('should confirm save delete role data', function() {
				controller.deleteRoleConfirm();
				expect(roleService.deleteRole).toHaveBeenCalled();
			});
			it('should cancel delete role data', function() {
				controller.deleteRoleCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
		});
	});
});