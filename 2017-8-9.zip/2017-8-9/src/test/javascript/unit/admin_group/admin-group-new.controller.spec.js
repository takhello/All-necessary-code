'use strict';

describe('mypage-admin:controllers', function() {

	beforeEach(module('adminManageApp'));

	describe('AdminGroupAddController', function() {
		var scope, modalInstance, controller, adminToGroupService,state;
		//		beforeEach(module('adminManageApp'));
		beforeEach(inject(function($rootScope, $controller, AdminToGroupService,$state) {
			adminToGroupService = AdminToGroupService;
			scope = $rootScope.$new();
			state = $state;
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				ok: {
					then: jasmine.createSpy('modalInstance.result.then')
				}
			};

			controller = $controller('AdminGroupAddController', {
				$scope: scope,
				$modalInstance: modalInstance,
				AdminToGroupService: adminToGroupService,
				groupId:"111",
				adminId:"222"
			});
		}));

		describe('Initial state', function() {
			it('should instantiate the controller properly', function() {
				expect(controller).toBeDefined();
			});

		});

		describe('Test callback function', function() {
			beforeEach(inject(function(){
				spyOn(state,'reload');
				spyOn(adminToGroupService,'newAdminGroup');
			}));
			it('should dismiss the modal with the result "false" when rejected', function() {
				controller.addAdminGroupCancel();
				expect(modalInstance.dismiss).toHaveBeenCalledWith('cancel');
			});
			it('test:addSuccessCallback', function() {
				controller.addSuccessCallback();
				expect(state.reload).toHaveBeenCalledWith('home.admin.admin-group');
			});
			it('test:addFailCallback',function(){
				controller.addFailCallback();
				expect(state.reload).toHaveBeenCalledWith("home.admin.admin-group");
				expect(modalInstance.close).toHaveBeenCalledWith('cancel');
			});
			it('adminToGroupService:newAdminGroup',function(){
				controller.addAdminGroupConfirm();
				expect(adminToGroupService.newAdminGroup).toHaveBeenCalled();
			});
		});

	});


});