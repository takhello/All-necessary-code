(function() {
	"use strict";

	angular.module("adminManageApp").controller('UserFunctionController', UserFunctionController);
	UserFunctionController.$injector = ['$scope', 'UserManageAccessService', '$modal', '$modalInstance','getIdViewFunction'];

	function UserFunctionController($scope, UserManageAccessService, $modal, $modalInstance,getIdViewFunction) {
		var vm = this;

		vm.nullFunction = "No function is assigned";

		vm.addRoleCancel = addRoleCancel;
		vm.getIdFunction = getIdFunction;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		getIdFunction();

		function closeError(){
			vm.isAlertHide = true;
		}
		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}
		function getIdFunction() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"language": USER_LANGUAGE
			};
			UserManageAccessService.getIdFunction(getIdViewFunction,obj, vm.successCallback, vm.failCallback);
		}
		function successCallback(result) {
			vm.userIdFunction = result.data.functionList;
			vm.FunctionList = result.data.functionList;
			vm.checkedFunctionLevel = serializeData(result.data.functionList,"parentFunctionId","10","20","30","40");
		
			var functionNanes1 = arrayToHeavy(vm.checkedFunctionLevel.functionId1);
			var functionNanes2 = arrayToHeavy(vm.checkedFunctionLevel.functionId2);
			var functionNanes3 = arrayToHeavy(vm.checkedFunctionLevel.functionId3);
			var functionNanes4 = arrayToHeavy(vm.checkedFunctionLevel.functionId4);
			vm.functionList1 = arrayToObject(functionNanes1);
			vm.functionList2 = arrayToObject(functionNanes2);
			vm.functionList3 = arrayToObject(functionNanes3);
			vm.functionList4 = arrayToObject(functionNanes4);
			function serializeData(data,key,val1,val2,val3,val4){
				var obj ={
					_obj1:[],
					_obj2:[],
					_obj3:[],
					_obj4:[],
					functionId1:[],
					functionId2:[],
					functionId3:[],
					functionId4:[]
				};
				var index = 0;
				for (var i=0; i < data.length;  i++) {

					if(data[i][key] == val1){
						obj.functionId1.push(data[i].functionName);

						obj._obj1.push({functionName:data[i].functionName}); 
					}else if(data[i][key] == val2){
						obj.functionId2.push(data[i].functionName);

						obj._obj2.push({functionName:data[i].functionName});

					}else if(data[i][key] == val3){
						obj.functionId3.push(data[i].functionName);

						obj._obj3.push({functionName:data[i].functionName}); 
					}else if(data[i][key] == val4){
						obj.functionId4.push(data[i].functionName);

						obj._obj4.push({functionName:data[i].functionName}); 
					}
				}
				return obj;
			}

			function arrayToHeavy(arr){
				 var res = [];
				 var json = {};
				 for(var i = 0; i < arr.length; i++){
				  if(!json[arr[i]]){
				   res.push(arr[i]);
				   json[arr[i]] = 1;
				  }
				 }
				return res;
			}
			function arrayToObject(arr){
				 var res = [];
				 for(var i = 0; i < arr.length; i++){
				   res.push({functionName : arr[i]});
				 }
				return res;
			}

			vm.isAlertHide = true;
			// $modalInstance.close('cancel');
			 hiddenFunction();
		}

		function hiddenFunction(){
			$(".functionListHide").show();
			if( (JSON.stringify(vm.functionList1) === '[]') && (JSON.stringify(vm.functionList2) === '[]') && (JSON.stringify(vm.functionList3) === '[]') && (JSON.stringify(vm.functionList4) === '[]')){
				$(".functionList1").hide();
				$(".functionList2").hide();
				$(".functionList3").hide();
				$(".functionList4").hide();
				$(".functionList5").show();
			}
			if(JSON.stringify(vm.functionList1) === '[]'){
				$(".functionList1").hide();
			}
			 if(JSON.stringify(vm.functionList2) === '[]'){
				$(".functionList2").hide();
			}
			 if(JSON.stringify(vm.functionList3) === '[]'){
				$(".functionList3").hide();
			}
			 if(JSON.stringify(vm.functionList4) === '[]'){
				$(".functionList4").hide();
			}
		}

		function failCallback(error) {
			$(".viewShow").show();
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();