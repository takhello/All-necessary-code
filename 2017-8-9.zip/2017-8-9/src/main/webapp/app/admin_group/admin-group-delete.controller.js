(function(){
	"use strict";
	angular.module("adminManageApp").controller("AdminGroupDeleteController",AdminGroupDeleteController);
	AdminGroupDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'AdminToGroupService', '$state', 'adminGroupId'];
	function AdminGroupDeleteController($scope,$modal,$modalInstance,AdminToGroupService,$state,adminGroupId){
		var vm = this;
		vm.deleteAdminGroupCancel = deleteAdminGroupCancel;
		vm.deleteAdminGroupConfirm = deleteAdminGroupConfirm;
		vm.deleteSuccessCallback = deleteSuccessCallback;
		vm.deleteFailCallback = deleteFailCallback;
		function deleteAdminGroupCancel(){
			$modalInstance.dismiss('cancel');
		}
		function deleteAdminGroupConfirm(){
			$modalInstance.close('cancel');
			AdminToGroupService.deleteAdminGroup(adminGroupId,vm.deleteSuccessCallback,vm.deleteFailCallback);
		}
		function deleteSuccessCallback(result){
			$state.reload("home.admin.admin-group");
		}
		function deleteFailCallback(error){
			// alert(error.data.message);
			$modalInstance.close('cancel');
			$state.reload("home.admin.admin-group");
		}
	}
})();