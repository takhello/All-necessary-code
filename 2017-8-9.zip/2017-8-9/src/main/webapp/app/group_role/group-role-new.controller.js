(function() {
	"use strict";
	angular.module("adminManageApp").controller("GroupRoleAddController", GroupRoleAddController);
	GroupRoleAddController.$injector = ['$scope', '$modal', '$modalInstance', 'GroupToRoleService', 'groupId', 'roleId', '$state'];

	function GroupRoleAddController($scope, $modal, $modalInstance, GroupToRoleService, groupId, roleId, $state) {
		var vm = this;
		vm.addGroupRoleCancel = addGroupRoleCancel;
		vm.addGroupRoleConfirm = addGroupRoleConfirm;
		vm.callback = callback;

		function addGroupRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addGroupRoleConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"groupId": groupId,
					"roleId": roleId
				}
			};
			$modalInstance.close('cancel');
			GroupToRoleService.newGroupRole(obj, vm.callback, vm.callback);
		}

		function callback() {
			$state.reload("home.group.group-role");
		}
	}
})();