(function(){
	"use strict";
	angular.module("adminManageApp").service("GroupsFunctionsService",GroupsFunctionsService);
	GroupsFunctionsService.$injector = ['$resource'];
	function GroupsFunctionsService($resource){
		var _service = {
			createGroup:createGroup,
			editGroup:editGroup,
			getIdFunction:getIdFunction,
			getFunctionList:getFunctionList
		
		};
		return _service;

		//createGroup
		//
		function createGroup(params, onSuccess, onError) {
			var url = SERVICE_URL + "v1/admin/admin_group";
			// var url ="http://cangzdwcis01:8699/mypage-admin/v1/admin/admin_user";

			var _resources = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resources.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}

		//edit User service
		function editGroup(id, params, onSuccess, onError) {
			console.log(params);
			var url = SERVICE_URL + "v1/admin/admin_group/" + id;
			// /v1/admin/admin_group/{group_id}
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params,
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}

		function getIdFunction(id,params, onSuccess, onError) {
            var url = SERVICE_URL + "v1/admin/admin_group/" + id;
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
        }
        function getFunctionList(params, onSuccess, onError) {
            var url = SERVICE_URL + "v1/admin/functions";
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
        }

	}


})();