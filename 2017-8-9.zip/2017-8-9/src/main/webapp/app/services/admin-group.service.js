(function(){
	"use strict";
	angular.module("adminManageApp").service("AdminToGroupService",AdminToGroupService);
	AdminToGroupService.$injector = ['$resource'];
	function AdminToGroupService($resource){
		var services = {
			getAdminGroupList:getAdminGroupList,
			newAdminGroup:newAdminGroup,
			deleteAdminGroup:deleteAdminGroup
		};
		return services;
		function getAdminGroupList(id,onSuccess,onError){
			var url = SERVICE_URL + 'admin/admin_user_groups';
			var _resource = $resource(url, {
				"adminUserId": id
			},{
				get:{
					"method":"GET"
				}
			});
			return _resource.get(id).$promise.then(onSuccess,onError);
		}
		function newAdminGroup(params, onSuccess, onError){
			var url = SERVICE_URL + 'admin/admin_user_group';
			var _resource = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess, onError);
		}
		function deleteAdminGroup(adminUserId,onSuccess,onError){
			var url = SERVICE_URL + 'admin/admin_user_group/' + adminUserId;
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}
	}
})();