(function(){
	"use strict";
	angular.module("adminManageApp").service('GroupsManageAccessService',GroupsManageAccessService);
	GroupsManageAccessService.$injector = ['$resource'];
	function GroupsManageAccessService($resource){
        var services = {
            getGroupsManageList: getGroupsManageList,
            deleteGroup:deleteGroup
        };
        return services;
        //update role service
        function getGroupsManageList(params, onSuccess, onError) {
            var url = SERVICE_URL + "v1/admin/admin_groups";
            // var url = "http://localhost:8099/mypage-admin/v1/admin/admin_groups";
            var _resource = $resource(url, {}, {
                get: {
                    "method": "GET",
                    "data": params
                }
            });
            return _resource.get(params).$promise.then(onSuccess, onError);
        }
        function deleteGroup(id,onSuccess,onError){
            var url = SERVICE_URL + "v1/admin/admin_group/" + id;
            // /v1/admin/admin_group/{group_id}
            var _resource = $resource(url,{},{
                delete:{
                    "method":"DELETE"
                }
            });
            return _resource.delete().$promise.then(onSuccess,onError);
        }

		
	}
})();