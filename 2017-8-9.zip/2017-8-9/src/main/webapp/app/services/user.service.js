(function(){
	"use strict";
	angular.module("adminManageApp").service("UserProfileService",UserProfileService);
	UserProfileService.$injector = ['$resource'];
	function UserProfileService($resource){
		var _service = {
			getUserProfile:getUserProfile
		};
		return _service;
		function getUserProfile(onSuccess,onError){
			var url = SERVICE_URL + "admin/profile";
			var _resource = $resource(url,{},{
				get:{
					"method":"GET"
				}
			});
			return _resource.get().$promise.then(onSuccess,onError);
		}
	}
})();