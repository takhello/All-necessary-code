(function() {
	"use strict";
	angular.module("adminManageApp").controller("RolePermissionDeleteController", RolePermissionDeleteController);
	RolePermissionDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'RoleToPermissionService', 'rolePermissionId', '$state'];

	function RolePermissionDeleteController($scope, $modal, $modalInstance, RoleToPermissionService, rolePermissionId, $state) {
		var vm = this;
		vm.deleteRolePermissionCancel = deleteRolePermissionCancel;
		vm.deleteRolePermissionConfirm = deleteRolePermissionConfirm;
		vm.callBack = callBack;
		function deleteRolePermissionCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteRolePermissionConfirm() {
			$modalInstance.close('cancel');
			RoleToPermissionService.deleteRolePermission(rolePermissionId,vm.callBack,vm.callBack);
		}

		function callBack(){
			$state.reload("home.role.role-permission");
		}
	}
})();