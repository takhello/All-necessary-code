(function() {
	"use strict";
	angular.module("adminManageApp").controller("RolePermissionAddController", RolePermissionAddController);
	RolePermissionAddController.$injector = ['$scope', '$modal', '$modalInstance', 'RoleToPermissionService', 'roleId', 'permissionid', '$state'];

	function RolePermissionAddController($scope, $modal, $modalInstance, RoleToPermissionService, roleId, permissionid, $state) {
		var vm = this;
		vm.addRolePermissionCancel = addRolePermissionCancel;
		vm.addRolePermissionConfirm = addRolePermissionConfirm;
		vm.callBack = callBack;
		function addRolePermissionCancel() {
			$modalInstance.dismiss('cancel');
		}
		function addRolePermissionConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"roleId": roleId,
					"permissionId": permissionid
				}
			};
			$modalInstance.close('cancel');
			RoleToPermissionService.newRolePermission(obj, vm.callBack, vm.callBack);
		}
		function callBack(){
			$state.reload("home.role.role-permission");
		}
	}
})();