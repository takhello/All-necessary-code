(function() {
	"use strict";
	angular.module("adminManageApp").controller('EndOfDayController', EndOfDayController);
	EndOfDayController.$injector = ['$scope', '$modal', 'EndOfDayService', '$state'];

	function EndOfDayController($scope, $modal, EndOfDayService, $state) {
		var vm = this;
		vm.addGroup = addGroup;
		vm.deleteGroup = deleteGroup;
		vm.editGroup = editGroup;
		vm.getGroupList = getGroupList;
		vm.getGroupRoleList = getGroupRoleList;

		vm.successCallback = successCallback;

		//getGroupList();
		
		//Date picker
	    
		
		function getGroupRoleList(id) {		//id
			$state.go("home.maintenance.customer-details", {
				id: id
			});
		}

		function getGroupList() {
			var obj = {
				"groupName": vm.groupName,
				"groupDesc": vm.groupDesc,
				"groupStatus": vm.groupStatus
			};
			EndOfDayService.getGroupList(obj,vm.successCallback);
		}

		function successCallback(result) {
			vm.groups = result.data.groupList;
		}

		function addGroup() {
			var modalInstance = $modal.open({
				templateUrl: "app/group/group-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getGroupList);
		}

		function deleteGroup(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/group/group-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					groupId: function() {
						return id;
					},
					groupData: function() {
						return vm.groups;
					}

				}
			});
			modalInstance.result.then(getGroupList);
		}

		function editGroup(group) {
			var modalInstance = $modal.open({
				templateUrl: "app/group/group-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editGroupIdItem: function() {
						return group.groupId;
					},
					groupData: function() {
						return group;
					}
				}
			});
			modalInstance.result.then(getGroupList);

		}


	}
})();