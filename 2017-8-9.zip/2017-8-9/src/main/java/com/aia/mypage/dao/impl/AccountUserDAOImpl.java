package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AccountUserDAO;
import com.aia.mypage.entity.AccountUserInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AccountUserDAOImpl extends JPABaseRepImpl<AccountUserInfo> implements AccountUserDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public AccountUserInfo getAccountUserByAccountName(String accountName) {
        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.AccountUserInfo");
        sql.append(
                " (a.accountId, a.userId, a.accountName, a.accountType, a.email, a.isEnabled, a.registerType, a.picture)");
        sql.append(" from Account a, User user where a.userId=user.userId and lower(a.accountName)=:accountName ");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("accountName", accountName.toLowerCase());
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

}
