package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.Group;

public interface GroupDAO {

    List<Group> getGroupsList(Group group);

    Group addGroup(Group group);

    boolean deleteGroupById(String groupId);

    Group getGroupById(String groupId);

    Group updateGroup(Group group);

}
