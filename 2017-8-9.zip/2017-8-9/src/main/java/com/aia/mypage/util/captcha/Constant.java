package com.aia.mypage.util.captcha;

import java.math.BigDecimal;

public class Constant {
    private static EnvUtil res = EnvUtil.getInstance();
    // common
    public static final String NULL_STR = "null";
    public static final String SUCCESS_CODE = "0";
    public static final String FAIL_CODE = "1";
    public static final String FLAG_Y = "Y";
    public static final String FLAG_N = "N";

    // Registration
    public static final String STATUS_A = "A";
    public static final String STATUS_F = "F";
    public static final String STATUS_D = "D";
    public static final String STATUS_C = "C";
    public static final String BASE_CODE_SRCPRE = "data:image/jpg;base64,";
    public static final String REG_USER_LOCKED = "Y";
    public static final String REG_USER_UNLOCKED = "N";
    public static final String AUTHENTICATED = "authenticated";

    // E2EE
    public static final String REALMID_VALUE = res.getRealmId();
    public static final String LOGIN_MODULE_ID = res.getLoginModuleId();
    public static final String RETRIEVE_PRINCIPAL = "retrievePrincipal";
    public static final String RETRIEVE_PRINCIPAL_VALUE = res.getRetrievePrincipalValue();
    public static final String REALM_ID = "realmId";
    public static final String DEFAULT_SMS_OTP_POLICY = "DefaultSmsOtpPolicy";
    public static final String E2EE_PARAMS = "params";
    public static final String E2EE_PUBLIC_KEY = "pubKey";
    public static final String E2EE_SERVER_RANDOM = "serverRandom";
    public static final String E2EE_SESSION_ID = "e2eeSid";
    public static final String CREATEUSER_DESC_CUSTOMER_USER = "customer user";
    public static final String IVR_PIN = "IVRPin";
    public static final String PASSWORD_GENERATION_OPTION = "passwordGenerationOption";
    public static final String PWD_GENERATION_OPTION_MANUAL_ENTRY = "ManualEntry";
    public static final String SESSION = "session";
    public static final String SESSION_TOKEN = "sessionToken";
    public static final String SESSION_ID = "sessionId";
    public static final String RPIN = "rpin";
    public static final String GEN_IVR_PWD_ALPHA_NUMERICS = "0123456789";
    public static final String GEN_OTP_SENDERNAME = "SenderName";
    public static final String GEN_OTP_DEPTID = "DEPTID";
    public static final String GEN_OTP_USERIDENTITY = "USERIDENTITY";
    public static final String GEN_OTP_GROUPID = "GROUPID";
    public static final String GEN_OTP_OPTCDE = "OPTCDE";
    public static final String GEN_OTP_PHONENO = "PHONENO";
    public static final String GEN_OTP_EVENT_NOTIFICATION_POLICY_ID = "eventNotificationPolicyId";
    public static final String GEN_OTP_REAL_ACTOR_ID = "realActorId";
    public static final String TOKENUUID = "tokenUUID";
    public static final String USERUUID = "userUUID";
    public static final String ID = "id";

    // JWT
    public static final String JWT_ID = "jwt";
    public static final String DEVICE_ID = "deviceId";
    public static final String JWT_SECRET = res.getJWTSecret();
    public static final int JWT_TTL = 60 * 60 * 1000; // millisecond
    public static final int JWT_REFRESH_INTERVAL = 55 * 60 * 1000; // millisecond
    public static final int JWT_REFRESH_TTL = 12 * 60 * 60 * 1000; // millisecond
    public static final int JWT_AVAIABLE_TIME_PERIOD = res.getJWTAvaiableTimePeriod(); // 15mins
    public static final String JWT_ISSUER = "wallet.aia.com.sg";

    // Agent
    public static final String SINGAPORE_AREA_CODE = "+65";

    // EDoc
    public static final String EDOC_CATEGORY_WELCOMElETTER = "Welcome Letter";
    public static final String EDOC_STATUS_NL = "NL";

    // EmailType
    public static final String EMAILTYPE_FIRST_LOGIN = "FL";
    // public static final String EMAILTYPE_REGEISTION = "REG";
    public static final String EMAILTYPE_PASSWORD_FORGET = "PF";
    public static final String EMAILTYPE_PASSWORD_CHANGE = "PC";

    // EmailSubjectOfType
    public static final String MAIL_SMTP_HOST = "mail.smtp.host";
    public static final String SMTP_SERVER = res.getSmtpServer();
    public static final String EMAILTYPE_PASSWORD_CHANGE_REQUEST_SUBJECT = "AIA eCare password change request";
    public static final String EMAILTYPE_PASSWORD_CHANGE_NOTIFICATIONT_SUBJECT = "AIA eCare password change notification";
    public static final String EMAILFROM = res.getEmailFrom();
    public static final String TEMPLATELOCATION_FIRST_LOGIN = "vm/first_login.vm";
    public static final String TEMPLATELOCATION_PASSWORD_CHANGE_REQUEST = "vm/password_change_request.vm";
    public static final String TEMPLATELOCATION_PASSWORD_CHANGE_NOTIFICATIONT = "vm/password_change_notificationt.vm";
    public static final String ENCODING = "ISO-8859-1";

    // PolicyCategroy
    public static final String CATEGORIZATION_POLICY_DETAIL_ANNUITIES = "Annuities";
    public static final String CATEGORIZATION_POLICY_DETAIL_TRADITIONAL = "Traditional";
    public static final String CATEGORIZATION_POLICY_DETAIL_HOSPITALIZATION = "Hospitalization";
    public static final String CATEGORIZATION_POLICY_DETAIL_INVESTMENT = "Investment Linked";
    public static final String CATEGORIZATION_POLICY_DETAIL_OTHERS = "Others";

    // Policy-Investment
    public static final BigDecimal ZERO = new BigDecimal("0.000000");
    public static final int CAL_SCALE = 6;
    public static final int SHOW_SCALE = 3;

    // CacheUtil
    public static final String CACHE_CONFIGURATIN_PATH = "/ehcache.xml";

    // DBCache
    public static final String JNDI_NAME_COMPASS = "java:comp/env/jdbc/topservice_ext_core_DS";
    public static final String JNDI_NAME_SMS_S = "java:comp/env/jdbc/TopService-SMS-S-DS";
    public static final String JNDI_NAME_SMS_N = "java:comp/env/jdbc/TopService-SMS-N-DS";
    // public static final String JNDI_NAME_SMS_UAT =
    // "java:comp/env/jdbc/TopService-SMS-DS";

    // EnvUtil
    public static final String ENVUTIL_CONFIGURATIN_PATH = "/sit_config.properties";

    // FileUtil
    public static final String OUTPUTPICS_STRING = "base64,";

    // VerifyCodeUtils
    public static final String VERIFY_CODES = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    public static final String VERIFY_CODES_FONT_TYPE = "Algerian";

    // GenerateUtil
    public static final String GEN_PWD_ALPHA_NUMERICS = "MNBVCXZKJHGF0123456789DSAPOIUTREWQ";

    // StringRandom
    public static final String[] RANDOM_CHARS = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
            "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
            "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

    // MD5Util
    public static final char[] MD5_HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b',
            'c', 'd', 'e', 'f' };

    // E2EEProxyFactory
    public static String E2EE_XML_RPC_URL = res.getE2eeRPCURL();

}
