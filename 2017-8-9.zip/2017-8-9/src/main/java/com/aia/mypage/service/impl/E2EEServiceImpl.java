package com.aia.mypage.service.impl;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.xmlrpc.XmlRpcException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.aia.mypage.service.E2EEService;
import com.aia.mypage.util.captcha.Constant;
import com.aia.mypage.util.captcha.E2EEProxyFactory;
import com.aia.mypage.util.captcha.EnvUtil;
import com.isprint.am.dto.bean.AuthResultTO;
import com.isprint.am.dto.bean.AuthnAccountTO;
import com.isprint.am.dto.bean.LoginAccountTO;
import com.isprint.am.dto.bean.UserInfoBean;
import com.isprint.am.xmlrpc.api.API.Proxy;
import com.isprint.am.xmlrpc.api.API.ProxyFactory;

public class E2EEServiceImpl implements E2EEService {

    private static Log logger = LogFactory.getLog(E2EEServiceImpl.class);

    private static EnvUtil res = EnvUtil.getInstance();

    public void unLockeUser(String custId) throws MalformedURLException, XmlRpcException {
        Proxy proxy = null;
        E2EEProxyFactory.getProxyFactory();
        proxy = ProxyFactory.createProxy(E2EEProxyFactory.PROXY_FACTORY_NAME);

        boolean isExited = false;
        UserInfoBean user = getUserById(proxy, custId);
        if (user != null && user.getId().equals(custId)) {
            isExited = true;
        }
        if (!isExited) {
        }

        String strAccountStatus = "";
        LoginAccountTO[] loginAccts = user.getLoginAccounts();
        if (loginAccts != null) {
            for (int j = 0; j < loginAccts.length; j++) {
                strAccountStatus = loginAccts[0].getStatus();

                System.out.println("User LoginModule Id: " + loginAccts[j].getLoginModuleId());
                System.out.println("     Status: " + loginAccts[j].getStatus());
                System.out.println("     Bad Login Count: " + loginAccts[j].getBadLoginCount());
                System.out
                        .println("     Last Password Change Date: " + ((loginAccts[j].getLastPasswordChanged() != null)
                                ? loginAccts[j].getLastPasswordChanged().toString() : "Not available"));
            }
        }
        strAccountStatus = loginAccts[0].getStatus();
        if (strAccountStatus != null && strAccountStatus.equals("Activated")) {
        }

        String adminToken = getAdminToken(proxy);
        String loginModuleId = res.getLoginModuleId();
        HashMap params1 = new HashMap();
        proxy.getPasswordSvc().unlockLoginAccount(adminToken, custId, "", loginModuleId, params1);
        try {
            proxy.getAuthnSvc().logout(adminToken, params1);
        }
        catch (XmlRpcException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public UserInfoBean getUserById(Proxy proxy, String custId) throws XmlRpcException {

        String adminToken = getAdminToken(proxy);
        UserInfoBean templateParam = new UserInfoBean();
        templateParam.set(Constant.ID, ""); // default system defined field name
        UserInfoBean user = new UserInfoBean();

        UserInfoBean tmp = new UserInfoBean();
        tmp.set("id", "");

        AuthnAccountTO authAcct = new AuthnAccountTO();
        LoginAccountTO loginAcct = new LoginAccountTO();

        tmp.setAuthnAccounts(new AuthnAccountTO[] { authAcct });
        tmp.setLoginAccounts(new LoginAccountTO[] { loginAcct });

        user = proxy.getQuerySvc().findUserById(adminToken, "", custId, tmp);

        return user;
    }

    public boolean findUserById(Proxy proxy, String custId) throws XmlRpcException {

        String adminToken = getAdminToken(proxy);
        UserInfoBean templateParam = new UserInfoBean();
        templateParam.set(Constant.ID, ""); // default system defined field name
        try {
            proxy.getQuerySvc().findUserById(adminToken, "", custId, templateParam);
        }
        catch (XmlRpcException e) { // 30001 user not found
            int errorCode = e.code;
            if (30001 == errorCode) {

                logger.debug("End call findUserById service: " + false);

                return false;
            } else {

                logger.error("Faild to call findUserById service. ErrorMessage: " + e.code + e.getMessage());

                // throw new MypageException(BaseUtil.DATA_EXCEPTION,
                // e.getMessage(), BaseUtil.ERROR_CODE_550);
            }
        }
        logger.debug("End call findUserById service: " + true);
        return true;
    }

    public String getAdminToken(Proxy proxy) throws XmlRpcException {

        Map<String, String> params = new HashMap<String, String>();
        params.put(Constant.RETRIEVE_PRINCIPAL, Constant.RETRIEVE_PRINCIPAL_VALUE);
        params.put(Constant.REALM_ID, res.getAdminRealmId());

        AuthResultTO loginResult;
        String sessionToken = null;
        loginResult = proxy.getAuthnSvc().login("", res.getAdminLoginId(), res.getAdminPwd(), params);
        sessionToken = String.valueOf(loginResult.getMap(Constant.SESSION).get(Constant.SESSION_TOKEN));

        return sessionToken;
    }

}
