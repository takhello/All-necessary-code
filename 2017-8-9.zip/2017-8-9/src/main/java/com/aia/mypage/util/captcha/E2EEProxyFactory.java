package com.aia.mypage.util.captcha;

import java.net.MalformedURLException;

import com.isprint.am.xmlrpc.api.API.ProxyFactory;

public class E2EEProxyFactory {

    public static String PROXY_FACTORY_NAME = "2FAProxyFactory";

    private static ProxyFactory fact = null;

    private static Object lockProxyFactory = new Object();

    public static ProxyFactory getProxyFactory() throws MalformedURLException {
        if (fact == null) {
            synchronized (lockProxyFactory) {
                // register proxy factory
                fact = ProxyFactory.registerFactory(PROXY_FACTORY_NAME, new String[] { Constant.E2EE_XML_RPC_URL }, 30);
            }
        }
        return fact;
    }
}
