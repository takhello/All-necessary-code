package com.aia.mypage.util.constant;

import java.util.Map;

public class ConfigConstant {

    private ConfigConstant() {

    }

    public static Map<String, String> configMap;

    public static final String RELOAD_ROLE_PERMISSION_TIME = "RELOAD_ROLE_PERMISSION_TIME";

    public static final String ESB_RELOAD_TIME = "ESB_RELOAD_TIME";

    public static final String VERIFY_DEBUG_CODE = "VERIFY_DEBUG_CODE";

    public static final String VERIFY_OTP_DEBUG = "VERIFY_OTP_DEBUG";

    public static final String OTP_API_URL = "OTP_API_URL";

    public static final String OTP_API_VERIFY_OTP = "OTP_API_VERIFY_OTP";

    public static final String PROXY_USERNAME = "PROXY_USERNAME";

    public static final String PROXY_PASSWORD = "PROXY_PASSWORD";

    public static final String PROXY_HOSTNAME = "PROXY_HOSTNAME";

    public static final String PROXY_PORT = "PROXY_PORT";

    public static final String HTTP_CLIENT_MAX_CONNECTION_SECONDS = "HTTP_CLIENT_MAX_CONNECTION_SECONDS";

    public static final String IS_PROXY_OTP = "IS_PROXY_OTP";

    public static final String ESB_FORWARDER_ESB_USERNAME = "ESB_FORWARDER_ESB_USERNAME";

    public static final String ESB_FORWARDER_ESB_PASSWORD = "ESB_FORWARDER_ESB_PASSWORD";

    public static final String ESB_FORWARDER_ESB_TARGET_URL = "ESB_FORWARDER_ESB_TARGET_URL";

    public static final String MAX_VERIFY_OTP_FAILED_COUNTER = "MAX_VERIFY_OTP_FAILED_COUNTER";

    public static final String DEFAULT_LANGUAGE = "DEFAULT_LANGUAGE";

    public static final String ESB_FORWARDER_ECARE_TARGET_URL = "ESB_FORWARDER_ECARE_TARGET_URL";

    public static final String ESB_FORWARDER_WALLET_TARGET_URL = "ESB_FORWARDER_WALLET_TARGET_URL";
}
