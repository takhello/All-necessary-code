package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AccountUserWorkDAO;
import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.entity.UserWorkInfo;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AccountUserWorkDAOImpl extends JPABaseRepImpl<UserWorkInfo> implements AccountUserWorkDAO {

    @Override
    protected EntityManager getEntityManager() {
        // TODO Auto-generated method stub
        return null;
    }

    public List<UserWorkInfo> getAccountListByIdName(String custId, String custName) {
        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.UserWorkInfo");
        sql.append(
                " (a.accountId, a.accountName, a.firstName, a.isEnabled, a.enabledTime, a.lastFailedTime, a.isLocked, a.lockedType)");
        sql.append(" from Account a where 1=1");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(custId) && custId != null) {
            sql.append(" and accountName like:accountName");
            parameters.put("accountName", "%" + custId + "%");
        }
        if (!"".equals(custName) && custName != null) {
            sql.append(" and lower(firstName) like:firstName");
            parameters.put("firstName", "%" + custName.toLowerCase() + "%");
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<UserWorkInfo> accountList = super.query(sqlParameters);
        return accountList;
    }
}
