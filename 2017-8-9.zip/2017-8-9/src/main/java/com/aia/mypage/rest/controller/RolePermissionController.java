package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.service.PermissionService;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class RolePermissionController extends BaseController {

    @Autowired
    @Qualifier("rolePermissionServiceImpl")
    private RolePermissionService rolePermissionService;

    @Autowired
    @Qualifier("roleServiceImpl")
    private RoleService roleService;

    @Autowired
    @Qualifier("permissionServiceImpl")
    private PermissionService permissionService;

    /**
     * retrieving associations of Role and Permission list.
     * 
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/role_permissions", method = RequestMethod.GET)
    public Map<String, Object> getRolePermissionsList(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        String permissionId = request.getParameter("permissionId");
        String permissionName = request.getParameter("permissionName");
        String permissionType = request.getParameter("permissionType");
        String permissionStatus = request.getParameter("permissionStatus");
        String permissionMethod = request.getParameter("permissionMethod");
        String permissionPattern = request.getParameter("permissionPattern");
        String isOTP = request.getParameter("isOTP");
        String roleId = request.getParameter("roleId");
        String roleName = request.getParameter("roleName");
        String roleStatus = request.getParameter("roleStatus");

        Role role = new Role();
        Permission permission = new Permission();
        role.setRoleId(roleId);
        role.setRoleName(roleName);
        role.setRoleStatus(roleStatus);
        permission.setPermissionId(permissionId);
        permission.setPermissionName(permissionName);
        permission.setPermissionType(permissionType);
        permission.setPermissionPattern(permissionPattern);
        permission.setPermissionStatus(permissionStatus);
        permission.setPermissionMethod(permissionMethod);
        permission.setIsOTP(isOTP);

        List<RolePermissionRP> rolePermissionRPList = rolePermissionService.getRolePermissionsRPList(role, permission);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("rolePermissionList", rolePermissionRPList);
        successJson.put("data", data);
        return successJson;

    }

    /**
     * creating associations of Role and Permission.
     * 
     * @param jsonMap
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/role_permission", method = RequestMethod.POST)
    public Map<String, Object> addRolePermission(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String roleId = (String) data.get("roleId");
        String permissionId = (String) data.get("permissionId");
        if ("".equals(roleId) || roleId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("roleId"));
        }
        if ("".equals(permissionId) || permissionId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("permissionId"));
        }

        Role role = roleService.getRoleById(roleId);
        if (role == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ROLE_UNREGISTERED);
        }
        Permission permission = permissionService.getPermissionById(permissionId);
        if (permission == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.PERMISSION_UNREGISTERED);
        }

        boolean result = rolePermissionService.hasSameRolePermission(permissionId);
        if (result) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ROLE_PERMISSION_REGISTERED);
        }

        RolePermission rolePermission = new RolePermission();
        rolePermission.setRoleId(roleId);
        rolePermission.setPermissionId(permissionId);
        rolePermissionService.addRolePermission(rolePermission);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    /**
     * deleting associations of Role and Permission.
     * 
     * @param role_permission_id
     * @param request
     * @param response
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/role_permission/{role_permission_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteRolePermission(@PathVariable Integer role_permission_id,
            HttpServletRequest request, HttpServletResponse response) {

        RolePermission rolePermission = rolePermissionService.getRolePermissionById(role_permission_id);
        if (rolePermission == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.ROLE_PERMISSION_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(rolePermission.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("role_permission"));
        }

        rolePermissionService.deleteRolePermissionById(role_permission_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }
}
