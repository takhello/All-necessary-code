package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;
import com.aia.mypage.service.GroupRoleService;
import com.aia.mypage.service.GroupService;
import com.aia.mypage.service.RoleService;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

@Controller
@RequestMapping(value = "admin")
public class GroupRoleController extends BaseController {

    @Autowired
    @Qualifier("groupServiceImpl")
    private GroupService groupService;

    @Autowired
    @Qualifier("roleServiceImpl")
    private RoleService roleService;

    @Autowired
    @Qualifier("groupRoleServiceImpl")
    private GroupRoleService groupRoleService;

    @ResponseBody
    @RequestMapping(value = "/group_roles", method = RequestMethod.GET)
    public Map<String, Object> getGroupRolesList(HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        String groupId = request.getParameter("groupId");
        String groupName = request.getParameter("groupName");
        String groupStatus = request.getParameter("groupStatus");
        String roleId = request.getParameter("roleId");
        String roleName = request.getParameter("roleName");

        Group group = new Group();
        group.setGroupId(groupId);
        group.setGroupName(groupName);
        group.setGroupStatus(groupStatus);
        Role role = new Role();
        role.setRoleId(roleId);
        role.setRoleName(roleName);

        List<GroupRoleGR> groupRolesList = groupRoleService.getGroupRoleGRsList(group, role);
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new LinkedHashMap<String, Object>();
        data.put("groupRoleList", groupRolesList);
        successJson.put("data", data);
        return successJson;

    }

    @SuppressWarnings("unchecked")
    @ResponseBody
    @RequestMapping(value = "/group_role", method = RequestMethod.POST)
    public Map<String, Object> addGroupRole(@RequestBody Map<String, Object> jsonMap, HttpServletRequest request,
            HttpServletResponse response) {

        Map<String, Object> data = (Map<String, Object>) jsonMap.get("data");
        String groupId = (String) data.get("groupId");
        String roleId = (String) data.get("roleId");
        if ("".equals(groupId) || groupId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("groupId"));
        }
        if ("".equals(roleId) || roleId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, paramRequired("roleId"));
        }

        Group group = groupService.getGroupById(groupId);
        if (group == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_UNREGISTERED);
        }
        Role role = roleService.getRoleById(roleId);
        if (role == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.ROLE_UNREGISTERED);
        }

        boolean result = groupRoleService.hasSameGroupRole(groupId, roleId);
        if (result) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, ErrorMessageUtil.GROUP_ROLE_REGISTERED);
        }
        groupRoleService.addGroupRole(groupId, roleId);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }

    @ResponseBody
    @RequestMapping(value = "/group_role/{group_role_id}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteGroupRole(@PathVariable Integer group_role_id, HttpServletRequest request,
            HttpServletResponse response) {

        GroupRole groupRole = groupRoleService.getGroupRoleListById(group_role_id);
        if (groupRole == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550,
                    ErrorMessageUtil.GROUP_ROLE_UNREGISTERED);
        }

        if (BaseUtil.IS_DEFAULT_Y.equals(groupRole.getIsDefault())) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, isDefault("group_role"));
        }

        groupRoleService.deleteGroupRoleById(group_role_id);
        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

    }
}
