package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

public class UserWorkAuditLog implements Serializable {

    private static final long serialVersionUID = -6584518653803243227L;

    /** log_id. */
    private Integer logId;

    /** log_type. */
    private String logType;

    /** log_desc. */
    private String logDesc;

    /** user_ip. */
    private String userIp;

    /** request_method */
    private String requestMethod;

    /** create_time. */
    private Date createTime;

    /**
     * Constructor.
     */
    public UserWorkAuditLog() {
    }

    public UserWorkAuditLog(Integer logId, String logType, String logDesc, String userIp, Date createTime) {
        super();
        this.logId = logId;
        this.logType = logType;
        this.logDesc = logDesc;
        this.userIp = userIp;
        this.createTime = createTime;
    }

    public Integer getLogId() {
        return logId;
    }

    public void setLogId(Integer logId) {
        this.logId = logId;
    }

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public String getLogDesc() {
        return logDesc;
    }

    public void setLogDesc(String logDesc) {
        this.logDesc = logDesc;
    }

    public String getUserIp() {
        return userIp;
    }

    public void setUserIp(String userIp) {
        this.userIp = userIp;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

}
