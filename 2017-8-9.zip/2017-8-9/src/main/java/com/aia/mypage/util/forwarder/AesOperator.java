package com.aia.mypage.util.forwarder;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

@SuppressWarnings("restriction")
public class AesOperator {
//	private String sKey = "0123456789abcdef";
//	private String ivParameter = "0123456789abcdef";
	private String sKey = "hjiugt57698fdsjk";
	private String ivParameter = "hjiugt57698fdsjk";
	private static AesOperator instance = null;

	public AesOperator() {
	}

	public static AesOperator getInstance() {
		if (instance == null)
			instance = new AesOperator();
		return instance;
	}

	// encrypt
	public String encrypt(String sSrc) throws Exception {
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		byte[] raw = sKey.getBytes();
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes()); //cbc mode
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
		byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8")); 
	    return Base64.encodeBase64String(encrypted); 
	}

	// decrypt
	public String decrypt(String sSrc) throws Exception {
		try {
			byte[] raw = sKey.getBytes("ASCII");
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
			byte[] encrypted1 = Base64.decodeBase64(sSrc);
			byte[] original = cipher.doFinal(encrypted1);
			String originalString = new String(original, "utf-8");
			return originalString;
		} catch (Exception ex) {
			return null;
		}
	}
}
