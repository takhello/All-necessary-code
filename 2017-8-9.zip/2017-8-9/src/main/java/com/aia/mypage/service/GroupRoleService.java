package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.GroupRole;
import com.aia.mypage.entity.GroupRoleGR;
import com.aia.mypage.entity.Role;

public interface GroupRoleService {

    boolean deleteGroupRoleByRoleId(String roleId);

    boolean deleteGroupRoleByGroupId(String groupId);

    List<GroupRoleGR> getGroupRoleGRsList(Group group, Role role);

    GroupRole addGroupRole(String groupId, String roleId);

    boolean deleteGroupRoleById(Integer groupRoleId);

    boolean hasSameGroupRole(String groupId, String roleId);

    List<GroupRole> getGroupRoleList();

    List<GroupRole> getGroupRoleListByRoleId(String role_id);

    List<GroupRole> getGroupRoleListByGroupId(String group_id);

    GroupRole getGroupRoleListById(Integer groupRoleId);

}
