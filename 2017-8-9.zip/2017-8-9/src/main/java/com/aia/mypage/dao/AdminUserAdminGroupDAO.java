package com.aia.mypage.dao;

import java.util.List;

import com.aia.mypage.entity.AdminUserAdminGroupInfo;

public interface AdminUserAdminGroupDAO {
    
    List<AdminUserAdminGroupInfo> getAllAdminUserAdminGroup(String userId);

}
