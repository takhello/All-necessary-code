package com.aia.mypage.service;

import java.util.List;
import java.util.Map;

import com.aia.mypage.entity.Config;

public interface ConfigService {

    List<Config> getConfigList();

    Map<String, String> getConfigLists();

    void initParamData() throws Exception;

}
