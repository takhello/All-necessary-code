package com.aia.mypage.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * Model class of t_admin_group.
 * 
 */
@Table(name = "T_ADMIN_GROUP")
@Entity
public class AdminGroup implements Serializable {

    /**
     * serialVersionUID.
     */
    private static final long serialVersionUID = 779776673969509030L;

    /** group_id. */
    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid")
    @GeneratedValue(generator = "uuid")
    @Column(name = "group_id")
    private String groupId;

    /** group_name. */
    @Column(name = "group_name")
    private String groupName;

    /** group_desc. */
    @Column(name = "group_desc")
    private String groupDesc;

    /** group_status. */
    @Column(name = "group_status")
    private String groupStatus;

    /** create_time. */
    @Column(name = "create_time")
    private Date createTime;

    /** update_time. */
    @Column(name = "update_time")
    private Date updateTime;

    public AdminGroup() {
    }
    
    public AdminGroup(String groupId, String groupName) {
        this.groupId = groupId;
        this.groupName = groupName;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public String getGroupStatus() {
        return groupStatus;
    }

    public void setGroupStatus(String groupStatus) {
        this.groupStatus = groupStatus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
