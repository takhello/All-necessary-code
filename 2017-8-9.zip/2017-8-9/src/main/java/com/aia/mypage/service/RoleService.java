package com.aia.mypage.service;

import java.util.List;

import com.aia.mypage.entity.Role;

public interface RoleService {

    Role getRoleById(String roleId);

    List<Role> getRolesList(Role role);

    Role addRole(Role role);

    boolean deleteRoleById(String roleId);

    Role updateRole(Role role);

}
