package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.AdminUserInfoDAO;
import com.aia.mypage.entity.AdminUser;
import com.aia.mypage.entity.AdminUserInfo;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class AdminUserInfoDAOImpl extends JPABaseRepImpl<AdminUserInfo> implements AdminUserInfoDAO {

    @Override
    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<AdminUserInfo> getAdminUserListByAccountName(AdminUserInfo adminUserInfo) {
       /* StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.AdminUserInfo");
        sql.append(" (user.userId, au.isDefault, user.firstName, user.lastName, au.isEnabled)");
        sql.append(" from User user, AdminUser au where user.userId=au.userId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        String firstName = adminUserInfo.getFirstName();
        if (!"".equals(firstName) && firstName != null) {
            sql.append(" and lower(user.firstName) like:firstName ");
            parameters.put("firstName", "%" + firstName.toLowerCase() + "%");
        }

        String lastName = adminUserInfo.getLastName();
        if (!"".equals(lastName) && lastName != null) {
            sql.append(" and lower(user.lastName) like:lastName ");
            parameters.put("lastName", "%" + lastName.toLowerCase() + "%");
        }
        String isEnabled = adminUserInfo.getIsEnabled();
        if (!"".equals(isEnabled) && isEnabled != null) {
            sql.append(" and au.isEnabled =:isEnabled ");
            parameters.put("isEnabled", isEnabled);
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.query(sqlParameters);*/
    	
    	return null;	
    }

    @Override
    public AdminUserInfo getAdminProfile(String accountName) {
       /* StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.AdminUserInfo");
        sql.append(" (user.userId, au.isDefault, user.firstName, user.lastName, au.isEnabled)");
        sql.append(" from Account account, User user, AdminUser au where user.userId=au.userId");
        sql.append("  and account.userId=user.userId and lower(account.accountName) =:accountName ");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("accountName", accountName.toLowerCase());
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return querySingleResult(sqlParameters);*/
    	return new AdminUserInfo();
    }

}
