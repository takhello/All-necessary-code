package com.aia.mypage.rest.controller;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.xmlrpc.XmlRpcException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.aia.mypage.entity.Account;
import com.aia.mypage.entity.TempAccount;
import com.aia.mypage.entity.User;
import com.aia.mypage.entity.UserWorkAuditLog;
import com.aia.mypage.service.AccountService;
import com.aia.mypage.service.AuditLogService;
import com.aia.mypage.service.E2EEService;
import com.aia.mypage.service.TempAccountService;
import com.aia.mypage.service.UserService;
import com.aia.mypage.util.BaseUtil;

@Controller
@RequestMapping(value = "v1/admin")
public class AdminUserWork extends BaseController {

    @Autowired
    @Qualifier("tempAccountServiceImpl")
    private TempAccountService tempAccountService;

    @Autowired
    @Qualifier("accountServiceImpl")
    private AccountService accountService;

    @Autowired
    @Qualifier("auditLogServiceImpl")
    private AuditLogService auditLogService;

    @Autowired
    @Qualifier("userServiceImpl")
    private UserService userService;

    @Autowired
    @Qualifier("e2EEServiceImpl")
    private E2EEService e2EEService;

    @ResponseBody
    @RequestMapping(value = "/user/{userId}/pre_login", method = RequestMethod.GET)
    public Map<String, Object> adminLogin(@PathVariable Integer userId, HttpServletRequest request,
            HttpServletResponse response) {

        User user = userService.getUserById(userId);

        if (user == null) {
            returnErrorJson(request, response, BaseUtil.ERROR_CODE_550, "account not found");
        }
        Account account = accountService.getAccountByUserId(userId);
        TempAccount tempAccount = tempAccountService.addTempAccount(account.getAccountId());
        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("custId", account.getAccountName());
        data.put("loginUUID", tempAccount.getVerifyString());
        successJson.put("data", data);
        return successJson;
    }

    @ResponseBody
    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public Map<String, Object> getUsers(HttpServletRequest request, HttpServletResponse response) {
        String partyId = request.getParameter("custId");
        String firstName = request.getParameter("custName");
        List<User> userList = userService.getUserList(partyId, firstName);

        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
        successJson.put("data", userList);
        return successJson;
    }

    @ResponseBody
    @RequestMapping(value = "/user_log", method = RequestMethod.GET)
    public Map<String, Object> getAuditLog(HttpServletRequest request, HttpServletResponse response) {
        String custId = request.getParameter("custId");

        Map<String, Object> successJson = returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);

        Account account = accountService.getAccountByAccountName(custId);
        List<UserWorkAuditLog> auditLogList = auditLogService.getAuditLogList(account.getUserId());
        successJson.put("data", auditLogList);
        return successJson;
    }

    @ResponseBody
    @RequestMapping(value = "/user_lock/{userId}/lock_stauts", method = RequestMethod.PUT)
    public Map<String, Object> lockAndUnlock(@PathVariable Integer userId, @RequestBody Map<String, Object> jsonMap,
            HttpServletRequest request, HttpServletResponse response) {

        if (userId == null) {
            return returnErrorJson(request, response, BaseUtil.ERROR_CODE_400, paramRequired("user id"));
        }
        User user = userService.getUserById(userId);
        try {
            e2EEService.unLockeUser(user.getPartyId());
        }
        catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (XmlRpcException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return returnSuccessJson(request, response, BaseUtil.SUCCESS_MESSAGE);
    }

}
