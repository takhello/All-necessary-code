/*
* @Author: tongbiao
* @Date:   2016-01-27 10:46:43
* @Last Modified by:   tongbiao
* @Last Modified time: 2016-01-27 10:46:50
*/

'use strict';

(function() {
  // alert('sdfsdf');
  console.log("自执行");
})();

