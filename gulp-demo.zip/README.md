1. 命令行创建npm的配置文件
  a. npm init
2. 添加一个gulp的依赖
  npm install gulp --save-dev
3. 在项目根目录下添加一个gulpfile.js文件，这个是gulp的主文件，这个文件名是固定的
4. 在gulpfile中抽象我们需要做的任务