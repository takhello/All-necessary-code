package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.GroupDAO;
import com.aia.mypage.entity.Group;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class GroupDAOImpl extends JPABaseRepImpl<Group> implements GroupDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    public Group getGroupById(String groupId) {
        StringBuffer sql = new StringBuffer("from Group where groupId = :groupId");
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("groupId", groupId);
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        return super.querySingleResult(sqlParameters);
    }

    public List<Group> getGroupsList(Group group) {
        String groupId = group.getGroupId();
        StringBuffer sql = new StringBuffer("from Group where 1=1");
        Map<String, Object> parameters = new HashMap<String, Object>();
        if (!"".equals(groupId) && groupId != null) {
            sql.append(" and groupId =:groupId");
            parameters.put("groupId", groupId);
        }
        String groupName = group.getGroupName();
        if (!"".equals(groupName) && groupName != null) {
            sql.append(" and lower(groupName) like:groupName");
            parameters.put("groupName", "%" + groupName.toLowerCase() + "%");
        }
        String groupStatus = group.getGroupStatus();
        if (!"".equals(groupStatus) && groupStatus != null) {
            sql.append(" and groupStatus =:groupStatus");
            parameters.put("groupStatus", groupStatus);
        }
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);
        List<Group> rolesList = super.query(sqlParameters);
        return rolesList;
    }

    public Group addGroup(Group group) {
        group = super.create(group);
        return group;
    }

    public boolean deleteGroupById(String groupId) {
        super.remove(groupId);
        return true;
    }

    public Group updateGroup(Group group) {
        group = super.update(group);
        return group;
    }

}
