package com.aia.mypage.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import com.aia.mypage.dao.GroupRoleMapDAO;
import com.aia.mypage.entity.GroupRoleMapVO;
import com.aia.mypage.entity.SqlParameters;
import com.aia.mypage.util.jpa.JPABaseRepImpl;

public class GroupRoleMapDAOImpl extends JPABaseRepImpl<GroupRoleMapVO> implements GroupRoleMapDAO {

    protected EntityManager getEntityManager() {
        return null;
    }

    @Override
    public List<GroupRoleMapVO> getAllGroupRoleMap() {

        StringBuffer sql = new StringBuffer();
        sql.append("select new com.aia.mypage.entity.GroupRoleMapVO(gr.groupId, r.roleId, r.roleName)");
        sql.append(" from GroupRole gr, Role r where gr.roleId=r.roleId order by gr.groupId");

        Map<String, Object> parameters = new HashMap<String, Object>();
        SqlParameters sqlParameters = new SqlParameters(sql, parameters);

        return super.query(sqlParameters);
    }

}
