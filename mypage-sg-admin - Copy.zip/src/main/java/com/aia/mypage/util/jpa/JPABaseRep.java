package com.aia.mypage.util.jpa;

import java.io.Serializable;
import java.util.List;

import com.aia.mypage.entity.SqlParameters;

public interface JPABaseRep<T> {

    T create(T t);

    T update(T t);

    void remove(T t);

    void remove(Serializable id);

    T find(Serializable id);

    T getReference(Serializable id);

    List<T> query(SqlParameters sqlParameters);

    T querySingleResult(SqlParameters sqlParameters);

    List<T> queryByNoParamters(String sql);

    T querySingleResultByNoParamters(String sql);

    long count(SqlParameters sqlParameters);

    List<T> queryPage(SqlParameters sqlParameters, int pageNumber, int pageSize);

    int newUpdate(SqlParameters sqlParameters);

}