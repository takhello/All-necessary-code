package com.aia.mypage.service;

public interface UserRoleService {

    void initGroupRoleMap() throws Exception;

}
