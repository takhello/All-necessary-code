package com.aia.mypage.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.RolePermissionDAO;
import com.aia.mypage.dao.RolePermissionRPDAO;
import com.aia.mypage.entity.Permission;
import com.aia.mypage.entity.Role;
import com.aia.mypage.entity.RolePermission;
import com.aia.mypage.entity.RolePermissionRP;
import com.aia.mypage.service.RolePermissionService;
import com.aia.mypage.util.BaseUtil;

public class RolePermissionServiceImpl implements RolePermissionService {

    @Autowired
    @Qualifier("rolePermissionRPDAOImpl")
    private RolePermissionRPDAO rolePermissionRPDAO;

    @Autowired
    @Qualifier("rolePermissionDAOImpl")
    private RolePermissionDAO rolePermissionDAO;

    public List<RolePermissionRP> getRolePermissionsRPList(Role role, Permission permission) {
        List<RolePermissionRP> list = rolePermissionRPDAO.getList(role, permission);
        return list;
    }

    public RolePermission addRolePermission(RolePermission rolePermission) {
        rolePermission.setCreateTime(new Date());
        rolePermission.setIsDefault(BaseUtil.IS_DEFAULT_N);
        rolePermission = rolePermissionDAO.addRolePermission(rolePermission);
        return rolePermission;
    }

    public boolean deleteRolePermissionById(Integer rolePermissionId) {
        boolean result = rolePermissionDAO.deleteRolePermissionById(rolePermissionId);
        return result;
    }

    public boolean deleteRolePermissionByPermissionId(String permissionId) {
        List<RolePermission> rolePermissionListByPermissionId = rolePermissionDAO
                .getRolePermissionListByPermissionId(permissionId);
        if (rolePermissionListByPermissionId.size() == 0) {
            return false;
        }
        for (RolePermission rolePermission : rolePermissionListByPermissionId) {
            rolePermissionDAO.deleteRolePermissionById(rolePermission.getRolePermissionId());
        }
        return true;
    }

    public boolean deleteRolePermissionByRoleId(String roleId) {
        List<RolePermission> rolePermissionListByRoleId = rolePermissionDAO.getRolePermissionListByRoleId(roleId, "N");
        if (rolePermissionListByRoleId.size() == 0) {
            return false;
        }
        for (RolePermission rolePermission : rolePermissionListByRoleId) {
            rolePermissionDAO.deleteRolePermissionById(rolePermission.getRolePermissionId());
        }
        return true;
    }

    public boolean hasSameRolePermission(String permissionId) {
        RolePermission rolePermission = rolePermissionDAO.hasSameRolePermission(permissionId);
        if (rolePermission == null) {
            return false;
        }
        return true;
    }

    @Override
    public List<RolePermission> getRolePermissionList() {

        return rolePermissionDAO.getRolePermissionList();
    }

    @Override
    public List<RolePermission> getRolePermissionByPermissionId(String permissionId) {

        return rolePermissionDAO.getRolePermissionListByPermissionId(permissionId);
    }

    @Override
    public List<RolePermission> getRolePermissionListByRoleId(String roleId) {

        return rolePermissionDAO.getRolePermissionListByRoleId(roleId);
    }

    @Override
    public RolePermission getRolePermissionById(Integer rolePermissionId) {

        return rolePermissionDAO.getRolePermissionListById(rolePermissionId);
    }

}
