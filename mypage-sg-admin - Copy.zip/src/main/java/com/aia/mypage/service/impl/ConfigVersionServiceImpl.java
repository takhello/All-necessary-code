package com.aia.mypage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.aia.mypage.dao.ConfigVersionDAO;
import com.aia.mypage.entity.ConfigVersion;
import com.aia.mypage.service.ConfigVersionService;

public class ConfigVersionServiceImpl implements ConfigVersionService {

    @Autowired
    @Qualifier("configVersionDAOImpl")
    private ConfigVersionDAO configVersionDAO;

    @Override
    public List<ConfigVersion> getConfigVersionList() {

        return configVersionDAO.getConfigVersionList();
    }

    @Override
    public ConfigVersion addConfigVersion(ConfigVersion configVersion) {

        return configVersionDAO.addConfigVersion(configVersion);
    }

}
