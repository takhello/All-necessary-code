package com.aia.mypage.rest.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;

import com.aia.mypage.framework.MyPageUser;
import com.aia.mypage.util.BaseUtil;
import com.aia.mypage.util.errorMessage.ErrorMessageUtil;

public class BaseController {

    public Map<String, Object> returnSuccessJson(HttpServletRequest request, HttpServletResponse response,
            String errorDesc) {
        Map<String, Object> successJson = new LinkedHashMap<String, Object>();
        successJson.put(BaseUtil.SUCCESS, BaseUtil.SUCCESS_TRUE);
        successJson.put(BaseUtil.CODE_NAME, BaseUtil.SUCCESS_CODE);
        successJson.put(BaseUtil.MESSAGE, errorDesc);
        successJson.put(BaseUtil.DETAILED_MESSAGE, "");
        return successJson;
    }

    public Map<String, Object> returnErrorJson(HttpServletRequest request, HttpServletResponse response,
            int httpStatusCode, String errorDesc) {
        Map<String, Object> errorJson = new LinkedHashMap<String, Object>();
        errorJson.put(BaseUtil.SUCCESS, BaseUtil.SUCCESS_FALSE);
        errorJson.put(BaseUtil.CODE_NAME, httpStatusCode);
        errorJson.put(BaseUtil.MESSAGE, errorDesc);
        errorJson.put(BaseUtil.DETAILED_MESSAGE, "");
        response.setStatus(httpStatusCode);
        return errorJson;
    }

    public String getUserName() {
        MyPageUser user = (MyPageUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return user.getUsername();
    }

    public String paramRequired(String param) {
        String result = ErrorMessageUtil.PARAMETER_IS_REQUIRED;
        result = result.replace("@param", param);
        return result;
    }

    public String isDefault(String isDefault) {
        String result = ErrorMessageUtil.IS_DEFAULT;
        result = result.replace("@default", isDefault);
        return result;
    }
}