(function() {
	"use strict";

	angular.module("adminManageApp").controller('RoleEditController', RoleEditController);
	RoleEditController.$injector = ['$scope', '$modal', '$modalInstance', 'editRoleIdItem', 'RoleData', 'RoleService'];

	function RoleEditController($scope, $modal, $modalInstance, editRoleIdItem, RoleData, RoleService) {
		var vm = this;
		vm.RoleData = RoleData;
		vm.closeError = closeError;
		vm.editRoleCancel = editRoleCancel;
		vm.editRoleConfirm = editRoleConfirm;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.isAlertHide = true;
		vm.modalVal = angular.copy(RoleData);

		function testData(){
			
		}

		function closeError(){
			vm.isAlertHide = true;
		}

		function editRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function editRoleConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.modalVal
			};
			RoleService.editRole(editRoleIdItem, object, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();