(function() {
    "use strict";
    angular.module('adminManageApp').controller("AuditLogController", AuditLogController);
    AuditLogController.$injector = ['$scope', 'RoleService', '$modal', '$state'];

    function AuditLogController($scope, RoleService, $modal, $state) {


        var vm = this;
        vm.getRoleList = getRoleList;
        vm.deleteRole = deleteRole;
        vm.editRole = editRole;
        vm.addRole = addRole;
        vm.getUserToFunction = getUserToFunction;
        console.log('getUserToFunctionaaaaa');

        vm.successCallback = successCallback;
        vm.failCallback = failCallback;
        vm.roles = testData();
        // getRoleList();



        function testData() {
            console.log('user-Lisr测试数据 success');
            return {
                data1: { UserId: "1", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data2: { UserId: "2", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data4: { UserId: "3", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data5: { UserId: "4", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data6: { UserId: "5", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data7: { UserId: "6", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data8: { UserId: "7", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data9: { UserId: "8", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data10: { UserId: "9", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data11: { UserId: "10", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data12: { UserId: "11", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data13: { UserId: "12", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data14: { UserId: "13", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data15: { UserId: "14", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data16: { UserId: "15", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data17: { UserId: "16", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data18: { UserId: "18", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data19: { UserId: "19", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data19: { UserId: "19", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data19: { UserId: "19", UserName: "bbb", Department: "ccc", Group: "ddd" },
                data20: { UserId: "20", UserName: "bbb", Department: "ccc", Group: "ddd" }
            };
        }

        //tong
        //Date range picker

        $('#reservation').daterangepicker();
        $(function() {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
        //tong 
        function getUserToFunction(id) {
            console.log('getUserToFunction');
            $state.go('home.user.user-function', {
                id: id
            });
        }


        function getRoleList() {
            var obj = {
                roleName: vm.roleName,
                roleStatus: vm.roleStatus
            };
            RoleService.getRoleList(obj, vm.successCallback, vm.failCallback);
        }

        function successCallback(result) {
            vm.roles = result.data.roleList;

        }

        function failCallback(error) {
            if (error.data.code === 403) {
                $state.go('home.403');
            }
        }

        function deleteRole(id) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-delete.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleDeleteController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    roleData: function() {
                        return vm.roles;
                    },
                    roleId: function() {
                        return id;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function editRole(role) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-edit.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleEditController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    editRoleIdItem: function() {
                        return role.roleId;
                    },

                    RoleData: function() {
                        return role;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function addRole() {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-new.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "UserAddController",
                controllerAs: "vm",
                size: 'md'
            });
            modalInstance.result.then(getRoleList);
        }
    }

})();
