(function(){
	"use strict";
	angular.module("adminManageApp").directive("daterangpickerDirective", function() {
		return {
			template: '<div class="input-group">'+
		                  '<button type="button" class="btn btn-default pull-right" id="daterange-btn">'+
		                    '<span>'+
		                      '<i class="fa fa-calendar"></i> Date range picker'+
		                    '</span>'+
		                    '<i class="fa fa-caret-down"></i>'+
		                  '</button>'+
		                '</div>',

			controller: function() {
				$('#daterange-btn').daterangepicker(
			        {
			          ranges: {
			            'Today': [moment(), moment()],
			            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			            'This Month': [moment().startOf('month'), moment().endOf('month')],
			            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
			          },
			          startDate: moment().subtract(29, 'days'),
			          endDate: moment()
			        },
			        function (start, end) {
			          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
			          console.log(start._d);
			        }
			    );
			}
		};
	});
})();
