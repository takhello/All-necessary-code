(function(){
	"use strict";
	angular.module("adminManageApp").directive("daterpickerDirective", function() {
		return {
			template: '<label>Select Report Date</label>'+
		                '<div class="input-group date">'+
		                  '<div class="input-group-addon">'+
		                    '<i class="fa fa-calendar"></i>'+
		                  '</div>'+
		                  '<input type="text" class="form-control pull-right" id="datepicker">'+
		                '</div>',

			controller: function() {
				$('#datepicker').datepicker({
			      autoclose: true
			    });
			}
		};
	});
})();
