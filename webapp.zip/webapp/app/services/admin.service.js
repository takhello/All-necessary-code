(function(){
	"use strict";
	angular.module("adminManageApp").service('AdminService',AdminService);
	AdminService.$injector = ['$resource'];

	function AdminService($resource){
		var services = {
			newAdmin:newAdmin,
			deleteAdmin:deleteAdmin,
			editAdmin:editAdmin,
			getUserByAccountName:getUserByAccountName,
			getAdmin:getAdmin
		};
		return services;
		
		function newAdmin(params, onSuccess, onError){
			var url = SERVICE_URL+'admin/admin_user';
			var _resource = $resource(url,{},{
				create:{
					method:"POST",
					params:{}
				}
			});
			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}

		function deleteAdmin(id,onSuccess,onError){
			var url = SERVICE_URL + "admin/admin_user/" + id;
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}

		function editAdmin(id,params,onSuccess,onError){
			var url = SERVICE_URL + "admin/admin_user/" + id;
			var _resource = $resource(url, {}, {
				update: {
					"method": "PUT",
					"data": params,
				}
			});
			return _resource.update(params).$promise.then(onSuccess,onError);
		}

		function getUserByAccountName(obj,onSuccess,onError){
			var url = SERVICE_URL+"admin/user";
			var _resource = $resource(url,obj,{
				get:{
					"method":"GET"
				}
			});
			return _resource.get().$promise.then(onSuccess,onError);
		}

		function getAdmin(obj,onSuccess,onError){
			var url = SERVICE_URL + "admin/admin_users";
			var _resource = $resource(url, obj,{
				get:{
					"method":"GET"
				}
			});
			return _resource.get().$promise.then(onSuccess,onError);
		}

	}
})();