(function(){
	"use strict";
	angular.module('adminManageApp').service("RoleToPermissionService",RoleToPermissionService);
	RoleToPermissionService.$injector = ['$resource'];
	function RoleToPermissionService($resource){
		var services = {
			getRolePermissionList:getRolePermissionList,
			getAllRolePermission:getAllRolePermission,
			deleteRolePermission:deleteRolePermission,
			newRolePermission:newRolePermission
		};
		return services;
		function getRolePermissionList(id,onSuccess,onError){
			var url = SERVICE_URL+'admin/role_permissions';
			var _resource = $resource(url,{
				"roleId":id
			},{
				get:{
					"method":"GET"
				}
			});
			return _resource.get(id).$promise.then(onSuccess,onError);
		}
		function getAllRolePermission(params,onSuccess,onError){
			var url = SERVICE_URL+'admin/role_permissions';
			var _resource = $resource(url,{},{
				get:{
					"method":"GET",
					"data":params
				}
			});
			return _resource.get(params).$promise.then(onSuccess,onError);
		}
		function newRolePermission(params, onSuccess, onError){
			var url = SERVICE_URL+'admin/role_permission';
			var _resource = $resource(url, {}, {
				create: {
					method: 'POST',
					params: {}
				}
			});
			return _resource.create(JSON.stringify(params)).$promise.then(onSuccess,onError);
		}
		function deleteRolePermission(rolePermissionId,onSuccess,onError){
			var url = SERVICE_URL+'admin/role_permission/'+rolePermissionId;
			var _resource = $resource(url,{},{
				delete:{
					"method":"DELETE"
				}
			});
			return _resource.delete().$promise.then(onSuccess,onError);
		}
		
	}
})();