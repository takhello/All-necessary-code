var SERVICE_URL = '';
var USER_ID = "";
var USER_PARTYID = "";
var USER_SESSIONID = "123456";
var USER_COUNTRY = "hk";
var USER_LANGUAGE = "zh-hk";

var USER_PROFILE = {
	"firstName": "",
	"lastName": "",
	"userId": "",
	"IsEnabled": ""
};


var PERMISSION_TYPE = {
	"00": "MyPage Admin",
	"01": "MyPage ESB",
	"02": "MyPage Login"	
};

_debugMode = function() {
	var DEBUG_SERVICE_URL = localStorage.getItem('DEBUG_SERVICE_URL');
	var DEBUG_MODE = localStorage.getItem('DEBUG_MODE');
	if (DEBUG_MODE === 'true' && DEBUG_SERVICE_URL !== '') {
		SERVICE_URL = DEBUG_SERVICE_URL;
	}
};
_enableDebugMode = function(url) {
	var DEBUG_SERVICE_URL = localStorage.setItem('DEBUG_SERVICE_URL', url);
	var DEBUG_MODE = localStorage.setItem('DEBUG_MODE', 'true');
	_debugMode();
};

_disableDebugMode = function() {
	var DEBUG_MODE = localStorage.setItem('DEBUG_MODE', 'false');
	_debugMode();
};
_debugMode();

_checkLogStatus = function() {
	console.log(USER_PROFILE.userId.length);
	if (USER_PROFILE.userId.length === 0) {
		// console.log(USER_PROFILE.userId.length);
		USER_PROFILE.firstName = "Default";
		USER_PROFILE.lastName = "User";	
	}
};
_checkLogStatus();