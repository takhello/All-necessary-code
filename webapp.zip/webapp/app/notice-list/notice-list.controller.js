(function() {
    "use strict";
    angular.module('adminManageApp').controller("NoticeListController", NoticeListController);
    NoticeListController.$injector = ['$scope', 'RoleService', '$modal', '$state'];

    function NoticeListController($scope, RoleService, $modal, $state) {


        var vm = this;
        vm.addNotice = addNotice;

        vm.getRoleList = getRoleList;
        vm.deleteRole = deleteRole;
        vm.editRole = editRole;
        // vm.addRole = addRole;
        vm.getUserToFunction = getUserToFunction;
        console.log('getUserToFunctionaaaaa');

        vm.successCallback = successCallback;
        vm.failCallback = failCallback;
        vm.notice = testData();
        // getRoleList();


        function testData() {
            console.log('user-Lisr测试数据 success');
            return {
                data1: { From: "1", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data2: { From: "2", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data3: { From: "3", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data4: { From: "4", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data5: { From: "5", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data6: { From: "6", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data7: { From: "7", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data8: { From: "8", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data9: { From: "9", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data10: { From: "10", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data11: { From: "11", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data12: { From: "12", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
                data13: { From: "13", To: "bbb", Page: "ccc", NoticeMessage: "ddd",Status:"asd",LastUpdateBy:"qwe"},
            };
        }

        //tong
        //Date range picker

        $('#reservation').daterangepicker();
        // $(function() {
        //     $("#example1").DataTable();
        //     $('#example2').DataTable({
        //         "paging": true,
        //         "lengthChange": false,
        //         "searching": false,
        //         "ordering": true,
        //         "info": true,
        //         "autoWidth": false
        //     });
        // });
        //tong 
        function getUserToFunction(id) {
            console.log('getUserToFunction');
            $state.go('home.user.user-function', {
                id: id
            });
        }


        function getRoleList() {
            var obj = {
                roleName: vm.roleName,
                roleStatus: vm.roleStatus
            };
            RoleService.getRoleList(obj, vm.successCallback, vm.failCallback);
        }

        function successCallback(result) {
            vm.roles = result.data.roleList;

        }

        function failCallback(error) {
            if (error.data.code === 403) {
                $state.go('home.403');
            }
        }

        function deleteRole(id) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-delete.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleDeleteController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    roleData: function() {
                        return vm.roles;
                    },
                    roleId: function() {
                        return id;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function editRole(role) {
            var modalInstance = $modal.open({
                templateUrl: "app/user/user-edit.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "RoleEditController",
                controllerAs: "vm",
                size: 'md',
                resolve: {
                    editRoleIdItem: function() {
                        return role.roleId;
                    },

                    RoleData: function() {
                        return role;
                    }
                }
            });
            modalInstance.result.then(getRoleList);
        }

        function addNotice() {
            var modalInstance = $modal.open({
                templateUrl: "app/notice-list/notice-new.html" + "?datestamp=" + (new Date()).getTime(),
                backdrop: false,
                controller: "NoticeAddController",
                controllerAs: "vm",
                size: 'md'
            });
            modalInstance.result.then(getRoleList);
        }
    }

})();
