(function() {
	"use strict";

	angular.module("adminManageApp").controller('NoticeAddController', NoticeAddController);
	NoticeAddController.$injector = ['$scope', 'RoleService', '$modal', '$modalInstance'];

	function NoticeAddController($scope, RoleService, $modal, $modalInstance) {
		var vm = this;
		vm.addRoleCancel = addRoleCancel;
		vm.addRoleConfirm = addRoleConfirm;
		vm.closeError = closeError;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.roleStatus = 'Y';
		vm.isAlertHide = true;

		console.log('11111')
        $('#reservation1').daterangepicker();
		console.log('22222')

		function closeError(){
			vm.isAlertHide = true;
		}



		function addRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addRoleConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
						"userLANID":vm.userLANID,
						"userName":vm.userName,
						"userTelephon":vm.userTelephon,
						"userEmail":vm.userEmail,
						"userDepartment":vm.userDepartment
					// "roleName": vm.roleName,
					// "roleDesc": vm.roleDesc,
					// "roleStatus": vm.roleStatus
				}
			};
			RoleService.newRole(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();