(function() {
	"use strict";
	angular.module("adminManageApp").controller("AdminGroupAddController", AdminGroupAddController);
	AdminGroupAddController.$injector = ['$scope', '$modal', '$modalInstance', 'AdminToGroupService', 'groupId', 'adminId', '$state'];

	function AdminGroupAddController($scope, $modal, $modalInstance, AdminToGroupService, groupId, adminId, $state) {
		var vm = this;
		vm.addAdminGroupCancel = addAdminGroupCancel;
		vm.addAdminGroupConfirm = addAdminGroupConfirm;
		vm.addSuccessCallback = addSuccessCallback;
		vm.addFailCallback = addFailCallback;
		function addAdminGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addAdminGroupConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"userId": adminId,
					"groupId": groupId
				}
			};
			$modalInstance.close('cancel');
			AdminToGroupService.newAdminGroup(obj, vm.addSuccessCallback, vm.addFailCallback);
		}

		function addSuccessCallback(result) {
			$state.reload("home.admin.admin-group");
		}

		function addFailCallback(error) {
			// alert(error.data.message);
			$modalInstance.close('cancel');
			$state.reload("home.admin.admin-group");
		}
	}
})();