(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupController', GroupController);
	GroupController.$injector = ['$scope', '$modal', 'GroupService', '$state'];

	function GroupController($scope, $modal, GroupService, $state) {
		var vm = this;
		vm.addGroup = addGroup;
		vm.deleteGroup = deleteGroup;
		vm.editGroup = editGroup;
		vm.getGroupList = getGroupList;
		vm.getGroupRoleList = getGroupRoleList;

		vm.successCallback = successCallback;
		//测试数据
		vm.groups = datatest();
		function datatest(){
			console.log('groups-Lisr测试数据 success');
			return{
				data1:{groupName:"groupName1",Description:"asd"},
				data2:{groupName:"groupName2",Description:"sdsd"},
				data3:{groupName:"groupName3",Description:"bsadab"},
				data4:{groupName:"groupName4",Description:"dad"}
			};
		}
		getGroupList();

		function getGroupRoleList(id) {
			$state.go("home.group.group-role", {
				id: id
			});
		}

		function getGroupList() {
			var obj = {
				"groupName": vm.groupName,
				"groupDesc": vm.groupDesc,
				"groupStatus": vm.groupStatus
			};
			GroupService.getGroupList(obj,vm.successCallback);
		}

		function successCallback(result) {
			// vm.groups = result.data.groupList;//原始数据
		}

		function addGroup() {
			var modalInstance = $modal.open({
				templateUrl: "app/group-sg/group-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getGroupList);
		}

		function deleteGroup(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/group-sg/group-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					groupId: function() {
						return id;
					},
					groupData: function() {
						return vm.groups;
					}

				}
			});
			modalInstance.result.then(getGroupList);
		}

		function editGroup(group) {
			var modalInstance = $modal.open({
				templateUrl: "app/group-sg/group-edit.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupEditController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					editGroupIdItem: function() {
						return group.groupId;
					},
					groupData: function() {
						return group;
					}
				}
			});
			modalInstance.result.then(getGroupList);

		}


	}
})();