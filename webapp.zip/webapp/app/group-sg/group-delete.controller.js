(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupDeleteController', GroupDeleteController);
	GroupDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'GroupService', 'groupId', 'groupData'];

	function GroupDeleteController($scope, $modal, $modalInstance, GroupService, groupId, groupData) {
		var vm = this;
		vm.deleteGroupCancel = deleteGroupCancel;
		vm.deleteGroupConfirm = deleteGroupConfirm;
		vm.isAlertHide = true;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		function deleteGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteGroupConfirm() {
			GroupService.deleteGroup(groupId,vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();