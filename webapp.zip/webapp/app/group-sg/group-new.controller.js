(function() {
	"use strict";
	angular.module("adminManageApp").controller('GroupAddController', GroupAddController);
	GroupAddController.$injector = ['$scope', 'GroupService', '$modal', '$modalInstance'];

	function GroupAddController($scope, GroupService, $modal, $modalInstance) {
		var vm = this;
		vm.addGroupCancel = addGroupCancel;
		vm.addGroupConfirm = addGroupConfirm;
		vm.errorClose = errorClose;
		vm.groupStatus = 'Y';
		vm.isDefault = 'N';
		vm.isAlertHide = true;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		function errorClose(){
			vm.isAlertHide = true;
		}

		function addGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function addGroupConfirm() {
			var obj = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": {
					"groupName": vm.groupName,
					"groupDesc": vm.groupDesc,
					"groupStatus": vm.groupStatus,
					"isDefault": vm.isDefault,
				}
			};
			GroupService.newGroup(obj, vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			console.log(error);
			vm.submitted = true;
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();