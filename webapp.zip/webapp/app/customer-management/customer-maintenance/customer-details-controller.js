(function() {
	"use strict";
	angular.module("adminManageApp").controller("CustomerDetailsController", CustomerDetailsController);
	CustomerDetailsController.$injector = ['$scope', '$stateParams', '$state', 'GroupToRoleService', 'RoleService', '$modal'];

	function CustomerDetailsController($scope, $stateParams, $state, CustomerDetailsService,  $modal) {
		
		var vm = this;
		vm.unlockAction = unlockAction;
		vm.backToGroup = backToGroup;
		vm.addGroupRole = addGroupRole;
		vm.deleteGroupRole = deleteGroupRole;
		vm.groupRoleSelected = groupRoleSelected;
		vm.loadSuccessCallback = loadSuccessCallback;
		vm.selectedSuccessCallback = selectedSuccessCallback;
		vm.selectedFailCallback = selectedFailCallback;

		function unlockAction() {
			var modalInstance = $modal.open({
				templateUrl: "app/customer-management/customer-maintenance/unlock-action.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupAddController",
				controllerAs: "vm",
				size: 'md'
			});
			modalInstance.result.then(getGroupList);
		}
		
		//GroupToRoleService.getGroupRoleList($stateParams.id,vm.loadSuccessCallback, vm.groupRoleSelected);
		
	    /*$scope.delEmploy = function() {
			var id;
			$scope.user = tmpUsers[0]
			
			if(!confirm('你确定要删除该用户？')){
				return;
			}
			
			id=$scope.user.id;
			//console.log($scope.user.id)
			var url = "api/user_manage_del.php";		
			$http({
				url:url,
				method:'get',
				params:{ids:id}
			}).success(function(response){
				if(response.success){
					//$('#myModal').modal('hide');
					initTable();				
				}else{
					//..
				}
			});
		};*/
		/*function unlockAction() {
			if(!confirm("Have you verified the policyholder's details before unlocking the account?")){
				return;
			}

		}*/
		

		function backToGroup() {
			$state.go("home.maintenance");
		}

		function loadSuccessCallback(result) {
			vm.currentRoles = result.data.groupRoleList;
			groupRoleSelected();
		}

		function groupRoleSelected() {
			RoleService.getRoleList({},vm.selectedSuccessCallback, vm.selectedFailCallback);
		}

		function selectedSuccessCallback(result) {
			var arr = [];
			vm.allRoles = result.data.roleList;
			if (vm.currentRoles.length === 0) {
				vm.selectedRoles = vm.allRoles;
			} else {
				angular.forEach(vm.allRoles, function(item) {
					var flag = vm.currentRoles.length;
					angular.forEach(vm.currentRoles, function(value) {

						if (item.roleId === value.roleId) {
							return;
						} else {
							flag -= 1;
							if (flag === 0) {
								arr.push(item);
							}
						}
					});
				});
				vm.selectedRoles = arr;
			}
		}

		function selectedFailCallback() {
			vm.selectedRoles = vm.allRoles;
		}

		function addGroupRole(id) {
			var modalInstance = $modal.open({
				templateUrl: "app/group_role/group-role-new.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupRoleAddController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					roleId: function() {
						return id;
					},
					groupId: function() {
						return $stateParams.id;
					}
				}
			});
		}

		function deleteGroupRole(groupRoleId) {
			var modalInstance = $modal.open({
				templateUrl: "app/group_role/group-role-delete.html"+"?datestamp="+(new Date()).getTime(),
				backdrop:false,
				controller: "GroupRoleDeleteController",
				controllerAs: "vm",
				size: 'md',
				resolve: {
					groupRoleId: function() {
						return groupRoleId;
					}
				}
			});

		}

	}
})();