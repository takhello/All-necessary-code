(function() {
	"use strict";
	angular.module("adminManageApp").controller('UnlockActionController', UnlockActionController);
	UnlockActionController.$injector = ['$scope', '$modal', '$modalInstance', 'MaintenanceService', 'groupId', 'groupData'];

	function UnlockActionController($scope, $modal, $modalInstance, MaintenanceService, groupId, groupData) {
		var vm = this;
		vm.deleteGroupCancel = deleteGroupCancel;
		vm.deleteGroupConfirm = deleteGroupConfirm;
		vm.isAlertHide = true;

		vm.successCallback = successCallback;
		vm.failCallback = failCallback;

		function deleteGroupCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteGroupConfirm() {
			MaintenanceService.deleteGroup(groupId,vm.successCallback, vm.failCallback);

		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();