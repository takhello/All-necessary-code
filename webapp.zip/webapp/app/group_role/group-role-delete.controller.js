(function() {
	"use strict";
	angular.module("adminManageApp").controller("GroupRoleDeleteController", GroupRoleDeleteController);
	GroupRoleDeleteController.$injector = ['$scope', '$modal', '$modalInstance', 'GroupToRoleService', '$state', 'groupRoleId'];

	function GroupRoleDeleteController($scope, $modal, $modalInstance, GroupToRoleService, $state, groupRoleId) {
		var vm = this;
		vm.deleteGroupRoleCancel = deleteGroupRoleCancel;
		vm.deleteGroupRoleConfirm = deleteGroupRoleConfirm;
		vm.callback = callback;
		function deleteGroupRoleCancel() {
			$modalInstance.dismiss('cancel');
		}

		function deleteGroupRoleConfirm() {
			$modalInstance.close('cancel');
			GroupToRoleService.deleteGroupRole(groupRoleId,vm.callback,vm.callback);
		}

		function callback(){
			$state.reload("home.group.group-role");
		}
	}
})();