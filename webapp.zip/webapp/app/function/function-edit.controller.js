(function() {
	"use strict";
	angular.module('adminManageApp').controller('FunctionEditController', FunctionEditController);
	FunctionEditController.$injector = ['$scope','$modalInstance', 'PermissionService', 'editPermissionIdItem', 'permissionData'];

	function FunctionEditController($scope, $modalInstance, PermissionService, editPermissionIdItem, permissionData) {
		var vm = this;
		vm.permissionTypeMap = PERMISSION_TYPE;
		vm.permissionData = permissionData;
		vm.editPermissionCancel = editPermissionCancel;
		vm.editPermissionConfirm = editPermissionConfirm;
		vm.errorClose = errorClose;
		vm.editPermissionIdItem = editPermissionIdItem;
		vm.permissionData = permissionData;
		vm.successCallback = successCallback;
		vm.failCallback = failCallback;
		vm.modalVal = angular.copy(vm.permissionData);
		vm.isAlertHide = true;

		function errorClose(){
			vm.isAlertHide = true;
		}

		function editPermissionCancel() {
			$modalInstance.dismiss('cancel');
		}
		
		function editPermissionConfirm() {
			var object = {
				"userId": USER_ID,
				"partyId": USER_PARTYID,
				"sessionId": USER_SESSIONID,
				"country": USER_COUNTRY,
				"language": USER_LANGUAGE,
				"data": vm.modalVal
			};
			console.log(vm.permissionData);
			PermissionService.editPermission(vm.editPermissionIdItem, object, vm.successCallback, vm.failCallback);
		}

		function successCallback(result) {
			vm.isAlertHide = true;
			$modalInstance.close('cancel');
		}

		function failCallback(error) {
			vm.isAlertHide = false;
			vm.fail = error.data.message;
			vm.status = error.data.code;
		}
	}
})();