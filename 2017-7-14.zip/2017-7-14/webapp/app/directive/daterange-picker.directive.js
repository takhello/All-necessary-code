(function(){
	"use strict";
	angular.module("adminManageApp").directive("daterangepickerDirective", function() {
		return {
		     template:'<div class="form-group margin">'+
                    		'<label for="reservation1" class="control-label">Life Span *</label>'+
		     
                        '<div class="input-group">'+
                            '<div class="input-group-addon">'+
                                '<i class="fa fa-calendar"></i>'+
                            '</div>'+
                            '<input type="text" class="form-control pull-right" id="reservation1">'+
                        '</div>'+
                    '</div>',
			controller: function() {
       		 $('#reservation1').daterangepicker();
			}
		};
	});
})();
