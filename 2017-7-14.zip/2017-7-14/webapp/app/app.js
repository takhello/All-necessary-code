angular.module('adminManageApp', ['ui.router', 'ngResource', 'ui.bootstrap']);

angular.module('adminManageApp').config(configure);
configure.$injector = ['$urlRouterProvider', '$stateProvider','$locationProvider','$qProvider'];

function configure($urlRouterProvider, $stateProvider,$locationProvider,$qProvider) {
	$urlRouterProvider.otherwise(''); //defult state --> site
	$locationProvider.hashPrefix(''); //solve url contain "!" 
	$qProvider.errorOnUnhandledRejections(false); 

	$stateProvider
		.state("home", {
			url: "",
			views: {
				"main-header@": {
					templateUrl: "app/layout/main-header.html",
					controller:"MainHeaderController",
					controllerAs:"vm"
				},
				"side-bar@": {
					templateUrl: "app/layout/side-bar.html",
					controller:"SidebarController",
					controllerAs:"vm"
				},
				"footer-bar@": {
					templateUrl: "app/layout/footer-bar.html"
				},
				//tong
				"content-panel@": {
					templateUrl: "app/home/home.html",
					controller: "HomeController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.permission", { //home state --> 
			url: "/permission",
			views: {
				"content-panel@": {
					templateUrl: "app/permission/permission-list.html",
					controller: "PermissionController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.role", {
			url: "/role",
			views: {
				"content-panel@": {
					templateUrl: "app/role/role-list.html",
					controller: "RoleController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.role.role-permission", {
			url: "/:id/permission",
			views: {
				"content-panel@": {
					templateUrl: "app/role_permission/role-permission-list.html",
					controller:"RolePermissionController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.group", {
			url: "/group",
			views: {
				"content-panel@": {
					templateUrl: "app/group/group-list.html",
					controller: "GroupController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.group.group-role",{
			url:"/:id/role",
			views:{
				"content-panel@":{
					templateUrl:"app/group_role/group-role-list.html",
					controller:"GroupRoleController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.admin",{
			url:"/admin",
			views:{
				"content-panel@":{
					templateUrl:"app/admin/admin-list.html",
					controller:"AdminController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.admin.admin-group",{
			url:"/:id/group",
			views:{
				"content-panel@":{
					templateUrl:"app/admin_group/admin-group-list.html",
					controller:"AdminGroupController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.version",{
			url:"/version",
			views:{
				"content-panel@":{
					templateUrl:"app/version/version-list.html",
					controller:"VersionController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.mapping",{
			url:"/mapping",
			views:{
				"content-panel@":{
					templateUrl:"app/customer-management/customer-mapping/customer-mapping-list.html",
					controller:"MappingController",
					controllerAs:"vm"
				}
			}
		})

		.state("home.maintenance",{
			url:"/maintenance",
			views:{
				"content-panel@":{
					templateUrl:"app/customer-management/customer-maintenance/customer-maintenance-list.html",
					controller:"MaintenanceController",
					controllerAs:"vm"
				}
			}
		})

		.state("home.maintenance.customer-details",{
			url:"/:id/maintenance",
			views:{
				"content-panel@":{
					templateUrl:"app/customer-management/customer-maintenance/customer-details.html",
					controller:"CustomerDetailsController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.statical-reports",{
			url:"/statical-reports",
			views:{
				"content-panel@":{
					templateUrl:"app/summary-reports/statical-reports/statical-reports-list.html",
					controller:"StaticalReportsController",
					controllerAs:"vm"
				}
			}
		})

		.state("home.end-of-day-reports",{
			url:"/end-of-day-reports",
			views:{
				"content-panel@":{
					templateUrl:"app/summary-reports/end-of-day-reports/end-of-day-reports.html",
					controller:"EndOfDayController",
					controllerAs:"vm"
				}
			}
		})
		
		.state("home.403",{
			url:"/403",
			views:{
				"content-panel@":{
					templateUrl:"403.html"
				}
			}
		})

		// tong 
		.state("home.function", { //home state --> 
			url: "/function",
			views: {
				"content-panel@": {
					templateUrl: "app/function/function-list.html",
					controller: "PermissionController",
					controllerAs: "vm"
				}
			}
		})

		.state("home.user", {
			url: "/user",
			views: {
				"content-panel@": {
					templateUrl: "app/user/user-list.html",
					controller: "UserController",
					controllerAs: "vm"
				}
			}
		})

		.state("home.user.user-function", {
			url: "/:id/permission",
			views: {
				"content-panel@": {
					templateUrl: "app/user-function/user-function-list.html",
					controller:"RolePermissionController",
					controllerAs:"vm"
				}
			}
		})
		.state("home.group-sg", {
			url: "/group-sg",
			views: {
				"content-panel@": {
					templateUrl: "app/group-sg/group-list.html",
					controller: "GroupController",
					controllerAs: "vm"
				}
			}
		})
		.state("home.group-sg.group-role",{
			url:"/:id/role",
			views:{
				"content-panel@":{
					templateUrl:"app/group_role/group-role-list.html",
					controller:"GroupRoleController",
					controllerAs:"vm"
				}
			}
		})
		// home.AuditLog
		.state("home.audit-log",{
			url:"/audit-log",
			views:{
				"content-panel@":{
					templateUrl:"app/audit-log/audit-log.html",
					controller:"AuditLogController",
					controllerAs:"vm"
				}
			}
		})
		// home.notice-list
		.state("home.notice-list",{
			url:"/notice-list",
			views:{
				"content-panel@":{
					templateUrl:"app/notice-list/notice-list.html",
					controller:"NoticeListController",
					controllerAs:"vm"
				}
			}
		})

		// tong end
		;
}

$(document).ajaxStart(function() { Pace.restart(); });