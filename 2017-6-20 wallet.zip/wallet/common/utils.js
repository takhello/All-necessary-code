

var SGUtil = {
	ajax : function(api,type,datas,isLoading,successCB,errorCB) {
		if(isLoading) {
			SGUtil.startLoading();
		}
		var args = arguments;
		var url = SGEnv.getApiRoot() + api;
		var type = (type == null || type == "") ? "POST" : type;
		var dataType = (dataType == null || dataType == "") ? "json" : dataType;
		var async = (async == null || async == "" || $.type(async) === "boolean") ? true : async;
		$.ajax({
			url: url,
			type: type,
			timeout : 60 * 1000,
			data: datas,
			dataType: "json",
			cache:false,
			async: true,
			beforeSend: function(xhr) {
				 var jwt = SGUtil.getStorage("jwt");
				 if(jwt) {
					 xhr.setRequestHeader(SGEnv.jwtHeader, jwt);
				 }
			},
			success: function(data) {
				SGUtil.stopLoading();
				
				if(data.code == "95001" || data.code == "95002" || data.code == "95003") {
					SGUtil.alert(data.message,function(){
						SGUtil.toPage("login.html#/index");
					});
					return ;
				}
				
				if(data.success == true){  //success
					successCB && successCB.apply(this, [data, args, this]);
					return;
				} else if(data.success == false) {  //error
					errorCB && errorCB.apply(this, [data, args, this]);
					return;
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown){
				SGUtil.stopLoading();
				
				if(window.navigator.onLine == false) {
					SGUtil.alert("Network is offline now !");
					errorCB && errorCB.apply(this, [data, args, this]);
					return ;
				}
				
				if(XMLHttpRequest.status == 0) {
					var data = {
							"message" : "Unable to connect to server"
					};
				}
				errorCB && errorCB.apply(this, [data, args, this]);
			}
		});
	},
	
	getHostPath : function() {
		var curWwwPath = window.document.location.href;
		var pathName = window.document.location.pathname;
		var pos = curWwwPath.indexOf(pathName);
		//获取主机地址，如： http://localhost:8083
		var localhostPath = curWwwPath.substring(0, pos);
		return localhostPath;
	},
	alert : function(msg,callback) {
	  	var msgHtml = "";
		msgHtml +='<div class="" style="height: 100%;width: 100%;position: fixed;left: 0;top: 0;background-color: rgba(128,128,128,0.2);z-index: 1000;">'
		msgHtml +='<div class="alert-strong alert alert-dismissable" style="left: 0px;right: 0px;bottom: 0px; padding-right: 0px;padding: 0px;margin-bottom: 0px;border: 0px solid transparent;border-radius: 0px;" role="alert">'
		msgHtml +='<button type="button" class="btn-glyph alert-strong-close" name="alertCloseBtn" style="margin-top: -20px;"><img class="icon-xs hide-on-fallback" src="/content/dam/reference/dls/dist/img/icons/closewhite-glyph.png" /></button>'
		msgHtml +='<div class="alert-strong-cols bg-p4">'
		msgHtml +='<div class="alert-strong-thumbnail">'
		msgHtml +='<img class="icon-xs hide-on-fallback" src="/content/dam/reference/dls/dist/img/icons/notification-2nd.png" />'
		msgHtml +='</div>'
		msgHtml +='<div class="alert-strong-body">'
		msgHtml +='<div class="alert-strong-content">'
		msgHtml +='<p class="bt2 w margin-bottom-m" style="padding-top: 8px;">'+msg+'</p>'
		msgHtml +='</div>'
		msgHtml +='</div>'
		msgHtml +='</div>'
		msgHtml +='</div>'
		msgHtml +='</div>';
		
		var $alertMsg = $("<div name='alertMsg'></div>").css("opacity","0").animate({opacity:1},200).append(msgHtml);
		
		$("body").append($alertMsg);	
		
		//$("body").append($("<div name='alertMsg'></div>").append(msgHtml));
		
		$("button[name='alertCloseBtn']").off("click").on("click",function(){
			SGUtil.closeAlert();
			callback && callback();
		});

	},
	startLoading : function(){
		
		if(this.isInDevice()) {
			showHUD();
		} else {
			var loadingHtml="";
		    loadingHtml+='<div class="loadEffect">'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='<span></span>'
		    loadingHtml+='</div>';
		  	$("body").append($("<div name='load' class='loading'></div>").append(loadingHtml));
		}
	},
	stopLoading :function() {
		if(this.isInDevice()) { 
			canceHUD();
		} else {
			$("div[name='load']").remove();
		}
	},
	closeAlert :function(){
		$("div[name='alertMsg']").animate({opacity:0},100,function(){
			$(this).remove();
		});
	},
	toHashUrl : function(hash) {
		window.location.hash = hash;
	},
	
	toPage : function(pageName) {
		window.location.href = pageName;
	},
	markStr : function(str,frontLen,endLen) {
	    var len = str.length-frontLen-endLen;
	    var xing = '';
	    for (var i=0;i<len;i++) {
	        xing+='*';
	    }
	    return str.substr(0,frontLen)+xing+str.substr(str.length-endLen);
	},
	setStorage : function(key,value) {
		sessionStorage.setItem(SGEnv.storagePre + key, value);
	},
	getStorage : function(key) {
		return sessionStorage.getItem(SGEnv.storagePre + key);
	},
	
	setStorageTimer : function(key,value) {
		var currentTime = new Date().getTime();
		var expiredTime = currentTime + (1000 * 60 * SGEnv.storageTime);
		var dataObj = {
				"expiredTime" : expiredTime,
				"data" : value
		};
		this.setStorage(key,JSON.stringify(dataObj));
	},
	
	getStorageTimer : function(key,checkTimeFlag) {
		var value = this.getStorage(key);
		if(value) {
			value = JSON.parse(value);
			
			if(checkTimeFlag == false) return value.data;
			
			var currentTime = new Date().getTime();
			if(currentTime - value.expiredTime > 0) {
				return null;
			} else {
				return value.data;
			}
		} else {
			return null;
		}
	},
	
	delStorage: function(key) {
		sessionStorage.removeItem(SGEnv.storagePre + key);
	},
	
	checkHasSpace : function(str) {
		var arr = str.split(" ");
		if(arr.length != 1){
		　　return false;
		} else {
		  return true;
		}
	},
	isTel : function isTel(s) {
        var patrn = /^((\+?86)|(\+86))?\d{3,4}-\d{7,8}(-\d{3,4})?$/  
        if (!patrn.exec(s)) return false  
        return true  
        
    },
    isMobile: function isMobile(value) {  
        var validateReg = /^((\+?65)|(\+65)|(\+?86)|(\+86))?[0-9]\d{7,10}$/;  
          // var validateReg = /^1\d{10}$/;
        return validateReg.test(value);  
    },  
	isEmail : function isEmail(mail) {  
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
	    if (filter.test(mail)) {  
	        return true;   
	    } else {  
	        return false;  
	    }   
	},
	strToDate : function(dateStr) {
		if(dateStr == "") return "";
		var dateArr = dateStr.split("-");
		return new Date().setFullYear(dateArr[2],dateArr[1],dateArr[0]);
	},
	getPageHash() {
		return window.location.hash;
	},
	setDatePicker($dataSelector) {
		var now = new Date();
	 	var currYear = now.getFullYear();	
		var opt={};
		opt.date = {preset : 'date'};
		opt.datetime = {preset : 'datetime'};
		opt.time = {preset : 'time'};
		opt.default = {
			dateFormat : 'dd-mm-yy',
			theme: 'android-ics light', //皮肤样式
	        display: 'bottom', //显示方式 
	        mode: 'scroller', //日期选择模式
	        //startYear:'1990', //开始年份
	        dateWheels : 'dd MM yy',
	        maxDate: new Date(now.getFullYear(), now.getMonth(), (now.getDate()))
		};
		$dataSelector.val('').scroller('destroy').scroller($.extend(opt['date'], opt['default']));
	},
	getUrlFilePath : function() {
		var hash = window.location.hash;
		var isHashUrl = ""
		hash ? isHashUrl = true : isHashUrl = false;
		var path = window.location.pathname;
		var splitArr = path.split("/");
		if(isHashUrl) {
			return splitArr[splitArr.length-1] + hash;
		} else {
			return splitArr[splitArr.length-1];
		}
	},
	browser : {
		 versions:function(){
		        var u = navigator.userAgent, app = navigator.appVersion;
		        return {
		            trident: u.indexOf('Trident') > -1, //IE内核
		            presto: u.indexOf('Presto') > -1, //opera内核
		            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
		            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
		            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
		            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
		            android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
		            iPhone: u.indexOf('iPhone') > -1 , //是否为iPhone或者QQHD浏览器
		            iPad: u.indexOf('iPad') > -1, //是否iPad
		            webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
		            weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
		            qq: u.match(/\sQQ/i) == " qq" //是否QQ
		        };
		    }(),
		    language:(navigator.browserLanguage || navigator.language).toLowerCase()
	},
	isInDevice : function() {
		var appEnv = this.getAppEnv();
		if(SGUtil.browser.versions.mobile && appEnv !== null) {
			return true;
		} else {
			return false;
		}
	},
	isSetOtpTime : function isSetOtpTime(otpPageStore,SGOtpPage) { 
		var resendTimeVal = 20;// SGOtpPage.getResendTimeSpan().text();
		var timer = window.setInterval(function(){
			resendTimeVal = resendTimeVal - 1;
			SGOtpPage.getResendTimeSpan().text(resendTimeVal);
			if(resendTimeVal == 0){
				clearInterval(timer);
				SGOtpPage.getResendTimeSpan().text("20");
				resendTimeVal = 20;
				SGOtpPage.getResendBtn().off("click").on("click",function(){	
					SGOtpPage.getResendTimeSpan().text("20");
					resendTimeVal = 20;				
					
					var data = {
							"phoneNumber" : otpPageStore
					};
					
					SGService.sendOTPService(true,data,function(data){
						otpPageStore['otpTokenUUID'] = data.data.otpTokenUUID;
						//SGFPStore['otpTokenUUID'] = data.data.otpTokenUUID;
					},function(data){
						SGUtil.alert(data.message);
						return;
					});

					SGOtpPage.resendOtpAction();
				})

				SGOtpPage.getResendTimeSpan().text("");
			}
		},1000);

	},
	getQueryString : function(name) {
		 var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	     var r = window.location.search.substr(1).match(reg);
	     if(r!=null)return  unescape(r[2]); return null;
	},
	getAppEnv : function() {
		return window.localStorage.getItem("appEnv");
	},
	setAppEnv : function() {
		var appEnv = this.getQueryString("appEnv");
		if(appEnv != null) {
			window.localStorage.setItem("appEnv",appEnv);
		} 
	},
	setExpandFirst : function (elementid){
		if($("#"+elementid+"").length == 0) return ;
		new $.fn.collapse.Constructor($("#"+elementid+"")).toggle(); 
	},
	showNotDataMsg : function () {
		var notDataMsg = '<div name="notDataMsg" style="width: 200px;  height: 100px; position: absolute;  text-align: center;  left:0; right:0; top: 0; bottom: 0; margin: auto;">' +
	  					'<span style="font-size:28px; color: #BFBFBF; text-shadow:  0.1em 0.1em 0.2em #DEDEDE;">No Data Found</span>' +
	  					'</div>';
		$("body").remove("div[name='notDataMsg']").append($(notDataMsg));
	},
	fmoney : function (s, n) { //s:传入的float数字 ，n:希望返回小数点几位
		n = n > 0 && n <= 20 ? n : 2; 
		s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + ""; 
		var l = s.split(".")[0].split("").reverse(), 
		r = s.split(".")[1]; 
		t = ""; 
		for(i = 0; i < l.length; i ++ ) { 
			t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : ""); 
		} 
		return t.split("").reverse().join("") + "." + r; 
	}
};





var SGRoute = {
		routes : {},
		defaultRoute : "",
		allroutes : function() {
            var route = window.location.hash.slice(2);
            var sections = $('section');
            var section;
            section = sections.filter('[data-route=' + route + ']');
            if (section.length) {
            	//set Nav
               pageNavRoute.setMenuNav();	
               //sections.hide(0);
               //section.show(0);
               sections.fadeOut(0);
               section.fadeIn(200);
            }
        },
		init : function() {
			 var _that = this;
		     var router = Router(this.routes);
		     router.configure({
		    	 on: this.allroutes,
		    	 notfound : function() {
		    		 if(_that.defaultRoute) {
		    			 window.location.hash = _that.defaultRoute;
		    		 }
		    		
		    	 }
		     });
		     router.init();
		}
};

