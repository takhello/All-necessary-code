function setCircularCharData() {
	if (window.circularChartData) {
			var t = {
				credits: {
					enabled: !1
				}
			};
			Highcharts.setOptions(t);
			for (var e = 0; e < window.circularChartData.length; e++) {
				for (var a = window.circularChartData[e], i = [], n = [], s = 0; s < a.graphData.length; s++) {
					var r = a.graphData[s];
					i.push(r.category),
					n.push({
						value: r.value,
						color: r.colour
					})
				}
				var o = [],
				l = n.length;
				for (s = 0; l > s; s += 1) o.push({
					name: i[s],
					y: n[s].value,
					color: n[s].color
				});
				var d = "",
				c = "";
				a.text && (a.text.main && (d = a.text.main), a.text.secondary && (c = a.text.secondary)),
				a.hideLegendOnSmall === !0 && (console.log("circular-chart.js hide : ", a.chartId), $("#" + a.chartId).addClass("no-legend")),
				window.chart = Highcharts.chart(a.chartId, {
					chart: {
						type: "pie",
						animation: !1,
						marginBottom: 30,
						spacing: [10, 10, 0, 10]
					},
					subtitle: {
						text: c,
						align: "center",
						verticalAlign: "middle",
						y: 0,
						useHTML: !1,
						style: {
							color: "#554344"
						}
					},
					title: {
						text: d,
						align: "center",
						verticalAlign: "middle",
						y: -17,
						style: {
							"font-family": "AIATitle",
							color: "#554344"
						},
						useHTML: !1
					},
					yAxis: {
						title: {
							text: "Total percent market share"
						}
					},
					legend: {
						layout: "vertical",
						align: "center",
						verticalAlign: "bottom",
						enabled: !1,
						itemStyle: {
							"font-size": "14px",
							"font-family": "AIABody",
							"font-weight": "normal",
							color: "#554344"
						},
						labelFormatter: function() {
							return '<span style="font-size: 15px;font-weight:bold;">' + this.y + "% </span>" + this.name
						},
						padding: 14,
						itemMarginTop: 4,
						itemMarginBottom: 4
					},
					plotOptions: {
						pie: {
							shadow: !1,
							center: ["50%", "50%"],
							allowPointSelect: !0,
							cursor: "pointer",
							slicedOffset: 0,
							borderWidth: 3,
							dataLabels: {
								softConnector: !1,
								enabled: !0,
								connectorWidth: 2
							},
							showInLegend: !1
						}
					},
					tooltip: {
						useHTML: !0,
						backgroundColor: "rgba(247,247,247,1)",
						headerFormat: '<span class="bt9 chart-tooltip-title margin-bottom-xs block">{point.key} ({point.y}%)</span>',
						valueSuffix: "%",
						pointFormatter: function() {
							return "<span class='chart-tooltip bt4'><span>Pct. of Portfolio: 50%</span><span class='bt4'>Total Assets: $35,234</span><span class='bt4'>Year to Date: +4.34%</span></span> "
						}
					},
					series: [{
						name: a.segmentTitle || "",
						data: o,
						size: "80%",
						innerSize: "pie" === a.chartType ? "0%": "70%",
						animation: !1,
						dataLabels: {
							style: {
								fontSize: "14px",
								fontFamily: "AIABody",
								fontWeight: "normal",
								color: "#554344"
							},
							formatter: function() {
								return '<span style="font-size: 15px;font-weight:bold;">' + this.y + "% </span>" + this.point.name
							}
						}
					}],
					responsive: {
						rules: [{
							condition: {
								maxWidth: 568
							},
							chartOptions: {
								title: {
									verticalAlign: "top",
									y: 75,
									style: {
										"font-size": "24px"
									}
								},
								subtitle: {
									verticalAlign: "top",
									y: 90
								},
								plotOptions: {
									pie: {
										center: ["50%", "75px"],
										dataLabels: {
											enabled: !1
										},
										showInLegend: a.hideLegendOnSmall ? !1 : !0
									}
								},
								legend: {
									enabled: !0,
									floating: !0
								},
								series: [{
									size: "150px"
								}]
							}
						}]
					}
				})
			}
		}
}
