/**
 * Created by louischen on 2017/5/4.
 */


//var JSBridge = {};

/*
  显示指纹
  callback 回调方法
 */
function showTouchID(callback){
    JSBridge.mutualJSApp('VerifyFingerprint',function(json){
       callback(json)
    });
}

function closeTouchID(){
    JSBridge.jsToApp('CloseFingerprint');
}

/*
 指纹是否存在
 callback 回调方法
 */
function touchIDStatus(callback){
    JSBridge.mutualJSApp('FPStatus',function(json){
        callback(json)
    });
}

/*
 保存密码
 */
function savePassword(json){
    JSBridge.jsToAppValue('SavePassword',json);
}

/*
 取出密码
 */
function  retrievePassword(callback){
    JSBridge.mutualJSApp('RetrievePassword',function(json){
       callback(json)
    });
}

/*
 清空密码
 */
function removePassword(callback){
    JSBridge.mutualJSApp('RemovePassword',function(json){
        callback(json);
    });
}

/*
 调用原生弹窗
 */
function alertClick(str) {
    JSBridge.jsToAppValue('ViewAlert',str);
}

/*
 进度条显示
 */
function showHUD() {
    JSBridge.jsToApp('ShowDialog');
}

function showHUD(msg) {
    JSBridge.jsToApp('ShowDialog',msg);
}

/*
 进度条取消
 */
function canceHUD() {
    JSBridge.jsToApp('DismissDialog');
}

/*
 下载pdf文件
 */
function downDocmentPdf(json,callback) {
    JSBridge.mutualJSAppValue('DownloadPDF',json,function(json){
        callback(json);
    });
}

/*
 显示pdf文件
 */
function showDocumentPdf(json){
    JSBridge.jsToAppValue('OpenPDF',json);
}

/*
  判断是否存在pdf文件
 */
function viewDoucmentPdf(json,callback){
    JSBridge.mutualJSAppValue('IsPdfExist',json,function(json){
        callback(json);
    });
}

/*
移除pdf文件
*/
function removeDocumentPdf(json){
   JSBridge.jsToAppValue('RemovePDF',json);
}


/*
图标显示状态
*/
function showPageAct(json){
   JSBridge.jsToAppValue('PageAct',json);
}


function showUserName(custName){
	var json = {
		"user" : custName	
	};
    JSBridge.jsToAppValue('UserName',json);
}

/**
 * 取出保存的id,在指纹登录上显示
 */
function getEnabledFpId(callback){
    JSBridge.mutualJSApp('EnabledFpId',function(json){
        callback(json)
    });
}

/**
 * 启用计时器
 */
function startTokenTimer(json){
	JSBridge.jsToAppValue('StartTokenTimer',json);
}

/**
 * 停用计时器
 */
function stopTokenTimer(){
    JSBridge.jsToApp('StopTokenTimer');
}

/**
 * 关闭菜单
 */
function disableMenu(){
    JSBridge.jsToApp('DisableMenu');
}

/**
 *  显示账号是否开启指纹
 */
function touchIDIsFpEnabled(json,callback){
    JSBridge.mutualJSAppValue('IsFpEnabled',json,function(callJson){
        callback(callJson);
    });
}



function jwtExpiredHandler() {
	disableMenu();
	var urlPath =$.trim(SGUtil.getUrlFilePath());
	if(urlPath == "login.html#/index" ||  urlPath == "login.html#/fingerprintlogin") {
		return ;
	}
	SGUtil.alert("Your session has expired. Please log in again.",function(){
		SGUtil.toPage("login.html#/index");
	});
}
