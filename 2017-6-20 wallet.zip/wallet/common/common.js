

var SGService = {
	getPreLogonService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.preLogonService,"POST",datas,isLoading,successCB,errorCB);
	},
	loginVerifyService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.loginVerifyService,"POST",datas,isLoading,successCB,errorCB);
	},
	verifyOTPService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.verifyOTPService,"POST",datas,isLoading,successCB,errorCB);
	},
	getCaptchaService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getCaptchaService,"POST",datas,isLoading,successCB,errorCB);
	},
	verifyStepSimpleService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.verifyStepSimpleService,"POST",datas,isLoading,successCB,errorCB);
	},
	verifyStepDetailService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.verifyStepDetailService,"POST",datas,isLoading,successCB,errorCB);
	},
	sendOTPService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.sendOTPService,"POST",datas,isLoading,successCB,errorCB);
	},
	verifyOtpAndResetPwdService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.verifyOtpAndResetPwdService,"POST",datas,isLoading,successCB,errorCB);
	},
	getDocumentListService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getDocumentListService,"POST",datas,isLoading,successCB,errorCB);
	},
	changePwdService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.changePwdService,"POST",datas,isLoading,successCB,errorCB);
	},
	resetPwdService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.resetPwdService,"POST",datas,isLoading,successCB,errorCB);
	},
	sendMailService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.sendMailService,"POST",datas,isLoading,successCB,errorCB);
	},
	checkAvaiablePDFService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.checkAvaiablePDFService,"POST",datas,isLoading,successCB,errorCB);
	},
	generateDocumentService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.generateDocumentService,"POST",datas,isLoading,successCB,errorCB);
	},
	checkAvaiablePDFListService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.checkAvaiablePDFListService,"POST",datas,isLoading,successCB,errorCB);
	},
	getProfileDetailService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getProfileDetailService,"POST",datas,isLoading,successCB,errorCB);
	},
	getPolicyListService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getPolicyListService,"POST",datas,isLoading,successCB,errorCB);
	},
	getAgentListService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getAgentListService,"POST",datas,isLoading,successCB,errorCB);
	},
	getPolicyDetailService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getPolicyDetailService,"POST",datas,isLoading,successCB,errorCB);
	},	
	verifyforgetOTPService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.verifyforgetOTPService,"POST",datas,isLoading,successCB,errorCB);
	},
	getRewardsListService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getRewardsListService,"POST",datas,isLoading,successCB,errorCB);
	},
	getVatalityService : function(isLoading,datas,successCB,errorCB) {
		SGUtil.ajax(SGApi.getVatalityService,"POST",datas,isLoading,successCB,errorCB);
	}
};

function logout() {
	sessionStorage.clear();
	SGUtil.toPage("login.html#/index");
}

/**
 * Nav Handler
 * **/
function clickNavButton(json){
	
	var actionState = json.action;
	
	if(actionState == "0" || actionState == "1") {
		return ;
	}
	
	var currentPagePath = SGUtil.getUrlFilePath();
	var navRoteObjectAttr =  navConfigMap[currentPagePath];
	pageNavRoute.navAction(navRoteObjectAttr);

}

/**
 * bootstrap Expand plugin 
 * **/
function setExpandText() {
	$.fn.collapse.Constructor.prototype.toggle = function () {
	 	  if(this.$element.hasClass('in')) {
	 		  this.$element.parent().find("p.item-expand").html("Expand");
	 	  } else {
	 		  this.$element.parent().find("p.item-expand").html("Close");
	 	  }
	 	  this[this.$element.hasClass('in') ? 'hide' : 'show']();
	 }
}

//set evn config
;(function(){
	SGUtil.setAppEnv();
	SGEnv.setApiRoot();
	//$("body").append("Env: <span>"+ SGUtil.getAppEnv() +"</span></br>");
	//$("body").append("URL: <span>"+ SGEnv.getApiRoot() +"</span>");
	pageNavRoute.setMenuNav();
	FastClick.attach(document.body);
	setExpandText();
	$("input").attr("autocomplete","off");
	console.log("api root now is..." + SGEnv.apiRoot);
})();



