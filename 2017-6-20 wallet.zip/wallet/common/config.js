
var SGEnv = {
	storagePre : "wallet-",
	jwtHeader : "jwt",
	storageTime : 5,  //minute,sessionTimeOut 
	localDev : "http://localhost:9090",
	AEMDev: "http://hkgdcdlapp010:4502",
	AEMSit : "http://hkgdcdlapp010:4503",
	serviceSitUrl : "http://10.121.111.36:9080/sg-wallet",
	serviceUatUrl : "http://sincmulapp01:9080/sg-wallet",
	serviceProdUrl : "",
	apiRoot : "",     //http://10.121.111.36:9080/sg-wallet
	setApiRoot : function() {
		if(SGUtil.isInDevice()) {  //device model
			if(SGUtil.getAppEnv() == "DEV") {
				this.apiRoot = "http://10.65.3.132:8080/sg-wallet";
				return ;
			} else if(SGUtil.getAppEnv() == "SIT") {
				this.apiRoot = this.serviceSitUrl;
				return ;
			} else if(SGUtil.getAppEnv() == "UAT"){
				this.apiRoot = this.serviceUatUrl;
				return ;
			} else if(SGUtil.getAppEnv() == "PROD") {
				
			}
		} else {
			var hostPath = SGUtil.getHostPath();
			if(hostPath == this.localDev) {
				this.apiRoot = "http://10.65.3.132:8080/sg-wallet";
				return ;
			} else if(hostPath == this.AEMDev || hostPath == this.AEMSit) {
				this.apiRoot = this.serviceSitUrl;
				return ;
			}
			//UAT PROD pending..
		}
	},
	getApiRoot : function() {
		//this.setApiRoot();
		//alert("api root.." + this.apiRoot);
		return this.apiRoot;
	}
};

var SGApi = {
	"preLogonService" : "/wallet/auth/preLogonService",
	"loginVerifyService" : "/wallet/auth/verifyService",
	"verifyOTPService" : "/wallet/auth/verifyOTP",
	"getCaptchaService" : "/wallet/register/getCaptcha",
	"verifyStepSimpleService" : "/wallet/register/verifyStepSimple",
	"verifyStepDetailService" : "/wallet/register/verifyStepDetail",
	"sendOTPService" : "/wallet/register/sendOTP",
	"verifyOtpAndResetPwdService" : "/wallet/register/verifyOtpAndResetPwd",
	"getDocumentListService" : "/wallet/eDoc/getDocumentList",
	"changePwdService" : "/wallet/setting/changePwd",
	"resetPwdService" : "/wallet/setting/forgetPwdVerifyAndSendOTP",	//resetPwd
	"verifyforgetOTPService" : "/wallet/setting/verifyOTPAndResetPwd",		//verifyOTPAndResetPwd
	"sendMailService" : "/wallet/setting/sendEmail",
	"checkAvaiablePDFService" : "/wallet/eDoc/checkAvaiablePDF",
	"generateDocumentService" : "/wallet/eDoc/generateDocument",
	"checkAvaiablePDFListService" : "/wallet/eDoc/checkAvaiablePDFList",
	"getProfileDetailService" : "/wallet/profile/getProfileDetail",
	"getPolicyListService" : "/wallet/policy/getPolicyList",
	"getAgentListService" : "/wallet/agent/getAgentList",
	"getPolicyDetailService" : "/wallet/policy/getPolicyDetail",
	"getRewardsListService" : "/wallet/rewards/getRewardList", 	//rewardList
	"getVatalityService" : "/wallet/vitality/getVitality"
};

var navConfigMap = {
		"login.html#/fingerprintlogin" : "fingerLogin",
		"registration.html#/notice" : "signNotice",
		"registration.html#/signup" : "signUp",
		"registration.html#/signupExpand" : "signupExpand",
		"registration.html#/signupinputpwd" : "signUpInputPwd",
		"registration.html#/signupotp" : "signUpOtp",
		"registration.html#sussessful" : "signUpSussessful",
		"registration.html#/askemail" : "signAskEmail",
		"landing.html#/policyList" : "policyList",
		"forgotpassword.html#/index" : "forgotPwd",
		"profile.html" : "profile",
		"changepassword.html#/index" : "cpwdIndex",
		"changepassword.html#/newpwd" : "cpwdNewPwd",
		"changepassword.html#/otp" : "cpwdOtp",
		"edoc.html#/eDocList" : "eDocList",
		"edoc.html#/eDocDownload" : "eDocDownload",
		"enablefinger.html#/t_and_c" : "enFingerTAC",
		"enablefinger.html#/authenPwd" : "enFingerAuthPwd",
		"enablefinger.html#/enablefingrtotp" : "enFingerOtp",
		"enablefinger.html#/ok" : "enFingerOk",
		"policydetails_a_traditional.html" : "traditionalDetail",
		"policydetails_b_investment.html" : "investmentDetail",
		"policydetails_c_annuity.html" : "annuityDetail",
		"policydetails_d_hospitalization.html" : "hospitalizationDetail",
		"policydetails_e_others.html" : "othersDetail",
		"agent.html" : "agent",
		"terms_of_use.html" : "termsForLogin",
		"landing.html#/rider" : "landingRider",
		"rewards.html" : "rewards",
		"policydetail_hosp_coverageList.html" : "hospCoverList"
};

//page nav route
var pageNavRoute =  {
	"landingRider" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard" 
	},
		
	"traditionalDetail" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard"
	}, 	
	
	"investmentDetail" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard"
	}, 	
	"annuityDetail" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard"
	}, 
	"hospitalizationDetail" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard"
	}, 	
	"othersDetail" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Dashboard"
	}, 	
	"fingerLogin" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/index",
		toUrlBefore : function() {
			closeTouchID();
		},
		title : "Login"
	},
	"signNotice" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "login.html#/index",
		title : "Registration"
	},
	
	"signUp" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/notice",
		title : "Registration"
	},
	
	"signupExpand" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/signup",
		title : "Registration"
	},
	
	"signUpInputPwd" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/signup",
		title : "Registration"
	},
	
	"signUpOtp" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/signupinputpwd",
		title : "Registration"
	},

	"signUpSussessful" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/sussessful",
		title : "Registration"
	},
	"signAskEmail" : {
		menuType : "3",
		isSinglePageNavUrl : false,
		toUrl : "landing.html#/policyList",
		title : "Send Mail"
	},
	
	"policyList" : {
		menuType : "1",
		title : "Dashboard" 
	},
	
	"termsForLogin" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "login.html#/index",
		title : "Login"
	},
	
	"forgotPwd" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "login.html#/index",
		title : "Forgot Password"
	},
	
	"profile" : {
		menuType : "1",
		title : "Profile"
	},
	
	"cpwdIndex" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "profile.html",
		title : "Change Password"
	},
	
	"cpwdNewPwd" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/index",
		title : "Change Password"
	},
	
	"cpwdOtp" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/newpwd",
		title : "Change Password"
	},
	
	"eDocList" : {
		menuType : "1",
		title : "E-Document"
	},
	
	"eDocDownload" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/eDocList",
		title : "E-Document"
	},
	
	"enFingerTAC" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "profile.html",
		title : "Finger Setting"
	},
	
	"enFingerAuthPwd" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/t_and_c",
		title : "Finger Setting"
	},
	
	"enFingerOtp" : {
		menuType : "2",
		isSinglePageNavUrl : true,
		toUrl : "#/authenPwd",
		title : "Finger Setting"
	},
	
	"enFingerOk" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "profile.html",
		title : "Finger Setting"
	},
	
	"agent" : {
		menuType : "1",
		title : "Agent"
	},
	
	"rewards" : {
		menuType : "1",
		title : "Rewards"
	},
	
	"hospCoverList" : {
		menuType : "2",
		isSinglePageNavUrl : false,
		toUrl : "policydetails_d_hospitalization.html",
		title : "COVERAGE"
	},
	
	navAction : function(attr) {
		var attrObj =  pageNavRoute[attr];
		var isSinglePageNavUrl = attrObj.isSinglePageNavUrl;
		var toUrl = attrObj.toUrl;
		attrObj.toUrlBefore && attrObj.toUrlBefore();
		if(isSinglePageNavUrl) {
			SGUtil.toHashUrl(toUrl);
		} else {
			SGUtil.toPage(toUrl);
		}
	},
	setMenuNav : function() {
		var currentPagePath = SGUtil.getUrlFilePath();
		var navRoteObjectAttr = navConfigMap[currentPagePath];
		if(navRoteObjectAttr) {
			var menuType = pageNavRoute[navRoteObjectAttr].menuType;
			var title = pageNavRoute[navRoteObjectAttr].title;
			showPageAct({"action":menuType,"title":title});
		} else {
			showPageAct({"action":0,"title":"Login"});
		}
	}
};