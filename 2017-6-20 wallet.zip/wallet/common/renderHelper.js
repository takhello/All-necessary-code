~$(function(){
	$.views.helpers({
		policyTypeImg: function(policyType) {
			policyType = $.trim(policyType);
			if(policyType == "Critical Illness Protection") {
				return "criticalillnesspro-prime1.png";
			} else if(policyType == "Disability Income Protection") {
				return "disability-prime1.png";
			} else if(policyType == "Savings"){
				return "savings-prime1.png";
			} else if(policyType == "Life Protection") {
				return "lifepro-prime1.png";
			} else if(policyType == "Investments") {
				return "investment-prime1.png";
			} else if(policyType == "Accident Protection") {
				return "accidentpro-prime1.png";
			} else if(policyType == "Platinum") {
				return "lifetime-prime1.png";
			} else if(policyType == "Medical Protection") {
				return "medicalpro-prime1.png";
			} else if(policyType == "Travel and Lifestyle") {
				return "travel_insurance-prime1.png";
			}
		},
		coverPolicyStatusClass : function(policyStatus) {
			var policyStatus = $.trim(policyStatus);
			if(policyStatus == "Inforce") {
				return "status status-good";
			} else if(policyStatus == "Lapsed"){
				return "status status-pending";
			} else if(policyStatus == "Terminated") {
				return "status status-error";
			}
		},
		trimStr: function(str) {
			return $.trim(str);
		},
		coverCurrency : function(currency) {
			var currency = $.trim(currency);
			if(currency == "SGD") {
				return "S$";
			} else if(currency == "BND") {
				return "B$";
			} else if(currency == "AUD") {
				return "A$";
			} else if(currency == "USD") {
				return "US$";
			} else if(currency == "GBP") {
				return "£";
			} else if(currency == "CAD") {
				return "C$";
			}
		},
		fmMoneny : function(money) {
			if(isNaN(money)) {
				return money;
			}
			var money = SGUtil.fmoney(money,2);
			return money;
		}
});
})


