var SGEnableStore = {
		"NRIC" : "",
		"otpTxtPhone" : "",
		"otpTokenUUID" : "",
		"password" : ""
};


var SGAuthenPwdPage = {
	getCustIdSpan : function() {
		return $("span[name='custId']");
	},
	
	setCustIdText : function(custId) {
		this.getCustIdSpan().html(custId);
	},
	
	getAuthenPwdInput : function() {
		return $("input[name='authenPwd']");
	},
	getAuthenPwdCtnBtn : function() {
		return $("button[name='authenPwdCtnBtn']");
	},
	getAuthenPwdCcBtn : function() {
		return $("button[name='authenPwdCcBtn']");
	},
	
	setAuthenPwdCtnBtnOn : function() {
		this.getAuthenPwdCtnBtn().removeAttr("disabled");
	},
	
	setAuthenPwdCtnBtnOff : function() {
		this.getAuthenPwdCtnBtn().attr("disabled","disabled");
	},
	
	verifAuthenAction :function(){
		
		var password = $.trim(this.getAuthenPwdInput().val());
		if(password==""){
			SGUtil.alert("Please input authen Password !");
			return "";
		}
		
		SGAuthenPwdPage.setAuthenPwdCtnBtnOff();
		SGService.getPreLogonService(true,{},function(data){
				var publicKey =  data.data.publicKey;
				var randomNum = data.data.randomNum;
				var sessionId = data.data.sessionId;
				var encryPwd = encryPassword(password,publicKey,randomNum,sessionId);
				var loginData = {
					"custId" : 	SGUtil.getStorage("custId"),
					"rpin" : encryPwd,
					"sessionId" : sessionId
				};
				SGService.loginVerifyService(true,loginData,function(data){
					SGEnableStore["NRIC"] = SGUtil.getStorage("custId");
					SGEnableStore["otpTxtPhone"] = data.data.otpTxtPhone;
					SGEnableStore["otpTokenUUID"] = data.data.otpTokenUUID;
					SGEnableStore['password']  = password;
					SGAuthenPwdPage.setAuthenPwdCtnBtnOn();
					SGUtil.toHashUrl("#/enablefingrtotp");
				},function(data){
					SGAuthenPwdPage.setAuthenPwdCtnBtnOn();
					SGUtil.alert(data.message);
					return;
				})
		},function(data){
				SGAuthenPwdPage.setAuthenPwdCtnBtnOn();
				SGUtil.alert(data.message);
		});
		
	},
	initPage : function() {
		
		this.setCustIdText(SGUtil.getStorage("custId"));
		
		this.getAuthenPwdCtnBtn().off("click").on("click",function(){
			SGAuthenPwdPage.verifAuthenAction();
		});

		this.getAuthenPwdCcBtn().off("click").on("click",function(){
			SGUtil.toHashUrl("#/t_and_c");
		});
    }
};

var SGAuthenOtpPage = {
	
	getOtpPwdInput : function() {
		return $("input[name='otpPwd']");
	},
	getOtpVerifyBtn : function(){
		return $("button[name='optVerifyBtn']");
	},
	
	setOtpVerifyBtnOn : function() {
		this.getOtpVerifyBtn().removeAttr("disabled");
	},
	
	setOtpVerifyBtnOff : function() {
		this.getOtpVerifyBtn().attr("disabled","disabled");
	},
	
	getOtpCancleBtn :function(){
		return $("button[name='otpCancleBtn']");
	},
	getResendBtn : function() {
		return  $("p[name='resend']");
	},
	getResendTimeSpan : function() {
		return  $("span[name='resendTime']");
	},
	resendOtpAction : function() {
		this.getResendBtn().off("click");
		//service

		SGUtil.isSetOtpTime(SGEnableStore['otpTxtPhone'],SGAuthenOtpPage);

	},
	verifyOtpAuthenAction : function() {
		var otpInputPwd = $.trim(this.getOtpPwdInput().val());
		if(otpInputPwd == "") {
			SGUtil.alert("Please input OTP password!");
			return "";
		}
		
		this.setOtpVerifyBtnOff();
		var optVerifyData = {
				"custId" : SGEnableStore.NRIC,
				"otpPassword" : otpInputPwd,
				"otpTokenUUID" : SGEnableStore.otpTokenUUID
		};
		SGService.verifyOTPService(true,optVerifyData,function(data) {
			
			savePassword({
				"id" :  SGEnableStore['NRIC'],
				"pwd" : SGEnableStore['password']
			});
			
			SGAuthenOtpPage.setOtpVerifyBtnOn();
			SGUtil.toHashUrl("#/ok");
		},function(data){
			SGAuthenOtpPage.setOtpVerifyBtnOn();
			if(data.code == "92012") { //OTP error > 3
				SGUtil.alert(data.message,function(){
					SGUtil.toHashUrl("#/authenPwd");
				});
				return ;
			}
			if(data.message) {
				SGUtil.alert(data.message);
			}
			return ;
		})
	},
	initPage :function(){
		
		this.getOtpCancleBtn().off("click").on("click",function(){
			SGUtil.toHashUrl("#/t_and_c");
		});

		this.getOtpVerifyBtn().off("click").on("click",function(){
			SGAuthenOtpPage.verifyOtpAuthenAction();
		});
		
		this.resendOtpAction();

	}
};




$(function(){
	
	 //SGUtil.setStorage("custId","S3888440I");
	
     function t_and_cPageShow() {
    	 $("button[name='acceptBtn']").off("click").on("click",function(){
			SGUtil.toHashUrl("#/authenPwd");
		});
    	 $("button[name='cancelbtn']").off("click").on("click",function(){
			SGUtil.toPage("profile.html");
		});

     }
     
     function authenPwdPageShow() {
    	 SGAuthenPwdPage.initPage();
     }
     
     function enablefingrtotpPageShow(){
     	 SGAuthenOtpPage.initPage();
     }

     function okPageShow(){
    	 $("button[name='OKBtn']").off("click").on("click",function(){
    		 	SGUtil.toPage("profile.html");
    	 });
     }

     var routes = {
       '/t_and_c': t_and_cPageShow,
       '/authenPwd': authenPwdPageShow,
       '/enablefingrtotp' : enablefingrtotpPageShow,
       '/ok' : okPageShow
     };
     
     SGRoute.routes = routes;
     SGRoute.defaultRoute = "#/t_and_c";
     SGRoute.init();
     
     
 
     
     
});