
var SGOthersPage ={
		getBaseInfoTemplate : function() {
			return $("script[name='baseInfoTempl']");
		},
		getBaseInfoContainer : function() {
			return $("div[name='baseInfo']");
		},
		renderBaseInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='baseInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getBaseInfoTemplate().render(data));
		},
		
		getCardInfoTemplate : function() {
			return $("script[name='cardInfoTempl']");
		},
		getCardInfoContainer : function() {
			return $("div[name='cardInfo']");
		},
		renderCardInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='cardInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getCardInfoTemplate().render(data));
		},
		
		getPolicyFinancialTempl : function() {
			return $("script[name='policyFinancial']");
		},
		
		getPolicyFinnancialContainer : function() {
			return $("div[name='policyFinancialContainer']");
		},
		
		renderPolicyFinnancial : function(data) {
			this.getPolicyFinnancialContainer().children("script[name='policyFinancial']").siblings().remove();
			this.getPolicyFinnancialContainer().append(this.getPolicyFinancialTempl().render(data));
		},
		
		getPolicyRiderListTempl : function() {
			return $("script[name='policyRiderListTempl']");
		},
		
		getPolicyRiderListContainer : function() {
			return $("div[name='policyRiderListContainer']");
		},
		
		renderPolicyRider : function(data) {
			this.getPolicyRiderListContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getPolicyRiderListContainer().append(this.getPolicyRiderListTempl().render(data));
		},
		
		getCounponHistoryTempl : function() {
			return $("script[name='counponHistoryTempl']");
		},
		
		getCounponHistoryContainer : function() {
			return $("ul[name='counponHistory']");
		},
		
		renderCounponHistoryRider : function(data) {
			this.getCounponHistoryContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getCounponHistoryContainer().append(this.getCounponHistoryTempl().render(data));
		},
		
		getAgentTempl : function() {
			return $("script[name='agentTempl']");
		},
		
		getAgentContainer : function() {
			return $("div[name='agentContainer']");
		},
		
		renderAgent : function(data) {
			this.getAgentContainer().children("script[name='agentTempl']").siblings().remove();
			this.getAgentContainer().append(this.getAgentTempl().render(data));
		},
		
		
		getPolicyDetailAction : function() {
			var sendData = {
				"custId" : SGUtil.getStorage("custId"),
				"detailCategory":"Others",
				"policyNo":  SGUtil.getStorage("currentPolicyNo"),   // "L812345678",
				"agentNo":  SGUtil.getStorage("currentAgentNo")      //"0000054535",
			};
			
			
			SGService.getPolicyDetailService(true,sendData,function(data) {
				SGOthersPage.renderBaseInfo(data.data.baseInfo);
				SGOthersPage.renderCardInfo(data.data.cardInfo);
				SGOthersPage.renderPolicyFinnancial(data.data.financialInfo);
				SGOthersPage.renderPolicyRider(data.data.policyRiderList);
				//SGOthersPage.renderCounponHistoryRider(data.data.couponHistoryList);
				SGOthersPage.renderAgent(data.data.agent);
				
				
				$("div[name='policyInfoContainer']").show(1);
				$("div[name='footer']").show(1);

				SGUtil.setExpandFirst("collapse-major-illness0");
				
			},function(data){
				SGUtil.alert(data.message);
				return ;
			})
		}
};











$(function () {
	
	SGOthersPage.getPolicyDetailAction();
	
    svg4everybody();
 });
