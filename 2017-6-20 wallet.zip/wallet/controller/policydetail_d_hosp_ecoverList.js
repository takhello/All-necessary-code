

var SGECoverList ={
		getTemplate : function() {
			return $("script[name='eCoverageListTempl']");
		},
		getContainer : function() {
			return $("ul[name=riderContainer]");
		},
		renderCoverList : function(data) {
			this.getContainer().children("script[name='eCoverageListTempl']").siblings().remove();
			this.getContainer().append(this.getTemplate().render(data));
		}
};


$(function () {
	var data = SGUtil.getStorageTimer("eCoverListData");
	SGECoverList.renderCoverList(data);
});
  
  
