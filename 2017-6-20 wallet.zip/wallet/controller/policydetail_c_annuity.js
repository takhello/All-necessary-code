

var SGTraditionalPage ={
		getBaseInfoTemplate : function() {
			return $("script[name='baseInfoTempl']");
		},
		getBaseInfoContainer : function() {
			return $("div[name='baseInfo']");
		},
		renderBaseInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='baseInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getBaseInfoTemplate().render(data));
		},
		
		getCardInfoTemplate : function() {
			return $("script[name='cardInfoTempl']");
		},
		getCardInfoContainer : function() {
			return $("div[name='cardInfo']");
		},
		renderCardInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='cardInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getCardInfoTemplate().render(data));
		},
		
		getPolicyFinancialTempl : function() {
			return $("script[name='policyFinancial']");
		},
		
		getPolicyFinnancialContainer : function() {
			return $("div[name='policyFinancialContainer']");
		},
		
		renderPolicyFinnancial : function(data) {
			this.getPolicyFinnancialContainer().children("script[name='policyFinancial']").siblings().remove();
			this.getPolicyFinnancialContainer().append(this.getPolicyFinancialTempl().render(data));
		},
		
		getPolicyRiderListTempl : function() {
			return $("script[name='policyRiderListTempl']");
		},
		
		getPolicyRiderListContainer : function() {
			return $("div[name='policyRiderListContainer']");
		},
		
		renderPolicyRider : function(data) {
			this.getPolicyRiderListContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getPolicyRiderListContainer().append(this.getPolicyRiderListTempl().render(data));
		},
		
		getCounponHistoryTempl : function() {
			return $("script[name='counponHistoryTempl']");
		},
		
		getCounponHistoryContainer : function() {
			return $("ul[name='counponHistory']");
		},
		
		renderCounponHistoryRider : function(data) {
			this.getCounponHistoryContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getCounponHistoryContainer().append(this.getCounponHistoryTempl().render(data));
		},
		
		getAgentTempl : function() {
			return $("script[name='agentTempl']");
		},
		
		getAgentContainer : function() {
			return $("div[name='agentContainer']");
		},
		
		renderAgent : function(data) {
			this.getAgentContainer().children("script[name='agentTempl']").siblings().remove();
			this.getAgentContainer().append(this.getAgentTempl().render(data));
		},
		
		
		getPolicyDetailAction : function() {
			var sendData = {
				"custId" : SGUtil.getStorage("custId"),
				"detailCategory":"Aunnutiy",
				"policyNo":  SGUtil.getStorage("currentPolicyNo"),   // "L812345678",
				"agentNo":  SGUtil.getStorage("currentAgentNo")      //"0000054535",
			};
			
			//
			function render() {
				data = '{"success":true,"code":"0","message":"Get policy detail success!","detailMessage":"","data":{"currency":"SGD","baseInfo":{"policyName":"All Save","category":"Savings","detailCategory":"Annuities","policyNo":"L441234567","policyStatus":"Inforce","policyEffectiveDate":"04-10-2013","maturityDate":"04-10-2023","nominationMade":"NO","beneficiaryDetails":"BUILD AND HIDE, APP NOT SHOWING BENEFICIARY DETAILS","powerUpDollar":"0.00"},"cardInfo":{"singlePremium":"N","nextPremiumDueDate":"04-10-2023","netSurrenderValue":"0.00","annuityPayoutAmount":"1234.00","annuityPayoutAge":"65","annuityPayoutFrequency":"monthly","annuityPayoutEndDate":"31-08-2018"},"financialInfo":{"paymentMethod":"Cash/Cheque","frequencyOfPayment":"Annual","premiumEndDate":"04-10-2023","nettModalPremium":"0.00"},"policyRiderList":[{"benefitName":"All Save","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"3000000.00","premiumBreakdown":"1500.00","extraPremiums":"1500.00","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023","rider":"00"}],"couponHistoryList":[],"agent":{"agentName":"OMA CSKE HWEI MATTHED","agentTitle":"Appointed FSC","officePhone":"63496268","mobile":"91327147","email":"abc@uat1.com","managedPolicies":[]}}}';
				data = JSON.parse(data);
				SGTraditionalPage.renderBaseInfo(data.data.baseInfo);
				SGTraditionalPage.renderCardInfo(data.data.cardInfo);
				SGTraditionalPage.renderPolicyFinnancial(data.data.financialInfo);
				SGTraditionalPage.renderPolicyRider(data.data.policyRiderList);
				//SGTraditionalPage.renderCounponHistoryRider(data.data.couponHistoryList);
				SGTraditionalPage.renderAgent(data.data.agent);
				
				$("div[name='policyInfoContainer']").show(1);
				$("div[name='footer']").show(1);

				SGUtil.setExpandFirst("collapse-major-illness0");
			}
			render();
			
			
//			SGService.getPolicyDetailService(true,sendData,function(data) {
//				
//				data = '{"success":true,"code":"0","message":"Get policy detail success!","detailMessage":"","data":{"currency":"SGD","baseInfo":{"policyName":"All Save","category":"Savings","detailCategory":"Annuities","policyNo":"L441234567","policyStatus":"Inforce","policyEffectiveDate":"04-10-2013","maturityDate":"04-10-2023","nominationMade":"NO","beneficiaryDetails":"BUILD AND HIDE, APP NOT SHOWING BENEFICIARY DETAILS","powerUpDollar":"0.00"},"cardInfo":{"singlePremium":"N","nextPremiumDueDate":"04-10-2023","netSurrenderValue":"0.00","annuityPayoutAmount":"1234.00","annuityPayoutAge":"65","annuityPayoutFrequency":"monthly","annuityPayoutEndDate":"31-08-2018"},"financialInfo":{"paymentMethod":"Cash/Cheque","frequencyOfPayment":"Annual","premiumEndDate":"04-10-2023","nettModalPremium":"0.00"},"policyRiderList":[{"benefitName":"All Save","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"3000000.00","premiumBreakdown":"1500.00","extraPremiums":"1500.00","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023","rider":"00"}],"couponHistoryList":[],"agent":{"agentName":"OMA CSKE HWEI MATTHED","agentTitle":"Appointed FSC","officePhone":"63496268","mobile":"91327147","email":"abc@uat1.com","managedPolicies":[]}}}';
//				
//				SGTraditionalPage.renderBaseInfo(data.data.baseInfo);
//				SGTraditionalPage.renderCardInfo(data.data.cardInfo);
//				SGTraditionalPage.renderPolicyFinnancial(data.data.financialInfo);
//				SGTraditionalPage.renderPolicyRider(data.data.policyRiderList);
//				SGTraditionalPage.renderCounponHistoryRider(data.data.couponHistoryList);
//				SGTraditionalPage.renderAgent(data.data.agent);
//				
//				
//				$("div[name='policyInfoContainer']").show(1);
//				$("div[name='footer']").show(1);
//				
//			},function(data){
//				SGUtil.alert(data.message);
//				return ;
//			})
		}
};











$(function () {
	
	
	SGTraditionalPage.getPolicyDetailAction();
	
	
    svg4everybody();

 });
  
  
  