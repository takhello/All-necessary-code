

var SGInvestmentPage ={
		getBaseInfoTemplate : function() {
			return $("script[name='baseInfoTempl']");
		},
		getBaseInfoContainer : function() {
			return $("div[name='baseInfo']");
		},
		renderBaseInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='baseInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getBaseInfoTemplate().render(data));
		},
		
		getCardInfoTemplate : function() {
			return $("script[name='cardInfoTempl']");
		},
		getCardInfoContainer : function() {
			return $("div[name='cardInfo']");
		},
		renderCardInfo : function(data) {
			this.getBaseInfoContainer().children("script[name='cardInfoTempl']").siblings().remove();
			this.getBaseInfoContainer().append(this.getCardInfoTemplate().render(data));
		},
		
		getPolicyFinancialTempl : function() {
			return $("script[name='policyFinancial']");
		},
		
		getPolicyFinnancialContainer : function() {
			return $("div[name='policyFinancialContainer']");
		},
		
		renderPolicyFinnancial : function(data) {
			this.getPolicyFinnancialContainer().children("script[name='policyFinancial']").siblings().remove();
			this.getPolicyFinnancialContainer().append(this.getPolicyFinancialTempl().render(data));
		},
		
		getPolicyRiderListTempl : function() {
			return $("script[name='policyRiderListTempl']");
		},
		
		getPolicyRiderListContainer : function() {
			return $("div[name='policyRiderListContainer']");
		},
		
		renderPolicyRider : function(data) {
			this.getPolicyRiderListContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getPolicyRiderListContainer().append(this.getPolicyRiderListTempl().render(data));
		},
		
		getCounponHistoryTempl : function() {
			return $("script[name='counponHistoryTempl']");
		},
		
		getCounponHistoryContainer : function() {
			return $("ul[name='counponHistory']");
		},
		
		renderCounponHistoryRider : function(data) {
			this.getCounponHistoryContainer().children("script[name='policyRiderListTempl']").siblings().remove();
			this.getCounponHistoryContainer().append(this.getCounponHistoryTempl().render(data));
		},
		
		getAgentTempl : function() {
			return $("script[name='agentTempl']");
		},
		
		getAgentContainer : function() {
			return $("div[name='agentContainer']");
		},
		
		renderAgent : function(data) {
			this.getAgentContainer().children("script[name='agentTempl']").siblings().remove();
			this.getAgentContainer().append(this.getAgentTempl().render(data));
		},
		
		
		getPolicyDetailAction : function() {
			var sendData = {
				"custId" : SGUtil.getStorage("custId"),
				"detailCategory":"Investment Linked",	//Investment
				"policyNo":  SGUtil.getStorage("currentPolicyNo"),   // "LA12345678",
				"agentNo": SGUtil.getStorage("currentAgentNo")      //"0000054535",r555
			};
			
			
			SGService.getPolicyDetailService(true,sendData,function(data) {
				
				var cardInfo =  data.data.cardInfo;
				
				SGInvestmentPage.renderBaseInfo(data.data.baseInfo);
				SGInvestmentPage.renderCardInfo(cardInfo);
				SGInvestmentPage.renderPolicyFinnancial(data.data.financialInfo);
				SGInvestmentPage.renderPolicyRider(data.data.policyRiderList);
				//SGInvestmentPage.renderCounponHistoryRider(data.data.cardInfo.investmentDetailInfo);
				SGInvestmentPage.renderAgent(data.data.agent);
				
				$("div[name='policyInfoContainer']").css("visibility","visible");
				$("div[name='footer']").css("visibility","visible");
				$('ul.sub li:first a').removeClass("collapsed");


				
				var graphData = [];
				for(var i=0; i<cardInfo.percentageOfFunds.length; i++) {
					var value = parseInt(new Number(cardInfo.percentageOfFunds[i].value).toFixed(2));
					graphData.push({
						category: cardInfo.percentageOfFunds[i].key,
						value: value
					});
				}
				
				var graphDataObj = {
						chartId: 'donutchart',
						chartType: 'donut',
						segmentTitle: '% of total fund',
						text: {
							main: "$" + data.data.cardInfo.totalInvestmentValue,
							secondary: 'total growth'
						}
				}
				
				graphDataObj.graphData = graphData;
				
				window.circularChartData = [];
				
				window.circularChartData.push(graphDataObj);
				
				

				/***
				window.circularChartData =
					[{
						chartId: 'donutchart',
						chartType: 'donut',
						segmentTitle: '% of total fund',
						text: {
							main: "$711.120",
							secondary: 'total growth'
						},
						graphData: [{
							category: 'Fidelity Funds Euro Aggressive Fund',
							value: 80,
							colour: '#551893'
						}, {
							category: 'Lion Global Japan Growth Fund',
							value: 20,
							colour: '#E86487'
						}]
					}];
				***/
				
				setCircularCharData();


				SGUtil.setExpandFirst("collapse-major-illness0");
				
		
			},function(data){
				SGUtil.alert(data.message);
				return ;
			})
		}
};











$(function () {
	
	SGInvestmentPage.getPolicyDetailAction();
    svg4everybody();

 });
  
  
