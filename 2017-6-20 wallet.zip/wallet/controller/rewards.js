
var SGRewardsPage = {
	getRewardsTempl : function() {
		return $("script[name='rewardsTempl']");
	},
	getRewardsContainer : function() {
		return $("div[name='rewardsContainer']");
	},
	renderRewardsList : function(data) {
		if(JSON.stringify(data) == "{}") {
			SGUtil.showNotDataMsg();
			return ;
		}
		
		this.getRewardsContainer().children("script[name='rewardsTempl']").siblings().remove();
		var membership = data.membership;
		this.getRewardsContainer().append(this.getRewardsTempl().render(membership));
		for (prop in data){
			if(prop != "membership"){
				this.getRewardsContainer().append(this.getRewardsTempl().render(data[prop]));
			}
		}
	},
	getRewardsListAction : function() {
		var sendData = {
			"custId" : SGUtil.getStorage("custId")
		};
		
		//custId is null
		if(!sendData.custId) { 
			SGUtil.alert("Login failed, Please try again.");
			return;
		}
		
		SGService.getRewardsListService(true,sendData,function(data) {
			SGRewardsPage.renderRewardsList(data.data);
		},function(data){
			SGUtil.alert(data.message);
			return;
		});
	},
	initPage : function() {
		SGRewardsPage.getRewardsListAction();
	},
	alertRewardByMembership : function(_this){
		var merchantName = $.trim($(_this).attr("data-merchantName"));
		var discountInfo = $.trim($(_this).attr("data-discountInfo"));
		var merchantLogo = $.trim($(_this).attr("data-merchantLogo"));
		var RewardHtml="";
		RewardHtml+='<div class="container" style="margin-top: 30%;" >'
		RewardHtml+='<div class="block card-13 card-border-top-t5" style="padding: 24px 12px;margin-bottom: 20px;margin-top: 40%;">'
		RewardHtml+='<a href="javascript:void(0)">'
		RewardHtml+='<div class="row component-base">'
		RewardHtml+='<div class="col-xs-12">'
		RewardHtml+='<div class="">'
		RewardHtml+='<div class="thumbnail" style="margin-left: 10px;">'
		RewardHtml+='<img class="icon-fallback" src="/content/dam/reference/dls/dist/img/icons/lifepro-prime1.png">'
		RewardHtml+='</div>'
		RewardHtml+='<div class="content">'
		RewardHtml+='<div class="title">'
		RewardHtml+='<h5 class="" style="color: #D31145 ;">MEMBERSHIP</h5>';
		RewardHtml+='<h3 class="title-text margin-bottom-xs">'+merchantName+'</h3>';
		RewardHtml+='<p class="description"><span class="">'+discountInfo+'</span> </p>';
		//RewardHtml+='<div class="glyph-r-arrow">';
		//RewardHtml+='<img class="icon-fallback" src="/content/dam/reference/dls/dist/img/icons/arrow-2ndg.png">';
		//RewardHtml+='</div>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
		RewardHtml+='</a>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
	  	$("body").append($("<div name='alertReward' onclick='SGRewardsPage.closeAlertReward(this)' class='loading'></div>").append(RewardHtml));
	},
	/*alertRewardByNoMembership : function(_this){
		var merchantName = $.trim($(_this).attr("data-merchantName"));
		var discountInfo = $.trim($(_this).attr("data-discountInfo"));
		var merchantLogo = $.trim($(_this).attr("data-merchantLogo"));
		//console.log("merchantName:",merchantName,",discountInfo:",discountInfo,",merchantLogo:",merchantLogo);
		var RewardHtml="";
		RewardHtml+='<div class="container" style="margin-top: 40%;">'
		RewardHtml+='<div class="block card-4 card-border-top-t7">'
		RewardHtml+='<a href="javascript:void(0)">'
		RewardHtml+='<div class="content" style="position: static;display: block;width: 180px;margin-left: auto;margin-right: auto;margin-bottom: 20px; margin-top: 20px;">'
		RewardHtml+='<image class="icon-fallback" src="/content/dam/reference/dls/dist/img/icons/famous_amos.png"></image>'
		RewardHtml+='</div>'
		RewardHtml+='<div class="content">'
		RewardHtml+='<h4 class="margin-bottom-xl">'+merchantName+'</h4>'
		RewardHtml+='<ul class="policy-list">';
		RewardHtml+='<li>'+discountInfo+'</li>';
		RewardHtml+='</ul>';
		RewardHtml+='</div>';
		RewardHtml+='</a>';
		RewardHtml+='</div>';
		RewardHtml+='</div>';
		$("body").append($("<div name='alertReward' onclick='SGRewardsPage.closeAlertReward(this)' class='loading'></div>").append(RewardHtml));
	},*/
	closeAlertReward :function() {
		$("div[name='alertReward']").remove();
	},
};


$(function(){
	
	SGRewardsPage.initPage();
	
});