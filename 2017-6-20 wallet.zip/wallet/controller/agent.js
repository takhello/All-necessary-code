

var SGAgentPage = {
	getAgentTempl : function() {
		return $("script[name='agentTempl']");
	},
	getAgentContainer : function() {
		return $("div[name='agentContainer']");
	},
	renderAgentList : function(data) {
		if(data.length == 0) {
			SGUtil.showNotDataMsg();
			return;
		}
		this.getAgentContainer().children("script[name='agentTempl']").siblings().remove();
		this.getAgentContainer().append(this.getAgentTempl().render(data));
	},
	getAgentListAction : function() {
		var sendData = {
			"custId" : SGUtil.getStorage("custId")
		};
		SGService.getAgentListService(true,sendData,function(data) {
			SGAgentPage.renderAgentList(data.data);
		},function(data){
			SGUtil.alert(data.message);
			return;
		});
	},
	initPage : function() {
		SGAgentPage.getAgentListAction();
	}
	
};


$(function(){
	
	SGAgentPage.initPage();
	
});