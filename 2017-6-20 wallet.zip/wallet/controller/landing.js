function sortByEffectDate() {
	return function(a,b) {
		var value1 = a['policyEffectiveDate'];
		var value2 = b['policyEffectiveDate'];
		var date1 = SGUtil.strToDate(value1);
		var date2 = SGUtil.strToDate(value2);
		if(date1 > date2) {
			return -1;
		} else if(date1 < date2) {
			return 1;
		} else {
			return 0;
		}
	}
}


var CateGoryUtil = {
		cateGoryList : ['Life Protection','Medical Protection','Critical Illness Protection',
	                     'Accident Protection','Savings','Investments','Platinum',
	                     'Disability Income Protection','Travel and Lifestyle'],
	    getGoryListMap : function() {
	    	var cateGoryListMap = new Map();
			var length  = CateGoryUtil.cateGoryList.length;
			for(var i=0; i<length; i++) {
				cateGoryListMap.put(CateGoryUtil.cateGoryList[i],CateGoryUtil.cateGoryList[i]);
			}
			return cateGoryListMap;
	    },
	    
	    getCurrentCateGoryMap : function(policyData) {
	    	var currentCateGoryMap = new Map();
	    	for(var i=0; i<policyData.length; i++) {
	    		var cateGory = policyData[i].category;
	    		currentCateGoryMap.put(cateGory,cateGory);   //当前data的category
	    	}
	    	return currentCateGoryMap;
	    },
	    
	    
	    getUnCoverCageGory : function(policyData) {
	    	var currentCateGoryMap = CateGoryUtil.getCurrentCateGoryMap(policyData);
	    	var cateGoryListMap = CateGoryUtil.getGoryListMap();  //完整的category
	    	for(var i=0; i<CateGoryUtil.cateGoryList.length; i++) {    
	    		if(currentCateGoryMap.containsKey(CateGoryUtil.cateGoryList[i])) {
	    			cateGoryListMap.remove(CateGoryUtil.cateGoryList[i]);   
	    		}
	    	}
	    	var unCoverArr = [];
	    	var cateGoryList = cateGoryListMap.keys();
	    	for(var i=0, len=cateGoryList.length; i<len; i++) {
	    		var unCoverageCategory = {
		    			"category" : cateGoryList[i]
		    	};
	    		unCoverArr.push(unCoverageCategory);
	    	}
	    	
	    	return unCoverArr;
	    },
	    
	    getCateGoryBySort : function(policyData) {
	    	var currentCateGoryMap = CateGoryUtil.getCurrentCateGoryMap(policyData);
	    	
	    	var cateGoryListMap = CateGoryUtil.getGoryListMap();  //完整的category
	    	for(var i=0; i<CateGoryUtil.cateGoryList.length; i++) {    
	    		if(! currentCateGoryMap.containsKey(CateGoryUtil.cateGoryList[i])) {
	    			cateGoryListMap.remove(CateGoryUtil.cateGoryList[i]);   //去掉不存在的Catetory
	    		}
	    	}
	    	
	    	var cateGorys = cateGoryListMap.keys();
	    	var policysByCategory = {};
	    	for(var i=0; i<cateGorys.length; i++) {
	    		var arr = [];
	    		var currentCategoryData = {
	    			"category" : cateGorys[i],
	    			"data" : arr
	    		};
	    		policysByCategory[i] =  currentCategoryData;
	    		policysByCategory.size = i + 1;
	    		for(var j=0; j<policyData.length; j++) {
	    			if(cateGorys[i] == policyData[j].category) {
	    				arr.push(policyData[j]);
	    			}
	    		}
	    	}
	    	
	    	for(var i=0; i< policysByCategory.size; i++) {
	    		console.log("category.." + policysByCategory[i].category);
	    		policysByCategory[i].data = policysByCategory[i].data.sort(sortByEffectDate());
	    	}
	    	
	    	return policysByCategory;
	    	
	    }
};



var StatusUtil = {
	statusList : ['Inforce','Lapsed','Terminated'],
	getStatusSort : function(policyData) {
		var policysByStatus = [
				{
					"category" : StatusUtil.statusList[0],
	    			"data" : []
				},
				{
					"category" :  StatusUtil.statusList[1],
		    		"data" : []
				},
				{
					"category" :  StatusUtil.statusList[2],
			    	"data" : []
				}];		
		
		policysByStatus.size = 3;
		
		for(var i=0; i<policyData.length; i++) {
			if(policyData[i].status == StatusUtil.statusList[0]) {
				policysByStatus[0].data.push(policyData[i]);
			} else if(policyData[i].status == StatusUtil.statusList[1]) {
				policysByStatus[1].data.push(policyData[i]);
			} else if(policyData[i].status == StatusUtil.statusList[2]) {
				policysByStatus[2].data.push(policyData[i]);
			}
		}
		
		for(var i=0; i< policysByStatus.size; i++) {
    		policysByStatus[i].data = policysByStatus[i].data.sort(sortByEffectDate());
    	}
    	
		return policysByStatus;
    	
	}
};

var InsuredUtil = {
		getInsuredSort : function(policyData) {
			var currentCateGoryMap = new Map();
	    	for(var i=0; i<policyData.length; i++) {
	    		var lifeAssured = policyData[i].lifeAssured;
	    		currentCateGoryMap.put(lifeAssured,lifeAssured);   //当前data的lift assuredName
	    	}
	    	
	    	var insuredNameArr = currentCateGoryMap.keys();
	    	var insuredNameArr = insuredNameArr.sort();
	    	
	    	var policysByInsuredName = {};
	    	for(var i=0; i<insuredNameArr.length; i++) {
	    		var arr = [];
	    		var currentCategoryData = {
	    			"category" : insuredNameArr[i],
	    			"data" : arr
	    		};
	    		policysByInsuredName[i] =  currentCategoryData;
	    		policysByInsuredName.size = i + 1;
	    		for(var j=0; j<policyData.length; j++) {
	    			if(insuredNameArr[i] == policyData[j].lifeAssured) {
	    				arr.push(policyData[j]);
	    			}
	    		}
	    	}
	    	
	    	for(var i=0; i< policysByInsuredName.size; i++) {
	    		policysByInsuredName[i].data = policysByInsuredName[i].data.sort(sortByEffectDate());
	    	}
			return policysByInsuredName;
		}
}


var SGLandingPage = {
		getPolicyContainer : function() {
			return $("div[name='policyContainer']");
		},
		
		clearPolicyContainer : function() {
			this.getPolicyContainer().children("script[name='policyListTempl']").siblings().remove();
		},	
		
		getPolicyCardTempl : function() {
			return $("script[name='policyListTempl']");
		},
		
		getPolicyCountSpan : function() {
			return $("span[name='policyCount']");
		},
		
		setPolicyCount : function(count) {
			this.getPolicyCountSpan().html(count);
		},
		
		setWelcomCustName : function(custName) {
			$("span[name='custName']").html(custName);
		},
		
		getPolicyRenderHtml : function(data) {
			return this.getPolicyCardTempl().render(data);
		},
		getUncoverTempl : function() {
			return $("script[name='unCoverCategoryTempl']");
		},
		getUncoverContainer : function() {
			return $("div[name='unCoverCategory']");
		},
		clearUncoverContainer : function() {
			this.getUncoverContainer().children("script[name='unCoverCategoryTempl']").siblings().remove();
		},
		renderUnconver : function(data) {
			this.clearUncoverContainer();
			this.getUncoverContainer().append(this.getUncoverTempl().render(data));
		},
		getVitalityTempl : function() {
			return $("script[name='vitalityTempl']");
		},
		
		getVitalityContainer : function() {
			return $("div[name='vitalityContainer']");
		},
		
		clearVitalityContainer : function() {
			this.getVitalityContainer().children("script[name='vitalityTempl']").siblings().remove();
		},
		
		renderVitalityCard : function(data) {
			this.clearVitalityContainer();
			this.getVitalityContainer().append(this.getVitalityTempl().render(data));
		},
		
		getVitalityAction : function() {
			var vitalityData = SGUtil.getStorageTimer("vitalityData");
			
			if(vitalityData) {
				SGLandingPage.renderVitalityCard(vitalityData);
			} else {
				SGService.getVatalityService(false,{"custId":SGUtil.getStorage("custId")},function(data) {
					SGUtil.setStorageTimer("vitalityData",data.data);
					SGLandingPage.renderVitalityCard(data.data);
				},function(data){
					SGUtil.alert(data.message);
					return ;
				});
			}
		},
		
		getSortTypeSelect : function() {
			return $("select[name='sortType']");
		},
		
		changeSortType : function(sortType,policyData) {
			var policyContainer = SGLandingPage.getPolicyContainer();
			var sortData = "";
			if(sortType == "category") {
				sortData = CateGoryUtil.getCateGoryBySort(policyData);
			} else if(sortType == "status") {
				sortData = StatusUtil.getStatusSort(policyData);
			} else if(sortType == "insured") {
				sortData = InsuredUtil.getInsuredSort(policyData)
			}
			SGLandingPage.clearPolicyContainer();
			var pool = [];
			for(var i=0; i<sortData.size; i++) {
				if(sortData[i].data.length == 0) continue;
				var head = "<h6 class='margin-bottom-m'>"+sortData[i].category+"</h6>";
				pool.push(head);
				for(var j=0; j<sortData[i].data.length; j++) {
					pool.push(SGLandingPage.getPolicyRenderHtml(sortData[i].data[j]));
				} 
			}
			policyContainer.append(pool.join(""));
		},
		
		renderPolicyList : function(data) {
			SGLandingPage.changeSortType("category",data);
			var unCoverData = CateGoryUtil.getUnCoverCageGory(data);
			SGLandingPage.renderUnconver(unCoverData);
			//set policy count
			SGLandingPage.setPolicyCount(data.length);
			
			$("div[name='unCoverContainer']").show();
			
		},
		
		getPolicyListAction : function() {
			
			var policyData = SGUtil.getStorageTimer("policyListData");
			
			if(policyData) {
				SGLandingPage.renderPolicyList(policyData);
			} else {
				SGService.getPolicyListService(true,{"custId":SGUtil.getStorage("custId")},function(data) {
					SGUtil.setStorageTimer("policyListData",data.data);
					SGLandingPage.renderPolicyList(data.data);
					
				},function(data){
					SGUtil.alert(data.message);
					return ;
				});
			}
			
		},
		
		getRiderListTempl : function() {
			return $("script[name='riderList']");
		},
		
		getRiderListContainer : function() {
			return $("ul[name='riderContainer']");
		},
		
		renderRiderList : function(policyNo, category) {
			var policyData = SGUtil.getStorageTimer("policyListData",false);
			this.getRiderListContainer().children("li").remove();
			var currentRiderData = [];
			for(var i=0; i<policyData.length; i++) {
				if($.trim(policyData[i].policyNo) == policyNo && $.trim(policyData[i].category) == category) {
					currentRiderData = policyData[i].policyRiderList;
					break;
				}
			}
			this.getRiderListContainer().append(this.getRiderListTempl().render(currentRiderData));
		},
		
		toShowRiderList : function(_this) {
			var policyNo = $.trim($(_this).attr("data-policyNo"));
			var category = $.trim($(_this).attr("data-category"));
			this.renderRiderList(policyNo,category);
			SGUtil.toHashUrl("#/rider");
		},
		
		toPolicyDetailPage : function(_this) {
			//alert("aaaa");
			var policyNo = $(_this).attr("data-policyNo");
			var detailCategory = $.trim($(_this).attr("data-detailCategory"));
			var agentNo = $(_this).attr("data-agentNo");
			
			if(detailCategory == "Traditional") {
				SGUtil.setStorage("currentPolicyNo",$.trim(policyNo));
				SGUtil.setStorage("currentDetailCategory",$.trim(detailCategory));
				SGUtil.setStorage("currentAgentNo",$.trim(agentNo));
				SGUtil.toPage("policydetails_a_traditional.html");
			} else if(detailCategory == "Investment Linked") {
				SGUtil.setStorage("currentPolicyNo",$.trim(policyNo));
				SGUtil.setStorage("currentDetailCategory",$.trim(detailCategory));
				SGUtil.setStorage("currentAgentNo",$.trim(agentNo));
				SGUtil.toPage("policydetails_b_investment.html");
			} else if(detailCategory == "Others") {
				SGUtil.setStorage("currentPolicyNo",$.trim(policyNo));
				SGUtil.setStorage("currentDetailCategory",$.trim(detailCategory));
				SGUtil.setStorage("currentAgentNo",$.trim(agentNo));
				SGUtil.toPage("policydetails_e_others.html");
			} else if(detailCategory == "Annuities") {
				SGUtil.setStorage("currentPolicyNo",$.trim(policyNo));
				SGUtil.setStorage("currentDetailCategory",$.trim(detailCategory));
				SGUtil.setStorage("currentAgentNo",$.trim(agentNo));
				SGUtil.toPage("policydetails_c_annuity.html");
			} else if(detailCategory == "Hospitalization") {
				SGUtil.setStorage("currentPolicyNo",$.trim(policyNo));
				SGUtil.setStorage("currentDetailCategory",$.trim(detailCategory));
				SGUtil.setStorage("currentAgentNo",$.trim(agentNo));
				SGUtil.toPage("policydetails_d_hospitalization.html");
			}
			
		},
		
		initPage : function() {
			this.setWelcomCustName(SGUtil.getStorage("custName"));
			this.getPolicyListAction();
			this.getSortTypeSelect().off("change").on("change",function(){
					var selectValue = $(this).children('option:selected').val();
					var policyData = SGUtil.getStorageTimer("policyListData");
					SGLandingPage.changeSortType(selectValue,policyData);
			});
			setTimeout(function(){
				SGLandingPage.getVitalityAction();	
			},1500);
			
		}
};



$(function(){
	
	
	
	 function policyListShow() {
		 SGLandingPage.initPage();
     }
     
     function riderPageShow() {
     }
     
     var routes = {
       '/policyList': policyListShow,
       '/rider': riderPageShow
     };
     
     SGRoute.routes = routes;
     SGRoute.defaultRoute = "#/policyList";
     SGRoute.init();
     
     
});