

var SGCPStore = {
		"newPwd" : "",
		"oldPwd" : "",
		"otpTxtPhone" : "",
		"otpTokenUUID" : ""
};

var SGCPNewPwdPage = {
		getOldPwdInput : function() {
			return $("input[name='oldPwd']");
		},
		getNewPwdInput : function() {
			return $("input[name='newPwd']");
		},
		getVerifyPwdInput : function() {
			return $("input[name='verifyPwd']");
		},
		getVerifyBtn : function() {
			return $("button[name='changepwdVerifyBtn']");
		},
		setVerifyBtnOn : function() {
			this.getVerifyBtn().removeAttr("disabled");
		},
		setVerifyBtnOff : function() {
			this.getVerifyBtn().attr("disabled","disabled");
		},
		getCancleBtn : function() {
			return $("button[name='changepwdCancleBtn']");
		},
		clearOldPwd : function() {
			this.getOldPwdInput().val("");
			return this;
		},
		clearNewPwd : function() {
			this.getNewPwdInput().val("");
			return this;
		},
		clearVerifyPwd : function() {
			this.getVerifyPwdInput().val("");
			return this;
		},
		changePwdAction : function() {
			var oldPwd = this.getOldPwdInput().val();
			var newPwd = this.getNewPwdInput().val();
			var verifyNewPwd = this.getVerifyPwdInput().val();
			if(oldPwd == "") {
				SGUtil.alert("Old Password should not be empty");
				return ;
			} 
			if(newPwd == "") {
				SGUtil.alert("New Password should not be empty");
				return ;
			}
			if(newPwd.length < 8 ) {
				SGUtil.alert("Password cannot be less than 8 characters");
				return ;
			}
			if(newPwd.length > 18) {
				SGUtil.alert("Maximum entry for Password is 18 chars in length");
				return ;
			}
			if(verifyNewPwd == "") {
				SGUtil.alert("Verify Password should not be empty");
				return ;
			}

			if(verifyNewPwd.length < 8 ) {
				SGUtil.alert("Password cannot be less than 8 characters");
				return ;
			}
			if(verifyNewPwd.length > 18) {
				SGUtil.alert("Maximum entry for Password is 18 chars in length");
				return ;
			}
			
			if(newPwd != verifyNewPwd) {
				SGUtil.alert("New password and verify password must be equal");
				return ;
			}
			
			//verify old pwd
			SGCPNewPwdPage.setVerifyBtnOff();
			SGService.getPreLogonService(true,{},function(data){
				var publicKey =  data.data.publicKey;
				var randomNum = data.data.randomNum;
				var sessionId = data.data.sessionId;
				var encryPwd = encryPassword(oldPwd,publicKey,randomNum,sessionId);
				var loginData = {
					"custId" : 	SGUtil.getStorage("custId"),
					"rpin" : encryPwd,
					"sessionId" : sessionId
				};
				SGService.loginVerifyService(true,loginData,function(data){
					SGCPStore['newPwd'] = newPwd;
					SGCPStore['oldPwd'] = oldPwd;
					SGCPStore["otpTxtPhone"] = data.data.otpTxtPhone;
					SGCPStore["otpTokenUUID"] = data.data.otpTokenUUID;
					SGUtil.toHashUrl("#/otp");
					SGCPNewPwdPage.setVerifyBtnOn()
				},function(data){
					SGUtil.alert(data.message);
					SGCPNewPwdPage.setVerifyBtnOn();
					return;
				})
			},function(data){
				SGUtil.alert(data.message);
				SGCPNewPwdPage.setVerifyBtnOn();
			});
			
		},
		initPage : function() {

			this.clearOldPwd().clearNewPwd().clearVerifyPwd();
			this.getVerifyBtn().off("click").on("click",function(){
					SGCPNewPwdPage.changePwdAction();
			});
			
			this.getCancleBtn().off("click").on("click",function(){
				SGUtil.toHashUrl("#/index");
			});
		}
}



var SGCPOtpPage = {
		getOtpPwdInput : function() {
			return $("input[name='otpPwd']");
		},
		getVerifyBtn : function() {
			return $("button[name='cpwVerifyOtpBtn']");
		},
		getCancleBtn : function() {
			return $("button[name='cpwCancleBtn']");
		},
		getOtpPhoneText : function() {
			return $("b[name='otpPhoneNumber']");
		},
		setOtpPhoneText : function(otpPhoneNumber) {
			this.getOtpPhoneText().text(otpPhoneNumber);
		},	
		setVerifyBtnOff : function() {
			this.getVerifyBtn().attr("disabled","disabled");
		},
		setVerifyBtnOn : function() {
			this.getVerifyBtn().removeAttr("disabled");
		},
		getResendBtn : function() {
			return  $("p[name='resend']");
		},
		getResendTimeSpan : function() {
			return  $("span[name='resendTime']");
		},
		clearOtpPwd : function() {
			this.getOtpPwdInput().val("");
			return this;
		},
		optVerifyAction : function() {
			
			var otpInput = $.trim(this.getOtpPwdInput().val());
			if(otpInput == "") {
				SGUtil.alert("OTP filed should must be input");
				return ;
			}
			
			SGCPOtpPage.setVerifyBtnOff();
	
			var resetData = {
					"custId" : SGUtil.getStorage("custId"),
					"otpPassword" : otpInput,
					"otpTokenUUID" : SGCPStore['otpTokenUUID'],
					"oldPwd" : SGCPStore['oldPwd'],
					"newPwd" : SGCPStore['newPwd']
			};


			SGService.changePwdService(true,resetData,function(data) {
					console.log(data);
					
					//reset pwd into native
					savePassword({
						"id" :  SGUtil.getStorage("custId"),
						"pwd" : SGCPStore['newPwd']
					});
					
	
					//send mail
					// var isSendMail = data.data.isSendMail;
					var isHasEmailAddress = data.data.isHasEmailAddress;
	
					if(isHasEmailAddress == "N") {
						SGCPOtpPage.setVerifyBtnOn();
						SGUtil.toHashUrl("#/askemail");
						return ;
					}
					
					if(isHasEmailAddress == "Y") {
						//send mail
						var emailAddress = data.data.emailAddress;
						var sendMailData = {
								"custId" : SGUtil.getStorage("custId"),
								"emailAddress" : emailAddress,
								"emailType" : "PC"
						};
						SGService.sendMailService(true,sendMailData,function(data){
							SGCPOtpPage.setVerifyBtnOn();
							SGUtil.toHashUrl("#/cpwdsucessfully");
						},function(data){
							SGCPOtpPage.setVerifyBtnOn();
							SGUtil.toHashUrl("#/cpwdsucessfully");
							//SGUtil.alert(data.message);
							return;
						});
					}
					
					SGCPOtpPage.setVerifyBtnOn();
					
					},function(data){
						SGCPOtpPage.setVerifyBtnOn();
						if(data.code == "92012") { //OTP error > 3
							SGUtil.alert(data.message,function(){
								SGUtil.toHashUrl("#/newpwd");
							});
							return ;
						}
						SGUtil.alert(data.message);
						return ;
					});
		},

		resendOtpAction : function() {
			this.getResendBtn().off("click");
			//service
			
			SGUtil.isSetOtpTime(SGCPStore['otpTxtPhone'],SGCPOtpPage);

		},
		
		initPage : function() {
			this.clearOtpPwd();

			var optPhoneNumber  = SGCPStore['otpTxtPhone'];
			var markPhoneNumber = SGUtil.markStr(optPhoneNumber,0,4);
			this.setOtpPhoneText(markPhoneNumber);
			
			this.getVerifyBtn().off("click").on("click",function(){
				SGCPOtpPage.optVerifyAction();
			});
			
			this.getCancleBtn().off("click").on("click",function(){
				SGUtil.toHashUrl("#/index");
			});
			this.getResendBtn().off("click").on("click",function(){
					SGCPOtpPage.resendOtpAction();
			});
			SGCPOtpPage.resendOtpAction();
		}
};







$(function(){

		// SGUtil.setStorage("custId","S1635511I");
	   function indexPageShow() {
		   
	   	     var nScrollHight = 0; 
	   	     var nScrollTop = 0;   
	   	     var nDivHight = $("div[name='div1']").height();
	   	     $("div[name='div1']").scroll(function(){
	   	          nScrollHight = $(this)[0].scrollHeight;
	   	          nScrollTop = $(this)[0].scrollTop;
	   	          if(nScrollTop + nDivHight >= nScrollHight - 10) {
	   	           	 $("button[name='continuedbdBtn']").attr("disabled",false);
	   	          }
	   	     });
	   	     $("button[name='continuedbdBtn']").off("click").on("click",function(){
	   	    	 	SGUtil.toHashUrl("#/newpwd");
	   	     });
	   	     $("button[name='cpwdCancelBtn']").off("click").on("click",function(){
	   	    	 	SGUtil.toPage("profile.html");
	   	     });


	     }
     
	     function newpwdPageShow() {
	    	 SGCPNewPwdPage.initPage();
	     }
	     function otpPageShow() {
	    	 SGCPOtpPage.initPage();
	     }
	     
	     
	     function askemailPageShow(){
	     	$("button[name='emailOKBtn']").off("click").on("click",function(){
	    		
	    		//send mail
				var signUpEmail = $("input[name='sigupEmail']").val();
    		 	if(signUpEmail == "") {
	    		 		SGUtil.alert("Email adress should be not null");
	    		 		return ;
    		 	}

    		 	if(!SGUtil.isEmail(signUpEmail)) {
					SGUtil.alert("Email address is not valid");
					return ;
				}
    		 	var sendMailData = {
						"custId" : SGUtil.getStorage("custId"),
						"emailAddress" : signUpEmail,
						"emailType" : "PC",
						"password" : ""
				};
				SGService.sendMailService(true,sendMailData,function(data){
					SGUtil.toHashUrl("#/cpwdsucessfully");
				},function(data){
					SGUtil.alert(data.message);
					SGUtil.toHashUrl("#/cpwdsucessfully");
					return;
				});

	    	});
	     }

	     function cpwdsucessfullyPageShow(){
	     	$("button[name='continueBtn']").off("click").on("click",function(){
	     		SGUtil.toPage("profile.html");
	     	});
	     }

	     var routes = {
	       '/index': indexPageShow,
	       '/newpwd': newpwdPageShow,
	       '/otp':otpPageShow,
	       '/askemail' : askemailPageShow,
	       '/cpwdsucessfully' : cpwdsucessfullyPageShow
	     };
	     
	     SGRoute.routes = routes;
	     SGRoute.defaultRoute = "#/index";
	     SGRoute.init();
 
});




