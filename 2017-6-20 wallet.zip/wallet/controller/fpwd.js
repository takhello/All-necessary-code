
var SGFPStore = {
		
		"NRIC" : "",
		"otpTxtPhone" : "",
		"otpTokenUUID" : "",
		"emailAddress" : ""
};



var SGFPwdPage = {
	getNameInput : function() {
		return $("input[name='fortgotpwdName']");
	},

	getNRICInput : function() {
		return $("input[name='fortgotNric']");
	},

	getGenderValue : function() {
		var isMale = $("button[name='btn-male']").hasClass("btn-selected");
		if(isMale) {
			return "M"
		}
		var isFemale = $("button[name='btn-female']").hasClass("btn-selected");
		if(isFemale) {
			return "F";
		}
	},
	getDobValue : function() {
		return $("input[name='forgotDob']").val();
	},
	getEmailInput : function() {
		return $("input[name='fortgotPwdEmail']");
	},
	getVerifyEmailInput : function() {
		return $("input[name='fortgotPwdVeEmail']");
	},
	getSubmitBtn : function() {
		return $("button[name='fortgotPwdSubBtn']");
	},
	setSubmitBtnOff : function() {
		this.getSubmitBtn().attr("disabled","disabled");
	},
	setSubmitBtnOn : function() {
		this.getSubmitBtn().removeAttr("disabled");
	},
	getCancleBtn : function() {
		return $("button[name='fortgotPwdCancelBtn']");
	},
	clearName : function() {
		this.getNameInput().val("");
		return this;
	},
	clearNRIC : function() {
		this.getNRICInput().val("");
		return this;
	},
	
	clearEmail : function() {
		this.getEmailInput().val("");
		return this;
	},
	clearVerifyEmail : function() {
		this.getVerifyEmailInput().val("");
		return this;
	},
	submitFGPwdAction : function() {
		var name = $.trim(this.getNameInput().val());
		var NRIC = $.trim(this.getNRICInput().val());
		var gender = this.getGenderValue();
		var dob = this.getDobValue();
		var email = $.trim(this.getEmailInput().val());
		var verifyEmail = $.trim(this.getVerifyEmailInput().val());
		
		if(name == "") {
			SGUtil.alert("Name should not be empty");
			return ;
		}
		
		if(NRIC == "") {
			SGUtil.alert("NRIC should not be empty");
			return ;
		}
		
		if(dob == "") {
			SGUtil.alert("DOB should not be empty");
			return ;
		}
		
		if(email == "") {
			SGUtil.alert("Email should not be empty");
			return ;
		}
		
		if(!SGUtil.isEmail(email)) {
			SGUtil.alert("Email address is not valid");
			return ;
		}
		
		if(verifyEmail == "") {
			SGUtil.alert("VerifyEmail should not be empty");
			return ;
		}
		
		if(!SGUtil.isEmail(verifyEmail)) {
			SGUtil.alert("Verify Email address is not valid");
			return ;
		}
		
		if(email != verifyEmail) {
			SGUtil.alert("email and verifyEmail should be equal");
			return ;
		}
		
		
		SGFPwdPage.setSubmitBtnOff();
		var fpwdData = {
			"custId" : NRIC,
			"custName" :  name,
			"gender" : gender,
			"dob" : dob,
			"email" : email,
			"emailConfirmed" : verifyEmail
		};
		
		SGService.resetPwdService(true,fpwdData,function(data){
			// SGUtil.alert("forget password reset successful");
			SGFPStore['NRIC'] = NRIC;
			SGFPStore["otpTxtPhone"] = data.data.otpTxtPhone;
			SGFPStore["otpTokenUUID"] = data.data.otpTokenUUID;
			SGFPStore["emailAddress"] = verifyEmail;
			
			SGUtil.toHashUrl("#/forgotpwdotp");
			SGFPwdPage.setSubmitBtnOn();
		},function(data){
			SGUtil.alert(data.message);
			SGFPwdPage.setSubmitBtnOn();
			return;
		});
	},
	initPage : function(){
		this.clearName().clearNRIC().clearEmail().clearVerifyEmail();
		SGFPwdPage.getSubmitBtn().off("click").on("click",function(){
			SGFPwdPage.submitFGPwdAction();
		});
		
		SGFPwdPage.getCancleBtn().off("click").on("click",function(){
			SGUtil.toPage("login.html#/index");
		})
	}
		
		
}



var SGFOtpPage = {
	getOtpPwdInput : function() {
		return $("input[name='otpPwd']");
	},
	getVerifyBtn : function() {
		return $("button[name='optVerifyBtn']");
	},
	getCancleBtn : function() {
		return $("button[name='otpCancleBtn']");
	},
	setVerifyBtnOff : function() {
		this.getVerifyBtn().attr("disabled","disabled");
	},
	setVerifyBtnOn : function() {
		this.getVerifyBtn().removeAttr("disabled");
	},
	getOtpPhoneText : function() {
		return $("b[name='otpPhoneNumber']");
	},
	setOtpPhoneText : function(otpPhoneNumber) {
		this.getOtpPhoneText().text(otpPhoneNumber);
	},
	getResendBtn : function() {
		return  $("p[name='resend']");
	},
	clearOtpPwd : function() {
		this.getOtpPwdInput().val("");
		return this;
	},
	getResendTimeSpan : function() {
		return  $("span[name='resendTime']");
	},
	resendOtpAction : function() {
		this.getResendBtn().off("click");

		//service

		SGUtil.isSetOtpTime(SGFPStore['otpTxtPhone'],SGFOtpPage);

		
	},
	verifyOtpAction : function() {
		var otpInputPwd = $.trim(this.getOtpPwdInput().val());
		if(otpInputPwd == "") {
			SGUtil.alert("Please input OTP Password!");
			return "";
		}
		var optVerifyData = {
				"custId" : SGFPStore.NRIC,
				"otpPassword" : otpInputPwd,
				"otpTokenUUID" : SGFPStore.otpTokenUUID,
				"emailAddress" : SGFPStore.emailAddress
		}
		SGFOtpPage.setVerifyBtnOff();
		SGService.verifyforgetOTPService(true,optVerifyData,function(data) {
			//clear pwd in native
			removePassword();

			SGFOtpPage.setVerifyBtnOn();
			SGUtil.toHashUrl("#/askemail");
			

		},function(data){
			SGFOtpPage.setVerifyBtnOn();
			if(data.code == "92012") { //OTP error > 3
				SGUtil.alert(data.message,function(){
					SGUtil.toHashUrl("#/index");
				});
				return ;
			}
			SGUtil.alert(data.message);
			return ;
		})
	},
	
	verifyPageInvalid : function() {
			if(SGFPStore.NRIC == "" || SGFPStore.otpTxtPhone == "" || SGFPStore.otpTokenUUID == "") {
				 SGUtil.toHashUrl("#/index");
			}
	},
	initPage : function() {
		this.verifyPageInvalid();
		this.clearOtpPwd();
		
		var markPhoneNumber = SGUtil.markStr(SGFPStore.otpTxtPhone,0,4);
		this.setOtpPhoneText(markPhoneNumber);
		this.getCancleBtn().off("click").on("click",function(){
    		 SGUtil.toHashUrl("#/index");
    	});
		this.getVerifyBtn().off("click").on("click",function(){
			SGFOtpPage.verifyOtpAction();
		});
		this.getResendBtn().off("click").on("click",function(){
			SGFOtpPage.resendOtpAction();
		});
		SGFOtpPage.resendOtpAction();

	}
}


$(function(){ 
	
	SGUtil.setDatePicker($("input[name='forgotDob']"));
	
	
	function indexPageShow(){
		// setRangePicker();
		SGFPwdPage.initPage();
		
	}

	function otpPageShow() {
    	SGFOtpPage.initPage();
    }
    
    function askEmailShow(){
    	$("button[name='continueBtn']").off("click").on("click",function(){
    		SGUtil.toPage("login.html#/index");
    	});
    }
     
     var routes = {
       '/index': indexPageShow,
       '/forgotpwdotp':otpPageShow,
       '/askemail' : askEmailShow
     };
     
     SGRoute.routes = routes;
     SGRoute.defaultRoute = "#/index";
     SGRoute.init();
     
     
});
 

