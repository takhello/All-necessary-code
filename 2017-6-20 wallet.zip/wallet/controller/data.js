//var a = '{"success":true,"code":"0","message":"Get policy list success!","detailMessage":"","data":[{"policyNo":"L612345678    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"18-09-2013","premiumDueDate":"18-09-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"18-09-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24136     ","policyRiderList":[{"benefitName":"Crisis Cover III","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"500000.00","premiumBreakdown":"250.00","extraPremiums":"250.00","coverStartDate":"18-09-2013","coverEndDate":"18-09-2023"},{"benefitName":"Crisis Cover Extra","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"400000.00","premiumBreakdown":"200.00","extraPremiums":"200.00","coverStartDate":"18-09-2013","coverEndDate":"18-09-2023"}],"firstRiderName":"Crisis Cover III","riderListSize":2},{"policyNo":"L512345678    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"18-09-2013","premiumDueDate":"18-09-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"18-09-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24136     ","policyRiderList":[{"benefitName":"Accelerated Terminal Illness","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"50000.00","premiumBreakdown":"25.00","extraPremiums":"25.00","coverStartDate":"18-09-2013","coverEndDate":"18-09-2023"}],"firstRiderName":"Accelerated Terminal Illness","riderListSize":1},{"policyNo":"L812345678    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24129     ","policyRiderList":[{"benefitName":"Crisis Cover Extra","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"31000.00","premiumBreakdown":"15.50","extraPremiums":"15.50","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"},{"benefitName":"Premium Waiver on ESCW","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"15.00","premiumBreakdown":"0.01","extraPremiums":"0.01","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"}],"firstRiderName":"Crisis Cover Extra","riderListSize":2},{"policyNo":"l22345678     ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24130     ","policyRiderList":[{"benefitName":"Accelerated Terminal Illness","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"200000.00","premiumBreakdown":"100.00","extraPremiums":"100.00","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"},{"benefitName":"Premium Waiver on ESCW","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"1500.00","premiumBreakdown":"0.75","extraPremiums":"0.75","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"}],"firstRiderName":"Accelerated Terminal Illness","riderListSize":2},{"policyNo":"L212345678    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"03-10-2013","premiumDueDate":"03-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"03-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24134     ","policyRiderList":[{"benefitName":"Accelerated Terminal Illness","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"444444.00","premiumBreakdown":"222.22","extraPremiums":"222.22","coverStartDate":"03-10-2013","coverEndDate":"03-10-2023"}],"firstRiderName":"Accelerated Terminal Illness","riderListSize":1},{"policyNo":"L312345678    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"16929     ","policyRiderList":[{"benefitName":"Crisis Cover III","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"399900.00","premiumBreakdown":"199.95","extraPremiums":"199.95","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"}],"firstRiderName":"Crisis Cover III","riderListSize":1},{"policyNo":"L221234567    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"83893     ","policyRiderList":[],"firstRiderName":"","riderListSize":0},{"policyNo":"U123456122    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24134     ","policyRiderList":[{"benefitName":"Accelerated Terminal Illness","lifeAssured":"VEERAPPAN PALANIAPPAN","benefitStatus":"Inforce","sumAssured":"50000.00","premiumBreakdown":"2.10","extraPremiums":"2.10","coverStartDate":"04-10-2013","coverEndDate":"04-10-2023"}],"firstRiderName":"Accelerated Terminal Illness","riderListSize":1},{"policyNo":"L441234567    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"All Save","policyStartDate":"04-10-2013","premiumDueDate":"04-10-2023","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"04-10-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"24134     ","policyRiderList":[],"firstRiderName":"","riderListSize":0},{"policyNo":"U522460841    ","category":"Investments","detailCategory":"Investment Linked","status":"Inforce","policyName":"AIA FAMILY FIRST ASSURANCE","policyStartDate":"17-09-2013","premiumDueDate":"17-09-2089","lifeAssured":"CARRIE HENG","policyEffectiveDate":"17-09-2013","address1":"Block 879","address2":"Yishun Street 81","address3":"#07-17","address4":"","address5":"","agentNo":"24136     ","policyRiderList":[],"firstRiderName":"","riderListSize":0},{"policyNo":"LA12345678    ","category":"Investments","detailCategory":"Investment Linked","status":"Inforce","policyName":"AIA FAMILY FIRST ASSURANCE","policyStartDate":"05-12-2013","premiumDueDate":"05-12-2082","lifeAssured":"VEERAPPAN PALANIAPPAN","policyEffectiveDate":"05-12-2013","address1":"BLK 321C","address2":"ANCHORVALE DRIVE","address3":"03-30","address4":"SengKang","address5":"","agentNo":"87546     ","policyRiderList":[],"firstRiderName":"","riderListSize":0},{"policyNo":"L444777111    ","category":"Life Protection","detailCategory":"Traditional","status":"Lapsed","policyName":"AIA GEN3","policyStartDate":"03-10-2013","premiumDueDate":"03-10-2023","lifeAssured":"CARRIE HENG","policyEffectiveDate":"03-10-2013","address1":"Block 879","address2":"Yishun Street 81","address3":"#07-17","address4":"","address5":"","agentNo":"48857     ","policyRiderList":[{"benefitName":"TPD ON AIA GEN3","lifeAssured":"CARRIE HENG","benefitStatus":"Lapsed","sumAssured":"100000.00","premiumBreakdown":"0.00","extraPremiums":"0.00","coverStartDate":"03-10-2013","coverEndDate":"03-10-2054"}],"firstRiderName":"TPD ON AIA GEN3","riderListSize":1},{"policyNo":"AA77777777    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"AIA LIFE PLUS","policyStartDate":"18-11-2013","premiumDueDate":"18-11-2097","lifeAssured":"A2","policyEffectiveDate":"18-11-2013","address1":"1","address2":"A","address3":"1","address4":"A","address5":"","agentNo":"24132     ","policyRiderList":[{"benefitName":"TPD ON LIFE PLUS (II)","lifeAssured":"A2","benefitStatus":"Inforce","sumAssured":"100000.00","premiumBreakdown":"0.00","extraPremiums":"0.00","coverStartDate":"18-11-2013","coverEndDate":"18-11-2062"}],"firstRiderName":"TPD ON LIFE PLUS (II)","riderListSize":1},{"policyNo":"AA58888888    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"AIA LIFE PLUS","policyStartDate":"20-11-2013","premiumDueDate":"20-11-2097","lifeAssured":"A2","policyEffectiveDate":"20-11-2013","address1":"1","address2":"A","address3":"1","address4":"A","address5":"","agentNo":"41574     ","policyRiderList":[{"benefitName":"TPD ON LIFE PLUS (II)","lifeAssured":"A2","benefitStatus":"Inforce","sumAssured":"52000.00","premiumBreakdown":"0.00","extraPremiums":"0.00","coverStartDate":"20-11-2013","coverEndDate":"20-11-2062"}],"firstRiderName":"TPD ON LIFE PLUS (II)","riderListSize":1},{"policyNo":"AA87774444    ","category":"Savings","detailCategory":"Traditional","status":"Inforce","policyName":"AIA LIFE PLUS","policyStartDate":"25-11-2013","premiumDueDate":"25-11-2097","lifeAssured":"A2","policyEffectiveDate":"25-11-2013","address1":"1","address2":"A","address3":"1","address4":"A","address5":"","agentNo":"41574     ","policyRiderList":[{"benefitName":"TPD ON LIFE PLUS (II)","lifeAssured":"A2","benefitStatus":"Inforce","sumAssured":"100000.00","premiumBreakdown":"0.00","extraPremiums":"0.00","coverStartDate":"25-11-2013","coverEndDate":"25-11-2062"}],"firstRiderName":"TPD ON LIFE PLUS (II)","riderListSize":1}]}';
//
//var data = JSON.parse(a);
//var policyData = data.data;
//
//var cateGoryListMap = new Map();   //结果
//var cateGorayList = ['Life Protection','Medical Protection','Critical Illness Protection',
//                     'Accident Protection','Savings','Investments','Platinum',
//                     'Disability Income Protection','Travel & Lifestyle'];
//
//for(var i=0; i<cateGorayList.length; i++) {
//	cateGoryListMap.put(cateGorayList[i],cateGorayList[i]);
//}
//
//var currentCateGoryMap = new Map();
//function start() {
//	for(var i=0; i<policyData.length; i++) {
//		var cateGory = policyData[i].category;
//		currentCateGoryMap.put(cateGory,cateGory);
//	}
//	
//	for(var i=0; i<cateGorayList.length; i++) {
//		if(! currentCateGoryMap.containsKey(cateGorayList[i])) {
//			cateGoryListMap.remove(cateGorayList[i]);
//		}
//	}
//}
//
//function strToDate(dateStr) {
//	if(dateStr == "") return "";
//	var dateArr = dateStr.split("-");
//	return new Date().setFullYear(dateArr[2],dateArr[1],dateArr[0]);
//}
//
//var policysByCategory = {};
//
//function collectByCateGory() {
//	var cateGorys = cateGoryListMap.keys();
//	for(var i=0; i<cateGorys.length; i++) {
//		var arr = [];
//		var currentCategoryData = {
//			"category" : cateGorys[i],
//			"data" : arr
//		};
//		policysByCategory[i] =  currentCategoryData;
//		for(var j=0; j<policyData.length; j++) {
//			if(cateGorys[i] == policyData[j].category) {
//				arr.push(policyData[j]);
//			}
//		}
//	}
//}
//
//
//function collectByCateGory() {
//	
//}
//
///***
//function sortByEffectDate(arr) {
//	arr.sort(function(a,b){
//		var value1 = a['policyEffectiveDate'];
//		var value2 = b['policyEffectiveDate'];
//		var date1 = strToDate(value1);
//		var date2 = strToDate(value2);
//		if(date1 > date2) {
//			return -1;
//		} else if(date1 < date2) {
//			return 1;
//		} else {
//			return 0;
//		}
//	});
//}
//
//***/
//
//
