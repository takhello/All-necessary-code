

var SGProfilePage = {
	touchStatus : "",
	getMarjorInfoTempl : function() {
		return $("script[name='marjorInfoTmpl']");
	},
	getMarjorContainer : function() {
		return $("div[name='marjorInfo']");
	},
	renderMarjorInfo : function(data) {
		this.getMarjorContainer().children("div").remove();
		this.getMarjorContainer().append(this.getMarjorInfoTempl().render(data));
	},
	renderProfileAction : function() {
		SGService.getProfileDetailService(true,{"custId":SGUtil.getStorage("custId")},function(data) {
			SGProfilePage.renderMarjorInfo(data.data);
			SGProfilePage.renderBenefit(data.data.policyList);
			
			SGProfilePage.getMainContainer().show();
			
			
		},function(data){
			SGUtil.alert(data.message);
			return ;
		});
	},
	getMainContainer : function() {
		return $("div[name='mainContainer']");
	},
	
	getBenefitAddressContainer() {
		return $("div[name='benefitAddressContainer']");
	},
	
	getBenefitAddressTempl () {
		return $("script[name='benefitAddressContainerTempl']");
	},
	
	renderBenefit(data) {
		this.getBenefitAddressContainer().children("div").remove();
		this.getBenefitAddressContainer().append(this.getBenefitAddressTempl().render(data));
	},
	
	getfortgotPwdCancelBtn() {
		return $("button[name='fortgotPwdCancelBtn']");
	},
	
	getFingerOnBtn : function() {
		return $("button[name='btn-enable']");
	},
	
	getFingerOffBtn : function() {
		return $("button[name='btn-disable']");
	},
	
	setFingerEnableBtnOn : function() {
		this.getFingerOnBtn().removeClass().addClass("btn btn-toggle btn-selected");
		this.getFingerOffBtn().removeClass().addClass("btn btn-toggle");
	},
	
	setFingerDisableBtnOn : function() {
		this.getFingerOffBtn().removeClass().addClass("btn btn-toggle btn-selected");
		this.getFingerOnBtn().removeClass().addClass("btn btn-toggle");
	},
	
	initPage : function() {
		this.renderProfileAction();
		this.getfortgotPwdCancelBtn().on("click",function(){
			SGUtil.toPage("changepassword.html#/index");
		});
		
		this.getFingerOnBtn().on("click",function(){
			if(SGProfilePage.touchStatus == "0") {
				SGUtil.alert("Device doesn’t support fingerprint ");
				return ;
			}
			
			if(SGProfilePage.touchStatus == "1") {
				SGUtil.alert("User didn’t set fingerprint in system");
				return ;
			} 
			
			if(SGProfilePage.touchStatus == "3") {
				 var json = {
					 'id' : SGUtil.getStorage("custId")
				 };
				 var isEnableFP = false;
				 touchIDIsFpEnabled(json,function(callJson){
					 if(callJson.state == "1") {
						 isEnableFP = true;
						 return ;
					 } 
				 });
				 if(isEnableFP) {
					 SGUtil.alert("User has already enabled fingerprint login");
					 return ;
				 }
				 SGUtil.toPage("enablefinger.html#/t_and_c");
				 return ;
			}
			
			if(SGProfilePage.touchStatus == "2") { //didn't set fingerprint
				SGUtil.toPage("enablefinger.html#/t_and_c");
				return ;
			}
			
		});
		
		this.getFingerOffBtn().on("click",function(){
				if(SGProfilePage.touchStatus == "3") {
					removePassword(function(json){
						SGUtil.alert("Disable fingerprint login successfully");
						SGProfilePage.touchStatus = "2";
						return ;
					});
				} else if(SGProfilePage.touchStatus == "0") {
					SGUtil.alert("Device doesn’t support fingerprint ");
					return ;
				} else if(SGProfilePage.touchStatus == "1") {
					SGUtil.alert("User didn’t set fingerprint in system");
					return ;
				}
		});
		
		setExpandOn();
	}
};

$(function(){
	
	 SGProfilePage.initPage();
	 
	 
	 var json = {
			'id' : SGUtil.getStorage("custId")
	 };
	 
	 touchIDIsFpEnabled(json,function(callJson){
		 if(callJson.state == "1") {
			 SGProfilePage.setFingerEnableBtnOn();
		 } else {
			 SGProfilePage.setFingerDisableBtnOn();
		 }
	 });

	 touchIDStatus(function(json){
		 SGProfilePage.touchStatus = json.state;
	 });
	 	
	 

});


function setExpandOn() {
	 $('.expand-all').on('click', function () {
		  	$('.expand-all, .collapse-all').toggleClass('hide');
		  	$('.benefit-content').collapse('show');
	 });
	 
	  $('.collapse-all').on('click', function () {
	       $('.expand-all, .collapse-all').toggleClass('hide');
	       $('.benefit-content').collapse('hide');
	  });
}


