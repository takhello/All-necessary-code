
var SGEdocListPage = {
	custDocListData : "",
	getDocListTemplate : function() {
		return $("script[name='eDocTempl']");
	},
	getDocListContainer : function() {
		return $("ul[name='docListContainer']");
	},
	renderDocList : function(data) {
		this.getDocListContainer().children("li").remove();
		this.getDocListContainer().append(this.getDocListTemplate().render(data));
	},
	toDownLoadPage : function(_this) {
		console.log($(_this).attr("data-policyNo"));
		var policyNo = $.trim($(_this).attr("data-policyNo"));
		SGEdocDownloadPage.currentPolicyNo = policyNo;
		SGUtil.toHashUrl("#/eDocDownload");
	},
	getDocumentListAction : function() {
		if(this.custDocListData != "") {  //cache data
			return ;
		}
		var sendData = {
			"custId" : SGUtil.getStorage("custId")
		};
		SGService.getDocumentListService(true,sendData,function(data) {
			SGEdocListPage.renderDocList(data.data);
			SGEdocListPage.custDocListData = data.data;
		},function(data){
			SGUtil.alert(data.message);
			return ;
		})
	}
};


var SGEdocDownloadPage = {
	currentPolicyNo : "",
	currentPolicyData : "",
	objectIdMaps : new Map(),
	getDocDLHeaderTemplate : function() {
		return $("script[name='eDocDLHeadTempl']");
	},
	getDocDLContainer : function() {
		return $("div[name='eDocHeadContainer']");
	},
	filterDataPolicyData : function() {
		var policyNo = this.currentPolicyNo;
		for(var i=0;i<SGEdocListPage.custDocListData.length; i++) {
			var currentPolicyData = SGEdocListPage.custDocListData[i];
			if($.trim(currentPolicyData.policyNo) == policyNo ) {
				SGEdocDownloadPage.currentPolicyData = currentPolicyData;
				break;
			} else {
				continue;
			}
		}
	},
	renderDocHeader : function() {
		this.getDocDLContainer().children("div").remove();
		//filterData
		this.getDocDLContainer().append(this.getDocDLHeaderTemplate().render(this.currentPolicyData));
	},
	
	getDocListConainer : function() {
		return $("div[name='edocDListContainer']");
	},
	getDocDListTempl : function() {
		return $("script[name='edocDListTempl']");
	},
	renderDLList : function() {
		this.getDocListConainer().children("div").remove();
		this.getDocListConainer().append(this.getDocDListTempl().render(SGEdocDownloadPage.currentPolicyData.documents));
	},
	generateDocumentService : function(objectId,policyNo,requestNo,formId,receivedDate,callback) {
		var data = {
				"objectId" : objectId,
				"policyNo" : policyNo,
				"requestNo" : requestNo,
				"formId" : formId,
				"receivedDate" : receivedDate,
				"custId" : SGUtil.getStorage("custId")
		};
		SGService.generateDocumentService(true,data,function(returnData) {
				if(callback) {
					callback(returnData);
				}
		},function(data){
			SGUtil.alert(data.message);
			return ;
		})
	},
	checkPDFListStatus : function(objectIds) {
			var sendData = {
				"custId" : SGUtil.getStorage("custId"),
				"objectIds" :  objectIds   //split ","
			};
			SGService.checkAvaiablePDFListService(true,sendData,function(data) {
				    var statusDatas = data.data;
					for(var i=0; i<statusDatas.length; i++) {
						var status = statusDatas[i].status;
						var objectId = statusDatas[i].objectId;
						if(status == "U" || status == "R") {
							SGEdocDownloadPage.changeDocStatusImg(objectId,status,"doc-prime1.png");
						} else if(status == "NL") {
							SGEdocDownloadPage.changeDocStatusImg(objectId,status,"doc-prime3.png");
						} else {
							SGEdocDownloadPage.changeDocStatusImg(objectId,status,"doc-prime2.png");
						}
					}
			},function(data){
				SGUtil.alert(data.message);
				return ;
			});
	},
	startThreadCheckPDFStatus : function() {
		var array = this.objectIdMaps.keys();
			setInterval(function(){
				if(array.length == 0) return ;
				var objectIds = array.join(",");
				var data = {
					"custId" : SGUtil.getStorage("custId"),
					"objectIds" :  objectIds
				};
				SGService.checkAvaiablePDFListService(false,data,function(data) {
					//todo
					var returnData = data.data;
					for(var i=0; i<returnData.length; i++) {
						var status = returnData[0].status;
						var objectId = returnData[0].objectId;
						if(status == "U" || status == "R") {
							SGEdocDownloadPage.changeDocStatusImg(objectId,status,"doc-prime1.png");
							this.objectIdMaps.remove(objectId);
						}
					}
				},function(data){
					SGUtil.alert(data.message);
					return ;
				});
			},5*1000);
	},
	downloadEdoc : function(_this) {
		var $this = $(_this);
		var status = $this.attr("data-status");
		var objectId = $this.attr("data-objectId");
		if(status == "NC") {  //exist nativce, show pdf 
			//native show 
			showDocumentPdf({"docid":objectId});
			return ;
		} else if(status == "U" ||  status == "R") { //download pdf and show pdf
			//native 
			SGUtil.startLoading();
			var custId = SGUtil.getStorage("custId");
			var eDocUrl = "/wallet/eDoc/downloadDocument?custId=" + custId + "&objectId=" + objectId;
			var downLoadUrl = SGEnv.getApiRoot() + eDocUrl;
			
			if(SGUtil.isInDevice()) {
				var downLoadData = {
						"url" : downLoadUrl,
						"docid" : objectId
				};
				downDocmentPdf(downLoadData,function(json){
					SGUtil.stopLoading();
					if(json.state == "0") {
						SGUtil.alert("Download eDoc PDF failed");
						return ;
					} else {
						showDocumentPdf({"docid":objectId});
					}
				});
			} else {
				window.location.href = downLoadUrl;
				SGUtil.stopLoading();
			}
	
		} else {  //generate pdf 
			var objectId = $this.attr("data-objectId");
			var policyNo = $this.attr("data-policyNo");
			var requestNo = $this.attr("data-requestNo");  
			var receviedDate = $this.attr("data-receivedDate");
			var formId = $this.attr("data-formId");
			this.generateDocumentService(objectId,policyNo,requestNo,formId,receviedDate,function(returnData){
				//改变ui样式
				SGEdocDownloadPage.changeDocStatusImg(objectId,status,"doc-prime2.png");
				SGEdocDownloadPage.objectIdMaps.put(objectId, objectId);
			});
		}
	},
	changeDocStatusImg : function(objectId,status,imgName) {
		$("div[data-objectId='"+objectId+"']").attr("data-status",status);
 		var $targetImg =  $("div[data-objectId='"+objectId+"'] img");
 		var imgSrc =  $targetImg.attr("src");
 		var indexOfVal = imgSrc.lastIndexOf("/");
 		var preImgStr = imgSrc.substr(0,indexOfVal);
 		$targetImg.attr("src",preImgStr + "/" + imgName);
	},
	nativeCheckPdfExist : function(objectId) {
		 try {
			 var data = {
				docid : objectId	 
			 };
			 viewDoucmentPdf(data,function(json){
				 	if(json.state == "1") {
				 		//change ui icon , and chenge status
				 		SGEdocDownloadPage.changeDocStatusImg(objectId,"NC","doc-prime1.png");
				 	} 
    		 });
		 } catch(e) {
			 alert(e);
		 }
	},
	verifyPage : function() {
		if(this.currentPolicyNo == "" || this.currentPolicyData == "") {
			SGUtil.toHashUrl("#/eDocList");
			return false;
		} 
	},
	initPage : function() {
		SGEdocDownloadPage.filterDataPolicyData();
		this.verifyPage();
		SGEdocDownloadPage.renderDocHeader();
		SGEdocDownloadPage.renderDLList();
		
		//check status is native
		var currentDocuments = SGEdocDownloadPage.currentPolicyData.documents;
		for(var i=0; i<currentDocuments.length; i++) {
			SGEdocDownloadPage.nativeCheckPdfExist(currentDocuments[i].objectId);
		}
		
		//请求服务器获取所有ObjectIds的 status
		var objectIdsArr = [];
		for(var i=0; i<currentDocuments.length; i++) {
			objectIdsArr.push(currentDocuments[i].objectId);
		}
		
		var objectIds = objectIdsArr.join(",");
		SGEdocDownloadPage.checkPDFListStatus(objectIds);
		
		
		SGEdocDownloadPage.startThreadCheckPDFStatus();
		
	}
};



$(function(){
	
	//SGUtil.setStorage("custId","S8408779C");
	
     function eDocListPageShow() {
    	 SGEdocListPage.getDocumentListAction();
     }
     
     function eDocDowloadPageShow() {
    	 SGEdocDownloadPage.initPage();
     }
     
     var routes = {
       '/eDocList': eDocListPageShow,
       '/eDocDownload': eDocDowloadPageShow
     };
     
     SGRoute.routes = routes;
     SGRoute.defaultRoute = "#/eDocList";
     SGRoute.init();
});




