var SGLoginStore = {
		"NRIC" : "",
		"otpTxtPhone" : "",
		"otpTokenUUID" : "",
		"touchIDStatus" : ""
};

var SGLoginPage = {
	getNRICInput : function() {
		return $("input[name='nric']");
	},
	getPassowrdInput : function() {
		return $("input[name='pwd']");
	},
	getLoginBtn : function() {
		return $("button[name='loginBtn']");
	},
	getFingerprintBtn : function(){
		return $("button[name='fingerprintBtn']");
	},
	
	setLoginBtnOff : function() {
		this.getLoginBtn().attr("disabled","disabled");
		return this;
	},
	setLoginBtnOn : function() {
		this.getLoginBtn().removeAttr("disabled");
		return this;
	},
	clearNRIC : function() {
		this.getNRICInput().val("");
		return this;
	},
	clearPassword : function() {
		this.getPassowrdInput().val("");
		return this;
	},
	getForgotBtn : function () {
		return $("a[name='forgotPwd']");
	},
	getSwitchIdBtn : function() {
		return $("a[name='switchId']");
	},
	getTOUBtn : function() {
		return $("a[name='tou']");
	},
	getRegisterBtn : function() {
		return $("a[name='registerNow']");
	},
	hideFinger : function(){
		$("div[name='fingerContainer']").hide();
	},
	showFinger : function() {
		$("div[name='fingerContainer']").show();
	},
	loginAction : function() {
		var NRIC = $.trim(this.getNRICInput().val());
		var password = $.trim(this.getPassowrdInput().val());
		//check nric , password length
		
		if(NRIC == "") {
			SGUtil.alert("Login ID should not be empty");
			return ;
		}
		
		if(password == "") {
			SGUtil.alert("Password should not be empty");
			return ;
		}
		
		if(password.length < 8 ) {
			SGUtil.alert("Password cannot be less than 8 characters");
			return ;
		}
		
		if(password.length > 18) {
			SGUtil.alert("Maximum length of password is 18 characters.");
			return ;	
		}
		
		if(!SGUtil.checkHasSpace(password)) {
			SGUtil.alert("Password should not contain white spaces");
			return ;
		}
		
		this.setLoginBtnOff();
		SGService.getPreLogonService(true,{},function(data){
			var publicKey =  data.data.publicKey;
			var randomNum = data.data.randomNum;
			var sessionId = data.data.sessionId;
			var encryPwd = encryPassword(password,publicKey,randomNum,sessionId);
			var loginData = {
				"custId" : 	NRIC,
				"rpin" : encryPwd,
				"sessionId" : sessionId
			};

			SGService.loginVerifyService(true,loginData,function(data){
				SGLoginStore["NRIC"] = NRIC;
				SGLoginStore["otpTxtPhone"] = data.data.otpTxtPhone;
				SGLoginStore["otpTokenUUID"] = data.data.otpTokenUUID;
			
				SGUtil.toHashUrl("#/loginotp");
				SGLoginPage.setLoginBtnOn();
			},function(data){
				SGUtil.alert(data.message);
				SGLoginPage.setLoginBtnOn();
				return;
			})


		},function(data){
			SGUtil.alert(data.message);
			SGLoginPage.setLoginBtnOn();
		});
	},
	
	initPage : function() {

		this.clearNRIC().clearPassword();
		this.getLoginBtn().off("click").on("click",function(){
			SGLoginPage.loginAction();
		});
		
		this.getForgotBtn().off("click").on("click",function(e){
			e.preventDefault()
			SGUtil.toPage("forgotpassword.html#/index");
		});

		this.getFingerprintBtn().off("click").on("click",function(e){
			e.preventDefault();
			SGUtil.toHashUrl("#/fingerprintlogin");
		});
		
		this.getRegisterBtn().off("click").on("click",function(e){
			e.preventDefault();
			SGUtil.toPage("registration.html#/notice");
		});

		this.getTOUBtn().off("click").on("click",function(e){
			e.preventDefault();
			SGUtil.toPage("terms_of_use.html");
		});

		
    }
};


var SGLoginOTPVerifyPage = {
	getOtpPwdInput : function() {
		return $("input[name='otpPwd']");
	},
	getVerifyBtn : function() {
		return $("button[name='optVerifyBtn']");
	},
	getCancleBtn : function() {
		return $("button[name='otpCancleBtn']");
	},
	setVerifyBtnOff : function() {
		this.getVerifyBtn().attr("disabled","disabled");
	},
	setVerifyBtnOn : function() {
		this.getVerifyBtn().removeAttr("disabled");
	},
	getOtpPhoneText : function() {
		return $("b[name='otpPhoneNumber']");
	},
	setOtpPhoneText : function(otpPhoneNumber) {
		this.getOtpPhoneText().text(otpPhoneNumber);
	},
	getResendBtn : function() {
		return  $("p[name='resend']");
	},
	getResendTimeSpan : function() {
		return  $("span[name='resendTime']");
	},
	resendOtpAction : function() {
		this.getResendBtn().off("click");
		//service
		SGUtil.isSetOtpTime(SGLoginStore["otpTxtPhone"],SGLoginOTPVerifyPage);


	},
	verifyOtpAction : function() {
		var otpInputPwd = $.trim(this.getOtpPwdInput().val());
		if(otpInputPwd == "") {
			SGUtil.alert("Please input OTP Password !");
			return "";
		}
		var optVerifyData = {
				"custId" : SGLoginStore.NRIC,
				"otpPassword" : otpInputPwd,
				"otpTokenUUID" : SGLoginStore.otpTokenUUID
		}
		SGLoginOTPVerifyPage.setVerifyBtnOff();
		SGService.verifyOTPService(true,optVerifyData,function(data) {
			
			SGUtil.setStorage("jwt",data.data.jwt);
			SGUtil.setStorage("custId",SGLoginStore.NRIC);
			SGUtil.setStorage("custName",data.data.custName);
			
			//start native jwt timer
			//startTokenTimer({"interval":"30"});
			startTokenTimer();
			
			
			showUserName(SGUtil.getStorage("custName"));
			
			var isSendMail = data.data.isSendMail;
			var isHasEmailAddress = data.data.isHasEmailAddress;

			if(isSendMail == "Y"){
				SGUtil.toPage("landing.html#/policyList");
				return;
			}

			if(isSendMail == "N" && isHasEmailAddress == "N") {
				SGLoginOTPVerifyPage.setVerifyBtnOn();
				SGUtil.toHashUrl("#/askemail");
				return ;
			}
			
			if(isSendMail == "N" && isHasEmailAddress == "Y") {
				//send mail
				var emailAddress = data.data.emailAddress;
				var sendMailData = {
						"custId" : SGUtil.getStorage("custId"),
						"emailAddress" : emailAddress,
						"emailType" : "FL"
				};
				SGService.sendMailService(true,sendMailData,function(data){
					SGLoginOTPVerifyPage.setVerifyBtnOn();
					SGUtil.toPage("landing.html#/policyList");
				},function(data){
					SGLoginOTPVerifyPage.setVerifyBtnOn();
					SGUtil.toPage("landing.html#/policyList");
					return;
				});
			}
		},function(data){
			
			SGLoginOTPVerifyPage.setVerifyBtnOn();
			if(data.code == "92012") { //OTP error > 3
				SGUtil.alert(data.message,function(){
					SGUtil.toHashUrl("#/index");
				});
				return ;
			}
			SGUtil.alert(data.message);
			return ;
		})
	},
	
	verifyPageInvalid : function() {
			if(SGLoginStore.NRIC == "" || SGLoginStore.otpTxtPhone == "" || SGLoginStore.otpTokenUUID == "") {
				 SGUtil.toHashUrl("#/index");
			}
	},
	
	initPage : function() {
		var markPhoneNumber = SGUtil.markStr(SGLoginStore.otpTxtPhone,0,4);
		this.setOtpPhoneText(markPhoneNumber);
		this.getCancleBtn().off("click").on("click",function(){
    		 SGUtil.toHashUrl("#/index");
    	});
		this.getVerifyBtn().off("click").on("click",function(){
			SGLoginOTPVerifyPage.verifyOtpAction();
		});
		this.getResendBtn().off("click").on("click",function(){
			SGLoginOTPVerifyPage.resendOtpAction();
		});
		SGLoginOTPVerifyPage.resendOtpAction();

	}
}




$(function(){
	
	 disableMenu();
	
     function indexShow() {
    	 
    	 if(SGLoginStore['touchIDStatus'] == "3") {
    		 SGLoginPage.showFinger();
    	 } else {
    		 try {
    			 touchIDStatus(function(json){
        			 //alert(json.state);
    				 SGLoginStore['touchIDStatus'] = json.state
    				 if(SGLoginStore['touchIDStatus'] == "3") {
    					 SGLoginPage.showFinger();
    				 }
        		 });
    		 } catch(e) {
    			 alert(e);
    		 }
    	 }
    	 

    	 SGLoginPage.initPage();
    	 
     }
     
     function loginOtpShow() {
    	 SGLoginOTPVerifyPage.verifyPageInvalid();
    	 SGLoginOTPVerifyPage.initPage();
     }
     
     function fingerprintlogin() {

    	 SGLoginPage.getSwitchIdBtn().off("click").on("click",function(e){
 			 e.preventDefault();
 			 closeTouchID();
     		 SGUtil.toHashUrl("#/index");
     	 });
    	 
    	 
    	 getEnabledFpId(function(json){
    		 var markId  = SGUtil.markStr(json.id,2,2);
    		 $("span[name='custId']").html(markId);
    	 })
    	 
    	 
    	 showTouchID(function(json){
    		 if(json.state == "1") {
    			 retrievePassword(function(json){
    				 var id = json.id ;
    				 var password = json.pwd;
    				 SGService.getPreLogonService(true,{},function(data){
    						var publicKey =  data.data.publicKey;
    						var randomNum = data.data.randomNum;
    						var sessionId = data.data.sessionId;
    						var encryPwd = encryPassword(password,publicKey,randomNum,sessionId);
    						var loginData = {
    							"custId" : 	id,
    							"rpin" : encryPwd,
    							"sessionId" : sessionId
    						};
    						SGService.loginVerifyService(true,loginData,function(data){
    							SGLoginStore["NRIC"] = id;
    							SGLoginStore["otpTxtPhone"] = data.data.otpTxtPhone;
    							SGLoginStore["otpTokenUUID"] = data.data.otpTokenUUID;
    							SGUtil.toHashUrl("#/loginotp");
    						},function(data){
    							SGUtil.alert(data.message);
    							return;
    						})
    					},function(data){
    						SGUtil.alert(data.message);
    					});
        		 });
    		 } else if(json.state == "2") {
    			 SGUtil.alert("Verify fingerprint failed, switching to ID & password login.",function(){
    					SGUtil.toPage("login.html#/index");  
    				});
    		 } else if(json.state == "0") {
    			 SGUtil.alert("Fingerprint is invalid now, switching to ID & password login.",function(){
    					SGUtil.toPage("login.html#/index");
    				});
    		 }
    	 });
    	 
    	 
    	 
    	 
     }
     
     function askEmail() {
    	 $("button[name='emailOKBtn']").off("click").on("click",function(){
    		 	var signUpEmail = $("input[name='sigupEmail']").val();
    		 	if(signUpEmail == "") {
    		 		SGUtil.alert("Email adress should be not null");
    		 		return ;
    		 	}
    		 	if(!SGUtil.isEmail(signUpEmail)) {
					SGUtil.alert("Email address is not valid");
					return ;
				}
    		 	var sendMailData = {
						"custId" : SGUtil.getStorage("custId"),
						"emailAddress" : signUpEmail,
						"emailType" : "FL",
						"password" : ""
				};
				SGService.sendMailService(true,sendMailData,function(data){
					SGUtil.toPage("landing.html#/policyList");
				},function(data){
					SGUtil.alert(data.message);
					SGUtil.toPage("landing.html#/policyList");
					return;
				});
    	 });
     }
     
     var routes = {
       '/index': indexShow,
       '/loginotp': loginOtpShow,
       '/fingerprintlogin' : fingerprintlogin,
       '/askemail' : askEmail
     };
     
     SGRoute.routes = routes;
     SGRoute.defaultRoute = "#/index";
     SGRoute.init();
     
     
     //SGUtil.setStorage("custId","S6568676G");
     //SGUtil.toPage("landing.html#/policyList");
     //alert(SGUtil.getStorage("custId"));
     
});