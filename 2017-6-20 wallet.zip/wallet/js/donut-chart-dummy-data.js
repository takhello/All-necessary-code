//  The examples of the single donut chart in the DLS use this dummy JSON data imported in a script tag.
// see the chart drawing code (circular-chart.js) for more information
/*
 Breakdown of data:

 chartId - the id of the element on the page that will render the graph
 chartType - should be 'pie' or 'donut'
 hideLegendOnSmall - set to true if you do not need a legend below the chart at any time
 segmentTitle - the text that is shown on rollover of a segments alongside the value
 text - (optional) - makes up the title which is shown in the middle of the donut chart.
 text.main - the main piece of text in the donut chart
 text.secondary - the second line of text in the donut chart
 graphData - the data that makes up the graph
 graphData.category - the name of the segment
 graphData.value - the value of the segment
 graphData.colour - the colour of the segment.  Colours should be picked from the graph themes in the DLS
 */
var circularChartData =
	[{
		chartId: 'donutchart',
		chartType: 'donut',
		segmentTitle: '% of total fund',
		text: {
			main: "$711.120",
			secondary: 'total growth'
		},
		graphData: [{
			category: 'Fidelity Funds Euro Aggressive Fund',
			value: 80,
			colour: '#551893'
		}, {
			category: 'Lion Global Japan Growth Fund',
			value: 20,
			colour: '#E86487'
		}]
	}];
